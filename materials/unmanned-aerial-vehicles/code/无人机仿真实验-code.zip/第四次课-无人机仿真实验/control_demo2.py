#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
优化版无人机控制任务脚本
- 改进的路径规划逻辑
- 增强的视觉检测稳定性
- 平滑的运动控制
- 更好的错误处理
"""

import math
import time
from typing import List, Optional, Tuple, Dict

import cv2
import numpy as np
import rospy
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Image
from std_msgs.msg import String
from tf.transformations import euler_from_quaternion


def _wrap_angle(rad: float) -> float:
    """将角度归一化到 (-pi, pi)。"""
    return (rad + math.pi) % (2.0 * math.pi) - math.pi


class OptimizedMissionController:
    """优化版任务控制器。"""

    # 目标位置定义（根据验收规则）
    TARGET_POSITIONS = {
        1: (6.5, 7.0, 1.72),    # 高处灰色框
        2: (3.5, 7.5, 0.72),    # 木制四层框第二层
        3: (5.0, 9.5, 1.0),     # 咖啡桌
        4: (4.0, 11.0, 1.72),   # 木制四层框第四层
        5: (1.0, 14.5, 0.2)     # 墙角
    }

    def __init__(self) -> None:
        # 状态缓存
        self._pose_xyz = [0.0, 0.0, 0.0]
        self._quat = [0.0, 0.0, 0.0, 1.0]
        self._last_bgr: Optional[np.ndarray] = None
        self._bridge = CvBridge()
        
        # 检测结果缓存
        self._detection_results: Dict[int, str] = {}
        
        # 控制参数
        self.control_rate = 30  # 提高控制频率
        self.pos_tolerance = 0.08  # 减小位置容差
        self.yaw_tolerance = 0.03  # 减小偏航容差
        self.max_speed = 8.0  # 降低最大速度提高稳定性

        # ROS 通信
        self._vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        rospy.Subscriber("/ground_truth/state", Odometry, self._on_odom)
        rospy.Subscriber("/front_cam/camera/image", Image, self._on_image)
        self._result_pub = rospy.Publisher("/tello/target_result", String, queue_size=10)

    def _on_odom(self, msg: Odometry) -> None:
        """里程计回调，更新位姿信息。"""
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self._pose_xyz = [p.x, p.y, p.z]
        self._quat = [q.x, q.y, q.z, q.w]

    def _on_image(self, msg: Image) -> None:
        """图像回调，更新最新图像。"""
        try:
            self._last_bgr = self._bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except CvBridgeError as e:
            rospy.logwarn(f"CvBridgeError: {e}")

    def _current_yaw(self) -> float:
        """获取当前偏航角。"""
        _, _, yaw = euler_from_quaternion(self._quat)
        return yaw

    def stop(self) -> None:
        """停止无人机。"""
        self._vel_pub.publish(Twist())

    def _smooth_control(self, error: float, max_error: float, gain: float = 1.0) -> float:
        """平滑控制函数，避免剧烈变化。"""
        # 使用饱和函数和死区
        if abs(error) < 0.02:  # 死区
            return 0.0
        normalized_error = max(min(error / max_error, 1.0), -1.0)
        return gain * normalized_error

    def goto(
        self,
        target: Tuple[float, float, float],
        yaw_target: Optional[float] = None,
        pos_tol: Optional[float] = None,
        timeout: float = 30.0,
    ) -> bool:
        """优化版移动控制，支持超时检测。"""
        if pos_tol is None:
            pos_tol = self.pos_tolerance
            
        tx, ty, tz = target
        yaw_tol = self.yaw_tolerance if yaw_target is not None else None
        rate = rospy.Rate(self.control_rate)
        start_time = time.time()

        while not rospy.is_shutdown():
            # 超时检查
            if time.time() - start_time > timeout:
                rospy.logwarn(f"Timeout reached for target {target}")
                self.stop()
                return False

            cx, cy, cz = self._pose_xyz
            dx, dy, dz = tx - cx, ty - cy, tz - cz

            yaw = self._current_yaw()
            # 世界坐标误差 -> 机体系误差
            lx = dx * math.cos(yaw) + dy * math.sin(yaw)
            ly = -dx * math.sin(yaw) + dy * math.cos(yaw)

            cmd = Twist()
            # 使用平滑控制
            cmd.linear.x = self._smooth_control(lx, 2.0, 2.5)
            cmd.linear.y = self._smooth_control(ly, 2.0, 2.5)
            cmd.linear.z = self._smooth_control(dz, 1.0, 3.0)

            d_yaw = 0.0
            if yaw_target is not None:
                d_yaw = _wrap_angle(yaw_target - yaw)
                cmd.angular.z = self._smooth_control(d_yaw, 1.0, 2.0)

            # 限幅
            vmax = self.max_speed
            cmd.linear.x = max(min(cmd.linear.x, vmax), -vmax)
            cmd.linear.y = max(min(cmd.linear.y, vmax), -vmax)
            cmd.linear.z = max(min(cmd.linear.z, vmax), -vmax)
            cmd.angular.z = max(min(cmd.angular.z, vmax), -vmax)

            # 到达判定
            reached_pos = (abs(dx) < pos_tol and abs(dy) < pos_tol and abs(dz) < pos_tol)
            reached_yaw = (yaw_target is None) or (abs(d_yaw) < yaw_tol)

            if reached_pos and reached_yaw:
                rospy.loginfo(f"Reached target: {target}")
                self.stop()
                rospy.sleep(0.5)  # 稳定时间
                return True

            self._vel_pub.publish(cmd)
            rate.sleep()

        self.stop()
        return False

    def _detect_with_retry(self, detection_func, retries: int = 3, delay: float = 0.5):
        """带重试的检测函数。"""
        for i in range(retries):
            result = detection_func()
            if result is not None:
                return result
            rospy.loginfo(f"Detection failed, retry {i+1}/{retries}")
            rospy.sleep(delay)
        return None

    def detect_firepoint(self) -> Optional[bool]:
        """优化火点检测，增加图像预处理。"""
        if self._last_bgr is None:
            return None

        # 图像预处理
        img = cv2.medianBlur(self._last_bgr, 5)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        # 红色火点双区间阈值
        lower1 = np.array([0, 150, 100], dtype=np.uint8)  # 提高饱和度阈值
        upper1 = np.array([5, 255, 255], dtype=np.uint8)
        lower2 = np.array([175, 150, 100], dtype=np.uint8)
        upper2 = np.array([180, 255, 255], dtype=np.uint8)

        mask1 = cv2.inRange(hsv, lower1, upper1)
        mask2 = cv2.inRange(hsv, lower2, upper2)
        red_mask = cv2.bitwise_or(mask1, mask2)
        
        # 形态学操作去除噪声
        kernel = np.ones((3, 3), np.uint8)
        red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)

        fire_detected = cv2.countNonZero(red_mask) > 800  # 调整阈值
        rospy.loginfo(f"Fire detection: {'FOUND' if fire_detected else 'NOT FOUND'}")
        return fire_detected

    def detect_color(self) -> Optional[str]:
        """优化颜色检测，改进阈值和稳定性。"""
        if self._last_bgr is None:
            return None

        # 图像预处理
        img = cv2.GaussianBlur(self._last_bgr, (5, 5), 0)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # 颜色阈值（优化版）
        color_masks = {
            'r': [  # 红色
                (np.array([0, 120, 70]), np.array([10, 255, 255])),
                (np.array([170, 120, 70]), np.array([180, 255, 255]))
            ],
            'b': [(np.array([100, 150, 50]), np.array([130, 255, 255]))],  # 蓝色
            'y': [(np.array([20, 100, 100]), np.array([30, 255, 255]))]   # 黄色
        }

        max_count = 0
        detected_color = 'e'
        
        for color, ranges in color_masks.items():
            total_mask = None
            for lower, upper in ranges:
                mask = cv2.inRange(hsv, lower, upper)
                if total_mask is None:
                    total_mask = mask
                else:
                    total_mask = cv2.bitwise_or(total_mask, mask)
            
            if total_mask is not None:
                count = cv2.countNonZero(total_mask)
                if count > max_count and count > 1500:  # 动态阈值
                    max_count = count
                    detected_color = color

        rospy.loginfo(f"Color detected: {detected_color} (count: {max_count})")
        return detected_color

    def search_firepoint_and_enter(self) -> bool:
        """优化火点搜索和进入逻辑。"""
        fire_windows = [
            (1.75, 2.0, 2.0),   # 左侧窗户
            (4.25, 2.0, 2.0),   # 中间窗户  
            (6.75, 2.0, 2.0)    # 右侧窗户
        ]

        for i, window_pos in enumerate(fire_windows):
            rospy.loginfo(f"Searching firepoint at window {i+1}")
            if not self.goto(window_pos, timeout=15.0):
                continue
                
            # 多次检测提高准确性
            fire_detected = self._detect_with_retry(self.detect_firepoint)
            
            if fire_detected:
                rospy.loginfo(f"Fire found at window {i+1}, entering...")
                # 进入楼内
                entry_low = (window_pos[0], 2.0, 1.0)
                entry_inside = (window_pos[0], 4.0, 1.0)
                
                if self.goto(entry_low) and self.goto(entry_inside):
                    return True
                else:
                    rospy.logwarn("Failed to enter through fire window")
                    return False

        rospy.logwarn("No firepoint found in any window!")
        return False

    def detect_target_color(self, target_id: int, optimal_yaw: Optional[float] = None) -> bool:
        """在指定目标位置检测颜色。"""
        position = self.TARGET_POSITIONS[target_id]
        rospy.loginfo(f"Detecting color at target {target_id}: {position}")
        
        if not self.goto(position, yaw_target=optimal_yaw, timeout=20.0):
            rospy.logwarn(f"Failed to reach target {target_id}")
            return False

        # 稳定姿态
        rospy.sleep(1.0)
        
        # 多次检测取最优结果
        color_result = self._detect_with_retry(self.detect_color, retries=5, delay=0.3)
        
        if color_result is not None:
            self._detection_results[target_id] = color_result
            rospy.loginfo(f"Target {target_id} color: {color_result}")
            return True
        else:
            rospy.logwarn(f"Failed to detect color at target {target_id}")
            self._detection_results[target_id] = 'e'  # 默认空
            return True

    def run_optimized_mission(self) -> None:
        """优化版任务执行流程。"""
        # 等待连接
        while self._vel_pub.get_num_connections() == 0 and not rospy.is_shutdown():
            rospy.loginfo("Waiting for /cmd_vel connections...")
            rospy.sleep(1.0)
        rospy.loginfo("Connected to /cmd_vel")

        self.stop()
        rospy.sleep(2.0)  # 初始稳定时间

        try:
            # 1. 起飞和初始定位
            rospy.loginfo("=== Phase 1: Takeoff and Initial Positioning ===")
            if not self.goto((1.0, 1.0, 1.5), yaw_target=1.57):  # 较低高度起飞
                rospy.logerr("Failed initial takeoff!")
                return

            # 2. 搜索火点并进入楼内
            rospy.loginfo("=== Phase 2: Firepoint Search and Entry ===")
            if not self.search_firepoint_and_enter():
                rospy.logerr("Failed firepoint search and entry!")
                return

            # 3. 楼内目标检测（优化顺序）
            rospy.loginfo("=== Phase 3: Indoor Target Detection ===")
            
            # 按空间顺序检测，减少飞行距离
            detection_sequence = [
                (2, 0.0),    # 目标2，面向x轴正方向
                (3, 1.57),   # 目标3，面向y轴正方向  
                (1, -1.57),  # 目标1，面向y轴负方向
                (4, -1.57),  # 目标4，面向y轴负方向
                (5, 3.14)    # 目标5，面向x轴负方向
            ]

            for target_id, optimal_yaw in detection_sequence:
                if not self.detect_target_color(target_id, optimal_yaw):
                    rospy.logwarn(f"Skipping target {target_id} due to detection failure")

            # 4. 发布结果
            rospy.loginfo("=== Phase 4: Result Publication ===")
            result_str = ''.join([self._detection_results.get(i, 'e') for i in range(1, 6)])
            self._result_pub.publish(String(data=result_str))
            rospy.loginfo(f"Published final result: {result_str}")

            # 5. 飞往终点并降落
            rospy.loginfo("=== Phase 5: Landing ===")
            self.goto((5.0, 12.5, 1.0))
            self.goto((7.0, 14.5, 1.0))
            self.goto((7.0, 14.5, 0.15))
            
            rospy.loginfo("Mission completed successfully!")

        except Exception as e:
            rospy.logerr(f"Mission failed with exception: {e}")
            # 紧急情况下仍尝试发布已有结果
            result_str = ''.join([self._detection_results.get(i, 'e') for i in range(1, 6)])
            self._result_pub.publish(String(data=result_str))
            rospy.loginfo(f"Published partial result: {result_str}")


def main() -> None:
    rospy.init_node("optimized_control_demo")
    controller = OptimizedMissionController()
    
    try:
        controller.run_optimized_mission()
    except rospy.ROSInterruptException:
        rospy.loginfo("ROS interrupted")
    except Exception as e:
        rospy.logerr(f"Unexpected error: {e}")
    finally:
        controller.stop()


if __name__ == "__main__":
    main()