#!/usr/bin/env python3

import rospy
from gazebo_msgs.srv import SpawnModel,DeleteModel
from geometry_msgs.msg import Pose
import tf.transformations as tf
import os

import random
from tools import getPackagePath

sphere_red = """
    <sdf version="1.5">
      <model name="sphere_r">
        <link name="sphere_r_link">
          <collision name="collision">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
          </collision>
          <visual name="visual">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
            <material>
            <script>
              <name>Gazebo/Red</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
          </visual>
        </link>
      </model>
    </sdf>
    """

sphere_yellow = """
    <sdf version="1.5">
      <model name="sphere_y">
        <link name="sphere_y_link">
          <collision name="collision">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
          </collision>
          <visual name="visual">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
            <material>
            <script>
              <name>Gazebo/Yellow</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
          </visual>
        </link>
      </model>
    </sdf>
    """

sphere_blue = """
    <sdf version="1.5">
      <model name="sphere_b">
        <link name="sphere_b_link">
          <collision name="collision">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
          </collision>
          <visual name="visual">
            <geometry>
              <sphere>
                <radius>0.2</radius>
              </sphere>
            </geometry>
            <material>
            <script>
              <name>Gazebo/SkyBlue</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
          </visual>
        </link>
      </model>
    </sdf>
    """

sphere_poses = [
    [6.5,7,1.72],
    [3.5,7.5,0.72],
    [5,9.5,1],
    [4,11,1.72],
    [1,14.5,0.2]
]


sphere_sdfs = [
    sphere_red,
    sphere_yellow,
    sphere_blue
]

cylinder_sdf = """
  <sdf version="1.5">
    <model name="cylinder_1">
      
      <static>true</static>
      <link name="cylinder1_link">
        <visual name="visual">
          <geometry>
            <cylinder>
              <radius>0.1 </radius>
              <length>0.002 </length>
            </cylinder>
          </geometry>
          <material>
            <script>
              <name>Gazebo/Red</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
      </link>
    </model>
  </sdf>
  """

invisible_wall_sdf = """
  <sdf version="1.5">
  <model name="invisible_wall">
      <static>true</static>
      <link name="link">
        <collision name="collision">
          <geometry>
            <box>
              <size>1.5 0.1 1.0 </size>
            </box>
          </geometry>
        </collision>
        <visual name="visual">
          <geometry>
            <box>
              <size>1.5 0.1 1.0 </size>
            </box>
          </geometry>
          <material>
            <script>
              <name>Gazebo/Grey</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
          <transparency>1.0</transparency>
        </visual>
      </link>
    </model>
    </sdf>s
  """

cylinder_xs = [1.75, 4.25, 6.75]

def spawn_sphere(spawn_model, random_sphere_pose_ids, random_sphere_sdf_ids):
    for i in range(3):
      sphere_name = "sphere"+str(i+1)
    #   delete_model(sphere_name)
      sphere_sdf_id = random_sphere_sdf_ids[i]
      sphere_pose_id = random_sphere_pose_ids[i]
      sphere_sdf = sphere_sdfs[sphere_sdf_id]
      sphere_pose = Pose()
      sphere_pose.position.x = sphere_poses[sphere_pose_id][0]
      sphere_pose.position.y = sphere_poses[sphere_pose_id][1]
      sphere_pose.position.z = sphere_poses[sphere_pose_id][2]

      spawn_model(sphere_name, sphere_sdf, sphere_pose)

def spawn_cylinder(spawn_model, random_cylinder_pose_id):
    # delete_model("cylinder1")
    cylinder_pose = Pose()
    cylinder_pose.position.x = cylinder_xs[random_cylinder_pose_id]
    cylinder_pose.position.y = 2.9
    cylinder_pose.position.z = 1.75
    quaternion = tf.quaternion_from_euler(1.57079632679, 0, 0)
    cylinder_pose.orientation.x = quaternion[0]
    cylinder_pose.orientation.y = quaternion[1]
    cylinder_pose.orientation.z = quaternion[2]
    cylinder_pose.orientation.w = quaternion[3]

    spawn_model("cylinder1", cylinder_sdf, cylinder_pose)

def spawn_invisible_wall(spawn_model, random_cylinder_pose_id):
    for i in range(3):
      invisible_wall_name = "invisible_wall"+str(i+1)
    #   delete_model(invisible_wall_name)
      if i == random_cylinder_pose_id:
        continue
      invisible_wall_pose = Pose()
      invisible_wall_pose.position.x = cylinder_xs[i]
      invisible_wall_pose.position.y = 2.95
      invisible_wall_pose.position.z = 1.0

      spawn_model(invisible_wall_name, invisible_wall_sdf, invisible_wall_pose)

def spawn_model(name, sdf, pose):
    # 创建模型
    rospy.wait_for_service('/gazebo/spawn_sdf_model')
    try:
        spawn_model_proxy = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        spawn_model_proxy(name, sdf, "", pose, "world")
        rospy.loginfo("{} spawned successfully.".format(name))
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

def delete_model(name):
    # 删除模型
    rospy.wait_for_service('/gazebo/delete_model')
    try:
        remove_model_proxy = rospy.ServiceProxy('/gazebo/delete_model', DeleteModel)
        remove_model_proxy(name)
        rospy.loginfo("Delete model named: {}".format(name))
    except rospy.ServiceException as e:
        rospy.logerr("Service call delete_model failed: %e" % e)

def random_spawn():
    rospy.init_node('random_env_node')
    clean_env()
    random_sphere_pose_ids = random.sample(range(5), 3)
    random_sphere_sdf_ids = [0,1,2]
    random.shuffle(random_sphere_sdf_ids)
    random_cylinder_pose_id = random.randint(0,2)
    # print(random_sphere_colors)
    rospy.loginfo("Sphere pose ids: {}, color ids: {}".format(random_sphere_pose_ids, random_sphere_sdf_ids))
    rospy.loginfo("Cylinder pose id: {}".format(random_cylinder_pose_id))

    spawn_sphere(spawn_model, random_sphere_pose_ids, random_sphere_sdf_ids)
    spawn_cylinder(spawn_model, random_cylinder_pose_id)
    spawn_invisible_wall(spawn_model, random_cylinder_pose_id)
    # change config
    Color_dict = {0:'r', 1:'y', 2:'b'}
    ros_path_ = getPackagePath('hector_quadrotor_demo')
    yaml_path = ros_path_ + '/config/target.yaml'
    target_groundtruth = list('eeeee')
    for i in range(3):
      target_groundtruth[random_sphere_pose_ids[i]] = Color_dict[random_sphere_sdf_ids[i]]
    target_groundtruth = ''.join(target_groundtruth)
    print('\n',target_groundtruth)
    
    with open(yaml_path, 'w') as f:
    	f.write('target_groundtruth_: '+target_groundtruth)

def clean_env():
    for i in range(3):
      invisible_wall_name = "invisible_wall"+str(i+1)
      delete_model(invisible_wall_name)
    for i in range(3):
      sphere_name = "sphere"+str(i+1)
      delete_model(sphere_name)
    delete_model("cylinder1")

if __name__ == "__main__":
    random_spawn()
