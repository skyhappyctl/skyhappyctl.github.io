# build
$ sudo apt-get install ros-noetic-hector-pose-estimation ros-noetic-hector-sensors-description ros-noetic-message-to-tf
$ catkin_make
$ source devel/setup.bash

# run
roslaunch hector_quadrotor_demo start_nics_world.launch # 加载gazebo环境
roslaunch hector_quadrotor_demo put_robot_in_world.launch   # 放置无人机
rosrun teleop_twist_keyboard teleop_twist_keyboard.py   # 键盘控制无人机
rosrun hector_quadrotor_demo control_demo.py # 指令控制无人机demo, 按照时间控制无人机飞行， 具体指令可以查看hector_quadrotor/hector_quadrotor_demo/scripts/control_demo.py文件
rosrun hector_quadrotor_demo set_model_state.py quadrotor 1 1 1.57	# 将无人机放置在起始点。其中参数"quadrotor"为无人机模型的名字，"1 1 1.57"表示放置在起始点（1，1），yaw角为pi/2。

src/hector_gazebo/hector_gazebo_worlds/worlds/arena_1.world：此文件会在仿真任务验收规则中规定的五个位置都放上小球方便调试，同学们也可以在这个文件中修改球的颜色（sphere_*的<material>属性，颜色可以是Red，Yellow或者SkyBlue）来模拟不同情况。

# test

roslaunch hector_quadrotor_demo pre_round.launch	# 加载初赛环境
roslaunch hector_quadrotor_demo put_robot_in_world.launch   # 放置无人机
rosrun hector_quadrotor_demo random_env.py  # 随机一个环境，包括红点和小球的位置
rosrun hector_quadrotor_demo judge.py  # 启动裁判机
rosrun hector_quadrotor_demo control_demo2.py # 可以在里面写自己的控制程序
