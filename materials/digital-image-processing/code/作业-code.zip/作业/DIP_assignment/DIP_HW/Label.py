import json
import time
import os
from tqdm import tqdm
from ultralytics import YOLO


# COCO 官方80类的原始ID（非连续列表）
COCO_OFFICIAL_IDS = [
 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20,
 21, 22, 23, 24, 25, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,
 59, 60, 61, 62, 63, 64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79,
 80, 81, 82, 84, 85, 86, 87, 88, 89, 90
]

# 配置参数（根据实际情况修改）
annotations_json_path = "C:/Users/local-user/Desktop/学校的破事/作业/数字图像处理/DIP_assignment/annotations.json" # COCO标注文件路径
output_path = "C:/Users/local-user/Desktop/DIP_HW" # 输出目录
image_path = "C:/Users/local-user/Desktop/DIP_HW/images" # 图片目录
val_path = os.path.join(output_path, 'image.txt')


# 创建映射字典：{原始COCO_ID : 连续YOLO_ID (0-79)}
COCO_TO_YOLO_ID = {coco_id: yolo_id for yolo_id, coco_id in enumerate(COCO_OFFICIAL_IDS)}

def coco2yolo(annotation_json_path, output_path, image_patj):
 # 创建输出目录
 labels_dir = os.path.join(output_path, 'Label')
 os.makedirs(labels_dir, exist_ok=True)


# 加载COCO标注
 with open(annotations_json_path, 'r') as f:
    coco_data = json.load(f)
 image_entries = coco_data.get("images", [])

 images_info = {img['id']: img for img in coco_data['images']}
 
 # 按图像分组标注
 annotations = {}
 for ann in coco_data['annotations']:
     img_id = ann['image_id']
     if img_id not in annotations:
         annotations[img_id] = []
     annotations[img_id].append(ann)

 for img_id, img_info in tqdm(images_info.items(), desc="Processing Images"):
     # 获取图片信息
     img_name = img_info['file_name']
     img_width = img_info['width']
     img_height = img_info['height']
 
     # 验证图片存在
     img_path = os.path.join(image_path, img_name)
     if not os.path.exists(img_path):
         print(f"Warning: Image {img_name} not found, skipping")
         continue
     
     with open(val_path, 'w') as f:
         for entry in image_entries:
            name = entry.get("file_name")
            f.write(f"C:/Users/local-user/Desktop/DIP_HW/images/{name}\n")
     f.close

     # 创建对应的标签文件
     label_name = os.path.splitext(img_name)[0] + '.txt'
     label_path = os.path.join(labels_dir, label_name)
 
     # 写入YOLO格式标注
     with open(label_path, 'w') as f:
         if img_id in annotations:
             for ann in annotations[img_id]:
                 # 检查是否为COCO 80类
                 coco_id = ann['category_id']
                 if coco_id not in COCO_TO_YOLO_ID:
                     continue # 跳过非COCO80类的标注

                 # 获取连续YOLO ID
                 class_id = COCO_TO_YOLO_ID[coco_id]
     
                 # 转换边界框格式,归一化
                 x, y, w, h = ann['bbox']
                 x_center = (x + w / 2) / img_width
                 y_center = (y + h / 2) / img_height
                 w_norm = w / img_width
                 h_norm = h / img_height
     
                 # 写入：class_id x_center y_center width height
                 f.write(f"{class_id} {x_center:.6f} {y_center:.6f} {w_norm:.6f} {h_norm:.6f}\n")

if __name__ == "__main__":
    # 执行转换
    coco2yolo(annotations_json_path, output_path, image_path)
    print(f"Conversion complete! Labels saved to: {os.path.join(output_path, 'Label')}")



