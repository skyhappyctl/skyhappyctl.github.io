import json
import os
import shutil
from pathlib import Path
import numpy as np
import cv2
from tqdm import tqdm
import argparse
import yaml


def parse_args():
    parser = argparse.ArgumentParser(description='YOLOv5检测结果可视化工具')
    parser.add_argument('--img-dir', type=str, default='C:/Users/local-user/Desktop/DIP_HW/exp3', help='预测输出图片目录')
    parser.add_argument('--label-dir', type=str, default='C:/Users/local-user/Desktop/DIP_HW/Label', help='真实标签目录')
    parser.add_argument('--output-dir', type=str, default='C:/Users/local-user/Desktop/DIP_HW/visual_results', help='可视化结果输出目录')
    parser.add_argument('--yaml-path', type=str, default='C:/Users/local-user/Desktop/DIP_HW/coco_test.yaml', help='数据集配置文件路径')
    parser.add_argument('--gt-color', type=tuple, default=(255, 255, 255), help='真实框颜色（BGR）')
    return parser.parse_args()


def load_class_names(yaml_path):
    """从YAML文件加载类别名称"""
    with open(yaml_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data['names']

def draw_boxes(image, label_path, color, class_names, is_gt=True):
    h, w = image.shape[:2]
    with open(label_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
            
            try:
                if is_gt:
                    cls_id, xc, yc, bw, bh = map(float, parts)
                    conf = None
                else:
                    cls_id, xc, yc, bw, bh, conf = map(float, parts)
            except Exception as e:
                print(f"错误：标签文件 {label_path} 中存在格式错误的行：{line.strip()}，错误信息：{e}")
                continue

            # 坐标转换
            x1 = int((xc - bw/2) * w)
            y1 = int((yc - bh/2) * h)
            x2 = int((xc + bw/2) * w)
            y2 = int((yc + bh/2) * h)
            # 绘制边界框
            cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)

            if not is_gt:
                cls_id = int(cls_id)
                if cls_id >= len(class_names):
                    print(f"警告：预测类别ID {cls_id} 超出类别列表范围（共{len(class_names)}类）")
                    continue
                label = f"{class_names[cls_id]} {conf:.2f}"
                (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                cv2.rectangle(image, (x1, y1-20), (x1+tw, y1), color, -1)
                cv2.putText(image, label, (x1, y1-5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
    
    return image

def main(args):
    os.makedirs(args.output_dir, exist_ok=True)
    class_names = load_class_names(args.yaml_path)
    processed = 0
    for img_name in os.listdir(args.img_dir):
        if not img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue

        base_name = os.path.splitext(img_name)[0]
        img_path = os.path.join(args.img_dir, img_name)
        gt_label_path = os.path.join(args.label_dir, f"{base_name}.txt")
        pred_label_path = os.path.join(args.pred_dir, f"{base_name}.txt")

        print(f"\n处理图片：{img_name}")
        print(f"真实标签路径：{gt_label_path}")
        print(f"预测标签路径：{pred_label_path}")

        image = cv2.imread(img_path)
        if image is None:
            print(f"错误：无法读取图片 {img_path}，请检查文件格式或路径。")
            continue

        image = draw_boxes(image, gt_label_path, args.gt_color, class_names, is_gt=True)

        output_path = os.path.join(args.output_dir, img_name)
        cv2.imwrite(output_path, image)
        processed += 1
        print(f"成功保存：{output_path}")


if __name__ == "__main__":
    args = parse_args()
    main(args)

