/* Hamming series: 3001 values on x = i/10, absolute target 1e-10.
   C99, double precision, no external libraries beyond the C math library. */
#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#if defined(_WIN32)
#include <windows.h>
#endif

#define LAST_INDEX 3000
#define N_BASE 20
#define EM_ORDER 4
#define FAST_REPEATS 10000
#if defined(_MSC_VER)
#define NOINLINE __declspec(noinline)
#elif defined(__GNUC__) || defined(__clang__)
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif

static volatile double benchmark_sink = 0.0;
static volatile double direct_benchmark_x = 0.0;

static double now_seconds(void)
{
#if defined(_WIN32)
    LARGE_INTEGER ticks, frequency;
    QueryPerformanceCounter(&ticks);
    QueryPerformanceFrequency(&frequency);
    return (double)ticks.QuadPart/(double)frequency.QuadPart;
#else
    return (double)clock()/(double)CLOCKS_PER_SEC;
#endif
}

/* First N terms, followed by an Euler-Maclaurin tail. */
static double base_value(double x)
{
    const double B[EM_ORDER] = {1.0/6.0, -1.0/30.0,
                               1.0/42.0, -1.0/30.0};
    const double n = (double)N_BASE;
    const double l = log1p(x / n);
    double sum = 0.0, correction = 0.0;
    int k, r;
    for (k = 1; k <= N_BASE; ++k)
        sum += 1.0 / ((double)k * ((double)k + x));
    for (r = 1; r <= EM_ORDER; ++r) {
        double diff = pow(n, -2.0*r) * (-expm1(-2.0*r*l));
        correction += B[r-1] * diff / (2.0*r*x);
    }
    return sum + log1p(x/n)/x - 1.0/(2.0*n*(n+x))
               + correction;
}

/* Ten residue classes: exact integer indices avoid drifting x += 0.1. */
static NOINLINE void compute_all(double values[LAST_INDEX + 1])
{
    const double pi = acos(-1.0);
    int r, i;
    values[0] = pi*pi/6.0;
    for (r = 1; r <= 10; ++r) {
        values[r] = base_value((double)r/10.0);
        for (i = r+10; i <= LAST_INDEX; i += 10)
            values[i] = ((double)(i-10)/(double)i)*values[i-10]
                      + 100.0/((double)i*(double)i);
    }
}

static NOINLINE double direct_sum(double x, int n)
{
    double sum = 0.0;
    int k;
    for (k = 1; k <= n; ++k)
        sum += 1.0/((double)k*((double)k+x));
    return sum;
}

int main(void)
{
    double values[LAST_INDEX + 1];
    const int selected[] = {0,1,2,5,10,20,50,100,200,500,
                            1000,1500,2000,2500,3000};
    const int ns[] = {1000,10000,100000,1000000,100000000,200000000};
    FILE *txt, *csv, *bench;
    double begin, end;
    double seconds;
    int i, j, repeat;
    compute_all(values);
    for (i = 0; i <= LAST_INDEX; ++i) {
        if (!isfinite(values[i]) || values[i] <= 0.0 ||
            (i > 0 && values[i] >= values[i-1])) {
            fprintf(stderr, "Invalid or nondecreasing result at index %d\n", i);
            return EXIT_FAILURE;
        }
    }
    txt = fopen("hamming_results.txt", "w");
    csv = fopen("hamming_results.csv", "w");
    bench = fopen("benchmark.txt", "w");
    if (!txt || !csv || !bench) {
        fprintf(stderr, "Cannot create output files.\n");
        if (txt) fclose(txt);
        if (csv) fclose(csv);
        if (bench) fclose(bench);
        return EXIT_FAILURE;
    }
    fprintf(csv, "x,psi_12dp,psi_full_precision\n");
    for (i = 0; i <= LAST_INDEX; ++i) {
        fprintf(txt, "%6.2f  %.12f\n", (double)i/10.0, values[i]);
        fprintf(csv, "%.1f,%.12f,%.17g\n", (double)i/10.0,
                values[i], values[i]);
    }
    printf("Selected results (all 3001 values saved in TXT and CSV):\n");
    for (j = 0; j < (int)(sizeof(selected)/sizeof(selected[0])); ++j) {
        i = selected[j];
        printf("%6.2f  %.12f\n", (double)i/10.0, values[i]);
    }
    fprintf(bench, "algorithm=Euler-Maclaurin + forward recurrence\n");
#if defined(_WIN32)
    fprintf(bench, "timer=Windows QueryPerformanceCounter (elapsed time)\n");
#else
    fprintf(bench, "timer=C clock (CPU time)\n");
#endif
    fprintf(bench, "N=%d\nEM_order=%d\nbase_values=10\n", N_BASE, EM_ORDER);
    fprintf(bench, "base_term_evaluations=%d\nrecurrence_steps=2990\n",
            10*N_BASE);
    fprintf(bench, "truncation_bound=%.17g\n", 1.0/(30.0*pow((double)N_BASE,9.0)));
    begin = now_seconds();
    for (repeat = 0; repeat < FAST_REPEATS; ++repeat) {
        compute_all(values);
        benchmark_sink += values[repeat % (LAST_INDEX+1)];
    }
    end = now_seconds();
    seconds = end-begin;
    fprintf(bench, "fast_repeats=%d\nfast_batch_seconds=%.9f\n",
            FAST_REPEATS, seconds);
    fprintf(bench, "fast_seconds_per_3001_values=%.12g\n",
            seconds/(double)FAST_REPEATS);
    fprintf(bench, "direct_x=0\nN,sum_17digits,repeats,total_seconds,seconds_per_value\n");
    for (j = 0; j < (int)(sizeof(ns)/sizeof(ns[0])); ++j) {
        int n = ns[j];
        int repetitions = 100000000/n;
        if (repetitions < 1) repetitions = 1;
        double s = direct_sum(0.0, n);
        begin = now_seconds();
        for (repeat = 0; repeat < repetitions; ++repeat)
            /* Volatile input prevents the optimizer hoisting a pure call. */
            benchmark_sink += direct_sum(direct_benchmark_x, n);
        end = now_seconds();
        seconds = end-begin;
        fprintf(bench, "%d,%.17g,%d,%.9f,%.12g\n", n,s,repetitions,
                seconds,seconds/(double)repetitions);
    }
    i = (fclose(txt) != 0);
    i |= (fclose(csv) != 0);
    i |= (fclose(bench) != 0);
    if (i) {
        fprintf(stderr, "Output write failure.\n");
        return EXIT_FAILURE;
    }
    printf("Checks passed: finite, positive and strictly decreasing.\n");
    printf("Benchmark saved in benchmark.txt (excludes file output).\n");
    return EXIT_SUCCESS;
}
