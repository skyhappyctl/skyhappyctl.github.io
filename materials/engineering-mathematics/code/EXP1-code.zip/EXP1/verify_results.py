"""Independent 80-decimal-digit validation of the compiled C results.
Run from EXP1: python verify_results.py (requires mpmath).
"""
from pathlib import Path
import csv
import json
import mpmath as mp

ROOT = Path(__file__).resolve().parent
mp.mp.dps = 80

def reference(x):
    return mp.zeta(2) if x == 0 else (mp.digamma(1+x) + mp.euler) / x

def em_high_precision(x):
    n = mp.mpf(20)
    total = mp.fsum(1/(k*(k+x)) for k in range(1,21))
    tail = mp.log1p(x/n)/x - 1/(2*n*(n+x))
    for r in range(1,5):
        tail += mp.bernoulli(2*r)/(2*r*x)*(n**(-2*r)-(n+x)**(-2*r))
    return total+tail

rows = list(csv.DictReader((ROOT/'hamming_results.csv').open(encoding='utf-8')))
assert len(rows) == 3001
assert len((ROOT/'hamming_results.txt').read_text().splitlines()) == 3001
max_internal = (mp.mpf(0), '')
max_printed = (mp.mpf(0), '')
validation = []
previous = mp.inf
for i,row in enumerate(rows):
    x = mp.mpf(i)/10
    assert mp.mpf(row['x']) == x
    actual = mp.mpf(float(row['psi_full_precision']))
    printed = mp.mpf(row['psi_12dp'])
    ref = reference(x)
    e = abs(actual-ref)
    ep = abs(printed-ref)
    assert e < mp.mpf('1e-10')
    assert ep < mp.mpf('1e-10')
    assert 0 < actual < previous
    previous = actual
    if e > max_internal[0]: max_internal = (e,row['x'])
    if ep > max_printed[0]: max_printed = (ep,row['x'])
    validation.append([row['x'],row['psi_full_precision'],mp.nstr(ref,50),
                       mp.nstr(e,16),mp.nstr(ep,16)])

base_errors = []
for r in range(1,11):
    x = mp.mpf(r)/10
    ref = reference(x)
    em = em_high_precision(x)
    actual = mp.mpf(float(rows[r]['psi_full_precision']))
    base_errors.append({'x':str(x),'exact_em_truncation':mp.nstr(abs(em-ref),18),
                        'c_rounding_vs_em':mp.nstr(abs(actual-em),18)})

benchmark_lines = (ROOT/'benchmark.txt').read_text().splitlines()
bench = {}
for line in benchmark_lines:
    if '=' in line:
        k,v = line.split('=',1)
        bench[k] = v
start = benchmark_lines.index('N,sum_17digits,repeats,total_seconds,seconds_per_value')+1
direct = []
for line in benchmark_lines[start:]:
    n,s,reps,total,per = line.split(',')
    nn = mp.mpf(n)
    exact_tail = mp.polygamma(1,nn+1)
    measured = mp.mpf(float(s))
    exact_partial = mp.zeta(2)-exact_tail
    direct.append({'N':int(n),'sum':s,'absolute_error':mp.nstr(abs(measured-mp.zeta(2)),18),
                   'exact_tail':mp.nstr(exact_tail,18),
                   'rounding_error':mp.nstr(abs(measured-exact_partial),18),
                   'seconds_per_value':per,'repetitions':int(reps)})

summary = {
    'reference_method':'mpmath digamma and Euler constant (x>0); zeta(2) (x=0)',
    'reference_decimal_digits':80,
    'grid_points':len(rows),
    'max_internal_absolute_error':mp.nstr(max_internal[0],20),
    'max_internal_error_at_x':max_internal[1],
    'max_12dp_output_absolute_error':mp.nstr(max_printed[0],20),
    'max_output_error_at_x':max_printed[1],
    'all_values_finite_positive_strictly_decreasing':True,
    'all_internal_and_printed_values_below_1e-10':True,
    'theoretical_base_truncation_bound':mp.nstr(mp.mpf(1)/(30*mp.mpf(20)**9),20),
    'max_exact_base_em_truncation_error':max(base_errors,key=lambda v:mp.mpf(v['exact_em_truncation'])),
    'base_validation':base_errors,
    'benchmark':bench,
    'direct_sum_validation':direct,
    'special_values':{rows[i]['x']:rows[i]['psi_12dp'] for i in [0,1,10,20,3000]},
}
record = ROOT/'验证记录'
record.mkdir(exist_ok=True)
with (record/'逐点误差校验.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f)
    w.writerow(['x','C_double','reference_50digits','internal_absolute_error','printed_absolute_error'])
    w.writerows(validation)
(record/'validation_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
