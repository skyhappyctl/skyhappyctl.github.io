% 媒认第一次作业

rng(2025);% 设置随机种子以确保结果可重复
N=50;%每个类别的样本数

% 初始化参数
w_opt = randn(3,1); %w_opt=[w1;w2;w0]

% 生成50对线性可分样本数据

% 正样本,满足w_opt*[psample;1]>0

count = 0;
psample = zeros(3,N);

while count < 50
    x = 10*rand()-10;
    y = 10*rand()-10;
    if(w_opt(1)*x+w_opt(2)*y+w_opt(3))>0
        count = count + 1;
        psample(:,count)=[x;y;1];
    end
end

% 负样本,满足w_opt*[nsample;1]<0
count = 0;
nsample = zeros(3,N);

while count < 50
    x = 10*rand()-10;
    y = 10*rand()-10;
    if(w_opt(1)*x+w_opt(2)*y+w_opt(3))<0
        count = count + 1;
        nsample(:,count)=[x;y;1];
    end
end

% 绘制样本分布图
figure;
hold on;
scatter(psample(1,:), psample(2,:), 'r', 'filled');
scatter(nsample(1,:), nsample(2,:), 'b', 'filled');
xlabel('x1');
ylabel('x2');
legend('正样本', '负样本');
title('样本的分布图像');
hold off;

sample = [psample,nsample];
tag = [ones(1,N), -ones(1,N)];


% 感知机训练
yita = 0.05; %learning rate
max_epochs = 100;

w_init_1 = randn(3,1);
w_train_1 = zeros(3,1);
[w_train_1,iter1,error_record1] = SGD(sample,tag,w_init_1,max_epochs,yita);

w_init_2 = zeros(3,1);
w_train_2 = zeros(3,1);
[w_train_2,iter2,error_record2] = SGD(sample,tag,w_init_2,max_epochs,yita);


% 绘制训练过程中的误分类数变化
figure;
plot(error_record1, 'r-o', 'LineWidth', 1.5);
hold on;
plot(error_record2, 'b-s', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('错分类样本个数');
legend('Initial Weights: Random', 'Initial Weights: Zero');
title('错分类样本个数 vs. Epochs');
grid on;
hold off;


% 绘制初始分隔线1对应的分类界面
figure;
x_range = linspace(min(sample(2,:)), max(sample(2,:)), 100);
if w_train_1(2) ~= 0
    y1 = (-w_train_1(3) - w_train_1(1)*x_range)/w_train_1(2);
else
    y1 = (-w_train_1(3)/w_train_1(1)) * ones(size(x_range));
end
plot(x_range, y1, 'g--', 'LineWidth', 2);
hold on;

% 绘制初始分隔线2对应的分类界面
if w_train_2(2) ~= 0
    y2 = (-w_train_2(3) - w_train_2(1)*x_range)/w_train_2(2);
else
    y2 = (-w_train_2(3)/w_train_2(1)) * ones(size(x_range));
end
plot(x_range, y2, 'y--', 'LineWidth', 2);
hold on;

scatter(psample(1,:), psample(2,:), 'r', 'filled');
scatter(nsample(1,:), nsample(2,:), 'b', 'filled');
xlabel('x1');
ylabel('x2');
title('训练感知机分类面');
legend('分类面1', '分类面2','正样本', '负样本');
hold off;

% 输出结果
disp('For random initial weights:');
fprintf('f*(x) =%.4f*x1 + %.4f*x2 + %.4f\n', w_train_1(1), w_train_1(2), w_train_1(3));
fprintf('Iterations: %d\n', iter1);

disp('For initial weights [0; 0; 0]:');
fprintf('f*(x) =  %.4f*x1 + %.4f*x2 + %.4f \n', w_train_2(1), w_train_2(2), w_train_2(3));
fprintf('Iterations: %d\n\n', iter2);




