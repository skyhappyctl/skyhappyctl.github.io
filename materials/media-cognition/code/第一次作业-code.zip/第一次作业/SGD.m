function [w,iter_num,error_record] = SGD(x,y,w_train,max_epochs,learning_rate)
%x是column major存储的
w = w_train;
N = size(x,2); %样本数量
iter_num = 0;
error_num = 0
error_record = zeros(1,max_epochs);

for epoch = 1:max_epochs
 % 打乱数据顺序以实现随机性
    shuffle_idx = randperm(N);
    x_shuffled = x(:,shuffle_idx);
    y_shuffled = y(shuffle_idx);

    for i = 1:N
        xi = x_shuffled(:,i);
        yi = y_shuffled(i);

        judge = transpose(w)*xi;

        if(yi*judge <= 0)%错误分类
            w = w + learning_rate.*yi.*xi;
            iter_num = iter_num + 1;
        end
    end

    error_num = sum(y.*(transpose(w)*x)<=0);
    error_record(epoch) = error_num;

    if error_num == 0 %提前终止
        error_record = error_record(1:epoch);
        break;
    end
end
end