import torch
import torch.nn.functional as F
#请在这里写出对比损失函数
def contrastive_loss(image_embeds, text_embeds, temperature=0.07):
    """
    image_embeds, text_embeds: [batch, embed_dim]
    """
 