import os
import csv
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as T
from transformers import BertTokenizer
import nlpaug.augmenter.word as naw

class Flickr8kDataset(Dataset):
    def __init__(self, root_dir, captions_file, tokenizer, transform=None, max_len=32, is_train=False):
        self.root_dir = root_dir
        self.transform = transform or T.Compose([
            T.Resize((224, 224)),
            T.ToTensor()
        ])
        self.tokenizer = tokenizer
        self.max_len = max_len
        self.is_train = is_train  # 标记是否为训练集
        self.pairs = self._load_pairs(captions_file)
        self.img_paths = [fname for fname, _ in self.pairs]
        self.captions  = [cap   for _, cap   in self.pairs]

        if self.is_train:
            self.text_augmenter = TextAugmenter(replace_ratio=0.2, delete_ratio=0.1)

    def _load_pairs(self, captions_file):
        pairs = []
        with open(captions_file, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) < 2:
                    continue
                image_filename = row[0].strip()
                caption = row[1].strip()
                pairs.append((image_filename, caption))
        return pairs

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        filename, caption = self.pairs[idx]
        image_path = os.path.join(self.root_dir, filename)
        image = Image.open(image_path).convert("RGB")
        #image = self.transform(image)

        # 图像变换（训练集/验证集共用）
        if self.transform is not None:
            image = self.transform(image)
        
        # 文本增强（仅训练集）
        if self.is_train:
            # 对文本进行增强（例如：每句话随机替换20%的词，删除10%的词）
            augmented_caption = self.text_augmenter.augment(caption)
            caption = augmented_caption  # 替换为增强后的文本

        caption_ids = self.tokenizer.encode(caption)

        # 使用BERT Tokenizer编码，生成input_ids和attention_mask
        encoded = self.tokenizer(
            caption,
            max_length=self.max_len,
            padding="max_length",  # 补全到max_len
            truncation=True,       # 截断过长文本
            return_attention_mask=True,
            return_tensors="pt"    # 返回PyTorch张量
        )
        attention_mask = encoded["attention_mask"].squeeze(0)  # [max_len]
        caption_ids = encoded["input_ids"].squeeze(0) 

        return image, caption_ids, attention_mask
    



class TextAugmenter:
    def __init__(self, aug_src='wordnet', replace_ratio=0.2, delete_ratio=0.1):
        # 同义词替换增强器（基于 WordNet）
        self.synonym_aug = naw.SynonymAug(aug_src=aug_src, aug_p=replace_ratio)
        # 随机删除单词增强器
        self.delete_aug = naw.RandomWordAug(aug_type='delete', aug_p=delete_ratio)

    def augment(self, text):
        # 随机选择一种增强方式（或叠加使用）
        augmented = self.synonym_aug.augment(text)  # 同义词替换
        augmented = self.delete_aug.augment(augmented)  # 随机删除
        return augmented
