# test_and_visualization.py

import os
from torch.utils.data import DataLoader
from models.image_encoder import ImageEncoder
from models.text_encoder import TextEncoder
from loss import contrastive_loss
from data_loader import Flickr8kDataset
from utils import SimpleTokenizer
import torch
import torch.nn.functional as F
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.manifold import TSNE
import random

#供同学们参考

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def evaluate_top_k(img_encoder, txt_encoder, dataloader, device, topk=(1, 5, 10)):
    img_encoder.eval()
    txt_encoder.eval()

    all_image_embeds = []
    all_text_embeds = []

    with torch.no_grad():
        for images, captions_ids in tqdm(dataloader, desc="Extracting embeddings"):
            images = images.to(device)
            captions_ids = captions_ids.to(device)

            image_embed = img_encoder(images)  # [1, dim]
            text_embed = txt_encoder(captions_ids)  # [1, dim]

            all_image_embeds.append(image_embed.cpu())
            all_text_embeds.append(text_embed.cpu())

    all_image_embeds = torch.cat(all_image_embeds, dim=0)  # [N, D]
    all_text_embeds = torch.cat(all_text_embeds, dim=0)    # [N, D]

    # 归一化
    all_image_embeds = F.normalize(all_image_embeds, dim=1)
    all_text_embeds = F.normalize(all_text_embeds, dim=1)

    # 文本 -> 图像检索
    sim_matrix = torch.matmul(all_text_embeds, all_image_embeds.T)  # [N, N]
    txt2img_ranks = torch.argsort(sim_matrix, dim=1, descending=True)

    # 图像 -> 文本检索
    sim_matrix_T = sim_matrix.T  # [N, N]
    img2txt_ranks = torch.argsort(sim_matrix_T, dim=1, descending=True)

    def recall_at_k(ranks, topk):
        recalls = []
        for k in topk:
            match = [i in ranks[i][:k] for i in range(len(ranks))]
            recalls.append(np.mean(match))
        return recalls

    r_txt2img = recall_at_k(txt2img_ranks, topk)
    r_img2txt = recall_at_k(img2txt_ranks, topk)


    return r_txt2img, r_img2txt

def visualize_top_k(query_idx, img_encoder, txt_encoder, dataset, device, k=5):
    img_encoder.eval()  #设置为评估模式
    txt_encoder.eval()  #设置为评估模式
    
    # 获取查询样本
    query_image, query_caption_ids = dataset[query_idx]
    query_caption = dataset.pairs[query_idx][1]
    
    # 提取所有图像嵌入
    all_image_embeds, all_img_paths = [], []
    with torch.no_grad():
        for img_path in dataset.img_paths:
            image = Image.open(os.path.join(dataset.root_dir, img_path)).convert("RGB")
            image = dataset.transform(image).unsqueeze(0).to(device)
            embed = img_encoder(image).cpu()
            all_image_embeds.append(embed)
            all_img_paths.append(img_path)
    all_image_embeds = torch.cat(all_image_embeds)
    
    # 提取查询文本嵌入
    with torch.no_grad():
        caption_ids = query_caption_ids.unsqueeze(0).to(device)
        text_embed = txt_encoder(caption_ids).cpu()
    
    # 计算相似度
    similarities = F.cosine_similarity(text_embed, all_image_embeds, dim=1)
    topk_indices = similarities.argsort(descending=True)[:k]
    
    # 可视化
    plt.figure(figsize=(15, 5))
    plt.subplot(1, k + 1, 1)
    plt.imshow(Image.open(os.path.join(dataset.root_dir, dataset.img_paths[query_idx])))
    plt.title("Query Image\n" + query_caption)
    plt.axis('off')
    
    for i, idx in enumerate(topk_indices):
        plt.subplot(1, k+1, i+2)
        img = Image.open(os.path.join(dataset.root_dir, all_img_paths[idx]))
        plt.imshow(img)
        plt.title(f"Rank {i+1}\nSimilarity: {similarities[idx]:.2f}")
        plt.axis('off')
    plt.tight_layout()
    plt.savefig("C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/retrieval_example.png")
    plt.show()

def tsne_visualize(img_encoder, txt_encoder, dataloader, device, n_samples=200):
    """TSNE嵌入空间可视化"""
    img_encoder.eval() # 设置为评估模式
    txt_encoder.eval() # 设置为评估模式
    
    # 收集嵌入
    image_embeds, text_embeds, labels = [], [], []
    with torch.no_grad():
        for idx, (images, captions_ids) in enumerate(dataloader):
            if idx * dataloader.batch_size >= n_samples:
                break
            images = images.to(device)
            captions_ids = captions_ids.to(device)
            
            image_embeds.append(img_encoder(images).cpu())
            text_embeds.append(txt_encoder(captions_ids).cpu())
            labels.extend([f"Sample {idx*dataloader.batch_size+i}" for i in range(len(images))])
    
    # 合并并降维
    combined_embeds = torch.cat(image_embeds + text_embeds).numpy()
    tsne = TSNE(n_components=2, random_state=42)
    reduced = tsne.fit_transform(combined_embeds)
    
    # 绘图
    plt.figure(figsize=(12, 8))
    split_point = len(image_embeds)
    plt.scatter(reduced[:split_point, 0], reduced[:split_point, 1], c='r', label='Images')
    plt.scatter(reduced[split_point:, 0], reduced[split_point:, 1], c='b', label='Texts')
    plt.title("T-SNE Visualization of Embedding Space")
    plt.xlabel("TSNE-1") 
    plt.ylabel("TSNE-2")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.savefig("C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/tsne_visualization.png")
    plt.show()



def calc_val_loss(img_encoder, txt_encoder, dataloader, device):
    img_encoder.eval() # 设置为评估模式
    txt_encoder.eval() # 设置为评估模式
    total_val_loss = 0 # 使用 total_val_loss 累加
    with torch.no_grad(): # 在评估阶段不计算梯度
        pbar = tqdm(dataloader, desc="计算验证损失", unit="batch", leave=False)
        for images, captions_ids in pbar:
            images = images.to(device)
            captions_ids = captions_ids.to(device)
            
            image_embeds = img_encoder(images)
            text_embeds = txt_encoder(captions_ids)
            loss = contrastive_loss(image_embeds, text_embeds) # 调用对比损失函数
            total_val_loss += loss.item()
            pbar.set_postfix(loss=loss.item()) # 显示当前batch的损失
    avg_val_loss = total_val_loss / len(dataloader)
    return avg_val_loss
 

def main():
    # 设备设置
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
     
    # 文件路径，根据实际调整
    token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/captions.txt"         # 总的 captions 文件，用于构建词表
    test_token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/test_captions.txt"    # 测试集
    
    # 读取所有 caption 用于构建总词表（假设以 tab 分隔，如果不是，请修改 split 参数）
    with open(token_file, 'r', encoding="utf-8") as f:
        lines = f.readlines()
    captions = [line.strip().split(',')[1] for line in lines if line.strip()]
    
    # 构建统一的 tokenizer
    tokenizer = SimpleTokenizer(captions, min_freq=1)
    vocab_size = len(tokenizer)
    print(f"Vocabulary size: {vocab_size}")
    
    test_dataset = Flickr8kDataset(
        root_dir="C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/images",
        captions_file=test_token_file,    # 测试集 captions 文件
        tokenizer=tokenizer
    )
    
    test_dataloader = DataLoader(test_dataset, batch_size=4, shuffle=False, num_workers=4, drop_last=False)
    
    # 构造模型（设定 embed_dim=256）
    embed_dim = 256

    # 训练完成，最终在测试集上评估
    print("\n 加载最佳模型进行最终测试...")
    checkpoint = torch.load("C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/best_metric_model.pth", map_location=device, weights_only = False)   #加载最优模型
        
    # 重新初始化模型结构以加载状态字典
    loaded_embed_dim = checkpoint.get('embed_dim', embed_dim)
    loaded_vocab_size = checkpoint.get('vocab_size', vocab_size)

    final_img_encoder = ImageEncoder(embed_dim=loaded_embed_dim).to(device)
    final_txt_encoder = TextEncoder(vocab_size=loaded_vocab_size, embed_dim=loaded_embed_dim).to(device)
    final_img_encoder.load_state_dict(checkpoint['img_encoder_state_dict'])
    final_txt_encoder.load_state_dict(checkpoint['txt_encoder_state_dict'])
    print("最佳模型加载成功。")
    tokenizer_for_eval_vis = SimpleTokenizer([], min_freq=1) # 创建空tokenizer
    tokenizer_for_eval_vis.word2idx = checkpoint['tokenizer_vocab']

    # 如果SimpleTokenizer依赖idx2word，也需要重建
    if hasattr(tokenizer_for_eval_vis, 'idx2word'):
            tokenizer_for_eval_vis.idx2word = {v: k for k, v in tokenizer_for_eval_vis.word2idx.items()}
    print("从检查点加载了Tokenizer词表用于评估和可视化。")

    # 使用加载的最佳模型进行评估
    img_to_eval = final_img_encoder
    txt_to_eval = final_txt_encoder
    print("\n 在测试集上进行最终评估...")
    r_txt2img_test, r_img2txt_test = evaluate_top_k(img_to_eval, txt_to_eval, test_dataloader, device)
    
    print("\n📊 测试集性能:")
    print(f"文本→图像 Recall@1: {r_txt2img_test[0]*100:.2f}%")
    print(f"文本→图像 Recall@5: {r_txt2img_test[1]*100:.2f}%")
    print(f"文本→图像 Recall@10: {r_txt2img_test[2]*100:.2f}%")

    print("\n📊 测试集性能:")
    print(f"图像→文本 Recall@1: {r_img2txt_test[0]*100:.2f}%")
    print(f"图像→文本 Recall@5: {r_img2txt_test[1]*100:.2f}%")
    print(f"图像→文本 Recall@10: {r_img2txt_test[2]*100:.2f}%")
    
    # 可视化示例
    random_idx = random.randint(0, len(test_dataset)-1)
    visualize_top_k(random_idx, img_to_eval, txt_to_eval, test_dataset, device, k=5)
    
    # T-SNE可视化
    tsne_visualize(img_to_eval, txt_to_eval, test_dataloader, device)

if __name__ == "__main__":
    main()
