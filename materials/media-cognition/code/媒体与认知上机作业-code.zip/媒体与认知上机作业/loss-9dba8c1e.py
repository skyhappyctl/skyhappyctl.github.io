import torch
import torch.nn.functional as F
import tqdm
#请在这里写出对比损失函数
def contrastive_loss(image_embeds, text_embeds, temperature=0.07):
    """
    image_embeds, text_embeds: [batch, embed_dim]
    """
    device = image_embeds.device
    batch_size = image_embeds.shape[0]

    logits = torch.matmul(image_embeds, text_embeds.T) / temperature

     # 创建正样本标签 [0,1,2,...,batch-1]
    labels = torch.arange(batch_size, device=image_embeds.device)

    # 计算图像->文本和文本->图像两个方向的交叉熵损失
    loss_i2t = F.cross_entropy(logits, labels)
    loss_t2i = F.cross_entropy(logits.T, labels)  # 转置矩阵计算反向

     # 最终损失取平均
    loss = (loss_i2t + loss_t2i) / 2

    return loss

def calc_val_loss(img_encoder, txt_encoder, dataloader, device):
    img_encoder.eval() # 设置为评估模式
    txt_encoder.eval() # 设置为评估模式
    total_val_loss = 0 # 使用 total_val_loss 累加
    with torch.no_grad(): # 在评估阶段不计算梯度
        pbar = tqdm(dataloader, desc="计算验证损失", unit="batch", leave=False)
        for images, captions_ids in pbar:
            images = images.to(device)
            captions_ids = captions_ids.to(device)
            
            image_embeds = img_encoder(images)
            text_embeds = txt_encoder(captions_ids)
            loss = contrastive_loss(image_embeds, text_embeds) # 调用对比损失函数
            total_val_loss += loss.item()
            pbar.set_postfix(loss=loss.item()) # 显示当前batch的损失
    avg_val_loss = total_val_loss / len(dataloader)
    return avg_val_loss



 