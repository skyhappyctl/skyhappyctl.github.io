# test_and_visualization.py

import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

from torch.utils.data import DataLoader
from models.image_encoder import ImageEncoder
from models.text_encoder import TextEncoder
from loss import contrastive_loss
from data_loader import Flickr8kDataset
from utils import SimpleTokenizer
import torch
import torch.nn.functional as F
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.manifold import TSNE
import random
import torchvision.transforms as T
from transformers import BertTokenizer


def main():

    # 设备设置
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 文件路径，根据实际调整
    token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/captions.txt"         # 总的 captions 文件，用于构建词表
    test_token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/test_captions.txt"    # 测试集
    
    # 加载最佳模型
    print("\n 加载最佳模型进行最终测试...")
    checkpoint = torch.load("C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/训练模型参数/vit+bert/best_metric_model.pth", map_location=device, weights_only=False)
    
    # ===================== 新增：打印最佳模型指标 =====================
    # 提取检查点中的信息（确保这些键存在，根据train.py的保存逻辑）
    best_epoch = checkpoint.get('epoch', '未知')
    best_recall_at_1 = checkpoint.get('best_val_recall_at_1', 0)
    best_val_loss = checkpoint.get('best_val_loss', 0)
    train_loss_history = checkpoint.get('train_loss_history', [])
    val_loss_history = checkpoint.get('val_loss_history', [])

    # 打印最佳指标
    print("\n📌 最佳模型指标信息：")
    print(f" - 最佳验证集Recall@1: {best_recall_at_1 * 100:.2f}%")
    print(f" - 最佳验证集损失: {best_val_loss:.4f}")
    # =================================================================

if __name__ == "__main__":
    main()

    