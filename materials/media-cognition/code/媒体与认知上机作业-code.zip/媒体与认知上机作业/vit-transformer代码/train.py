# train_and_eval.py

import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
from torch.utils.data import DataLoader
from models.image_encoder import ImageEncoder
from models.text_encoder import TextEncoder
from loss import contrastive_loss
from data_loader import Flickr8kDataset
from utils import SimpleTokenizer
import torch
import torch.nn.functional as F
from tqdm import tqdm
import math
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.manifold import TSNE
import random

#供同学们参考

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def evaluate_top_k(img_encoder, txt_encoder, dataloader, device, topk=(1, 5, 10)):
    img_encoder.eval()
    txt_encoder.eval()

    all_image_embeds = []
    all_text_embeds = []

    with torch.no_grad():
        for images, captions_ids in tqdm(dataloader, desc="Extracting embeddings"):
            images = images.to(device)
            captions_ids = captions_ids.to(device)

            image_embed = img_encoder(images)  # [1, dim]
            text_embed = txt_encoder(captions_ids)  # [1, dim]

            all_image_embeds.append(image_embed.cpu())
            all_text_embeds.append(text_embed.cpu())

    all_image_embeds = torch.cat(all_image_embeds, dim=0)  # [N, D]
    all_text_embeds = torch.cat(all_text_embeds, dim=0)    # [N, D]

    # 归一化
    all_image_embeds = F.normalize(all_image_embeds, dim=1)
    all_text_embeds = F.normalize(all_text_embeds, dim=1)

    # 文本 -> 图像检索
    sim_matrix = torch.matmul(all_text_embeds, all_image_embeds.T)  # [N, N]
    txt2img_ranks = torch.argsort(sim_matrix, dim=1, descending=True)

    # 图像 -> 文本检索
    sim_matrix_T = sim_matrix.T  # [N, N]
    img2txt_ranks = torch.argsort(sim_matrix_T, dim=1, descending=True)

    def recall_at_k(ranks, topk):
        recalls = []
        for k in topk:
            match = [i in ranks[i][:k] for i in range(len(ranks))]
            recalls.append(np.mean(match))
        return recalls

    r_txt2img = recall_at_k(txt2img_ranks, topk)
    r_img2txt = recall_at_k(img2txt_ranks, topk)

    print("\n📈 Text → Image Retrieval:")
    for i, k in enumerate(topk):
        print(f"Recall@{k}: {r_txt2img[i]*100:.2f}%")

    print("\n📈 Image → Text Retrieval:")
    for i, k in enumerate(topk):
        print(f"Recall@{k}: {r_img2txt[i]*100:.2f}%")


    return r_txt2img, r_img2txt

def calc_val_loss(img_encoder, txt_encoder, dataloader, device):
    img_encoder.eval() # 设置为评估模式
    txt_encoder.eval() # 设置为评估模式
    total_val_loss = 0 # 使用 total_val_loss 累加
    with torch.no_grad(): # 在评估阶段不计算梯度
        pbar = tqdm(dataloader, desc="计算验证损失", unit="batch", leave=False)
        for images, captions_ids in pbar:
            images = images.to(device)
            captions_ids = captions_ids.to(device)
            
            image_embeds = img_encoder(images)
            text_embeds = txt_encoder(captions_ids)
            loss = contrastive_loss(image_embeds, text_embeds) # 调用对比损失函数
            total_val_loss += loss.item()
            pbar.set_postfix(loss=loss.item()) # 显示当前batch的损失
    avg_val_loss = total_val_loss / len(dataloader)
    return avg_val_loss
 

def adjust_learning_rate(optimizer, epoch, warmup_epochs = 5, base_lr = 1e-3):
    """线性预热 + 余弦退火"""
    if (epoch < warmup_epochs):
         # 线性预热
        lr = base_lr * (epoch + 1) / warmup_epochs
    else:
        # 余弦退火
        progress = (epoch - warmup_epochs) / (100 - warmup_epochs)
        lr = 0.5 * base_lr * (1 + math.cos(math.pi * progress))
    
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

    

def main():
    # 设备设置
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    #print(torch.__version__)
     
    # 文件路径，根据实际调整
    token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/captions.txt"         # 总的 captions 文件，用于构建词表
    train_token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/train_captions.txt"  # 训练集，格式： image,caption
    val_token_file = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/val_captions.txt"      # 验证集
    
    # 读取所有 caption 用于构建总词表（假设以 tab 分隔，如果不是，请修改 split 参数）
    with open(token_file, 'r', encoding="utf-8") as f:
        lines = f.readlines()
    captions = [line.strip().split(',')[1] for line in lines if line.strip()]
    
    # 构建统一的 tokenizer
    tokenizer = SimpleTokenizer(captions, min_freq=1)
    vocab_size = len(tokenizer)
    print(f"Vocabulary size: {vocab_size}")
    
    # 构建数据集与 DataLoader：训练集、验证集、测试集
    train_dataset = Flickr8kDataset(
        root_dir="C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/images",      # 图片所在目录
        captions_file=train_token_file,   # 训练集 captions 文件，格式： image<TAB>caption
        tokenizer=tokenizer
    )
    val_dataset = Flickr8kDataset(
        root_dir="C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/Flickr8k/images",
        captions_file=val_token_file,     # 验证集 captions 文件
        tokenizer=tokenizer
    )
    
    train_dataloader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4, drop_last=True)
    # 为保证评估稳定，每个 batch 使用 batch_size=1
    val_dataloader = DataLoader(val_dataset, batch_size=4, shuffle=False, num_workers=4, drop_last=False)
    
    # 构造模型（设定 embed_dim=256）
    embed_dim = 256
    img_encoder = ImageEncoder(embed_dim = embed_dim, encoder_type = 'vit').to(device)
    txt_encoder = TextEncoder(vocab_size, embed_dim = embed_dim, encoder_type = 'transformer').to(device)
    
    # 优化器
    optimizer = torch.optim.Adam(
        list(img_encoder.parameters()) + list(txt_encoder.parameters()),
        lr=1e-4
    )
    
    best_val_loss = float('inf')
    epochs = 40   
    real_epochs = 0
    best_val_recall = 0
    val_loss = 0
    train_loss_history = []
    val_loss_history = []
    early_stop_patience = 5
    early_stop_counter = 0


    # 新增代码：定义检查点路径和恢复训练标志
    checkpoint_path = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/best_metric_model.pth"
    resume_training = False  # 是否从检查点恢复训练

    # 新增代码：初始化训练相关变量（会被检查点覆盖）
    start_epoch = 0
    best_val_recall = 0
    best_val_loss = float('inf')
    train_loss_history = []
    val_loss_history = []

    # 加载检查点 
    if os.path.exists(checkpoint_path):
        print(f"发现检查点文件 {checkpoint_path}，正在加载...")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only= False)
        
        # 加载模型和优化器状态
        img_encoder.load_state_dict(checkpoint['img_encoder_state_dict'])
        txt_encoder.load_state_dict(checkpoint['txt_encoder_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
        # 加载训练状态
        start_epoch = checkpoint['epoch']
        best_val_recall = checkpoint['best_val_recall_at_1']
        best_val_loss = checkpoint['best_val_loss']
        train_loss_history = checkpoint.get('train_loss_history', [])
        val_loss_history = checkpoint.get('val_loss_history', [])
        
        # 加载tokenizer词表（如果需要）
        tokenizer.word2idx = checkpoint['tokenizer_vocab']
        
        resume_training = True
        print(f"成功加载检查点，将从 epoch {start_epoch} 继续训练")
        print(f"当前最佳 Recall@1: {best_val_recall*100:.2f}% | 最佳验证损失: {best_val_loss:.4f}")

    for epoch in range(epochs):
        img_encoder.train()     #设置为训练模式
        txt_encoder.train()     #设置为训练模式
        epoch_loss = 0.0
        pbar = tqdm(train_dataloader,desc=f"Epoch {epoch+1}/{epochs}",unit = "batch")
        for images, captions_ids in pbar:
            images = images.to(device)
            captions_ids = captions_ids.to(device)
            
            image_embeds = img_encoder(images)      # [batch, embed_dim]
            text_embeds = txt_encoder(captions_ids)   # [batch, embed_dim]
            loss = contrastive_loss(image_embeds, text_embeds)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            

            epoch_loss += loss.item()
            pbar.set_postfix(loss = loss.item())

        avg_train_loss = epoch_loss / len(train_dataloader)
        train_loss_history.append(avg_train_loss) # 记录训练损失
        val_loss = calc_val_loss(img_encoder,txt_encoder,val_dataloader,device)
        val_loss_history.append(val_loss) # 记录验证损失


        # 查看当前学习率
        current_lr = optimizer.param_groups[0]['lr']
        print(f"Epoch {epoch}: Learning Rate = {current_lr:.6f}")

        # 手动更新学习率
        adjust_learning_rate(optimizer, epoch)  

        r_txt2img, r_img2txt = evaluate_top_k(img_encoder, txt_encoder, val_dataloader, device, topk=(1, 5, 10))
        
        print(f"  Epoch [{epoch+1}/{epochs}]: Train Loss: {avg_train_loss:.4f} | Val Loss: {val_loss:.4f}" )
        print(f"  验证集 文本->图像 Recall: @1 {r_txt2img[0]*100:.2f}% | @5 {r_txt2img[1]*100:.2f}% | @10 {r_txt2img[2]*100:.2f}%")
        print(f"  验证集 图像->文本 Recall: @1 {r_img2txt[0]*100:.2f}% | @5 {r_img2txt[1]*100:.2f}% | @10 {r_img2txt[2]*100:.2f}%")
        
        # 如果验证集有改善，则保存最佳模型，这里选择loss以及recall参数
        improved_metric = False
        if r_txt2img[0] >= best_val_recall:
            best_val_recall = r_txt2img[0]
            print(f"    > 验证集 Recall@1 提升至: {best_val_recall*100:.2f}%")
            improved_metric = True
        
        if val_loss <= best_val_loss:
            best_val_loss = val_loss
            print(f"    > 验证集损失降低至: {best_val_loss:.4f}")
            improved_metric = True

        if improved_metric:
            checkpoint = {
                'epoch': epoch + 1,
                'img_encoder_state_dict': img_encoder.state_dict(),
                'txt_encoder_state_dict': txt_encoder.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'tokenizer_vocab': tokenizer.word2idx, # 保存词表
                'best_val_recall_at_1': best_val_recall,
                'best_val_loss': best_val_loss,
                'embed_dim': embed_dim, # 保存模型参数
                'vocab_size': vocab_size # 保存模型参数
            }
            torch.save(checkpoint, checkpoint_path)
            print(f"    > Best model updated at epoch {epoch+1} ")
            early_stop_counter = 0  # 指标改善，重置计数器
        else:
            early_stop_counter += 1  # 指标未改善，计数器+1
            print(f"⚠️ 早停计数器: {early_stop_counter}/{early_stop_patience}")

        # 触发早停条件
        if early_stop_counter >= early_stop_patience:
            print(f"🚨 连续 {early_stop_patience} 轮无指标改善，提前终止训练！")
            real_epochs = epoch
            break
            


    
    print("\n训练完成。")

    #绘制loss曲线
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, real_epochs + 1), train_loss_history, label='平均训练损失 (Avg Train Loss)')
    plt.plot(range(1, real_epochs + 1), val_loss_history, label='平均验证损失 (Avg Val Loss)')
    plt.xlabel('轮次 (Epochs)')
    plt.ylabel('损失 (Loss)')
    plt.title('训练和验证损失随轮次变化曲线')
    plt.legend() # 显示图例
    plt.grid(True) # 显示网格
    plt.savefig("C:/Users/local-user/Desktop/学校的破事/作业/媒认/媒体与认知上机作业/loss_curve.png") # 将图像保存到文件
    print("损失曲线已保存为 loss_curve.png")
    plt.show()
    

if __name__ == "__main__":
    main()
