import torch.nn as nn
from .lstm_custom import LSTMTextEncoder
from .transformer_encoder import TransformerTextEncoder
from .bert_encoder import BERTTextEncoder
import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"


class TextEncoder(nn.Module):
    def __init__(self, vocab_size, embed_dim=256, hidden_dim=512, encoder_type='transformer'):
        """
        参数说明：
          - vocab_size: 词表大小,对于BERT可忽略（保留是为了接口兼容）
          - embed_dim: 嵌入维度（同时也是目标输出维度）
          - hidden_dim: LSTM 隐藏层维度（仅在 encoder_type='lstm' 时有效）
          - encoder_type: 指定使用哪种编码器，可选 'lstm' 或 'transformer' 或 'bert'
        """
        super().__init__()
        self.encoder_type = encoder_type

        if encoder_type == 'lstm':
            # 使用手写版 LSTMTextEncoder，注意此处 LSTMTextEncoder 内部已包含词嵌入层和全连接映射
            self.encoder = LSTMTextEncoder(vocab_size, embed_dim, hidden_dim)
        elif encoder_type == 'transformer':
            print("true")
            # 使用手写版 TransformerTextEncoder，注意内部参数可根据需求调整，如头数、最大序列长度等
            self.encoder = TransformerTextEncoder(vocab_size, embed_dim, num_heads=4, padding_idx=0, max_len=100)
        elif encoder_type == 'bert':
            # 使用手写版 BERTTextEncoder，注意内部参数可根据需求调整
            self.encoder = BERTTextEncoder(embed_dim, freeze_bert=True)
            self.head = nn.Sequential(
                        nn.Linear(embed_dim, embed_dim),
                        nn.ReLU(),
                        nn.Dropout(0.1),
                        nn.LayerNorm(embed_dim)
                    )
        else:
            raise ValueError("Unsupported encoder_type: choose either 'lstm' , 'transformer' or 'bert'")
    
    def forward(self, captions, attention_mask):
        # 直接调用内部 encoder 模块进行前向传播
        if self.encoder_type == 'bert':
            input_ids, attention_mask = captions, attention_mask
            embeddings = self.encoder(input_ids, attention_mask)
            embeddings = self.head(embeddings)
            return embeddings
        else:
            # 其他编码器输入为单一token ID序列
            return self.encoder(captions)  # 输出形状：[batch, embed_dim]

