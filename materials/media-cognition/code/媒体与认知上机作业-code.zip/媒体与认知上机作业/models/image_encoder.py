import torch.nn as nn
from .resnet_custom import ResNet18  # 替换 torch 的 resnet18
from .resnet_custom import ResNet34  # 替换 torch 的 resnet34
from .nfnet_custom import NFNet
from .vit_custom import VITEncoder

class ImageEncoder(nn.Module):
    def __init__(self, embed_dim=256, encoder_type = 'resnet34'):
        super().__init__()
        self.encoder_type = encoder_type
        if encoder_type == 'resnet18':
            self.resnet = ResNet18()  # 自己写的网络
            self.fc = nn.Linear(256, embed_dim)  # 将 ResNet 输出映射到共享空间

        elif encoder_type == 'resnet34':
            self.resnet = ResNet34()  # 自己写的网络
            self.fc = nn.Linear(256, embed_dim)  # 将 ResNet 输出映射到共享空间

        elif encoder_type == 'nfnet':
            self.nfnet = NFNet()  # 自己写的网络
            self.fc = nn.Linear(256, embed_dim)  # 将 NFNet 输出映射到共享空间

        elif encoder_type == 'vit':
            self.vit = VITEncoder(embed_dim)
            self.fc = nn.Sequential(
                    nn.Linear(embed_dim, embed_dim),
                    nn.GELU(),         # ViT 常用 GELU 激活
                    nn.Dropout(0.1),
                    nn.LayerNorm(embed_dim)
                )

    def forward(self, images):
        if self.encoder_type == "resnet18":
            features = self.resnet(images)  # [batch, 256]
            embeddings = self.fc(features)  # [batch, embed_dim]
        elif self.encoder_type == "resnet34":
            features = self.resnet(images)  # [batch, 256]
            embeddings = self.fc(features)  # [batch, embed_dim]
        elif self.encoder_type == "nfnet":
            features = self.nfnet(images)  # [batch, 256]
            embeddings = self.fc(features)  # [batch, embed_dim]
        elif self.encoder_type == "vit":
            embeddings = self.vit(images)  # [batch, embed_dim]
            embeddings = self.fc(embeddings)
        return embeddings
