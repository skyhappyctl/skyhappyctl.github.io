import torch
import torch.nn as nn
from transformers import AutoImageProcessor
from transformers import ViTModel

import timm

class VITEncoder(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        model_path = "C:/Users/local-user/Desktop/学校的破事/作业/媒认/vit-base-patch16-224-in21k"
        
        # 加载预训练模型和处理器
        self.processor = AutoImageProcessor.from_pretrained(model_path)
        self.model = ViTModel.from_pretrained(model_path)

        vit_output_dim = self.model.config.hidden_size


        
        # 冻结所有预训练权重参数
        for name, param in self.model.named_parameters():
            if 'encoder.layer' in name:
                layer_idx = int(name.split('.')[2])  # 层号在第2个拆分位置（索引2）
                if layer_idx < 9:
                    param.requires_grad = False  # 冻结前10层
                else:
                    param.requires_grad = True   # 解冻最后2层
            else:
                # 非encoder.layer的参数（如CLS token、嵌入层等）默认解冻
                param.requires_grad = False
        

        self.projection = nn.Sequential(
            nn.Linear(vit_output_dim, embed_dim),
            nn.LayerNorm(embed_dim)  
        )

        # 初始化投影层权重（可选）
        nn.init.xavier_uniform_(self.projection[0].weight)
        nn.init.constant_(self.projection[0].bias, 0)

    def forward(self, images):
        """
        images: [batch, 3, 224, 224] 归一化后的图像张量
        return: [batch, embed_dim] 归一化的图像嵌入
        """
        outputs = self.model(images)
        
        # 提取[CLS] token并投影
        cls_token = outputs.last_hidden_state[:, 0, :]
        image_embed = self.projection(cls_token)
        image_embed = nn.functional.normalize(image_embed, p=2, dim=1)  # L2归一化

        return image_embed
    