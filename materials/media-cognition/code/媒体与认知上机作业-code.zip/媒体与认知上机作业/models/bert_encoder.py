import torch.nn as nn
import torch.nn.functional as F
from transformers import BertModel, BertTokenizer


class BERTTextEncoder(nn.Module):
    def __init__(self, embed_dim=256, freeze_bert=True):
        """
        BERT文本编码器
        参数:
          - embed_dim: 输出特征维度
          - max_length: 最大序列长度
          - freeze_bert: 是否冻结BERT权重（默认冻结）
        """
        super().__init__()
        # 初始化BERT模型和tokenizer
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

         # BERT输出维度 (768) 到目标维度的投影层
        bert_hidden_size = self.bert.config.hidden_size
        self.projection = nn.Linear(bert_hidden_size, embed_dim)
        
        # 默认冻结BERT权重
        if freeze_bert:
            for name, param in self.bert.named_parameters():
                if 'encoder.layer' in name:
                    layer_idx = int(name.split('.')[2])  # 层号在第2个拆分位置（索引2）
                    if layer_idx < 9:
                        param.requires_grad = False  # 冻结前10层
                    else:
                        param.requires_grad = True   # 解冻最后2层
                else:
                    # 非encoder.layer的参数（如CLS token、嵌入层等）默认解冻
                    param.requires_grad = False

    def forward(self, input_ids, attention_mask=None):
        outputs = self.bert(input_ids = input_ids, attention_mask = attention_mask)
        pooled_output = outputs.pooler_output
        return F.normalize(self.projection(pooled_output), p=2, dim=1)
