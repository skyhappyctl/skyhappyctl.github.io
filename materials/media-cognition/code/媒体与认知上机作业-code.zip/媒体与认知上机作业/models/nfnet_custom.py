import torch
import torch.nn as nn
import torch.nn.functional as F
from math import sqrt

# Scaled Weight Standardized 卷积层 (NFNet核心组件)
class ScaledWSConv2d(nn.Conv2d):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, 
                 dilation=1, groups=1, bias=True, gain=True):
        super().__init__(in_channels, out_channels, kernel_size, stride, padding, 
                         dilation, groups, bias)
        # 增益参数 (每个输出通道一个缩放因子)
        if gain:
            self.gain = nn.Parameter(torch.ones(out_channels, 1, 1, 1))
        else:
            self.gain = None
        
    def get_weight(self):
        # 权重标准化
        var, mean = torch.var_mean(self.weight, dim=[1, 2, 3], keepdim=True)
        weight = (self.weight - mean) / (var + 1e-10).sqrt()
        
        # 应用增益
        if self.gain is not None:
            weight = weight * self.gain
        return weight
    
    def forward(self, x):
        return F.conv2d(x, self.get_weight(), self.bias, self.stride, 
                        self.padding, self.dilation, self.groups)

# NFNet基础残差块
class NFBlock(nn.Module):
    expansion = 2  # 通道扩展系数
    
    def __init__(self, in_channels, out_channels, stride=1, alpha=0.2):
        super().__init__()
        mid_channels = out_channels // self.expansion
        
        # 主分支
        self.conv1 = ScaledWSConv2d(in_channels, mid_channels, 1)
        self.act1 = nn.SiLU(inplace=True)
        self.conv2 = ScaledWSConv2d(mid_channels, mid_channels, 3, stride, 1)
        self.act2 = nn.SiLU(inplace=True)
        self.conv3 = ScaledWSConv2d(mid_channels, out_channels, 1, gain=False)
        
        # 快捷连接 (如果需要下采样或通道数变化)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                ScaledWSConv2d(in_channels, out_channels, 1, stride, gain=False)
            )
        
        # 残差缩放参数
        self.alpha = nn.Parameter(torch.tensor(alpha, dtype=torch.float32))
        
    def forward(self, x):
        identity = self.shortcut(x)
        x = self.conv1(x)
        x = self.act1(x)
        x = self.conv2(x)
        x = self.act2(x)
        x = self.conv3(x)
        return self.act2(identity + self.alpha * x)

class NFNet(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        # 初始卷积层
        self.conv1 = ScaledWSConv2d(3, 32, 3, stride=2, padding=1)
        self.act1 = nn.SiLU(inplace=True)
        self.conv2 = ScaledWSConv2d(32, 64, 3, stride=1, padding=1)
        self.act2 = nn.SiLU(inplace=True)
        self.conv3 = ScaledWSConv2d(64, 128, 3, stride=2, padding=1)
        self.act3 = nn.SiLU(inplace=True)
        
        # 残差阶段
        self.stage1 = self._make_stage(128, 128, stride=1, blocks=3)
        self.stage2 = self._make_stage(128, 256, stride=2, blocks=4)
        self.stage3 = self._make_stage(256, 512, stride=2, blocks=6)
        self.stage4 = self._make_stage(512, 512, stride=1, blocks=3)  
        
        # 全局平均池化+分类头
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, embed_dim)

        self._init_weights()
        
    
    def _make_stage(self, in_channels, out_channels, stride, blocks):
        layers = [NFBlock(in_channels, out_channels, stride)]
        for _ in range(1, blocks):
            layers.append(NFBlock(out_channels, out_channels, stride=1))
        return nn.Sequential(*layers)
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, ScaledWSConv2d):
                # He初始化
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        x = self.act1(self.conv1(x))
        x = self.act2(self.conv2(x))
        x = self.act3(self.conv3(x))
        
        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return F.normalize(x, p=2, dim=1, eps=1e-12)
