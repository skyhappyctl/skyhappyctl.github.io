// ============================================================
// 练习 5（组合逻辑·ALU）
// 功能：8 位 ALU，op：0=加(带进位) 1=按位与 2=按位或 3=异或
//       4=左移1位 5=右移1位 其余=输出 0
// ============================================================
`timescale 1ns/1ps
module ALU_8 (F, C_out, A, B, op);
  output [7:0] F;
  output       C_out;
  input  [7:0] A, B;
  input  [2:0] op;

  reg [7:0] F;
  reg       C_out;

  always @(*) begin
    C_out = 1'b0;
    case (op)
      3'd0: {C_out, F} = {1'b0, A} + {1'b0, B};
      3'd1: F = A & B;
      3'd2: F = A | B;
      3'd3: F = A ^ B;
      3'd4: F = A << 1;
      3'd5: F = A >> 1;
      default: F = 8'h00;
    endcase
  end
endmodule
