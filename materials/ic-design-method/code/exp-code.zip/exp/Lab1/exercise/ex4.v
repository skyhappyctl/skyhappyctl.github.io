// ============================================================
// 练习 4
// 功能：4 位数据监控单元 Mon_4，时钟上升沿工作
//   · val ：时钟边沿采样端口d的数据（en=1 采样；clr 同步清零，
//            清零优先于采样；其余保持）
//   · cnt ：节拍计数 0–3 循环，【仅 en=1 时计数】
//   · tick：cnt 计到 3 且 en=1 的当拍输出一个时钟宽脉冲
//   · alarm：val > TH（阈值，参数）时报警，即置1
//   · sum ：内部中间信号，val + d 的完整和
// ============================================================
`timescale 1ns/1ps
module Mon_4 (val, alarm, tick, d, en, clr, clk, rst_n);
  output [3:0] val;
  output       alarm, tick;
  input  [3:0] d;
  input        en, clr, clk, rst_n;

  parameter TH = 4'd6;

  wire [3:0] sum;   // 中间信号：val + d

  reg [3:0] val;
  reg [1:0] cnt;

  // 数据寄存器：en=1 采样、clr 同步清零（优先）、其余保持
  always @(posedge clk or negedge rst_n)
    if (!rst_n)
      val <= 4'd0;
    else if (clr) begin
      val <= 4'd0;
    end
    else if (en) begin
      val <= d;
    end
    else
      val <= val;

  // 节拍计数：0–3 循环，仅 en=1 时计数
  always @(posedge clk or negedge rst_n)
    if (!rst_n) 
      cnt <= 2'd0;
    else if (en)
      cnt <= cnt + 2'd1;
    else 
      cnt <= cnt;

  assign sum   = {1'b0, val} + {1'b0, d};
  assign tick  = en && (cnt == 2'd3);
  assign alarm = (val > TH);
endmodule
