// ============================================================
//练习 1行波进位加法器层次化调用
//按照文件夹内给出的电路框图，完成下面的代码空缺部分，同时找出代码中存在的错误
//要求用附带的tb进行代码测试，使得代码功能正确
// ============================================================
`timescale 1ns/1ps
module Add_rca_16_0_delay (sum, c_out, a, b, c_in);
  output [15:0] sum;
  output        c_out;
  input  [15:0] a, b;
  input         c_in;
  wire          c_in4, c_in8, c_in12;

  Add_rca_4 M1 (sum[3:0],   c_in4,   a[3:0],   b[3:0],   c_in);
  Add_rca_4 M2 (sum[7:4],   c_in8,   a[7:4],   b[7:4],   c_in4);
  Add_rca_4 M3 (sum[11:8],  c_in12,  a[11:8],  b[11:8],  c_in8);
  Add_rca_4 M4 (sum[15:12], c_out,   a[15:12], b[15:12], c_in12);
endmodule

module Add_rca_4 (sum, c_out, a, b, c_in);
  output [3:0] sum;
  output       c_out;
  input  [3:0] a, b;
  input        c_in;
  wire         c_in2, c_in3, c_in4;

  Add_full_0_delay G1 (.sum(sum[0]), .c_out(c_in2), .a(a[0]), .b(b[0]), .c_in(c_in));
  Add_full_0_delay G2 (sum[1], c_in3, a[1], b[1], c_in2);
  Add_full_0_delay G3 (.sum(sum[2]), .c_out(c_in4), .a(a[2]), .b(b[2]), .c_in(c_in3));
  Add_full_0_delay G4 (sum[3], c_out, a[3], b[3], c_in4);
endmodule

module Add_full_0_delay (sum, c_out, a, b, c_in);
  output sum, c_out;
  input  a, b, c_in;
  wire   w1, w2, w3;

  Add_half_0_delay M1 (w1, w2, a, b);
  Add_half_0_delay M2 (sum, w3, w1, c_in);
  or               M3 (c_out, w2, w3);
endmodule

module Add_half_0_delay (sum, c_out, a, b);
  output sum, c_out;
  input  a, b;

  xor M1 (sum,   a, b);
  and M2 (c_out, a, b);
endmodule
