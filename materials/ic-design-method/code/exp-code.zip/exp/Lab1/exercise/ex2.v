// ============================================================
// 练习 2（FSM）
//   检测 3 个连续 1，Mealy 输出
// 需求：En=1 时，串行输入 D_in 出现第 3 个连续 1 的当拍 D_out=1；
//       之后连续的 1 应保持输出（重叠命中）；输入 0 立即清零计数。
// ============================================================
`timescale 1ns/1ps
module Seq_Rec_3_1s_Mealy (output D_out, input D_in, En, clk, reset);

  parameter
    S_idle = 2'd0,  // Binary code
    S_0    = 2'd1,
    S_1    = 2'd2,
    S_2    = 2'd3;
  reg [1:0] state, next_state;

  always @(negedge clk)
    if (reset == 1'b1) state <= S_idle;
    else           state <= next_state;

  always @(*) begin
    next_state = S_idle;
    if (En == 1'b1) begin
      case (state)
        S_idle: begin
          if (D_in == 1'b0)      next_state = S_0;
          else if (D_in == 1'b1) next_state = S_1;
        end
        S_0: begin   
          if (D_in == 1'b0)                     next_state = S_0;
          else if (D_in == 1'b1)                next_state = S_1;
        end
        S_1: begin
          if (D_in == 1'b0)                     next_state = S_0;
          else if (D_in == 1'b1)                next_state = S_2;
        end
        S_2: begin
          if (D_in == 1'b0)                     next_state = S_0;
          else if (D_in == 1'b1)                next_state = S_2;
        end
        default:                                next_state = S_idle;
      endcase
    end
  end

  assign D_out = (!reset) && En && (state == S_2) && (D_in);  // Mealy output

endmodule
