// ============================================================
// 练习 3（FSM·自动售货机）
// 功能：可乐 3 元。投币输入 coin（每拍一种动作）：
//         2'b00 不投  2'b01 投 1 元  2'b10 投 2 元
//       状态记录已投金额（0/1/2 元，投满即出货清零）：
//         S0=0元  S1=1元  S2=2元
//       Mealy 输出：出货时Disp置1（当拍组合有效）；
//       需要找零时Change置1（2元币投在已有 2 元时：4-3=1 元）。
// ============================================================
`timescale 1ns/1ps
module Vend (Disp, Change, coin, clk, rst);
  output Disp, Change;
  input  [1:0] coin;
  input        clk, rst;

  localparam S0 = 2'd0,
             S1 = 2'd1,
             S2 = 2'd2;

  reg [1:0] state, next_state;
  reg       Disp, Change;

  always @(posedge clk)
    if (rst) state <= S0;
    else     state <= next_state;

  always @(*) begin
    next_state = state;
    Disp = 1'b0;
    Change = 1'b0;
    case (state)
      S0: case (coin)
            2'b01: next_state = S1;
            2'b10: next_state = S2;
            default: next_state = S0;
          endcase
      S1: case (coin)
            2'b01: next_state = S2;
            2'b10: begin next_state = S0; Disp = 1'b1; end
            default: next_state = S1;
          endcase
      S2: case (coin)
            2'b01: begin next_state = S0; Disp = 1'b1; end
            2'b10: begin
              next_state = S0;
              Disp = 1'b1;
              Change = 1'b1;
            end
            default: next_state = S2;
          endcase
      default: next_state = S0;
    endcase
  end
endmodule
