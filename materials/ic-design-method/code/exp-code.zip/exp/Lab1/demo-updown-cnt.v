`timescale 1ns/1ps

module updown_cnt(clk,rstn,din,load,updown,cnt);
input clk,rstn;
input [3:0] din;
input load, updown;
output [3:0] cnt;
reg [3:0] cnt;

always@(posedge clk or negedge rstn)
begin
if(!rstn)  cnt <= 4'd0;
else if(load)  cnt <= din;
     else if(updown) cnt <= cnt + 1;
          else cnt <= cnt - 1;
end

endmodule
