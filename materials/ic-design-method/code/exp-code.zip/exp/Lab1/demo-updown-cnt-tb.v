`timescale 1ns/1ps

module tb;

reg clk,rstn;
reg [3:0] din;
reg load, updown;
wire [3:0] cnt;

//initial $sdf_annotate("demo-updown-cnt.sdf", uut);
updown_cnt uut(clk,rstn,din,load,updown,cnt);

parameter half_cycle = 5;
initial 
begin
clk = 0;
forever 
clk = #half_cycle ~clk;
end

initial 
begin
rstn = 1;
#(1.5*half_cycle) rstn = 0;
#(2*half_cycle) rstn = 1;
end

initial 
begin
load = 0;
#(4*half_cycle) load = 1;
#(2*half_cycle) load = 0;
end

initial
begin
din = 0;
#(4*half_cycle) din = 4'd10;
#(2*half_cycle) din = 0;
end

initial
begin
updown = 0;
#(8*half_cycle) updown = 1;
#(10*half_cycle) updown = 0;
end

initial
#(50*half_cycle) $finish;

endmodule
