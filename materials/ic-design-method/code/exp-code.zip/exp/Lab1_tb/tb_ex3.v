// ------------------------------------------------------------
// 练习 3所使用tb
// credit ∈ {0,1,2}；投币 c：若 credit+c ≥ 3 则出货
//（=4 时找零），credit 清零；否则 credit 累加。
// 场景：1+1+1、2+1、2+2（找零）、1+2、1 元存款保持后再投 1 元
// ------------------------------------------------------------
`timescale 1ns/1ps
module tb_Vend;
  reg        clk, rst;
  reg  [1:0] coin;
  wire       Disp, Change;
  integer    errors;
  reg [1:0]  credit;
  reg        exp_d, exp_c;

  Vend M1 (Disp, Change, coin, clk, rst);

  always #5 clk = ~clk;                    // posedge 在 5,15,25,…ns

  task evt(input [1:0] c);
    begin
      @(posedge clk);  #2;  coin = c;  #3;      // 沿后 5ns：Mealy 稳定
      exp_d = (c != 2'b00) && (credit + c >= 3);
      exp_c = (c != 2'b00) && (credit + c >= 4);
      if (Disp !== exp_d || Change !== exp_c) begin
        errors = errors + 1;
        $display ("FAIL t=%0t coin=%b(credit=%0d): Disp=%b Change=%b exp %b/%b",
                  $time, c, credit, Disp, Change, exp_d, exp_c);
      end
      if (c != 2'b00)                        
        credit = (credit + c >= 3) ? 2'd0 : credit + c;
    end
  endtask

  initial begin
    clk = 0;  rst = 1;  coin = 2'b00;  errors = 0;  credit = 0;
    #12 rst = 0;

    evt (2'b01);  evt (2'b01);  evt (2'b01);   // 1+1+1 → 出货
    evt (2'b00);                                 // 静置
    evt (2'b10);  evt (2'b01);                   // 2+1 → 出货
    evt (2'b00);
    evt (2'b10);  evt (2'b10);                   // 2+2 → 出货+找零
    evt (2'b00);
    evt (2'b01);  evt (2'b10);                   // 1+2 → 出货
    evt (2'b01);  evt (2'b00);  evt (2'b00);     // 存 1 元并静置
    evt (2'b01);                                 // 1+1=2 元：不出货！

    if (errors == 0) $display ("*** ALL PASS ***");
    else             $display ("*** %0d ERRORS ***", errors);
    $finish;
  end

  initial $monitor ($time, " rst=%b coin=%b state=%0d Disp=%b Change=%b",
                    rst, coin, M1.state, Disp, Change);
endmodule
