// ------------------------------------------------------------
// 练习 5所用tb
// 修复目标：*** ALL PASS ***
// ------------------------------------------------------------
`timescale 1ns/1ps
module tb_ALU;
  reg  [7:0] A, B;
  reg  [2:0] op;
  wire [7:0] F;
  wire       C_out;
  integer    errors;

  ALU_8 M1 (F, C_out, A, B, op);

  task chk(input [2:0] op_, input [7:0] a_, b_,
           input [7:0] f_, input c_);
    begin
      op = op_;  A = a_;  B = b_;  #2;
      if (F !== f_ || C_out !== c_) begin
        errors = errors + 1;
        $display ("FAIL op=%0d: A=%h B=%h -> F=%h C=%b(exp F=%h C=%b)",
                  op_, a_, b_, F, C_out, f_, c_);
      end
    end
  endtask

  initial begin
    errors = 0;
    chk (3'd0, 8'h01, 8'hFF, 8'h00, 1'b1);   // 1+FF 进位溢出
    chk (3'd0, 8'h0A, 8'h0A, 8'h14, 1'b0);   // 10+10
    chk (3'd1, 8'h0F, 8'h3C, 8'h0C, 1'b0);   // 按位与
    chk (3'd2, 8'h0F, 8'h3C, 8'h3F, 1'b0);   // 按位或
    chk (3'd3, 8'h0F, 8'h3C, 8'h33, 1'b0);   // 异或
    chk (3'd4, 8'h81, 8'h00, 8'h02, 1'b0);   // 左移
    chk (3'd5, 8'h81, 8'h00, 8'h40, 1'b0);   // 右移
    chk (3'd6, 8'hFF, 8'hFF, 8'h00, 1'b0);   // 未定义
    chk (3'd7, 8'hA5, 8'h5A, 8'h00, 1'b0);   // 未定义
    if (errors == 0) $display ("*** ALL PASS ***");
    else             $display ("*** %0d ERRORS ***", errors);
    $finish;
  end
endmodule
