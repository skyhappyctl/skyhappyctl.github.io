// ------------------------------------------------------------
// 练习 2（ex1.v 行波进位加法器）配套测试平台
// 修复全部错误与空缺后，应打印 *** ALL PASS ***。
// ------------------------------------------------------------
`timescale 1ns/1ps
module tb_Add_rca16;
  reg  [15:0] a, b;
  reg         c_in;
  wire [15:0] sum;
  wire        c_out;
  reg  [16:0] exp;
  integer     errors;

  Add_rca_16_0_delay M1 (sum, c_out, a, b, c_in);

  task chk(input [15:0] aa, input [15:0] bb, input ci);
    begin
      a = aa;  b = bb;  c_in = ci;  #2;
      exp = {1'b0, aa} + {1'b0, bb} + ci;     
      if ({c_out, sum} !== exp) begin
        errors = errors + 1;
        $display ("FAIL a=%h b=%h c_in=%b -> sum=%h c_out=%b(exp %h)",
                  aa, bb, ci, sum, c_out, exp);
      end
    end
  endtask

  initial begin
    errors = 0;
    chk (16'h0000, 16'h0000, 1'b0);   
    chk (16'h0001, 16'hFFFF, 1'b0);   
    chk (16'h1234, 16'h5678, 1'b0);   
    chk (16'hABCD, 16'h1234, 1'b1);   
    chk (16'hFFFF, 16'hFFFF, 1'b1);   
    if (errors == 0) $display ("*** ALL PASS ***");
    else             $display ("*** %0d ERRORS ***", errors);
    $finish;
  end

  initial $monitor ($time, " a=%h b=%h c_in=%b | sum=%h c_out=%b",
                    a, b, c_in, sum, c_out);
endmodule
