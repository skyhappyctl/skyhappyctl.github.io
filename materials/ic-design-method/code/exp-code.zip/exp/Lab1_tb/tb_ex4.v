// ------------------------------------------------------------
// ex4所用tb
// 全部修复后打印 *** ALL PASS ***
// ------------------------------------------------------------
`timescale 1ns/1ps
module tb_Mon4_clr;
  reg        clk, rst_n, en, clr;
  reg  [3:0] d;
  wire [3:0] val;
  wire       alarm, tick;
  integer    errors;
  reg  [3:0] exp;

  Mon_4 M1 (val, alarm, tick, d, en, clr, clk, rst_n);

  always #5 clk = ~clk;

  always @(posedge clk or negedge rst_n)
    if (!rst_n)   exp <= 4'd0;
    else if (clr) exp <= 4'd0;
    else if (en)  exp <= d;
    else          exp <= exp;

  task chk(input [8*12-1:0] tag);
    begin
      if (val !== exp) begin
        errors = errors + 1;
        $display ("FAIL %0s t=%0t: val=%0d exp=%0d (en=%b clr=%b d=%0d)",
                  tag, $time, val, exp, en, clr, d);
      end
    end
  endtask

  initial begin
    clk = 0;  rst_n = 0;  en = 0;  clr = 0;  d = 4'd9;  errors = 0;
    #12 rst_n = 1;

    @(posedge clk);  #2;  en = 1;  d = 4'd9;      // 装载 9
    @(posedge clk);  #1;  chk ("load");

    @(posedge clk);  #2;  en = 0;                 // en=0 保持
    @(posedge clk);  #1;  chk ("hold");
    @(posedge clk);  #1;  chk ("hold");

    @(posedge clk);  #2;  clr = 1;  d = 4'd3;     
    @(posedge clk);  #1;  chk ("clr_en0");
    @(posedge clk);  #2;  clr = 0;
    @(posedge clk);  #1;  chk ("after_clr");

    @(posedge clk);  #2;  en = 1;  d = 4'd5;      // 清零后重新装载
    @(posedge clk);  #1;  chk ("reload");

    @(posedge clk);  #2;  clr = 1;  d = 4'd7;     
    @(posedge clk);  #1;  chk ("clr_en1");
    @(posedge clk);  #2;  clr = 0;  en = 0;
    @(posedge clk);  #1;  chk ("final");

    if (errors == 0) $display ("*** ALL PASS ***");
    else             $display ("*** %0d ERRORS ***", errors);
    $finish;
  end

  initial $monitor ($time, " en=%b clr=%b d=%0d | val=%0d exp=%0d",
                    en, clr, d, val, exp);
endmodule
