// ------------------------------------------------------------
// 测试平台 t_Seq_Rec_3_1s_Mealy
// 位流（En=1 期间，每 10ns 一位）：1 1 1 1 0 1 0 1 1 0 1 1 1 0
// ------------------------------------------------------------
`timescale 1ns/1ps
module t_Seq_Rec_3_1s_Mealy;
  reg  D_in, En, clk, reset;
  wire D_out;

  Seq_Rec_3_1s_Mealy M1 (D_out, D_in, En, clk, reset);

  always #5 clk = ~clk;          // 上升沿 5,15,25…；下降沿 10,20,30…

  initial begin
    reset = 1;  En = 0;  D_in = 0;  clk = 0;
    #12 reset = 0;
    #3  En   = 1;                  // t=15 起使能
    #10 D_in = 1;                  // b1  t=25
    #10 D_in = 1;                  // b2
    #10 D_in = 1;                  // b3  ← 命中（第 3 个连续 1）
    #10 D_in = 1;                  // b4  ← 命中（第 4 个连续 1，重叠保持）
    #10 D_in = 0;                  // b5
    #10 D_in = 1;                  // b6
    #10 D_in = 0;                  // b7  "1 0 1 1"：不应命中
    #10 D_in = 1;                  // b8  
    #10 D_in = 1;                  // b9  
    #10 D_in = 0;                  // b10
    #10 D_in = 1;                  // b11
    #10 D_in = 1;                  // b12
    #10 D_in = 1;                  // b13 ← 命中
    #10 D_in = 0;                  // b14
    #10 $finish;
  end

  initial $monitor ($time, " reset=%b En=%b D_in=%b state=%0d D_out=%b",
                    reset, En, D_in, M1.state, D_out);
endmodule
