module coded_lock(rstn,clk,key,dout);  //Input the three digit passwords 9, 3 and 1 in sequence, and output a positive pulse when the password is correct. 
    input wire clk;
    input wire rstn;
    input wire[3:0] key;
    output reg dout;

    localparam IDLE = 2'b00;
    localparam S1   = 2'b01; 
    localparam S2   = 2'b10; 
    localparam S3   = 2'b11; 

    reg [1:0] state, next_state;


    always@(posedge clk or negedge rstn) begin
        if(rstn==1'b0)
            state <= IDLE;
        else 
            state <= next_state;
    end
    
    always @(*) begin
        next_state = state;
        case (state)
            IDLE:begin
                if(k==4'd9) next_state = S1;
            end
            S1:begin
                if(k==4'd3) next_state = S2;
                else if(k==4'd9) next_state = S1;
                else next_state = IDLE;
            end
            S2:begin
                if(k==4'd1) next_state = S3;
                else if(k == 4'd9) next_state = S1;
                else next_state = IDLE;
            end
            S3:begin
                next_state = IDLE;
            end
            default: next_state = IDLE;
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            dout <= 1'b0;
        end else begin
            if (state == S3)
                dout <= 1'b1;
            else
                dout <= 1'b0;
        end
    end
endmodule