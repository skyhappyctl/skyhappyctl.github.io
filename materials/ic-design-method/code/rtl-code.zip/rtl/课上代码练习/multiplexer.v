module multiplexer(data_0,data_1,data_2,data_3,select,mux_int,enable,mux_out)
    input wire[31:0] data_0;
    input wire[31:0] data_1;
    input wire[31:0] data_2;
    input wire[31:0] data_3;
    input wire[1:0] select;
    input wire enable;
    output wire[31:0] mux_out;

    reg [31:0] mux_int;

    always@(*) begin
        case(select)
            2'b00:mux_int = data_0;
            2'b01:mux_int = data_1;
            2'b02:mux_int = data_2;
            2'b03:mux_int = data_3;
            default:mux_int = 32'b0;
        endcase
    end

    assign mux_out = enable?mux_int:32'bz;

endmodule