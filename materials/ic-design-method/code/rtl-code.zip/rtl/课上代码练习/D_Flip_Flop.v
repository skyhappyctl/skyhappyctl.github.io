module D_Flip_Flop(D,clk,rstn,Q,QN);
    input wire D;
    input wire clk;
    input wire rstn;
    output wire Q;
    output wire QN;

    always@(posedge clk or posedge rstn)    begin
        if(rstn == 0) begin
            Q<=0;
        end
        else begin
            Q<=D;
        end
    end

    assign QN = ~Q;

endmodule