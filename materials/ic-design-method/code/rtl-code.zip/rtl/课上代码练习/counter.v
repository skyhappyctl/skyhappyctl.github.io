module counter(clk,reset,Data_in,count_up,counter_on,count,load);

input wire[2:0] Data_in;
input wire reset;
input wire clk;
input wire load;
input wire counter_on;
input wire count_up;
output wire[2:0] count;

always@(posedge clk or posedge reset) begin
    if(reset==1'b1) begin
        count <=3'b0;
    end
    else if(load == 1'b1) begin
        count <= Data_in;
    end
    else if(counter_on == 1'b) begin
        if(count_up == 1'b1) begin
            count <= count + 1'b1;
        end
        else begin
            count <= count - 1'b1;
        end
    end
end

endmodule