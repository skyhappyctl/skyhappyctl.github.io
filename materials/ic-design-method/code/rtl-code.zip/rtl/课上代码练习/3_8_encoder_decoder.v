module encoder_8_to_3(data,code);
	input wire[7:0] data;
	output reg[2:0] code;

	always @(*) begin
		case (data)
            8'b00000001: code = 3'b000;
            8'b00000010: code = 3'b001;
            8'b00000100: code = 3'b010;
            8'b00001000: code = 3'b011;
            8'b00010000: code = 3'b100;
            8'b00100000: code = 3'b101;
            8'b01000000: code = 3'b110;
            8'b10000000: code = 3'b111;
            default:     code = 3'b000; 
        endcase
	end
end module

module decoder_3_to_8(code,data);
    input  wire [2:0] code;
    output reg  [7:0] data;

    always @(*) begin
        case (code)
            3'b000: data = 8'b00000001;
            3'b001: data = 8'b00000010;
            3'b010: data = 8'b00000100;
            3'b011: data = 8'b00001000;
            3'b100: data = 8'b00010000;
            3'b101: data = 8'b00100000;
            3'b110: data = 8'b01000000;
            3'b111: data = 8'b10000000;
            default: data = 8'b00000000; 
        endcase
    end

end module