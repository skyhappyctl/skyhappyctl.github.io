module three_state_gate(a,b,enable);
    input wire a;
    input wire enable;
    output wire b;

    assign b = enable?a:1'bz;
endmodule