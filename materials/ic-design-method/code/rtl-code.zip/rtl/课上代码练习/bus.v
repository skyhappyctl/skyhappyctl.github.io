module unidirectional_bus(ckt_to_bus,bus_enable,data_to_bus);
    input wire[31:0] ckt_to_bus;
    input wire bus_enable;
    output wire[31:0] data_to_bus;

    assign data_to_bus = bus_anble?ckt_to_bus:32'bz;
endmodule

module bidirectional_bus(ckt_to_bus,send_data,rcv_data,data_from_bus,data_to_from_bus);
    input wire[31:0] ckt_to_bus;
    input wire send_data;
    input wire rcv_data;
    output wire[31:0] data_from_bus;
    inout wire[31:0] data_to_from_bus;


    assign data_from_bus = rcv_data?data_to_from_bus:32'bz;
    assign data_to_from_bus = send_data?ckt_to_bus:32'bz;

endmodule