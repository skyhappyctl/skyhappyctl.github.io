# %%
# 本次实验包括后量化的过程，主要在于学习如何对DNN的权重（weight）和激活层（activation）进行量化。

# %%
# 引用外部软件包
import torch # pytorch包
import torchvision # torchvision是pytorch官方提供的工具，包含很多常用数据集的封装等
import torchvision.transforms as transforms
import torch.nn as nn # nn 和下面的F均包含了主要的神经网络模块，包括卷积层、全连接层、池化层等等
import torch.nn.functional as F
import torch.optim as optim # 优化器

# %%
# 确保device为gpu，否则会花费过长时间。
if torch.cuda.is_available():
    torch.cuda.set_device(0)
    device = "cuda"
else:
    device = torch.device('cpu')


# %%
# Load training and test data from the CIFAR10 dataset.
# torchvision是pytorch官方集成的工具库，包括学界常用的数据集和数据预处理方式。
transform = transforms.Compose(
    [transforms.ToTensor(), # 将数据归一化，并转换成tensor的形式
     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]) # 预处理数据的方式，normalize是将图像进行规则化。

trainset = torchvision.datasets.CIFAR10(root='C:/Users/local-user/Desktop/学校的破事/作业/数字系统设计/lab1/dataset/cifar10', train=True,
                                        download=True, transform=transform) #定义了训练集，path是训练数据所在地址。
trainloader = torch.utils.data.DataLoader(trainset, batch_size=4,
                                          shuffle=True, num_workers=2) #定义数据迭代器，batchsize为一次迭代训练，送进去图像的数量（可以尝试调整，看看会发生什么）。shuffle表示要不要打乱训练图像的排序。

testset = torchvision.datasets.CIFAR10(root='C:/Users/local-user/Desktop/学校的破事/作业/数字系统设计/lab1/dataset/cifar10', train=False,
                                       download=True, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=4,
                                         shuffle=False, num_workers=2)

# %%
# Define a simple CNN that classifies CIFAR images.
# The network provided is similar to LeNet-5, and it has the following architecture:

# **Layer** |     **Type**    | **Input Shape** | **Output Shape** | **Activation**
#   conv1   |  Convolutional  |     3x32x32     |     6x28x28      |      ReLU 
#   pool1   |     Max pool    |     6x28x28     |     6x14x14      |      None                
#   conv2   |  Convolutional  |     6x14x14     |     16x10x10     |      ReLU                
#   pool2   |     Max pool    |     16x10x10    |     16x5x5       |      None                
#   fc1     | Fully-connected |       400       |       120        |      ReLU                
#   fc2     | Fully-connected |       120       |       84         |      ReLU                
#   fc3     | Fully-connected |       84        |       10         |      None                

# None of the layers in the network have a bias associated with them.
# This makes them easier to quantize.
# Towards the end of this assignment, we will add biases to the final layer and quantize it as well.

# %%
# 重新定义conv函数与fc函数
import math
def TorchRound():
    """
    Apply STE to clamp function.
    """
    class identity_quant(torch.autograd.Function):
        @staticmethod
        def forward(ctx, input):
            out = torch.round(input)
            return out

        @staticmethod
        def backward(ctx, grad_output):
            return grad_output

    return identity_quant().apply

def quant_max(tensor):
    """
    Returns the max value for symmetric quantization.
    """
    return torch.abs(tensor.detach()).max() + 1e-8 # 防止除0的情况出现

class quant_weight(nn.Module):
    """
    Quantization function for quantize weight with maximum.
    """

    def __init__(self, k_bits=8):
        super(quant_weight, self).__init__()
        self.k_bits = k_bits
        self.qmax = 2. ** (k_bits -1) - 1.
        self.round = TorchRound()

    def forward(self, input):
        max_val = quant_max(input)
        weight = input * self.qmax / max_val
        q_weight = self.round(weight)
        q_weight = q_weight * max_val / self.qmax  # 通过这种方式引入量化误差，从而实现QAT
        #q_weight = self.round(q_weight)
        return q_weight

class QuantConv2d(nn.Module):
    """
    A convolution layer with quantized weight.
    """

    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                    padding=0, dilation=1, groups=1, bias=False, k_bits=8): # 默认使用bias=False的情况
        super(QuantConv2d, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(out_channels,in_channels,kernel_size,kernel_size))
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.in_channels = in_channels
        self.kernel_size = (kernel_size, kernel_size)
        self.bias_flag = bias
        if self.bias_flag:
            self.bias = nn.Parameter(torch.Tensor(out_channels))
            nn.init.constant_(self.bias)
        else:
            self.register_parameter('bias', None)
        self.k_bits = k_bits
        self.quant_weight = quant_weight(k_bits = k_bits)
        self.output = None
        nn.init.kaiming_normal_(self.weight) # 初始化参数
        

    def forward(self, input, order=None):
        return F.conv2d(input, self.quant_weight(self.weight), self.bias, self.stride, self.padding, self.dilation, self.groups)

class QuantFC(nn.Module):
    """
    A Fully Connected layer with quantized weight.
    """

    def __init__(self, in_features, out_features, bias=False, k_bits=8): # 默认使用bias=False的情况
        super(QuantFC, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(out_features, in_features))
        self.bias_flag = bias
        if self.bias_flag:
            self.bias = nn.Parameter(torch.Tensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.k_bits = k_bits
        self.quant_weight = quant_weight(k_bits = k_bits)
        nn.init.kaiming_normal_(self.weight) # 初始化参数，何恺明发明


    def forward(self, input, order=None):
        return F.linear(input, self.quant_weight(self.weight), self.bias)

# %%
class quant_act(nn.Module):
    """
    Quantization function for quantize activation with parameterized max scale.
    """
    def __init__(self, k_bits=8, decay=0.995):
        super(quant_act, self).__init__()
        self.k_bits = k_bits
        self.qmax = 2. ** (self.k_bits -1) -1.
        self.round = TorchRound()
        self.decay = decay #平滑因子，用于EMA，能够更敏感地反映最新的数据变化
        self.alpha = nn.Parameter(torch.Tensor(10))   #将激活值限制在 [-alpha, alpha] 范围内，避免异常值破坏量化。
        self.register_buffer('max_val', torch.ones(1))

    def _ema(self, x):   #通过指数移动平均（EMA）跟踪激活值的最大绝对值范围
        act = x.reshape(x.shape[0], -1)
        # print(act.shape)
        max_val = torch.mean(torch.max(act, dim=1)[0])

        self.max_val = (1.0-self.decay) * max_val + self.decay * self.max_val 

    def forward(self, x):
        act = x
        self._ema(x)
        self.alpha.data = self.max_val.unsqueeze(0)
        act = torch.max(torch.min(x, self.alpha), -self.alpha)
        
        act = act * self.qmax / self.alpha  
        q_act = self.round(act)
        q_act = q_act * self.alpha / self.qmax  # 引入量化误差
        #q_act = self.round(q_act)
    
        return q_act

# %%
# 网络定义，conv2d是卷积层，linear是全连接层。forward下定义了计算图，显示送进来的图像（x）会怎么处理。
class Net(nn.Module):
    #网络结构:2层卷积层、1层最大值池化层、3层全连接层，留意这些参数的内涵
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = QuantConv2d(3, 64, 3, padding='same', bias=False)
        self.pool = nn.MaxPool2d(2, 2) # run after each conv (hence the 3x3 FC layer)   16x16
        self.conv2 = QuantConv2d(64, 64, 3, padding='same', bias=False)
        self.conv3 = QuantConv2d(64, 64, 3, padding='same', bias=False)
        self.conv4 = QuantConv2d(64, 64, 3, padding='same', bias=False)
        self.conv5 = QuantConv2d(64, 64, 3, padding='same', bias=False)
        self.conv6 = QuantConv2d(64, 128, 3, padding=1, stride = 2, bias=False)    #8x8
        self.conv7 = QuantConv2d(128, 128, 3, padding='same', bias=False)
        self.conv8 = QuantConv2d(64, 128, 1, stride = 2, bias=False)
        self.pool2 = nn.AvgPool2d(2,2)
        self.fc1 = QuantFC(128 * 4 * 4, 128, bias=False)
        self.fc2 = QuantFC(128, 10, bias=False)

        self.quant_act1 = quant_act(k_bits=8) # activation for 8 bit
        self.quant_act2 = quant_act(k_bits=8)
        self.quant_act3 = quant_act(k_bits=8)
        self.quant_act4 = quant_act(k_bits=8)
        self.quant_act5 = quant_act(k_bits=8)
        self.quant_act6 = quant_act(k_bits=8)
        self.quant_act7 = quant_act(k_bits=8)
        self.quant_act8 = quant_act(k_bits=8)
        self.quant_act9 = quant_act(k_bits=8)
        
    #定义前向传播,将tensor数据送入网络之后的计算图
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = self.quant_act1(x)

        temp = x
        x = F.relu(self.conv2(x))
        temp = self.quant_act2(temp)
        x = self.quant_act2(x)
        x = F.relu(self.conv3(x))
        temp = self.quant_act3(temp)
        x = self.quant_act3(x)
        x = x + temp
        

        temp = x
        x = F.relu(self.conv4(x))
        temp = self.quant_act4(temp)
        x = self.quant_act4(x)
        x = F.relu(self.conv5(x))
        temp = self.quant_act5(temp)
        x = self.quant_act5(x)
        x = x + temp

        temp = x
        x = F.relu(self.conv6(x))
        temp = self.quant_act6(temp)
        x = self.quant_act6(x)
        x = F.relu(self.conv7(x))
        temp = self.quant_act7(temp)
        x = self.quant_act7(x)
        temp = F.relu(self.conv8(temp))
        temp = self.quant_act8(temp)
        x = self.quant_act8(x)
        x = x + temp

        x = self.pool2(x)

        x = x.view(-1, 128 * 4 * 4)
        x = F.relu(self.fc1(x))
        x = self.quant_act9(x)
        x = self.fc2(x)
        
        return x
    
net = Net().to(device)
# 到这里，我们定义好了网络和数据集的使用方式

# %%
from torch.utils.data import DataLoader
#将训练集的dataloader送入网络进行训练,每次读取batchsize数量的数据
def train(model: nn.Module, dataloader: DataLoader):
    criterion = nn.CrossEntropyLoss() # loss function（交叉熵损失函数）
    optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9) #optimizer，使用SGD优化器训练，第一个参数表示model的所有参数都会参与训练，学习率为0.001，动量为0.9

    for epoch in range(2):  # loop over the dataset multiple times。epoch指遍历所有训练集图像的次数。这里遍历所有训练图像三次

        running_loss = 0.0
        for i, data in enumerate(dataloader, 0): # dataloader是数据迭代器，从这里每次读出batchsize数量的数据。
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data

            inputs = inputs.to(device)
            labels = labels.to(device)

            # zero the parameter gradients
            optimizer.zero_grad()
            
            # forward + backward + optimize
            outputs = model(inputs) # 将数据送进网络，得到结果
            loss = criterion(outputs, labels) # 计算结果和标签的交叉熵损失函数
            loss.backward() # 基于上述损失函数求解梯度
            optimizer.step() # 更新参数

            # print statistics
            running_loss += loss.item() # 将loss的值取出来，记录其变化
            if i % 2000 == 1999:    # print every 2000 mini-batches
                print('[%d, %5d] loss: %.3f' %
                    (epoch + 1, i + 1, running_loss / 2000))
                running_loss = 0.0

    print('Finished Training')

def test(model: nn.Module, dataloader: DataLoader, max_samples=None) -> float:
    correct = 0
    total = 0
    n_inferences = 0

    with torch.no_grad(): # 测试时不用求解梯度，因此可以设置不计算梯度的模式
        for data in dataloader:
            images, labels = data

            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images) # get 1 batch worth of image predictions (i.e. 4 predictions of 10 each)
            other, predicted = torch.max(outputs.data, 1) # other == values, predicted == indicies
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            if max_samples:
                n_inferences += images.shape[0]
                if n_inferences > max_samples:
                    break
    
    return 100 * correct / total

# %%
train(net, trainloader) # 进行训练，将网络定义和数据迭代器传给train函数。

# %%
# Now that the CNN has been trained, let's test it on our test dataset.
score = test(net, testloader)
print('Accuracy of the network on the test images: {}%'.format(score))

# %%
# Define a convenience function which we use to copy CNN's.
from copy import deepcopy

def copy_model(model: nn.Module) -> nn.Module:
    result = deepcopy(model)

    # Copy over the extra metadata we've collected which copy.deepcopy doesn't capture
    if hasattr(model, 'input_activations'):
        result.input_activations = deepcopy(model.input_activations)

    for result_layer, original_layer in zip(result.children(), model.children()):
        if isinstance(result_layer, nn.Conv2d) or isinstance(result_layer, nn.Linear):
            if hasattr(original_layer.weight, 'scale'):
                result_layer.weight.scale = deepcopy(original_layer.weight.scale)
            if hasattr(original_layer, 'activations'):
                result_layer.activations = deepcopy(original_layer.activations)
            if hasattr(original_layer, 'output_scale'):
                result_layer.output_scale = deepcopy(original_layer.output_scale)

    return result

# %%
# Visualize Weights

# %%
import matplotlib.pyplot as plt
import numpy as np

name = ['conv1', 'conv2', 'conv3', 'conv4', 'conv5', 'conv6', 'conv7', 'conv8', 'fc1', 'fc2']
n = 0

for layer in net.children(): # 遍历类的成员
    if isinstance(layer, QuantConv2d) or isinstance(layer, QuantFC):
        weight = layer.weight.data.cpu().view(-1).numpy()
        print(name[n] + ": the range is [{:.5f}, {:.5f}]".format(weight.min(), weight.max()))

        # find 3-sigma range (u-3s, u+3s), 该范围能囊括99.73%参数
        sigma3 = int(np.size(weight)*0.0027) 
        sigma3_value = np.abs(weight)[np.argpartition(np.abs(weight), -sigma3)[-sigma3]]
        print(name[n] + ": the 3-sigma range is [{:.5f}, {:.5f}]".format(max(-sigma3_value, weight.min()), min(sigma3_value,weight.max())))

        plt.hist(weight, bins=50, facecolor="blue", edgecolor="black", alpha=0.7) # 画直方图
        plt.xlabel("range")
        plt.ylabel("frequency")
        plt.title(name[n])
        plt.show()
        n += 1
        
# You can get a flattened vector of the weights of fc1 like this:
#   fc1_weights = net.fc1.weight.data.cpu().view(-1)

# %%
score = test(net, testloader)
print('Accuracy of the quantized network on the test images: {}%'.format(score))


