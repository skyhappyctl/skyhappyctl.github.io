`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/28 10:25:30
// Design Name: 
// Module Name: _1_N_systolic_array
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module _1_N_systolic_array #(
    parameter BW_ACT     =   8,  // bit length of activation
    parameter BW_WET     =   8,  // bit length of weight
    parameter BW_ACCU    =   32,    // bit length of accu result  
    parameter COL_NUM    =   1,     //M   
    parameter ROW_NUM    =   10,  // N,number of multiply-accumulation units
    parameter Input_act_size = 100
        )(
    input        clk,
    input        rst_n,
    // // control signal
    input                        PE_mac_enable,      // high active
    input       [ROW_NUM-1:0]    PE_clear_acc       [COL_NUM-1:0] ,
    input                        PE_weight_update   [COL_NUM-1:0],       

    // data signal 
    input   signed     [BW_ACT-1:0]    PE_act_in [ROW_NUM-1:0] ,         // input activation
    input   signed     [BW_WET-1:0]    PE_wet_in [ROW_NUM-1:0][COL_NUM-1:0],         // input weight
    input               [7:0]           PE_res_shift_num,
    output  signed [BW_ACCU-1:0]   final_result_out_wo_quan [COL_NUM-1:0],     // output result
    output  signed [BW_ACT - 1 : 0]  final_result_out_with_quan [COL_NUM - 1 : 0],  //output result
    output  PE_waiting [ROW_NUM-1:0][COL_NUM-1:0] 
    );
    
    wire signed [BW_ACCU-1:0]   PE_pp_out [ROW_NUM-1:0][COL_NUM-1:0];     // internal output result
    wire signed [BW_ACT-1:0]   PE_act_out [ROW_NUM-1:0][COL_NUM-1:0];       


    genvar i;
    genvar j;
    generate 
        for(j=0;j<COL_NUM;j=j+1) begin: _1_N_systolic_array
            for(i=0;i<ROW_NUM;i=i+1) begin
                if(j == 0) begin
                    if(i==0) begin
                        systolic_mac_cell#(
                        .BW_ACT(BW_ACT),
                        .BW_WET(BW_WET),
                        .BW_ACCU(BW_ACCU),
                        .ROW_NUM(ROW_NUM),
                        .Input_act_size(Input_act_size)      
                        ) uut(
                        .clk(clk),
                        .rst_n(rst_n),
                        .PE_mac_enable(PE_mac_enable),
                        .PE_clear_acc(PE_clear_acc[j][i]),
                        .PE_weight_update(PE_weight_update[j]),
                        .PE_act_in(PE_act_in[i]),
                        .PE_wet_in(PE_wet_in[i][j]),
                        .PE_pp_in(0),
                        .PE_pp_out(PE_pp_out[i][j]),
                        .PE_act_out(PE_act_out[i][j]),
                        .PE_waiting(PE_waiting[i][j])
                        );
                    end
                    else begin
                    systolic_mac_cell #(
                        .BW_ACT(BW_ACT),
                        .BW_WET(BW_WET),
                        .BW_ACCU(BW_ACCU),
                        .ROW_NUM(ROW_NUM),
                        .Input_act_size(Input_act_size)      
                        ) uut(
                        .clk(clk),
                        .rst_n(rst_n),
                        .PE_mac_enable(PE_mac_enable),
                        .PE_weight_update(PE_weight_update[j]),
                        .PE_clear_acc(PE_clear_acc[j][i]),
                        .PE_act_in(PE_act_in[i]),
                        .PE_wet_in(PE_wet_in[i][j]),
                        .PE_pp_in(PE_pp_out[i-1][j]),
                        .PE_pp_out(PE_pp_out[i][j]),
                        .PE_act_out(PE_act_out[i][j]),
                        .PE_waiting(PE_waiting[i][j])
                        );
                    end
                end
            else begin
                if(i==0) begin
                     systolic_mac_cell #(
                        .BW_ACT(BW_ACT),
                        .BW_WET(BW_WET),
                        .BW_ACCU(BW_ACCU),
                        .ROW_NUM(ROW_NUM),
                        .Input_act_size(Input_act_size)      
                        ) uut(
                        .clk(clk),
                        .rst_n(rst_n),
                        .PE_mac_enable(PE_mac_enable),
                        .PE_clear_acc(PE_clear_acc[j][i]),
                        .PE_weight_update(PE_weight_update[j]),
                        .PE_act_in(PE_act_out[i][j-1]),
                        .PE_wet_in(PE_wet_in[i][j]),
                        .PE_pp_in(0),
                        .PE_pp_out(PE_pp_out[i][j]),
                        .PE_act_out(PE_act_out[i][j]),
                        .PE_waiting(PE_waiting[i][j])
                        );
                end
                else begin
                     systolic_mac_cell #(
                        .BW_ACT(BW_ACT),
                        .BW_WET(BW_WET),
                        .BW_ACCU(BW_ACCU),
                        .ROW_NUM(ROW_NUM),
                        .Input_act_size(Input_act_size)      
                        ) uut(
                            .clk(clk),
                            .rst_n(rst_n),
                            .PE_mac_enable(PE_mac_enable),
                            .PE_clear_acc(PE_clear_acc[j][i]),
                            .PE_weight_update(PE_weight_update[j]),
                            .PE_act_in(PE_act_out[i][j-1]),
                            .PE_wet_in(PE_wet_in[i][j]),
                            .PE_pp_in(PE_pp_out[i-1][j]),
                            .PE_pp_out(PE_pp_out[i][j]),
                            .PE_act_out(PE_act_out[i][j]),
                            .PE_waiting(PE_waiting[i][j])
                            );
                end
            end
        end
    end
endgenerate


generate 
    for(i=0;i<COL_NUM;i=i+1) begin
        assign final_result_out_wo_quan[i] = PE_pp_out[ROW_NUM-1][i];
        assign final_result_out_with_quan[i] = 
                    (PE_pp_out[ROW_NUM-1][i] >>> PE_res_shift_num > 127) ? 127 : 
                    ((PE_pp_out[ROW_NUM-1][i] >>> PE_res_shift_num < -128) ? -128 : 
                    (PE_pp_out[ROW_NUM-1][i] >>> PE_res_shift_num));                 
    end
endgenerate
endmodule
