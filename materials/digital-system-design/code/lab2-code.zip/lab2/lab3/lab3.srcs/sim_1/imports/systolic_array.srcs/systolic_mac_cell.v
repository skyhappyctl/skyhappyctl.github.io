`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/28 10:07:48
// Design Name: 
// Module Name: systolic_mac_cell
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module systolic_mac_cell #(
	parameter BW_ACT     =   8,  // bit length of activation
    parameter BW_WET     =   8,  // bit length of weight
    parameter BW_ACCU    =   32,    // bit length of accu result 
    parameter Input_act_size = 100,   
    parameter ROW_NUM    =   15
    )(
    input           clk,
    input           rst_n,              //low active
    //control signal
    input           PE_mac_enable,      // high active
    input           PE_clear_acc,
    input           PE_weight_update,
           
    // data signal 
    input   signed     [BW_ACT-1:0]    PE_act_in,         // input activation
    input   signed     [BW_WET-1:0]    PE_wet_in,         // input weight
    input   signed     [BW_ACCU-1:0]   PE_pp_in,          // input partial_product
    output  reg signed [BW_ACCU-1:0]   PE_pp_out,      // output result  
    output  reg signed [BW_ACT-1:0]    PE_act_out,
    output  reg                        PE_waiting     
    );
    
    //buffer
    reg signed [BW_ACT - 1 : 0]    PE_act_in_buffer;             // input buffer
    reg signed [BW_WET - 1 : 0]    PE_wet_in_buffer;             // weight buffer
    reg PE_clear_acc_buffer;                                //clear accumlation buffer
    reg [31:0]  PE_cycle_count = 0;
    
    integer total_cycle = Input_act_size + ROW_NUM - 1;

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            PE_act_in_buffer <= 0;
            PE_wet_in_buffer <= 0;
            PE_clear_acc_buffer <= 0;
            PE_pp_out <= 0;
            PE_act_out <= 0;
            PE_cycle_count <= 0;
            PE_waiting <= 0;
        end 
        else begin
            PE_act_in_buffer <= PE_act_in;
            PE_act_out <= PE_act_in_buffer;
            PE_clear_acc_buffer <= PE_clear_acc;
            if (PE_weight_update) begin
                PE_wet_in_buffer <= PE_wet_in;
                PE_cycle_count = 0;
                PE_waiting <= 0;
            end
            else begin
                PE_wet_in_buffer <= PE_wet_in_buffer;
            end            
            if(PE_mac_enable) begin
                if(PE_clear_acc_buffer) begin
                    PE_pp_out <= 0;
                    PE_cycle_count <= 0;
                end
                else begin
                    if (PE_cycle_count <= total_cycle) begin
                        PE_pp_out <= PE_pp_in + PE_wet_in_buffer * PE_act_in_buffer;           //MAC operation
                        PE_cycle_count <= PE_cycle_count + 1;
                        PE_waiting <= 0;
                    end
                    else begin
                        PE_waiting <= 1;
                    end
                end
            end
            else begin
                PE_pp_out <= PE_pp_out;
            end
        end
    end
    
    
endmodule

