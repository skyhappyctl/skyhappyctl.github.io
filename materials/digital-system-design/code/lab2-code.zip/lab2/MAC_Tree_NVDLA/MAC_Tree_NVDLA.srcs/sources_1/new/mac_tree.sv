`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/23 23:51:29
// Design Name: 
// Module Name: mac_tree
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mac_tree #(
	parameter BW_ACT = 8,        // bit length of activation
    parameter BW_WET = 8,        // bit length of weight
    parameter BW_ACCU = 32,       // bit length of accu result    
    parameter CELL_NUM = 10,      // the number of trees
    parameter INPUT_NUM = 8    // the number of input group in one tree
)(
    input        clk,
    input        rst_n,             //low active
    
    //  control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,      
    
    // data signal 
    input   reg signed     [BW_ACT-1:0]    PE_act_in [CELL_NUM*INPUT_NUM-1:0],                 // input activation
    input   reg signed     [BW_WET-1:0]    PE_wet_in [INPUT_NUM-1:0],                           // input weight
    input                   [7:0]           PE_res_shift_num,
    output  reg signed     [BW_ACT-1:0]    PE_result_out [CELL_NUM-1:0]                           // output result   
);

    reg signed                 PE_clear_acc_buffer;
    reg signed [BW_ACT-1:0]    PE_act_in_buffer [CELL_NUM*INPUT_NUM-1:0];
    reg signed [BW_WET-1:0]    PE_wet_in_buffer [INPUT_NUM-1:0];                              
    reg signed [BW_ACCU-1:0]   Products      [CELL_NUM-1:0];  

    integer N = $clog2(INPUT_NUM);
    
    
    // 数据信号因需要存入buffer而延后了 1 cycle，该控制信号也延后 1 cycle
    always @(posedge clk or negedge rst_n) begin
        if(~rst_n) begin 
            PE_clear_acc_buffer <= '0;
        end
        else begin
            PE_clear_acc_buffer <= PE_clear_acc;
        end         
    end

    genvar gv_i;
 
    generate
        for (gv_i = 0; gv_i < INPUT_NUM; gv_i = gv_i + 1) begin : MAC_UNIT
            
            integer cnt = INPUT_NUM;
            wire signed [BW_ACCU-1:0] output_temp;
            reg  signed [BW_ACCU-1:0] Partial_Products[2*INPUT_NUM-2:0];
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin // reset
                    for (integer j = 0; j < INPUT_NUM; j = j + 1) begin
                        PE_act_in_buffer[gv_i*INPUT_NUM+j] <= '0;
                        PE_wet_in_buffer[j] <= '0;
                    end
                end
                else begin
                    for (integer j = 0; j <INPUT_NUM; j = j + 1) begin
                        PE_act_in_buffer[gv_i * INPUT_NUM + j] <= PE_act_in[gv_i * INPUT_NUM + j];     
                        PE_wet_in_buffer[j] <= PE_wet_in[j];
                    end
                end
            end
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin // reset
                    Products[gv_i] <= '0;
                end
                else if(~PE_mac_enable) begin // hold
                    Products[gv_i] <= Products[gv_i];
                end
                else if(PE_clear_acc_buffer) begin     //clear
                    Products[gv_i] <= '0;
                end
                else begin // enable and not clear, doing the MAC
                    for(integer j = N; j >= 0; j = j - 1) begin
                        for (integer k = 0; k < INPUT_NUM; k = k + 1) begin
                            Partial_Products[k] = PE_act_in_buffer[gv_i * INPUT_NUM + k] * PE_wet_in_buffer[k];
                        end
                        for (integer j = INPUT_NUM - 2; j >= 0; j = j - 1) begin
                            Partial_Products[j] = Partial_Products[2 * j + 2] + Partial_Products[2 * j + 1];
                        end
                        Products[gv_i] = Products[gv_i] + Partial_Products[0];
                    end
                end
            end
            
            assign output_temp = Products[gv_i] >>> PE_res_shift_num;
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin
                    PE_result_out[gv_i] <= '0;
                end
                else if(output_temp>127) begin
                    PE_result_out[gv_i] <= 127;
                end
                else if(output_temp<-128) begin
                    PE_result_out[gv_i] <= -128;
                end
                else begin
                    PE_result_out[gv_i] <= output_temp[BW_ACT-1 : 0];  // lower 8 bit
                end
            end
        end
    endgenerate

endmodule