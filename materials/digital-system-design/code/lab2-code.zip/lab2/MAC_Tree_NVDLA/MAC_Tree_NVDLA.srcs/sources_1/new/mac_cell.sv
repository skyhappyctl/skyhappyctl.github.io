`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/23 23:51:29
// Design Name: 
// Module Name: mac_cell
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mac_cell #(
    parameter BW_ACT     =   8,  // bit length of activation
    parameter BW_WET     =   8,  // bit length of weight
    parameter BW_ACCU    =   32,    // bit length of accu result
    parameter CELL_NUM   =   10,    //the number of mac tree
    parameter INPUT_NUM  =   8,     //the number of inputs in one tree
    parameter N          =   $clog2(INPUT_NUM)      //number of input
)(
    input clk,
    input rst_n,
    // control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,
    // data signal 
    input   signed     [BW_ACT-1:0]    PE_act_in[CELL_NUM*INPUT_NUM-1:0],         //input activation
    input   signed     [BW_WET-1:0]    PE_wet_in[INPUT_NUM-1:0],         // input weight
    input              [7 : 0]         PE_res_shift_num,
    output  reg signed [BW_ACT-1:0]    PE_result_out[CELL_NUM-1:0]     // output result   
    );
        
    reg signed                     PE_clear_acc_reg;    
    reg signed [BW_ACT - 1 : 0]    PE_act_in_reg [CELL_NUM*INPUT_NUM-1 : 0];                    // input buffer
    reg signed [BW_WET - 1 : 0]    PE_wet_in_reg [INPUT_NUM-1 : 0];                              // weight buffer
    
    reg signed      [BW_ACCU-1:0]     products[N-1:0];
    
    integer i;
        
    always @(posedge clk or negedge rst_n) begin
        if(~rst_n) begin 
            PE_clear_acc_reg <= '0;
        end
        else begin
            PE_clear_acc_reg <= PE_clear_acc;
        end
    end
    
    genvar gv_i;
    generate
        for (gv_i = 0; gv_i < CELL_NUM; gv_i = gv_i + 1) begin : mac_unit
            
        
        end
    
endmodule

//        for(i=0;i<N;i=i+1) begin
       //     products[i] <= PE_act_in[i]*PE_wet_in[i];
     //   end
