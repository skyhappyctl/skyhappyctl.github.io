`timescale 1ns / 1ps
`define CLK_PERIOD 10 // 100MHz
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/12 15:57:16
// Design Name: 
// Module Name: mac_tree_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mac_tree_tb();

    parameter BW_ACT = 8;      // bit length of activation
    parameter BW_WET = 8;      // bit length of weight
    parameter BW_ACCU = 32;    // bit length of accu result  
    parameter MAC_NUM = 10;    // number of mac units
    parameter INPUT_NUM = 8;  // number of input pair for one mac tree

    parameter IA_H = 100;
    parameter IA_W = 150;
    parameter Weight_H = 150;
    parameter Weight_W = 16; 
    parameter OA_H = 100;
    parameter OA_W = 16;

    reg clk;
    reg rst_n;
    reg PE_mac_enable;
    reg PE_clear_acc;

    reg signed [BW_ACT-1:0]    PE_act_in [MAC_NUM * INPUT_NUM - 1 : 0];                // input activation
    reg signed [BW_WET-1:0]    PE_wet_in [INPUT_NUM - 1 : 0];                          // input weight
    reg  [7:0]                 PE_res_shift_num;
    wire signed [BW_ACT-1:0]   PE_result_out [MAC_NUM - 1:0];                           // output result   

    reg signed [BW_ACT-1:0]    Input_activation_main_memory[IA_H-1:0][IA_W-1:0];        // main memory (DRAM)
    reg signed [BW_ACT-1:0]    Weight_main_memory[Weight_H-1:0][Weight_W-1:0];
    reg signed [BW_ACT-1:0]    Output_activation_main_memory[OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACT-1:0]    reference_output[OA_H-1:0][OA_W-1:0];

    mac_tree #(
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU),
        .MAC_NUM(MAC_NUM),
        .INPUT_NUM(INPUT_NUM)
    )my_mac_tree(
        .clk(clk),
        .rst_n(rst_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .PE_result_out(PE_result_out)
    );


    initial begin
        forever begin
            #(`CLK_PERIOD/2) clk = ~clk; //generate the system clk
        end
    end
    
    
    

    integer wrong_ans_num = 0;
    integer correct_ans_num = 0;
    reg output_valid;
    reg data_ready;
    
    initial begin
        initialize(); 
        load_data();
        run_simulation();
        verify_output_results();
        $finish();
    end
    
    task initialize;
        begin
            clk = 0;
            rst_n = 0;
            #10;
            rst_n = 1;
            PE_res_shift_num = 8;
            PE_clear_acc = {MAC_NUM{1'b1}};
            #10;
            PE_clear_acc = 0; 
            
            for (integer m = 0; m < INPUT_NUM; m = m + 1) begin           
                for(integer n = 0; n < MAC_NUM; n = n + 1) begin
                    PE_act_in[m * MAC_NUM + n] <= '0;
                end
                PE_wet_in[m] <= '0;
            end
            for (integer m = 0; m < OA_H; m = m + 1) begin           
                for(integer n = 0; n <OA_W; n = n + 1) begin
                    Output_activation_main_memory[m][n] <= 0;
                end
            end
        end
    endtask
    
    task load_data;
        begin
             @(negedge clk); 
             rst_n = 0; // 经过一个周期，拉低reset信号
             data_ready = 0;
          // 加载任务数据
           $readmemb("C:/Users/local-user//Desktop//input_act_bin.txt", Input_activation_main_memory);
           $readmemb("C:/Users/local-user//Desktop//学校的破事//作业//数字系统设计//lab2//lab2//weight_bin.txt", Weight_main_memory);
           $readmemb("C:/Users/local-user//Desktop//学校的破事//作业//数字系统设计//lab2//lab2//reference_output_bin.txt", reference_output);
        end
        data_ready = 1;
    endtask
    
    
  task run_simulation;
        begin
        wait(data_ready);
          // loop nest
            @(negedge clk);
            rst_n = 1;
            PE_mac_enable = 1;
        
            for(integer m = 0; m < OA_W; m = m + 1) begin
                for(integer j = 0; j < IA_H / MAC_NUM; j = j + 1) begin
                    for(integer i = 0; i < (IA_W / INPUT_NUM) + 2; i = i + 1) begin
                        @(negedge clk) begin
                            if(i == 0) begin
                                PE_clear_acc <= 0; // 确保清零工作准时结束
                            end
                            for(integer n = 0; n < MAC_NUM; n = n + 1) begin // spatial for，在一个周期内完成
                                for(integer k = 0; k < INPUT_NUM; k = k + 1) begin
                                    if( i * INPUT_NUM + k < IA_W )begin
                                        PE_act_in[n * INPUT_NUM + k] <= Input_activation_main_memory[j * MAC_NUM + n][i * INPUT_NUM + k];
                                        PE_wet_in[k] <= Weight_main_memory[i * INPUT_NUM + k][m];
                                    end
                                    else begin
                                        PE_act_in[n * INPUT_NUM + k] <= 0;          //padding
                                        PE_wet_in[k] <= 0;               //padding
                                    end
                                end
                            end
                        end
                    end
                    
                    @(negedge clk) begin
                        PE_clear_acc <= 1;
                    end
                    @(negedge clk); // 结果输出会经过两个周期，因此再打一拍延时
                    
                    @(negedge clk) begin
                        for(integer n = 0; n < MAC_NUM; n = n + 1) begin
                            Output_activation_main_memory[j * MAC_NUM + n][m] <= PE_result_out[n];
                        end
                    end
                end
            end
        end
        output_valid = 1;
       endtask
              
      task verify_output_results;
          begin
              wait(output_valid);
              for(integer k = 0; k < OA_H; k = k + 1) begin
                  for(integer p = 0; p < OA_W; p = p + 1) begin
                      if(Output_activation_main_memory[k][p]!=reference_output[k][p]) begin
                          $display("wrong at (%d %d), output %d, reference %d", k, p, Output_activation_main_memory[k][p], reference_output[k][p]);
                          wrong_ans_num = wrong_ans_num + 1;
                      end
                      else begin
                           $display("The (%d %d) answer is correct! , output %d, reference %d", k, p, Output_activation_main_memory[k][p], reference_output[k][p]);
                           correct_ans_num = correct_ans_num + 1;
                       end
                  end
              end
              $display("wrong answer num: %d",wrong_ans_num);
              $display("correct answer num: %d",correct_ans_num);
              @(negedge clk)
              $finish(0);
          end
      endtask
    

endmodule
