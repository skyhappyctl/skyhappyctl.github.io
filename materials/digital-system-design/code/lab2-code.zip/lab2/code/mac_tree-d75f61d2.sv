`timescale 1ns/1ps

module mac_tree #(
    parameter MAC_NUM     = 10,
    parameter BRAHCN_NUM  = 10,
    parameter BRANCH_NUM  = BRAHCN_NUM,
    parameter BW_ACT      = 8,
    parameter BW_WET      = 8,
    parameter BW_ACCU     = 32
)(
    input  wire clk,
    input  wire reset_n,

    input  wire PE_mac_enable,
    input  wire PE_clear_acc,

    input  wire signed [BW_ACT-1:0]  PE_act_in [MAC_NUM-1:0][BRANCH_NUM-1:0],
    input  wire signed [BW_WET-1:0]  PE_wet_in [BRANCH_NUM-1:0],
    input  wire        [7:0]         PE_res_shift_num,
    output wire signed [BW_ACT-1:0]  PE_result_out [MAC_NUM-1:0],
    output wire signed [BW_ACCU-1:0] PE_result_ori [MAC_NUM-1:0]
);

    localparam TREE_LEVELS = (BRANCH_NUM <= 1) ? 1 : $clog2(BRANCH_NUM);
    localparam TREE_LEAVES = (1 << TREE_LEVELS);
    localparam integer ACT_MAX = (1 << (BW_ACT - 1)) - 1;
    localparam integer ACT_MIN = -(1 << (BW_ACT - 1));

    reg signed [BW_ACCU-1:0] acc_reg [MAC_NUM-1:0];
    wire signed [BW_ACCU-1:0] tree_node [MAC_NUM-1:0][TREE_LEVELS:0][TREE_LEAVES-1:0];

    function automatic signed [BW_ACT-1:0] quantize;
        input signed [BW_ACCU-1:0] value;
        input [7:0] shift_num;
        reg signed [BW_ACCU-1:0] shifted;
        begin
            shifted = value >>> shift_num;
            if (shifted > ACT_MAX) begin
                quantize = ACT_MAX;
            end
            else if (shifted < ACT_MIN) begin
                quantize = ACT_MIN;
            end
            else begin
                quantize = shifted[BW_ACT-1:0];
            end
        end
    endfunction

    genvar lane;
    genvar leaf;
    genvar level;
    genvar node;

    generate
        for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin : gen_lane
            for (leaf = 0; leaf < TREE_LEAVES; leaf = leaf + 1) begin : gen_leaf
                if (leaf < BRANCH_NUM) begin : gen_product
                    assign tree_node[lane][0][leaf] =
                        PE_act_in[lane][leaf] * PE_wet_in[leaf];
                end
                else begin : gen_padding
                    assign tree_node[lane][0][leaf] = '0;
                end
            end

            for (level = 1; level <= TREE_LEVELS; level = level + 1) begin : gen_level
                for (node = 0; node < (TREE_LEAVES >> level); node = node + 1) begin : gen_node
                    assign tree_node[lane][level][node] =
                        tree_node[lane][level-1][2*node] +
                        tree_node[lane][level-1][2*node+1];
                end
            end

            assign PE_result_ori[lane] = acc_reg[lane];
            assign PE_result_out[lane] = quantize(acc_reg[lane], PE_res_shift_num);
        end
    endgenerate

    integer i;
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            for (i = 0; i < MAC_NUM; i = i + 1) begin
                acc_reg[i] <= '0;
            end
        end
        else if (PE_clear_acc) begin
            for (i = 0; i < MAC_NUM; i = i + 1) begin
                acc_reg[i] <= '0;
            end
        end
        else if (PE_mac_enable) begin
            for (i = 0; i < MAC_NUM; i = i + 1) begin
                acc_reg[i] <= acc_reg[i] + tree_node[i][TREE_LEVELS][0];
            end
        end
    end

endmodule
