`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/27 15:57:16
// Design Name: 
// Module Name: mac_tree
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mac_tree #(
	parameter BW_ACT = 8,        // bit length of activation
    parameter BW_WET = 8,        // bit length of weight
    parameter BW_ACCU = 32,       // bit length of accu result    
    parameter MAC_NUM = 10,      // number of mac units
    parameter INPUT_NUM = 8    // number of input pair for one tree
)(
    input        clk,
    input        rst_n,             //low active
    
    // control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,
    
    // data signal 
    input   signed     [BW_ACT-1:0]    PE_act_in [MAC_NUM*INPUT_NUM-1:0],                 // input activation
    input   signed     [BW_WET-1:0]    PE_wet_in [INPUT_NUM-1:0],                           // input weight
    input              [7:0]           PE_res_shift_num,
    output  reg signed [BW_ACT-1:0]    PE_result_out [MAC_NUM-1:0]                           // output result   
);

    reg signed [BW_ACT-1:0]    PE_act_in_buffer [MAC_NUM*INPUT_NUM-1:0];                    // input buffer
    reg signed [BW_WET-1:0]    PE_wet_in_buffer [INPUT_NUM-1:0];                              // weight buffer
    reg signed [BW_ACCU-1:0]   PE_result_out_buffer[MAC_NUM-1:0];  
    reg                        PE_clear_acc_buffer;
    

    always @(posedge clk or negedge rst_n) begin
        if(~rst_n) begin 
            PE_clear_acc_buffer <= '0;
        end
        else begin
            PE_clear_acc_buffer <= PE_clear_acc;
        end         
    end


    genvar i;
    integer N = $clog2(INPUT_NUM);
    generate
        for (i = 0; i < MAC_NUM; i = i + 1) begin : MAC_TREE

            wire signed [BW_ACCU - 1 : 0] output_temp;
            reg signed [BW_ACCU - 1 : 0]  PARTIAL_SUM[(2 * INPUT_NUM - 1) - 1 : 0];
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin 
                    for (integer j = 0; j < INPUT_NUM; j = j + 1) begin
                        PE_act_in_buffer[i * INPUT_NUM + j] <= '0;
                        PE_wet_in_buffer[j] <= '0;
                    end
                end
                else begin
                    for (integer j = 0; j < INPUT_NUM; j = j + 1) begin
                        PE_act_in_buffer[i * INPUT_NUM + j] <= PE_act_in[i * INPUT_NUM + j];
                        PE_wet_in_buffer[j] <= PE_wet_in[j];
                    end
                end
            end
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin // 复位归零
                    PE_result_out_buffer[i] <= '0;
                end
                else if(~PE_mac_enable) begin // hold on
                    PE_result_out_buffer[i] <= PE_result_out_buffer[i];
                end
                else if(PE_clear_acc_buffer) begin
                    PE_result_out_buffer[i] <= '0;
                end
                else begin //start mac operation
                    for (integer j = 0; j <= N; j = j + 1) begin
                        if( j == 0) begin  //layer 0
                            for (integer k = 0; k < INPUT_NUM; k = k + 1) begin
                                PARTIAL_SUM[2 * INPUT_NUM - 2 - k] = PE_act_in_buffer[i * INPUT_NUM + k] * PE_wet_in_buffer[k];
                                if(PARTIAL_SUM[2 * INPUT_NUM - 2 - k] != 0) begin
                                    $display("%d=%d * %d",PARTIAL_SUM[2 * INPUT_NUM - 2 - k],PE_act_in_buffer[i * INPUT_NUM + k],PE_wet_in_buffer[k]);
                                end
                            end
                        end
                        else begin  //layer 1,2,3
                             for (integer k = INPUT_NUM - 2; k >= 0 ; k = k - 1) begin
                                PARTIAL_SUM[k] = PARTIAL_SUM[2 * k + 2] + PARTIAL_SUM[2 * k + 1];
                             end
                         end
                    end
                    PE_result_out_buffer[i] = PE_result_out_buffer[i] + PARTIAL_SUM[0];
                    for (integer j = 0; j <= (2 * INPUT_NUM - 1) - 1; j = j + 1) begin
                        PARTIAL_SUM[j] = 0;
                    end
                end
                /*
                else begin //start mac operation
                    for (integer j = 0; j < INPUT_NUM; j = j + 1) begin
                        partial_sum [2 * INPUT_NUM - 2 - j] = PE_act_in_buffer[i * INPUT_NUM + j] * PE_wet_in_buffer[j];
                    end
                    for (integer j = INPUT_NUM - 2; j >= 0; j = j - 1) begin
                        PARTIAL_SUM [j] = PARTIAL_SUM [2 * j + 2] + PARTIAL_SUM [2 * j + 1];
                    end
                    PE_result_out_buffer[i] = PE_result_out_reg[i] + PARTIAL_SUM[0];
                end
                */
            end
            
            assign output_temp = PE_result_out_buffer[i] >>> PE_res_shift_num;
            
            always @(posedge clk or negedge rst_n) begin
                if(~rst_n) begin
                    PE_result_out[i] <= '0;
                end
                else if(output_temp > 127) begin
                    PE_result_out[i] <= 127;
                end
                else if(output_temp < -128) begin
                    PE_result_out[i] <= -128;
                end
                else begin
                    PE_result_out[i] <= output_temp[BW_ACT - 1 : 0];  // 截取低8位
                end
            end
        end
    endgenerate

endmodule