`timescale 1ns/1ps

module systolic_array #(
    parameter CELL_W  = 1,
    parameter CELL_H  = 10,
    parameter BW_ACT  = 8,
    parameter BW_WET  = 8,
    parameter BW_ACCU = 32
)(
    input  wire clk,
    input  wire reset_n,

    input  wire PE_mac_enable,
    input  wire PE_clear_acc,
    input  wire PE_weight_fresh,

    input  wire signed [BW_ACT-1:0]  PE_act_in [CELL_H-1:0],
    input  wire signed [BW_WET-1:0]  PE_wet_in [CELL_H-1:0],
    input  wire        [7:0]         PE_res_shift_num,
    input  wire signed [BW_ACCU-1:0] PE_partial_sum,
    output wire signed [BW_ACT-1:0]  PE_result_out,
    output wire signed [BW_ACCU-1:0] PE_result_ori
);

    localparam integer ACT_MAX = (1 << (BW_ACT - 1)) - 1;
    localparam integer ACT_MIN = -(1 << (BW_ACT - 1));

    reg signed [BW_WET-1:0]  weight_reg [CELL_H-1:0];
    reg signed [BW_ACCU-1:0] psum_reg [CELL_H-1:0];

    function automatic signed [BW_ACT-1:0] quantize;
        input signed [BW_ACCU-1:0] value;
        input [7:0] shift_num;
        reg signed [BW_ACCU-1:0] shifted;
        begin
            shifted = value >>> shift_num;
            if (shifted > ACT_MAX) begin
                quantize = ACT_MAX;
            end
            else if (shifted < ACT_MIN) begin
                quantize = ACT_MIN;
            end
            else begin
                quantize = shifted[BW_ACT-1:0];
            end
        end
    endfunction

    assign PE_result_ori = psum_reg[CELL_H-1];
    assign PE_result_out = quantize(psum_reg[CELL_H-1], PE_res_shift_num);

    integer i;
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            for (i = 0; i < CELL_H; i = i + 1) begin
                weight_reg[i] <= '0;
            end
        end
        else if (PE_weight_fresh) begin
            for (i = 0; i < CELL_H; i = i + 1) begin
                weight_reg[i] <= PE_wet_in[i];
            end
        end
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            for (i = 0; i < CELL_H; i = i + 1) begin
                psum_reg[i] <= '0;
            end
        end
        else if (PE_clear_acc) begin
            for (i = 0; i < CELL_H; i = i + 1) begin
                psum_reg[i] <= '0;
            end
        end
        else if (PE_mac_enable) begin
            psum_reg[0] <= PE_partial_sum + PE_act_in[0] * weight_reg[0];
            for (i = 1; i < CELL_H; i = i + 1) begin
                psum_reg[i] <= psum_reg[i-1] + PE_act_in[i] * weight_reg[i];
            end
        end
    end

endmodule
