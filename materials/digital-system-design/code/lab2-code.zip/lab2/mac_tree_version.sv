module mac_tree #(
	parameter MAC_NUM = 10,      // number of multiply-accumulation units
    parameter BRAHCN_NUM = 8,    // number of nodes for one mac tree
	parameter BW_ACT = 8,        // bit length of activation
    parameter BW_WET = 8,        // bit length of weight
    parameter BW_ACCU = 32       // bit length of accu result    
)(
    input        clk,
    input        reset_n,
    
    // // control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,
    
    // data signal 
    input   signed     [BW_ACT - 1 : 0]    PE_act_in [MAC_NUM * BRAHCN_NUM - 1 : 0],                 // input activation
    input   signed     [BW_WET - 1 : 0]    PE_wet_in [BRAHCN_NUM - 1 : 0],                           // input weight
    input              [7 : 0]             PE_res_shift_num,
    output  reg signed [BW_ACT - 1 : 0]    PE_result_out [MAC_NUM - 1 : 0]                           // output result   
);

    reg signed [BW_ACT - 1 : 0]    PE_act_in_reg [MAC_NUM * BRAHCN_NUM - 1 : 0];                    // input buffer
    reg signed [BW_WET - 1 : 0]    PE_wet_in_reg [BRAHCN_NUM - 1 : 0];                              // weight buffer
    reg signed [BW_ACCU - 1 : 0]   PE_result_out_reg[MAC_NUM - 1 : 0];  
    reg PE_clear_acc_reg;
    
    // 数据信号因需要存入buffer而延后了 1 cycle，该控制信号也延后 1 cycle

    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin 
            PE_clear_acc_reg <= '0;
        end
        else begin
            PE_clear_acc_reg <= PE_clear_acc;
        end         
    end

    genvar gv_i;
    generate
        for (gv_i = 0; gv_i < MAC_NUM; gv_i = gv_i + 1) begin : line

            wire signed [BW_ACCU - 1 : 0] PE_result_shift_temp;
            reg signed [BW_ACCU - 1 : 0] partial_sum[2 * BRAHCN_NUM - 2 : 0];
            
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    for (integer j = 0; j < BRAHCN_NUM; j = j + 1) begin
                        PE_act_in_reg[gv_i * BRAHCN_NUM + j] <= '0;
                        PE_wet_in_reg[j] <= '0;
                    end
                end
                else begin
                    for (integer j = 0; j < BRAHCN_NUM; j = j + 1) begin
                        PE_act_in_reg[gv_i * BRAHCN_NUM + j] <= PE_act_in[gv_i * BRAHCN_NUM + j];
                        PE_wet_in_reg[j] <= PE_wet_in[j];
                    end
                end
            end
            
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    PE_result_out_reg[gv_i] <= '0;
                end
                else if(~PE_mac_enable) begin // 非计算时刻保持
                    PE_result_out_reg[gv_i] <= PE_result_out_reg[gv_i];
                end
                else if(PE_clear_acc_reg) begin
                    PE_result_out_reg[gv_i] <= '0;
                end
                else begin // 乘累加运算
                    for (integer j = 0; j < BRAHCN_NUM; j = j + 1) begin
                        partial_sum [2 * BRAHCN_NUM - 2 - j] = PE_act_in_reg[gv_i * BRAHCN_NUM + j] * PE_wet_in_reg[j];
                    end
                    for (integer j = BRAHCN_NUM - 2; j >= 0; j = j - 1) begin
                        partial_sum [j] = partial_sum [2 * j + 2] + partial_sum [2 * j + 1];
                    end
                    PE_result_out_reg[gv_i] = PE_result_out_reg[gv_i] + partial_sum [0];
                end
            end
            
            assign PE_result_shift_temp = PE_result_out_reg[gv_i] >>> PE_res_shift_num;
            
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin
                    PE_result_out[gv_i] <= '0;
                end
                else if(PE_result_shift_temp>127) begin
                    PE_result_out[gv_i] <= 127;
                end
                else if(PE_result_shift_temp<-128) begin
                    PE_result_out[gv_i] <= -128;
                end
                else begin
                    PE_result_out[gv_i] <= PE_result_shift_temp[BW_ACT - 1 : 0];  // 截取低位
                end
            end
        end
    endgenerate

endmodule