`timescale 1ns/1ps
`define CLK_PERIOD 10 // 100MHz

module tb_multi_systolic_array; // test bench

    parameter CELL_W = 4;
	parameter CELL_H = 10;
    parameter BW_ACT = 8;      // bit length of activation
    parameter BW_WET = 8;      // bit length of weight
    parameter BW_ACCU = 32;    // bit length of accu result  

    parameter IA_H = 100;
    parameter IA_W = 150;
    parameter Weight_H = 150;
    parameter Weight_W = 16; 
    parameter OA_H = 100;
    parameter OA_W = 16;

    reg clk;
    reg reset_n;
    reg PE_mac_enable;
    reg PE_clear_acc;
    reg PE_weight_fresh;

    reg signed [BW_ACT - 1 : 0]    PE_act_in [CELL_H - 1 : 0];                                          // input activation
    reg signed [BW_WET - 1 : 0]    PE_wet_in [CELL_H - 1 : 0][CELL_W - 1 : 0];                          // input weight
    reg  [7 : 0]                   PE_res_shift_num; 
    reg signed [BW_ACCU - 1 : 0]   PE_partial_sum[CELL_W - 1 : 0];
    wire signed [BW_ACT - 1 : 0]   PE_result_out[CELL_W - 1 : 0];                                       // output result
    wire signed [BW_ACCU - 1 : 0]   PE_result_ori[CELL_W - 1 : 0];   

    reg signed [BW_ACT-1:0]    Input_activation_main_memory[IA_H-1:0][IA_W-1:0];        // main memory (DRAM)
    reg signed [BW_ACT-1:0]    Weight_main_memory[Weight_H-1:0][Weight_W-1:0];
    reg signed [BW_ACT-1:0]    Output_activation_main_memory[OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACT-1:0]    reference_output[OA_H-1:0][OA_W-1:0];

    reg signed [BW_ACCU - 1 : 0]   PE_result_ori_reg[IA_H - 1 : 0][CELL_W - 1 : 0];

    multi_systolic_array #(
        .CELL_W(CELL_W),
        .CELL_H(CELL_H),
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU)
    )u_multi_systolic_array(
        .clk(clk),
        .reset_n(reset_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_weight_fresh(PE_weight_fresh),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .PE_partial_sum(PE_partial_sum),
        .PE_result_out(PE_result_out),
        .PE_result_ori(PE_result_ori)
    );

    initial begin
        clk = 0;
        reset_n = 1;
        PE_res_shift_num = 8;
        PE_clear_acc = 0;
        for (integer m = 0; m < CELL_H; m = m + 1) begin    
            PE_act_in[m] <= '0;
            for (integer n = 0; n < CELL_W; n = n + 1) begin  
                PE_wet_in[m][n] <= '0;
            end
        end
        forever begin
            #(`CLK_PERIOD/2) clk = ~clk; 
        end
    end

    integer wrong_num = 0; 
    initial begin
        @(negedge clk); 
        reset_n = 0; 
        
        $readmemb("C:/Users/local-user//vivado//pro2_ex//tbdata//input_act_bin.txt", Input_activation_main_memory);
        $readmemb("C:/Users/local-user//vivado//pro2_ex//tbdata//weight_bin.txt", Weight_main_memory);
        $readmemb("C:/Users/local-user//vivado//pro2_ex//tbdata//reference_output_bin.txt", reference_output);
        
        // loop nest
        @(negedge clk);
        reset_n = 1;
        PE_mac_enable = 1;

        for(integer m = 0; m < OA_W / CELL_W; m = m + 1) begin
            @(negedge clk) begin   // 每列更新 结果缓存
                for (integer q = 0; q < CELL_W; q = q + 1) begin
                    for (integer p = 0; p < IA_H; p = p + 1) begin
                        PE_result_ori_reg[p][q] <= '0;
                    end
                    PE_partial_sum[q] <= '0;
                end
            end
            for (integer n = 0; n < Weight_H / CELL_H; n = n + 1) begin
                @(negedge clk) begin // 更新权重
                    PE_weight_fresh <= 1;
                    PE_clear_acc <= 0;
                    for (integer j = 0; j < CELL_W; j = j + 1) begin
                        for (integer i = 0; i < CELL_H; i = i + 1) begin
                        PE_wet_in[i][j] <= Weight_main_memory[n * CELL_H + i][m * CELL_W + j];
                        end
                    end
                end
                for (integer j = 0; j < IA_H + CELL_H + 2; j = j + 1) begin
                    @(negedge clk) begin
                        if (j > 0) begin
                            PE_weight_fresh <= 0;
                        end
                        if (j < IA_H + CELL_H - 1) begin
                            if (j < IA_H && n > 0) begin
                                for(integer i = 0; i < CELL_W; i = i + 1) begin
                                    PE_partial_sum[i] <= PE_result_ori_reg[j][i];
                                end
                            end
                            else begin
                                for(integer i = 0; i < CELL_W; i = i + 1) begin
                                    PE_partial_sum[i] <= 0;
                                end
                            end

                            for (integer k = 0; k < CELL_H; k = k + 1) begin
                                if (k > j || k <= j - IA_H) begin
                                    PE_act_in[k] <= 0; 
                                end
                                else begin
                                    PE_act_in[k] <= Input_activation_main_memory[j - k][n * CELL_H + k]; 
                                end 
                            end
                        end
                        if (j > CELL_H + 1) begin
                            if (n < Weight_H / CELL_H - 1) begin
                                for(integer i = 0; i < CELL_W; i = i + 1) begin
                                    PE_result_ori_reg[j - CELL_H -2][i] <= PE_result_ori[i];
                                end
                            end
                            else begin
                                for(integer i = 0; i < CELL_W; i = i + 1) begin
                                    Output_activation_main_memory[j - CELL_H - 2][m * CELL_W + i] <= PE_result_out[i];
                                end
                            end
                        end
                    end
                end
                @(negedge clk) begin // 更新权重
                    PE_clear_acc <= 1;
                end
            end
        end

        for(integer k = 0; k < OA_H; k = k + 1) begin
            for(integer p = 0; p < OA_W; p = p + 1) begin
                if(Output_activation_main_memory[k][p] != reference_output[k][p]) begin
                    $display("wrong at (%d %d), output %d, reference %d", k, p, Output_activation_main_memory[k][p], reference_output[k][p]);
                    wrong_num = wrong_num + 1;
                end
            end
        end
        $display("wrong num: %d", wrong_num);
        @(negedge clk)
        $finish(0);
    end

endmodule