`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/17 23:36:22
// Design Name: 
// Module Name: tb_systolic_mac_unit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module tb_systolic_mac_cell;

    // 参数定义
    parameter BW_ACT = 8;
    parameter BW_WET = 8;
    parameter BW_ACCU = 32;

    // 信号声明
    reg clk;
    reg rst_n;
    reg PE_mac_enable;
    reg PE_clear_acc;
    reg PE_weight_update;
    reg signed [BW_ACT-1:0] PE_act_in;
    reg signed [BW_WET-1:0] PE_wet_in;
    reg signed [BW_ACCU-1:0] PE_pp_in;
    wire signed [BW_ACCU-1:0] PE_pp_out;
    wire signed [BW_ACT-1:0] PE_act_out;

    // 实例化被测模块
    systolic_mac_cell #(
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU)
    ) uut (
        .clk(clk),
        .rst_n(rst_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_weight_update(PE_weight_update),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_pp_in(PE_pp_in),
        .PE_pp_out(PE_pp_out),
        .PE_act_out(PE_act_out)
    );

    // 时钟生成
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns周期，100MHz时钟
    end

    // 测试序列
    initial begin
        // 初始化信号
        rst_n = 0;
        PE_mac_enable = 0;
        PE_clear_acc = 0;
        PE_weight_update = 0;
        PE_act_in = 0;
        PE_wet_in = 0;
        PE_pp_in = 0;
        
        // 复位
        #20 rst_n = 1;
        $display("复位完成");
        
        // 测试1：验证权重更新功能
        $display("开始测试权重更新功能");
        #10;
        PE_weight_update = 1;
        PE_wet_in = 5; // 设置权重为5
        #10;
        PE_weight_update = 0;
        $display("权重已更新为5");
        
        // 测试2：验证MAC功能（累加）
        $display("开始测试MAC功能（累加）");
        PE_mac_enable = 1;
        repeat(5) begin
            PE_act_in = $random % 10; // 随机输入0-9
            PE_pp_in =$random % 10;     // 反馈输出到输入
            PE_pp_in = 11/2;
             $display("%d",PE_pp_in);
            #10;
            $display("输入数据: %0d, 预期输出: %0d, 实际输出: %0d", 
                     PE_act_in, PE_pp_in + (PE_act_in * 5), PE_pp_out);
        end
        
        // 测试3：验证清除累加器功能
        $display("开始测试清除累加器功能");
        PE_clear_acc = 1;
        #10;
        PE_clear_acc = 0;
        $display("清除累加器后，预期输出: %0d, 实际输出: %0d", 0, PE_pp_out);
        
        // 测试4：验证新的累加操作
        $display("开始测试新的累加操作");
        PE_pp_in = 0; // 重置输入
        repeat(5) begin
            PE_act_in = $random % 10; // 随机输入0-9
            PE_pp_in = PE_pp_out;     // 反馈输出到输入
            #10;
            $display("输入数据: %0d, 预期输出: %0d, 实际输出: %0d", 
                     PE_act_in, PE_pp_in + (PE_act_in * 5), PE_pp_out);
        end
        
        // 测试5：验证关闭MAC功能
        $display("开始测试关闭MAC功能");
        PE_mac_enable = 0;
        #10;
        $display("关闭MAC后，预期输出保持不变: %0d, 实际输出: %0d", PE_pp_out, PE_pp_out);
        
        // 测试6：验证更新权重后的计算
        $display("开始测试更新权重后的计算");
        PE_mac_enable = 1;
        PE_weight_update = 1;
        PE_wet_in = 3; // 设置新权重为3
        #10;
        PE_weight_update = 0;
        PE_pp_in = 0; // 重置累加器
        repeat(3) begin
            PE_act_in = $random % 10; // 随机输入0-9
            PE_pp_in = PE_pp_out;     // 反馈输出到输入
            #10;
            $display("输入数据: %0d, 预期输出: %0d, 实际输出: %0d", 
                     PE_act_in, PE_pp_in + (PE_act_in * 3), PE_pp_out);
        end
        
        // 结束仿真
        #20 $finish;
    end

    // 自动验证结果
    reg [31:0] expected_result;
    initial begin
        expected_result = 0;
        forever @(posedge clk) begin
            if (rst_n && PE_mac_enable) begin
                if (PE_clear_acc) begin
                    expected_result = 0;
                end else if (PE_weight_update) begin
                    expected_result = $signed(PE_act_in * PE_wet_in); // 修改：使用PE_act_in而非内部信号
                end else begin
                    expected_result = PE_pp_in + $signed(PE_act_in * uut.PE_wet_in_buffer); // 修改：直接引用uut.weight_reg
                end
                
                #1; // 等待一个时间步，让输出更新
                if (expected_result !== PE_pp_out) begin
                    $error("验证失败! 时间: %0t, 预期结果: %0d, 实际输出: %0d", 
                           $time, expected_result, PE_pp_out);
                end
            end
        end
    end

    // 监控信号
    initial begin
        $monitor("时间: %0t, 使能: %b, 清除: %b, 更新权重: %b, 输入数据: %0d, 权重: %0d, 输入累加: %0d, 输出累加: %0d",
                 $time, PE_mac_enable, PE_clear_acc, PE_weight_update, 
                 PE_act_in, PE_wet_in, PE_pp_in, PE_pp_out);
    end

endmodule    
