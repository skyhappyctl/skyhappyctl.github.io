`timescale 1ns / 1ps
`define CLK_PERIOD      10//100MHz
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/28 11:21:12
// Design Name: 
// Module Name: tb_systolic_array
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_systolic_array();//testbench
    parameter ROW_NUM    =   15;  // number of multiply-accumulation units
    parameter COL_NUM    =   4;
    parameter BW_ACT     =   8;  // bit length of activation
    parameter BW_WET     =   8;  // bit length of weight
    parameter BW_ACCU    =   32;    // bit length of accu result  

    parameter IA_H = 100;
    parameter IA_W = 150;
    parameter Weight_H = 150;
    parameter Weight_W = 16; 
    parameter OA_H = 100;
    parameter OA_W = 16;
    parameter iterator_i = (Weight_H % ROW_NUM == 0) ? Weight_H / ROW_NUM : Weight_H / ROW_NUM + 1;
    parameter iterator_m = (OA_W % COL_NUM == 0) ? OA_W / COL_NUM : OA_W / COL_NUM + 1;

    
    reg clk;
    reg rst_n;
    reg PE_mac_enable;
    reg PE_weight_update [COL_NUM-1:0];
    reg [ROW_NUM-1:0] PE_clear_acc [COL_NUM-1:0];
    reg data_ready = 0;
    reg signed [31:0] prev_i = -1;
    reg signed [31:0] prev_m = -1;
    reg signed [31:0] current_i = -1;
    reg signed [31:0] current_m = -1;
    reg cycle_ready = 0;

    reg signed [BW_ACT-1:0]    PE_act_in [ROW_NUM-1:0];         // input activation
    reg signed [BW_WET-1:0]    PE_wet_in [ROW_NUM-1:0][COL_NUM-1:0];         // input weight
    reg  [7:0]                 PE_res_shift_num;
    reg signed [BW_ACCU-1:0]  final_result_out_wo_quan [COL_NUM-1:0];    // output result   
    reg signed [BW_ACT-1:0]   final_result_out_with_quan [COL_NUM-1:0];    // output result
    

    reg signed [BW_ACT-1:0]Input_activation_main_memory[IA_H-1:0][IA_W-1:0]; // main memory (DRAM)
    reg signed [BW_ACT-1:0]Weight_main_memory[Weight_H-1:0][Weight_W-1:0];
    reg signed [BW_ACT-1:0]Output_activation_main_memory[OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACT-1:0]reference_output[OA_H-1:0][OA_W-1:0];
    
    reg signed [BW_ACCU-1:0]Output_activation_buffer[OA_H-1:0][COL_NUM-1:0];
    
    wire PE_waiting [ROW_NUM-1:0][COL_NUM-1:0];
    
    integer total_cycle = OA_H + ROW_NUM - 1;
    reg [31:0]  cycle_count = 0;
    reg data_loading = 0;
    reg [31:0]  data_loading_count = -1;
    reg [31:0]  data_loading_total = 0;
    reg [31:0]  idx;
    
    _1_N_systolic_array #(
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU),
        .COL_NUM(COL_NUM),
        .ROW_NUM(ROW_NUM)
    )   my_1_N_systolic_array(
        .clk(clk),
        .rst_n(rst_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_weight_update(PE_weight_update),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .final_result_out_wo_quan(final_result_out_wo_quan),
        .final_result_out_with_quan(final_result_out_with_quan),
        .PE_waiting(PE_waiting)
    );
    initial begin
        forever begin
            #(`CLK_PERIOD/2) clk = ~clk; 
        end
    end
    
    initial begin
        initialize();            
        load_data();               
        run_simulation();         
        verify_output_results();   
        $finish();
    end
    
    integer wrong_num=0; 
    
    task initialize;
        begin
            clk = 0;
            rst_n = 0;
            #10;
            rst_n = 1;
            PE_res_shift_num = 8;
            for (integer n = 0; n < ROW_NUM; n = n + 1) begin
                for (integer m = 0; m < COL_NUM; m = m + 1) begin
                    PE_clear_acc[m][n] = 1;
                end
            end
            #10;
            for (integer n = 0; n < ROW_NUM; n = n + 1) begin
                for (integer m = 0; m < COL_NUM; m = m + 1) begin
                    PE_clear_acc[m][n] = 0;
                end
            end
            #10;
            for (integer n = 0; n < OA_H; n = n + 1) begin
                for (integer m = 0; m < OA_W; m = m + 1) begin
                    Output_activation_main_memory[n][m] = 0;
                end
                for (integer m = 0; m < COL_NUM; m = m + 1) begin
                     Output_activation_buffer[n][m] = 0;
                end
            end

            for(integer n = 0; n < ROW_NUM; n = n + 1) begin
                PE_act_in[n] <= 0;
                for(integer m = 0; m < COL_NUM; m = m + 1) begin
                    PE_wet_in[n][m] <= 0;
                end
            end
        end
     endtask
            
     task load_data;
        begin
                 $readmemb("input_act_bin.txt", Input_activation_main_memory);
                 $readmemb("weight_bin.txt", Weight_main_memory);
                 $readmemb("reference_output_bin.txt", reference_output);
             end
     endtask

     task run_simulation;
        begin
            integer i = 0;
            integer m = 0;
             $display("开始运行仿真...");
             @(posedge clk) begin
             PE_mac_enable = 1;
             end
             //loop nest
             while ( m < iterator_m) begin
                current_m <= m;
                while (i < iterator_i) begin
                    current_i <= i;
                    @(posedge clk) begin
                        for (integer ii = 0;ii < COL_NUM; ii = ii + 1) begin
                            PE_weight_update[ii] <= (cycle_count == 0) ? 1:0;
                        end
                        for (integer j = 0; j < ROW_NUM; j = j + 1) begin
                            for (integer k = 0; k < COL_NUM; k = k + 1) begin 
                                PE_wet_in[j][k] <= Weight_main_memory[i*ROW_NUM+j][m*COL_NUM+k];
                            end
                        end
                        for (integer j = 0; j < ROW_NUM; j = j + 1) begin
                            idx = cycle_count - j;
                            if (idx >= 0 && idx < OA_H) begin
                                PE_act_in[j] <= Input_activation_main_memory[idx][i*ROW_NUM+j];
                            end
                            else begin 
                                PE_act_in[j] <= 0;
                            end
                        end
                        if (cycle_count == 16) begin
                            data_loading = 1;
                        end
                        if (cycle_count == 0) begin
                            data_loading = 0;
                        end
                        if (data_loading) begin
                            for (integer k = 0; k < COL_NUM; k = k + 1) begin
                                Output_activation_buffer[data_loading_count][k] = Output_activation_buffer[data_loading_count][k] + final_result_out_wo_quan[k];
                            end
                            data_loading_count = data_loading_count + 1;
                            data_loading_total = data_loading_total + 1;
                        end
                        if (data_loading_count == 100) begin
                            data_loading_count = -1;
                        end
                    end 
                    if (cycle_count == total_cycle + 2) begin
                        cycle_count <= 0;
                        prev_i = i;
                        i = i + 1;
                    end
                    else begin
                        cycle_count <= cycle_count + 1;
                    end
                end  
                if (data_loading_total-iterator_i == OA_H*iterator_i) begin
                    for (integer nn = 0; nn < OA_H; nn = nn + 1) begin
                        for (integer mm = 0; mm < COL_NUM; mm = mm + 1) begin
                             Output_activation_main_memory[nn][m*COL_NUM+mm] = 
                             (Output_activation_buffer[nn][mm] >>> PE_res_shift_num > 127) ? 127 : 
                            ((Output_activation_buffer[nn][mm] >>> PE_res_shift_num < -128) ? -128 : 
                            (Output_activation_buffer[nn][mm] >>> PE_res_shift_num));
                        end
                    end
                    for (integer nn = 0; nn < OA_H; nn = nn + 1) begin
                        for (integer mm = 0; mm < COL_NUM; mm = mm + 1) begin
                            Output_activation_buffer[nn][mm] <= 0;
                        end
                    end
                    data_loading_total = 0;
                end
                if ( i == iterator_i) begin
                    m = m + 1;
                    i = 0;
                end
            end
         end
     data_ready = 1;
    endtask
            
    task verify_output_results;
        begin
            wait(data_ready);
            for(integer k=0;k<OA_H;k=k+1) begin
                for(integer p=0;p<OA_W;p=p+1) begin
                    if(Output_activation_main_memory[k][p]!=reference_output[k][p]) begin
                        $display("wrong at (%d %d), output %d, reference %d", k, p, Output_activation_main_memory[k][p], reference_output[k][p]);
                        wrong_num = wrong_num + 1;
                    end
                end
            end
            $display("wrong num: %d",wrong_num);
            if(wrong_num == 0) begin
                $display("所有答案均正确！");
            end
            @(negedge clk);
            $finish(0);
        end
    endtask
endmodule
