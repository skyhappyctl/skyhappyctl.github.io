create_clock period 10.000 -name CLK -waveform {0.000 5.000} [get_ports clk]
set_property -dict (PACKAGE PIN C8} [get_ports {clk}]