module multi_systolic_array #(
	parameter CELL_W     =   1,
	parameter CELL_H     =   10, 
    parameter BW_ACT     =   8,    // bit length of activation
    parameter BW_WET     =   8,    // bit length of weight
    parameter BW_ACCU    =   32    // bit length of accu result    
)(
    input        clk,
    input        reset_n,
    
    // control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,
    input        PE_weight_fresh,
    
    // data signal
    input   signed     [BW_ACT - 1 : 0]    PE_act_in [CELL_H - 1 : 0],                          // input activation
    input   signed     [BW_WET - 1 : 0]    PE_wet_in [CELL_H - 1 : 0][CELL_W - 1 : 0],          // input weight
    input              [7 : 0]             PE_res_shift_num,
    input   signed     [BW_ACCU - 1 : 0]   PE_partial_sum [CELL_W - 1 : 0],                      // reuse the partial sum
    output  reg signed [BW_ACT - 1 : 0]    PE_result_out [CELL_W - 1 : 0],                       // output result
    output  reg signed [BW_ACCU - 1 : 0]   PE_result_ori [CELL_W - 1 : 0]                        // result no quantization
);

    reg signed [BW_ACT - 1 : 0]    PE_act_in_reg [CELL_H - 1 : 0];                               // input buffer
    reg signed [BW_WET - 1 : 0]    PE_wet_in_reg [CELL_H - 1 : 0][CELL_W - 1 : 0];              // weight buffer
    reg signed [BW_ACCU - 1 : 0]   PE_result_out_reg [CELL_H - 1 : 0][CELL_W - 1 : 0];
    reg signed [BW_ACCU - 1 : 0]   PE_partial_sum_reg [CELL_W - 1 : 0];
    reg  PE_clear_acc_reg;                                                     // 数据信号因需要存入buffer而延后了 1 cycle，该控制信号也延后 1 cycle


    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin 
            PE_clear_acc_reg <= '0;
        end
        else begin
            PE_clear_acc_reg <= PE_clear_acc;
        end        
    end

    genvar gv_w;
    generate
        for (gv_w = 0; gv_w < CELL_H; gv_w = gv_w + 1) begin : line1
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    for (integer j = 0; j < CELL_W; j = j + 1) begin
                        PE_wet_in_reg[gv_w][j] <= '0;
                    end
                end
                else if(PE_weight_fresh)begin // 更新权重
                    for (integer j = 0; j < CELL_W; j = j + 1) begin
                        PE_wet_in_reg[gv_w][j] <= PE_wet_in[gv_w][j];
                    end
                end
            end
        end
    endgenerate

    genvar gv_ia;
    generate
        for (gv_ia = 0; gv_ia < CELL_H; gv_ia = gv_ia + 1) begin : line2
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零              
                    PE_act_in_reg[gv_ia] <= '0;
                end
                else begin // 更新
                    PE_act_in_reg[gv_ia] <= PE_act_in[gv_ia];
                end
            end
        end
    endgenerate

    genvar gv_ps;
    generate
        for (gv_ps = 0; gv_ps < CELL_W; gv_ps = gv_ps + 1) begin : line3
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零              
                    PE_partial_sum_reg[gv_ps] <= '0;
                end
                else begin // 更新
                    PE_partial_sum_reg[gv_ps] <= PE_partial_sum[gv_ps];
                end
            end
        end
    endgenerate
    
    genvar gv_oa;
    generate
        for (gv_oa = 0; gv_oa < CELL_H; gv_oa = gv_oa + 1) begin: line4
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    for (integer gv_ob = 0; gv_ob < CELL_W; gv_ob = gv_ob + 1) begin
                        PE_result_out_reg[gv_oa][gv_ob] <= '0;
                    end
                end
                else if(~PE_mac_enable) begin // 非计算时刻保持   
                    for (integer gv_ob = 0; gv_ob < CELL_W; gv_ob = gv_ob + 1) begin
                        PE_result_out_reg[gv_oa][gv_ob] <= PE_result_out_reg[gv_oa][gv_ob];
                    end
                end
                else if(PE_clear_acc_reg) begin
                    for (integer gv_ob = 0; gv_ob < CELL_W; gv_ob = gv_ob + 1) begin
                        PE_result_out_reg[gv_oa][gv_ob] <= '0;
                    end
                end
                else begin // 乘累加运算
                    if (gv_oa == 0) begin
                        for (integer gv_ob = 0; gv_ob < CELL_W; gv_ob = gv_ob + 1) begin
                            PE_result_out_reg[gv_oa][gv_ob] <= PE_wet_in_reg[gv_oa][gv_ob] * PE_act_in_reg[gv_oa] + PE_partial_sum_reg[gv_ob];
                        end
                    end
                    else begin
                        for (integer gv_ob = 0; gv_ob < CELL_W; gv_ob = gv_ob + 1) begin
                            PE_result_out_reg[gv_oa][gv_ob] <= PE_wet_in_reg[gv_oa][gv_ob] * PE_act_in_reg[gv_oa] + PE_result_out_reg[gv_oa - 1][gv_ob];
                        end
                    end
                end
            end
        end
    endgenerate

    genvar gv_o;
    generate
        wire signed [BW_ACCU - 1 : 0] PE_result_shift_temp[CELL_W - 1 : 0];
        for (gv_o = 0; gv_o <= CELL_W - 1; gv_o = gv_o + 1) begin
            assign PE_result_shift_temp[gv_o] = PE_result_out_reg[CELL_H - 1][gv_o] >>> PE_res_shift_num;
        end

        for (gv_o = 0; gv_o <= CELL_W - 1; gv_o = gv_o + 1) begin
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin
                    PE_result_out[gv_o] <= '0;
                    PE_result_ori[gv_o] <= '0;
                end
                else if(PE_result_shift_temp[gv_o] > 127) begin
                    PE_result_out[gv_o] <= 127;
                    PE_result_ori[gv_o] <= PE_result_out_reg[CELL_H - 1][gv_o];
                end
                else if(PE_result_shift_temp[gv_o] < -128) begin
                    PE_result_out[gv_o] <= -128;
                    PE_result_ori[gv_o] <= PE_result_out_reg[CELL_H - 1][gv_o];
                end
                else begin 
                    PE_result_out[gv_o] <= PE_result_shift_temp[gv_o][BW_ACT - 1 : 0];  // 截取低位
                    PE_result_ori[gv_o] <= PE_result_out_reg[CELL_H - 1][gv_o];
                end
            end
        end
    endgenerate

endmodule