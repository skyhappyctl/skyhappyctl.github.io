module systolic_array #(
	parameter CELL_W     =   1,
	parameter CELL_H     =   10, 
    parameter BW_ACT     =   8,    // bit length of activation
    parameter BW_WET     =   8,    // bit length of weight
    parameter BW_ACCU    =   32    // bit length of accu result    
)(
    input        clk,
    input        reset_n,
    
    // control signal
    input        PE_mac_enable,      // high active
    input        PE_clear_acc,
    input        PE_weight_fresh,
    
    // data signal
    input   signed     [BW_ACT - 1 : 0]    PE_act_in [CELL_H - 1 : 0] ,         // input activation
    input   signed     [BW_WET - 1 : 0]    PE_wet_in [CELL_H - 1 : 0],          // input weight
    input              [7 : 0]             PE_res_shift_num,
    input   signed     [BW_ACCU - 1 : 0]   PE_partial_sum,                      // reuse the partial sum
    output  reg signed [BW_ACT - 1 : 0]    PE_result_out,                       // output result
    output  reg signed [BW_ACCU - 1 : 0]   PE_result_ori                        // result no quantization
);

    reg signed [BW_ACT - 1 : 0]    PE_act_in_reg [CELL_H - 1 : 0];             // input buffer
    reg signed [BW_WET - 1 : 0]    PE_wet_in_reg [CELL_H - 1 : 0];             // weight buffer
    reg signed [BW_ACCU - 1 : 0]   PE_result_out_reg [CELL_H - 1 : 0];
    reg signed [BW_ACCU - 1 : 0]   PE_partial_sum_reg;
    reg  PE_clear_acc_reg;                                                     // 数据信号因需要存入buffer而延后了 1 cycle，该控制信号也延后 1 cycle


    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin 
            PE_clear_acc_reg <= '0;
        end
        else begin
            PE_clear_acc_reg <= PE_clear_acc;
        end        
    end

    genvar gv_w;
    generate
        for (gv_w = 0; gv_w < CELL_H; gv_w = gv_w + 1) begin : line1
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    PE_wet_in_reg[gv_w] <= '0;
                end
                else if(PE_weight_fresh)begin // 更新权重
                    PE_wet_in_reg[gv_w] <= PE_wet_in[gv_w];
                end
            end
        end
    endgenerate

    genvar gv_ia;
    generate
        for (gv_ia = 0; gv_ia < CELL_H; gv_ia = gv_ia + 1) begin : line2
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    PE_act_in_reg[gv_ia] <= '0;
                    PE_partial_sum_reg <= '0;
                end
                else begin // 更新
                    PE_act_in_reg[gv_ia] <= PE_act_in[gv_ia];
                    PE_partial_sum_reg <= PE_partial_sum;
                end
            end
        end
    endgenerate
    
    genvar gv_oa;
    generate
        for (gv_oa = 0; gv_oa < CELL_H; gv_oa = gv_oa + 1) begin: line3
            always @(posedge clk or negedge reset_n) begin
                if(~reset_n) begin // 复位归零
                    PE_result_out_reg[gv_oa] <= '0;
                end
                else if(~PE_mac_enable) begin // 非计算时刻保持
                    PE_result_out_reg[gv_oa] <= PE_result_out_reg[gv_oa];
                end
                else if(PE_clear_acc_reg) begin
                    PE_result_out_reg[gv_oa] <= '0;
                end
                else begin // 乘累加运算
                    if (gv_oa == 0) begin
                        PE_result_out_reg[gv_oa] <= PE_wet_in_reg[gv_oa] * PE_act_in_reg[gv_oa] + PE_partial_sum_reg;
                    end
                    else begin
                        PE_result_out_reg[gv_oa] <= PE_wet_in_reg[gv_oa] * PE_act_in_reg[gv_oa] + PE_result_out_reg[gv_oa - 1];
                    end
                end
            end
        end
    endgenerate

    wire signed [BW_ACCU - 1 : 0] PE_result_shift_temp;
    assign PE_result_shift_temp = PE_result_out_reg[CELL_H - 1] >>> PE_res_shift_num;
        
    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin
            PE_result_out <= '0;
            PE_result_ori <= '0;
        end
        else if(PE_result_shift_temp>127) begin
            PE_result_out <= 127;
            PE_result_ori <= PE_result_out_reg[CELL_H - 1];
        end
        else if(PE_result_shift_temp<-128) begin
            PE_result_out <= -128;
            PE_result_ori <= PE_result_out_reg[CELL_H - 1];
        end
        else begin 
            PE_result_out <= PE_result_shift_temp[BW_ACT - 1 : 0];  // 截取低位
            PE_result_ori <= PE_result_out_reg[CELL_H - 1];
        end
    end

endmodule