`timescale 1ns/1ps
`define CLK_PERIOD 10

module tb_mac_tree;

    parameter MAC_NUM    = 10;
    parameter BRANCH_NUM = 10;
    parameter BW_ACT     = 8;
    parameter BW_WET     = 8;
    parameter BW_ACCU    = 32;
    parameter TREE_LATENCY = (BRANCH_NUM <= 1) ? 1 : $clog2(BRANCH_NUM);

    parameter IA_H     = 100;
    parameter IA_W     = 150;
    parameter WEIGHT_H = 150;
    parameter WEIGHT_W = 16;
    parameter OA_H     = 100;
    parameter OA_W     = 16;

    reg clk;
    reg reset_n;
    reg PE_mac_enable;
    reg PE_clear_acc;
    reg [7:0] PE_res_shift_num;

    reg  signed [BW_ACT-1:0]  PE_act_in [MAC_NUM-1:0][BRANCH_NUM-1:0];
    reg  signed [BW_WET-1:0]  PE_wet_in [BRANCH_NUM-1:0];
    wire signed [BW_ACT-1:0]  PE_result_out [MAC_NUM-1:0];
    wire signed [BW_ACCU-1:0] PE_result_ori [MAC_NUM-1:0];
    wire                      PE_result_valid;

    reg signed [BW_ACT-1:0] Input_activation_main_memory [IA_H-1:0][IA_W-1:0];
    reg signed [BW_WET-1:0] Weight_main_memory [WEIGHT_H-1:0][WEIGHT_W-1:0];
    reg signed [BW_ACT-1:0] Output_activation_main_memory [OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACT-1:0] reference_output [OA_H-1:0][OA_W-1:0];
    integer match_count;

    mac_tree #(
        .MAC_NUM(MAC_NUM),
        .BRANCH_NUM(BRANCH_NUM),
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU)
    ) u_mac_tree (
        .clk(clk),
        .reset_n(reset_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .PE_result_out(PE_result_out),
        .PE_result_ori(PE_result_ori),
        .PE_result_valid(PE_result_valid)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD/2) clk = ~clk;
    end

    function integer open_or_fatal;
        input string path;
        input string fallback_path;
        begin
            open_or_fatal = $fopen(path, "r");
            if (open_or_fatal == 0) begin
                open_or_fatal = $fopen(fallback_path, "r");
            end
            if (open_or_fatal == 0) begin
                $fatal(1, "Could not open %s or %s", path, fallback_path);
            end
        end
    endfunction

    task load_input_activation;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "input_act_dec.txt");
            for (r = 0; r < IA_H; r = r + 1) begin
                for (c = 0; c < IA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short input activation file at (%0d,%0d)", r, c);
                    end
                    Input_activation_main_memory[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task load_weight;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "weight_dec.txt");
            for (r = 0; r < WEIGHT_H; r = r + 1) begin
                for (c = 0; c < WEIGHT_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short weight file at (%0d,%0d)", r, c);
                    end
                    Weight_main_memory[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task load_reference;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "reference_output_dec.txt");
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short reference file at (%0d,%0d)", r, c);
                    end
                    reference_output[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task clear_inputs;
        integer lane;
        integer k;
        begin
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                    PE_act_in[lane][k] = '0;
                end
            end
            for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                PE_wet_in[k] = '0;
            end
        end
    endtask

    task clear_accumulator;
        begin
            PE_mac_enable = 1'b0;
            PE_clear_acc = 1'b1;
            clear_inputs();
            @(posedge clk);
            #1;
            PE_clear_acc = 1'b0;
        end
    endtask

    task run_one_output_block;
        input integer out_ch;
        input integer row_base;
        integer k_base;
        integer lane;
        integer k;
        integer row;
        integer col;
        integer flush_cycle;
        begin
            clear_accumulator();
            for (k_base = 0; k_base < IA_W; k_base = k_base + BRANCH_NUM) begin
                for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                    row = row_base + lane;
                    for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                        col = k_base + k;
                        if (row < IA_H && col < IA_W) begin
                            PE_act_in[lane][k] = Input_activation_main_memory[row][col];
                        end
                        else begin
                            PE_act_in[lane][k] = '0;
                        end
                    end
                end

                for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                    col = k_base + k;
                    if (col < WEIGHT_H) begin
                        PE_wet_in[k] = Weight_main_memory[col][out_ch];
                    end
                    else begin
                        PE_wet_in[k] = '0;
                    end
                end

                PE_mac_enable = 1'b1;
                @(posedge clk);
                #1;
            end

            PE_mac_enable = 1'b0;
            clear_inputs();
            for (flush_cycle = 0; flush_cycle < TREE_LATENCY + 1; flush_cycle = flush_cycle + 1) begin
                @(posedge clk);
                #1;
            end
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                row = row_base + lane;
                if (row < OA_H) begin
                    Output_activation_main_memory[row][out_ch] = PE_result_out[lane];
                end
            end
        end
    endtask

    task init_output;
        integer r;
        integer c;
        begin
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    Output_activation_main_memory[r][c] = '0;
                end
            end
        end
    endtask

    task compare_output;
        integer r;
        integer c;
        integer wrong_num;
        integer total_count;
        begin
            wrong_num = 0;
            match_count = 0;
            total_count = OA_H * OA_W;
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    $display("CHECK mac_tree OA[%0d][%0d]: output=%0d, reference=%0d",
                             r, c, Output_activation_main_memory[r][c], reference_output[r][c]);
                    if (Output_activation_main_memory[r][c] === reference_output[r][c]) begin
                        match_count = match_count + 1;
                    end
                    else begin
                        $display("MISMATCH mac_tree OA[%0d][%0d]: output=%0d, reference=%0d",
                                 r, c, Output_activation_main_memory[r][c], reference_output[r][c]);
                        wrong_num = wrong_num + 1;
                    end
                end
            end

            $display("mac_tree match_count=%0d/%0d, wrong_num=%0d", match_count, total_count, wrong_num);
            if (wrong_num == 0) begin
                $display("PASS: mac_tree all %0d outputs match reference.", total_count);
            end
            else begin
                $fatal(1, "FAIL: mac_tree wrong num = %0d", wrong_num);
            end
        end
    endtask

    string act_file;
    string weight_file;
    string ref_file;
    integer out_ch;
    integer row_base;

    initial begin
        reset_n = 1'b0;
        PE_mac_enable = 1'b0;
        PE_clear_acc = 1'b0;
        PE_res_shift_num = 8;
        clear_inputs();
        init_output();

        if (!$value$plusargs("ACT_FILE=%s", act_file)) begin
            act_file = "lab2/input_act_dec.txt";
        end
        if (!$value$plusargs("WEIGHT_FILE=%s", weight_file)) begin
            weight_file = "lab2/weight_dec.txt";
        end
        if (!$value$plusargs("REF_FILE=%s", ref_file)) begin
            ref_file = "lab2/reference_output_dec.txt";
        end

        load_input_activation(act_file);
        load_weight(weight_file);
        load_reference(ref_file);

        repeat (3) @(posedge clk);
        reset_n = 1'b1;
        @(posedge clk);
        #1;

        for (out_ch = 0; out_ch < OA_W; out_ch = out_ch + 1) begin
            for (row_base = 0; row_base < IA_H; row_base = row_base + MAC_NUM) begin
                run_one_output_block(out_ch, row_base);
            end
        end

        compare_output();
        @(posedge clk);
        $finish;
    end

endmodule
