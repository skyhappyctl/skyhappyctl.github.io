`timescale 1ns/1ps
`define CLK_PERIOD 10

module tb_systolic_array;

    parameter CELL_W  = 1;
    parameter CELL_H  = 10;
    parameter BW_ACT  = 8;
    parameter BW_WET  = 8;
    parameter BW_ACCU = 32;

    parameter IA_H     = 100;
    parameter IA_W     = 150;
    parameter WEIGHT_H = 150;
    parameter WEIGHT_W = 16;
    parameter OA_H     = 100;
    parameter OA_W     = 16;

    reg clk;
    reg reset_n;
    reg PE_mac_enable;
    reg PE_clear_acc;
    reg PE_weight_fresh;
    reg [7:0] PE_res_shift_num;

    reg  signed [BW_ACT-1:0]  PE_act_in [CELL_H-1:0];
    reg  signed [BW_WET-1:0]  PE_wet_in [CELL_H-1:0];
    reg  signed [BW_ACCU-1:0] PE_partial_sum;
    wire signed [BW_ACT-1:0]  PE_result_out;
    wire signed [BW_ACCU-1:0] PE_result_ori;

    reg signed [BW_ACT-1:0]  Input_activation_main_memory [IA_H-1:0][IA_W-1:0];
    reg signed [BW_WET-1:0]  Weight_main_memory [WEIGHT_H-1:0][WEIGHT_W-1:0];
    reg signed [BW_ACT-1:0]  Output_activation_main_memory [OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACT-1:0]  reference_output [OA_H-1:0][OA_W-1:0];
    reg signed [BW_ACCU-1:0] partial_accum [IA_H-1:0];
    integer match_count;

    systolic_array #(
        .CELL_W(CELL_W),
        .CELL_H(CELL_H),
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU)
    ) u_systolic_array (
        .clk(clk),
        .reset_n(reset_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_weight_fresh(PE_weight_fresh),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .PE_partial_sum(PE_partial_sum),
        .PE_result_out(PE_result_out),
        .PE_result_ori(PE_result_ori)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD/2) clk = ~clk;
    end

    function integer open_or_fatal;
        input string path;
        input string fallback_path;
        begin
            open_or_fatal = $fopen(path, "r");
            if (open_or_fatal == 0) begin
                open_or_fatal = $fopen(fallback_path, "r");
            end
            if (open_or_fatal == 0) begin
                $fatal(1, "Could not open %s or %s", path, fallback_path);
            end
        end
    endfunction

    task load_input_activation;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "input_act_dec.txt");
            for (r = 0; r < IA_H; r = r + 1) begin
                for (c = 0; c < IA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short input activation file at (%0d,%0d)", r, c);
                    end
                    Input_activation_main_memory[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task load_weight;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "weight_dec.txt");
            for (r = 0; r < WEIGHT_H; r = r + 1) begin
                for (c = 0; c < WEIGHT_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short weight file at (%0d,%0d)", r, c);
                    end
                    Weight_main_memory[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task load_reference;
        input string path;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal(path, "reference_output_dec.txt");
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) begin
                        $fatal(1, "Short reference file at (%0d,%0d)", r, c);
                    end
                    reference_output[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task clear_inputs;
        integer i;
        begin
            for (i = 0; i < CELL_H; i = i + 1) begin
                PE_act_in[i] = '0;
                PE_wet_in[i] = '0;
            end
            PE_partial_sum = '0;
        end
    endtask

    task clear_pipe;
        begin
            PE_mac_enable = 1'b0;
            PE_clear_acc = 1'b1;
            clear_inputs();
            @(posedge clk);
            #1;
            PE_clear_acc = 1'b0;
        end
    endtask

    task load_weight_tile;
        input integer out_ch;
        input integer k_base;
        integer i;
        integer k_index;
        begin
            PE_mac_enable = 1'b0;
            PE_weight_fresh = 1'b1;
            for (i = 0; i < CELL_H; i = i + 1) begin
                k_index = k_base + i;
                if (k_index < WEIGHT_H) begin
                    PE_wet_in[i] = Weight_main_memory[k_index][out_ch];
                end
                else begin
                    PE_wet_in[i] = '0;
                end
            end
            @(posedge clk);
            #1;
            PE_weight_fresh = 1'b0;
        end
    endtask

    task stream_weight_tile;
        input integer out_ch;
        input integer k_base;
        input integer final_tile;
        integer cycle;
        integer i;
        integer row;
        integer k_index;
        integer out_row;
        begin
            for (cycle = 0; cycle < IA_H + CELL_H - 1; cycle = cycle + 1) begin
                if (cycle < IA_H) begin
                    PE_partial_sum = partial_accum[cycle];
                end
                else begin
                    PE_partial_sum = '0;
                end

                for (i = 0; i < CELL_H; i = i + 1) begin
                    row = cycle - i;
                    k_index = k_base + i;
                    if (row >= 0 && row < IA_H && k_index < IA_W) begin
                        PE_act_in[i] = Input_activation_main_memory[row][k_index];
                    end
                    else begin
                        PE_act_in[i] = '0;
                    end
                end

                PE_mac_enable = 1'b1;
                @(posedge clk);
                #1;

                out_row = cycle - CELL_H + 1;
                if (out_row >= 0 && out_row < IA_H) begin
                    if (final_tile) begin
                        Output_activation_main_memory[out_row][out_ch] = PE_result_out;
                    end
                    else begin
                        partial_accum[out_row] = PE_result_ori;
                    end
                end
            end
            PE_mac_enable = 1'b0;
            clear_inputs();
        end
    endtask

    task init_output;
        integer r;
        integer c;
        begin
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    Output_activation_main_memory[r][c] = '0;
                end
            end
        end
    endtask

    task init_partial_accum;
        integer r;
        begin
            for (r = 0; r < IA_H; r = r + 1) begin
                partial_accum[r] = '0;
            end
        end
    endtask

    task compare_output;
        integer r;
        integer c;
        integer wrong_num;
        integer total_count;
        begin
            wrong_num = 0;
            match_count = 0;
            total_count = OA_H * OA_W;
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    $display("CHECK systolic_array OA[%0d][%0d]: output=%0d, reference=%0d",
                             r, c, Output_activation_main_memory[r][c], reference_output[r][c]);
                    if (Output_activation_main_memory[r][c] === reference_output[r][c]) begin
                        match_count = match_count + 1;
                    end
                    else begin
                        $display("MISMATCH systolic_array OA[%0d][%0d]: output=%0d, reference=%0d",
                                 r, c, Output_activation_main_memory[r][c], reference_output[r][c]);
                        wrong_num = wrong_num + 1;
                    end
                end
            end

            $display("systolic_array match_count=%0d/%0d, wrong_num=%0d", match_count, total_count, wrong_num);
            if (wrong_num == 0) begin
                $display("PASS: systolic_array all %0d outputs match reference.", total_count);
            end
            else begin
                $fatal(1, "FAIL: systolic_array wrong num = %0d", wrong_num);
            end
        end
    endtask

    string act_file;
    string weight_file;
    string ref_file;
    integer out_ch;
    integer k_base;

    initial begin
        reset_n = 1'b0;
        PE_mac_enable = 1'b0;
        PE_clear_acc = 1'b0;
        PE_weight_fresh = 1'b0;
        PE_res_shift_num = 8;
        clear_inputs();
        init_output();

        if (!$value$plusargs("ACT_FILE=%s", act_file)) begin
            act_file = "lab2/input_act_dec.txt";
        end
        if (!$value$plusargs("WEIGHT_FILE=%s", weight_file)) begin
            weight_file = "lab2/weight_dec.txt";
        end
        if (!$value$plusargs("REF_FILE=%s", ref_file)) begin
            ref_file = "lab2/reference_output_dec.txt";
        end

        load_input_activation(act_file);
        load_weight(weight_file);
        load_reference(ref_file);

        repeat (3) @(posedge clk);
        reset_n = 1'b1;
        @(posedge clk);
        #1;

        for (out_ch = 0; out_ch < OA_W; out_ch = out_ch + 1) begin
            init_partial_accum();
            for (k_base = 0; k_base < IA_W; k_base = k_base + CELL_H) begin
                load_weight_tile(out_ch, k_base);
                clear_pipe();
                stream_weight_tile(out_ch, k_base, (k_base + CELL_H >= IA_W));
            end
        end

        compare_output();
        @(posedge clk);
        $finish;
    end

endmodule
