log_wave -r /tb_mac_tree_wave/*
run all
quit
