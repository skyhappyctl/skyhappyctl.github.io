`timescale 1ns/1ps

module mac_tree #(
    parameter MAC_NUM     = 10,
    parameter BRAHCN_NUM  = 10,
    parameter BRANCH_NUM  = BRAHCN_NUM,
    parameter BW_ACT      = 8,
    parameter BW_WET      = 8,
    parameter BW_ACCU     = 32
)(
    input  wire clk,
    input  wire reset_n,

    input  wire PE_mac_enable,
    input  wire PE_clear_acc,

    input  wire signed [BW_ACT-1:0]  PE_act_in [MAC_NUM-1:0][BRANCH_NUM-1:0],
    input  wire signed [BW_WET-1:0]  PE_wet_in [BRANCH_NUM-1:0],
    input  wire        [7:0]         PE_res_shift_num,
    output wire signed [BW_ACT-1:0]  PE_result_out [MAC_NUM-1:0],
    output wire signed [BW_ACCU-1:0] PE_result_ori [MAC_NUM-1:0],
    output wire                      PE_result_valid
);

    localparam integer TREE_LEVELS = 4;
    localparam integer TREE_LEAVES = 16;
    localparam integer ACT_MAX = (1 << (BW_ACT - 1)) - 1;
    localparam integer ACT_MIN = -(1 << (BW_ACT - 1));

    reg signed [BW_ACCU-1:0] acc_reg [MAC_NUM-1:0];

    reg signed [BW_ACCU-1:0] product_pipe [MAC_NUM-1:0][TREE_LEAVES-1:0];
    reg signed [BW_ACCU-1:0] sum_l1       [MAC_NUM-1:0][7:0];
    reg signed [BW_ACCU-1:0] sum_l2       [MAC_NUM-1:0][3:0];
    reg signed [BW_ACCU-1:0] sum_l3       [MAC_NUM-1:0][1:0];
    reg signed [BW_ACCU-1:0] sum_l4       [MAC_NUM-1:0];

    reg [TREE_LEVELS:0] valid_pipe;
    reg result_valid_reg;

    function automatic signed [BW_ACT-1:0] quantize;
        input signed [BW_ACCU-1:0] value;
        input [7:0] shift_num;
        reg signed [BW_ACCU-1:0] shifted;
        begin
            shifted = value >>> shift_num;
            if (shifted > ACT_MAX) begin
                quantize = ACT_MAX;
            end
            else if (shifted < ACT_MIN) begin
                quantize = ACT_MIN;
            end
            else begin
                quantize = shifted[BW_ACT-1:0];
            end
        end
    endfunction

    genvar out_i;
    generate
        for (out_i = 0; out_i < MAC_NUM; out_i = out_i + 1) begin : gen_output
            assign PE_result_ori[out_i] = acc_reg[out_i];
            assign PE_result_out[out_i] = quantize(acc_reg[out_i], PE_res_shift_num);
        end
    endgenerate

    assign PE_result_valid = result_valid_reg;

    integer lane;
    integer leaf;
    integer node;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            valid_pipe <= '0;
            result_valid_reg <= 1'b0;
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                acc_reg[lane] <= '0;
                sum_l4[lane] <= '0;
                for (leaf = 0; leaf < TREE_LEAVES; leaf = leaf + 1) begin
                    product_pipe[lane][leaf] <= '0;
                end
                for (node = 0; node < 8; node = node + 1) begin
                    sum_l1[lane][node] <= '0;
                end
                for (node = 0; node < 4; node = node + 1) begin
                    sum_l2[lane][node] <= '0;
                end
                for (node = 0; node < 2; node = node + 1) begin
                    sum_l3[lane][node] <= '0;
                end
            end
        end
        else if (PE_clear_acc) begin
            valid_pipe <= '0;
            result_valid_reg <= 1'b0;
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                acc_reg[lane] <= '0;
                sum_l4[lane] <= '0;
                for (leaf = 0; leaf < TREE_LEAVES; leaf = leaf + 1) begin
                    product_pipe[lane][leaf] <= '0;
                end
                for (node = 0; node < 8; node = node + 1) begin
                    sum_l1[lane][node] <= '0;
                end
                for (node = 0; node < 4; node = node + 1) begin
                    sum_l2[lane][node] <= '0;
                end
                for (node = 0; node < 2; node = node + 1) begin
                    sum_l3[lane][node] <= '0;
                end
            end
        end
        else begin
            valid_pipe <= {valid_pipe[TREE_LEVELS-1:0], PE_mac_enable};
            result_valid_reg <= valid_pipe[TREE_LEVELS];

            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                for (leaf = 0; leaf < BRANCH_NUM; leaf = leaf + 1) begin
                    if (PE_mac_enable) begin
                        product_pipe[lane][leaf] <= PE_act_in[lane][leaf] * PE_wet_in[leaf];
                    end
                    else begin
                        product_pipe[lane][leaf] <= '0;
                    end
                end
                for (leaf = BRANCH_NUM; leaf < TREE_LEAVES; leaf = leaf + 1) begin
                    product_pipe[lane][leaf] <= '0;
                end

                for (node = 0; node < 8; node = node + 1) begin
                    sum_l1[lane][node] <= product_pipe[lane][2*node] +
                                           product_pipe[lane][2*node+1];
                end
                for (node = 0; node < 4; node = node + 1) begin
                    sum_l2[lane][node] <= sum_l1[lane][2*node] +
                                           sum_l1[lane][2*node+1];
                end
                for (node = 0; node < 2; node = node + 1) begin
                    sum_l3[lane][node] <= sum_l2[lane][2*node] +
                                           sum_l2[lane][2*node+1];
                end
                sum_l4[lane] <= sum_l3[lane][0] + sum_l3[lane][1];

                if (valid_pipe[TREE_LEVELS]) begin
                    acc_reg[lane] <= acc_reg[lane] + sum_l4[lane];
                end
            end
        end
    end

endmodule
