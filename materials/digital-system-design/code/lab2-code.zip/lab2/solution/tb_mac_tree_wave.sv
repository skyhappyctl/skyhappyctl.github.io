`timescale 1ns/1ps
`define CLK_PERIOD 10

module tb_mac_tree_wave;

    parameter MAC_NUM    = 10;
    parameter BRANCH_NUM = 10;
    parameter BW_ACT     = 8;
    parameter BW_WET     = 8;
    parameter BW_ACCU    = 32;
    parameter TREE_LATENCY = (BRANCH_NUM <= 1) ? 1 : $clog2(BRANCH_NUM);

    parameter IA_H     = 100;
    parameter IA_W     = 150;
    parameter WEIGHT_H = 150;
    parameter WEIGHT_W = 16;
    parameter OA_H     = 100;
    parameter OA_W     = 16;

    reg clk;
    reg reset_n;
    reg PE_mac_enable;
    reg PE_clear_acc;
    reg [7:0] PE_res_shift_num;

    reg  signed [BW_ACT-1:0]  PE_act_in [MAC_NUM-1:0][BRANCH_NUM-1:0];
    reg  signed [BW_WET-1:0]  PE_wet_in [BRANCH_NUM-1:0];
    wire signed [BW_ACT-1:0]  PE_result_out [MAC_NUM-1:0];
    wire signed [BW_ACCU-1:0] PE_result_ori [MAC_NUM-1:0];
    wire                      PE_result_valid;

    reg signed [BW_ACT-1:0] Input_activation_main_memory [IA_H-1:0][IA_W-1:0];
    reg signed [BW_WET-1:0] Weight_main_memory [WEIGHT_H-1:0][WEIGHT_W-1:0];
    reg signed [BW_ACT-1:0] reference_output [OA_H-1:0][OA_W-1:0];

    integer wave_fd;
    integer sample_id;
    integer match_count;
    integer wrong_num;
    integer check_i;

    mac_tree #(
        .MAC_NUM(MAC_NUM),
        .BRANCH_NUM(BRANCH_NUM),
        .BW_ACT(BW_ACT),
        .BW_WET(BW_WET),
        .BW_ACCU(BW_ACCU)
    ) u_mac_tree (
        .clk(clk),
        .reset_n(reset_n),
        .PE_mac_enable(PE_mac_enable),
        .PE_clear_acc(PE_clear_acc),
        .PE_act_in(PE_act_in),
        .PE_wet_in(PE_wet_in),
        .PE_res_shift_num(PE_res_shift_num),
        .PE_result_out(PE_result_out),
        .PE_result_ori(PE_result_ori),
        .PE_result_valid(PE_result_valid)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD/2) clk = ~clk;
    end

    function integer open_or_fatal;
        input string path;
        input string fallback_path;
        begin
            open_or_fatal = $fopen(path, "r");
            if (open_or_fatal == 0) begin
                open_or_fatal = $fopen(fallback_path, "r");
            end
            if (open_or_fatal == 0) begin
                $fatal(1, "Could not open %s or %s", path, fallback_path);
            end
        end
    endfunction

    task load_matrix_files;
        integer fd;
        integer status;
        integer value;
        integer r;
        integer c;
        begin
            fd = open_or_fatal("lab2/input_act_dec.txt", "../../lab2/input_act_dec.txt");
            for (r = 0; r < IA_H; r = r + 1) begin
                for (c = 0; c < IA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) $fatal(1, "Short input activation file");
                    Input_activation_main_memory[r][c] = value;
                end
            end
            $fclose(fd);

            fd = open_or_fatal("lab2/weight_dec.txt", "../../lab2/weight_dec.txt");
            for (r = 0; r < WEIGHT_H; r = r + 1) begin
                for (c = 0; c < WEIGHT_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) $fatal(1, "Short weight file");
                    Weight_main_memory[r][c] = value;
                end
            end
            $fclose(fd);

            fd = open_or_fatal("lab2/reference_output_dec.txt", "../../lab2/reference_output_dec.txt");
            for (r = 0; r < OA_H; r = r + 1) begin
                for (c = 0; c < OA_W; c = c + 1) begin
                    status = $fscanf(fd, "%d", value);
                    if (status != 1) $fatal(1, "Short reference file");
                    reference_output[r][c] = value;
                end
            end
            $fclose(fd);
        end
    endtask

    task clear_inputs;
        integer lane;
        integer k;
        begin
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                    PE_act_in[lane][k] = '0;
                end
            end
            for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                PE_wet_in[k] = '0;
            end
        end
    endtask

    task sample_wave;
        reg signed [BW_ACT-1:0] ref_0;
        reg signed [BW_ACT-1:0] ref_1;
        reg signed [BW_ACT-1:0] ref_2;
        reg signed [BW_ACT-1:0] ref_3;
        reg match_0;
        reg match_1;
        reg match_2;
        reg match_3;
        begin
            ref_0 = reference_output[0][0];
            ref_1 = reference_output[1][0];
            ref_2 = reference_output[2][0];
            ref_3 = reference_output[3][0];
            match_0 = (PE_result_out[0] === ref_0);
            match_1 = (PE_result_out[1] === ref_1);
            match_2 = (PE_result_out[2] === ref_2);
            match_3 = (PE_result_out[3] === ref_3);

            $fdisplay(wave_fd, "%0d,%0t,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                      sample_id, $time, reset_n, PE_mac_enable, PE_clear_acc,
                      PE_act_in[0][0], PE_wet_in[0],
                      PE_result_valid, PE_result_ori[0], PE_result_out[0], ref_0, match_0,
                      PE_result_out[1], ref_1, match_1,
                      PE_result_out[2], ref_2, match_2,
                      PE_result_out[3], ref_3, match_3);
            sample_id = sample_id + 1;
        end
    endtask

    task tick_and_sample;
        begin
            @(posedge clk);
            #1;
            sample_wave();
        end
    endtask

    integer k_base;
    integer lane;
    integer k;
    integer row;
    integer col;
    integer flush_cycle;

    initial begin
        wave_fd = $fopen("solution/wave_mac_tree.csv", "w");
        if (wave_fd == 0) begin
            wave_fd = $fopen("../../solution/wave_mac_tree.csv", "w");
        end
        if (wave_fd == 0) begin
            wave_fd = $fopen("wave_mac_tree.csv", "w");
        end
        if (wave_fd == 0) begin
            $fatal(1, "Could not create solution/wave_mac_tree.csv");
        end
        $fdisplay(wave_fd, "cycle,time_ps,reset_n,PE_mac_enable,PE_clear_acc,PE_act_in_0_0,PE_wet_in_0,PE_result_valid,PE_result_ori_0,PE_result_out_0,reference_0_0,match_0,PE_result_out_1,reference_1_0,match_1,PE_result_out_2,reference_2_0,match_2,PE_result_out_3,reference_3_0,match_3");

        reset_n = 1'b0;
        PE_mac_enable = 1'b0;
        PE_clear_acc = 1'b0;
        PE_res_shift_num = 8;
        sample_id = 0;
        clear_inputs();
        load_matrix_files();

        tick_and_sample();
        tick_and_sample();
        reset_n = 1'b1;
        tick_and_sample();

        PE_clear_acc = 1'b1;
        tick_and_sample();
        PE_clear_acc = 1'b0;

        for (k_base = 0; k_base < IA_W; k_base = k_base + BRANCH_NUM) begin
            for (lane = 0; lane < MAC_NUM; lane = lane + 1) begin
                row = lane;
                for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                    col = k_base + k;
                    PE_act_in[lane][k] = Input_activation_main_memory[row][col];
                end
            end

            for (k = 0; k < BRANCH_NUM; k = k + 1) begin
                PE_wet_in[k] = Weight_main_memory[k_base + k][0];
            end

            PE_mac_enable = 1'b1;
            tick_and_sample();
        end

        PE_mac_enable = 1'b0;
        clear_inputs();
        for (flush_cycle = 0; flush_cycle < TREE_LATENCY + 1; flush_cycle = flush_cycle + 1) begin
            tick_and_sample();
        end

        match_count = 0;
        wrong_num = 0;
        for (check_i = 0; check_i < 4; check_i = check_i + 1) begin
            $display("CHECK mac_tree_wave OA[%0d][0]: output=%0d, reference=%0d",
                     check_i, PE_result_out[check_i], reference_output[check_i][0]);
            if (PE_result_out[check_i] === reference_output[check_i][0]) begin
                match_count = match_count + 1;
            end
            else begin
                $display("MISMATCH mac_tree_wave OA[%0d][0]: output=%0d, reference=%0d",
                         check_i, PE_result_out[check_i], reference_output[check_i][0]);
                wrong_num = wrong_num + 1;
            end
        end

        $display("mac_tree_wave match_count=%0d/4, wrong_num=%0d", match_count, wrong_num);
        if (wrong_num == 0) begin
            $display("PASS: mac_tree_wave all 4 sampled outputs match reference. raw OA[0][0]=%0d", PE_result_ori[0]);
        end
        else begin
            $fatal(1, "FAIL: mac_tree_wave wrong num = %0d", wrong_num);
        end

        $fclose(wave_fd);
        $finish;
    end

endmodule
