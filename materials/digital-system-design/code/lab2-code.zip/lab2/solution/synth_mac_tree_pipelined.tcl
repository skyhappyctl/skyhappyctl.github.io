read_verilog -sv solution/mac_tree_pipeline.sv
synth_design -top mac_tree -part xc7z035ffg676-2
create_clock -period 10.000 -name clk [get_ports clk]
report_timing_summary -file solution/mac_tree_pipelined_timing.rpt
report_utilization -file solution/mac_tree_pipelined_utilization.rpt
write_checkpoint -force solution/mac_tree_pipelined_synth.dcp
exit
