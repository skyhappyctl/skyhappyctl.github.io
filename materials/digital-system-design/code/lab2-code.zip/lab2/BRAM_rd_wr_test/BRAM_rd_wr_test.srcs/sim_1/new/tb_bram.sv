`timescale 1ns/1ps
`define CLK_PERIOD          10 //100MHz
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/18 12:32:58
// Design Name: 
// Module Name: tb_bram
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_bram;
    
    logic   clk;
    logic   ena;
    logic   wea;
    logic   [10:0]addr;
    logic   [15:0]din;
    logic   [15:0]dout;
    logic   [15:0]reference_output;

    logic   [15:0]Input_memory[2047:0];
    
    initial begin
        clk <= 0;
        ena <= 0;
        wea <= 0;
        addr <= 0;
        din <= 0;
        for(integer n=0;n<2048;n=n+1) begin
            Input_memory[n] <= $random % 65536; // initialize Input_memory with random values
        end
        forever begin
            #(`CLK_PERIOD/2) clk = ~clk; //模拟时钟产生
        end
    end
    BRAM_wrapper U_BRAM_wrapper(
        .clk    (clk    ),
        .ena    (ena    ),
        .wea    (wea    ),
        .addr   (addr   ),
        .din    (din    ),
        .dout   (dout   )
    );

    initial begin
        @(negedge clk);
        @(negedge clk);
        @(negedge clk);
        // Write data to BRAM
        ena <= 1;
        wea <= 1;
        for(integer n=0;n<2048;n=n+1) begin
            addr <= n;
            din <= Input_memory[n];
            @(negedge clk);
        end
        wea <= 0;
        addr <= 0;
        @(negedge clk);
        // Read data from BRAM
        for(integer n=1;n<2048;n=n+1) begin
            addr <= n;
            reference_output <= Input_memory[n-1]; // Store expected output 因为加了primitive output register，所以这里需要减1
            @(negedge clk);
            if(dout !== reference_output) begin
                $display("Error: Read data mismatch at address %0d. Expected: %0d, Got: %0d", n, reference_output, dout);
            end else begin
                $display("Read data match at address %0d. Data: %0d", n, dout);
            end
        end

        $finish(0);
    end

endmodule
