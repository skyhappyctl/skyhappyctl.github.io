`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/18 12:28:41
// Design Name: 
// Module Name: BRAM_wrapper
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module BRAM_wrapper(
    input logic clk,
    input logic ena,
    input logic wea,
    input logic [10:0]addr,
    input logic [15:0]din,
    output logic [15:0]dout
);
    blk_mem_2048x16 block_mem_1(
        .clka    (clk    ),
        .ena     (ena    ),
        .wea     (wea    ),
        .addra   (addr   ),
        .dina    (din    ),
        .douta   (dout   )
    );
endmodule
