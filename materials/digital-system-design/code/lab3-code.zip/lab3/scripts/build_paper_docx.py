# -*- coding: utf-8 -*-
"""Generate the dense-PE accelerator paper as a docx that reuses the IEEE
template's styles (论文格式模板.docx). We rebuild word/document.xml with our
content and repackage all other template parts unchanged so every paragraph
style (papertitle/Author/Abstract/Keywords/Heading1.. /BodyText/tablehead/
references) renders exactly as the template defines.
"""
import shutil
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[1]
TPL = ROOT / "论文格式模板.docx"
OUT = ROOT / "论文" / "稀疏矩阵乘法加速器设计.docx"

W = "http://purl.oclc.org/ooxml/wordprocessingml/main"

# ---- low level builders ----------------------------------------------------

def run(text, *, bold=False, italic=False):
    rpr = ""
    props = ""
    if bold:
        props += "<w:b/><w:bCs/>"
    if italic:
        props += "<w:i/><w:iCs/>"
    if props:
        rpr = f"<w:rPr>{props}</w:rPr>"
    return f'<w:r>{rpr}<w:t xml:space="preserve">{escape(text)}</w:t></w:r>'


def para(style, runs_xml, *, jc=None):
    ppr = f'<w:pStyle w:val="{style}"/>'
    if jc:
        ppr += f'<w:jc w:val="{jc}"/>'
    return f"<w:p><w:pPr>{ppr}</w:pPr>{runs_xml}</w:p>"


def p_text(style, text, *, bold=False, jc=None):
    return para(style, run(text, bold=bold), jc=jc)


def p_runs(style, runs, *, jc=None):
    return para(style, "".join(runs), jc=jc)


def sect(num_cols, *, space="18pt", continuous=True, last=False):
    """Section properties paragraph (column break) or final body sectPr."""
    cols = (f'<w:cols w:num="{num_cols}" w:space="{space}"/>'
            if num_cols and num_cols > 1 else
            f'<w:cols w:space="{space}"/>')
    typ = '<w:type w:val="continuous"/>' if continuous else ''
    inner = (f'{typ}<w:pgSz w:w="612pt" w:h="792pt" w:code="1"/>'
             '<w:pgMar w:top="54pt" w:right="44.65pt" w:bottom="72pt" '
             'w:left="44.65pt" w:header="36pt" w:footer="36pt" w:gutter="0pt"/>'
             f'{cols}<w:docGrid w:linePitch="360"/>')
    if last:
        return f"<w:sectPr>{inner}</w:sectPr>"
    # embedded in a paragraph's pPr to force a section break here
    return f'<w:p><w:pPr><w:sectPr>{inner}</w:sectPr></w:pPr></w:p>'


def table(headers, rows, *, widths=None):
    ncol = len(headers)
    if widths is None:
        widths = [int(468 / ncol)] * ncol  # ~ pt total content width is wider; use grid
    grid = "".join(f'<w:gridCol w:w="{w}pt"/>' for w in widths)

    def cell(text, *, head=False):
        style = "tablecolhead" if head else "tablecopy"
        # center, with thin borders
        tcpr = ('<w:tcPr>'
                '<w:tcBorders>'
                '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                '<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                '<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                '</w:tcBorders>'
                '<w:vAlign w:val="center"/>'
                '</w:tcPr>')
        ppr = f'<w:pPr><w:pStyle w:val="{style}"/><w:jc w:val="center"/></w:pPr>'
        return (f'<w:tc>{tcpr}<w:p>{ppr}'
                f'{run(text, bold=head)}</w:p></w:tc>')

    hdr = "<w:tr>" + "".join(cell(h, head=True) for h in headers) + "</w:tr>"
    body = ""
    for r in rows:
        body += "<w:tr>" + "".join(cell(str(c)) for c in r) + "</w:tr>"
    tblpr = ('<w:tblPr>'
             '<w:tblW w:w="0" w:type="auto"/>'
             '<w:jc w:val="center"/>'
             '<w:tblLayout w:type="autofit"/>'
             '</w:tblPr>')
    return (f'<w:tbl>{tblpr}<w:tblGrid>{grid}</w:tblGrid>{hdr}{body}</w:tbl>')


# ---- content ---------------------------------------------------------------

def build_body():
    P = []

    # ---------------- Title + authors (single column section) -------------
    P.append(p_text("papertitle",
        "基于稠密权重固定PE阵列的稀疏矩阵乘法加速器设计"))
    P.append(p_text("Author", "作者：请填写姓名"))
    P.append(p_text("Author", "电子工程系，清华大学，中国 北京"))
    P.append(p_text("Author", "邮箱：请填写邮箱"))
    # break to 2-column body
    P.append(sect(1, space="36pt"))

    # ---------------- Abstract & keywords ---------------------------------
    P.append(p_runs("Abstract", [
        run("摘要——", bold=True, italic=True),
        run("矩阵乘法是深度神经网络卷积层和全连接层的核心运算。"
            "模型剪枝与 ReLU 激活会在权重和激活矩阵中引入大量零值，"
            "若按稠密矩阵执行会浪费乘法器、访存带宽与片上存储。"
            "本文针对 VGG-16 第三卷积层（weight 128×576、activation 576×1024、"
            "输出 128×1024）设计了一种基于稠密权重与固定 PE 阵列的稀疏外积加速器。"
            "设计将权重按 K 维打包为单条 1024-bit 宽 BRAM 字，使 128 个输出行各自拥有"
            "独立累加器，从根本上消除了上一版位图并行方案中因变址读改写累加器堆而产生的"
            "巨型交叉开关；通过四级流水线实现稳态每周期处理一个非零激活，并以 ping-pong "
            "双累加器组将结果输出与下一列计算重叠。乘法器映射到 LUT 以规避 DSP 约束。"
            "Vivado 2019.2 在 xc7a200tfbg676-2 上的综合结果为 LUT 28,212、FF 8,996、"
            "BRAM 192、DSP 1，100 MHz 时序收敛（WNS=+4.353 ns）；全量 1024 列仿真输出"
            "131,072 个结果全部正确，总计算周期为 273,073。按课程指标公式计算，"
            "性能指标约为 0.0104。", italic=True),
    ]))
    P.append(p_runs("Keywords", [
        run("关键词——", bold=True, italic=True),
        run("稀疏矩阵；外积数据流；固定 PE 阵列；流水线；双缓冲；FPGA 加速器",
            italic=True),
    ]))

    # ---------------- I. Introduction -------------------------------------
    P.append(p_text("Heading1", "引言"))
    P.append(p_text("BodyText",
        "深度学习已广泛应用于图像识别、自然语言处理与边缘感知等领域。随着模型规模增大，"
        "推理计算逐渐成为系统能耗与延迟的主要来源。卷积层与全连接层从硬件执行角度都可归约为"
        "权重与激活之间的大规模乘加运算，因此矩阵乘法加速器一直是神经网络硬件设计的核心模块。"
        "以卷积为例，二维卷积可通过 img2col 展开为矩阵并以 GEMM 形式与权重相乘，便于利用规则"
        "的乘累加阵列，但展开会显著放大访存压力。"))
    P.append(p_text("BodyText",
        "实际网络中存在显著稀疏性：权重稀疏多来自剪枝，激活稀疏多来自 ReLU。若仍按稠密矩阵执行，"
        "乘法器会频繁执行无效的乘零操作，BRAM 与片外访存也会搬运大量无贡献数据，"
        "造成吞吐、面积与功耗的浪费。稀疏加速的难点在于非结构化零值分布不规则，需要额外保存索引"
        "或掩码，并在硬件中完成地址生成与累加调度；若格式设计不当，节省的乘法可能被额外的控制与"
        "存储开销抵消。"))
    P.append(p_text("BodyText",
        "本实验数据取自 VGG-16 第三层卷积。weight 规模 128×576，activation_col 规模 576×1024，"
        "输出 128×1024。统计表明 weight 非零 20,644 个（密度 28.00%），activation_col 非零 "
        "262,575 个（密度 44.52%）。直接稠密执行需 75,497,472 次单 MAC 级遍历，其中相当一部分"
        "与零值相关。实验 3 要求利用 Xilinx FPGA 的 BRAM 预存矩阵数据，并由可综合硬件完成矩阵到"
        "计算阵列的映射，关注的不仅是功能正确性，还包括 BRAM 使用方式、资源占用、计算周期与综合时序。"))
    P.append(p_text("BodyText",
        "本文的前一版实现采用按列位图压缩配合 16-lane 并行更新，虽然把 BRAM 压到 121.5，但其在单个"
        "更新状态内对 128 深累加器寄存器堆进行变址读改写，综合后产生约 70,101 个 LUT 与庞大的 "
        "F7/F8 多路选择网络，且 100 MHz 下时序违例（WNS=−3.572 ns）。针对该瓶颈，本文提出稠密权重"
        "固定 PE 架构：每个输出行独占累加器以消除交叉开关，并通过四级流水线与双缓冲在不牺牲时序的"
        "前提下提升吞吐。"))
    P.append(p_text("BodyText",
        "本文后续安排如下：第二节给出问题形式化；第三节介绍稠密权重固定 PE 加速架构；"
        "第四节说明数据部署与压缩格式；第五节给出仿真与综合结果；第六节进行分析与对比；第七节总结全文。"))

    # ---------------- II. Problem formulation -----------------------------
    P.append(p_text("Heading1", "问题形式化"))
    P.append(p_text("BodyText",
        "记权重矩阵为 W∈Z^{M×K}，激活矩阵为 A∈Z^{K×N}，输出为 O=W·A∈Z^{M×N}，"
        "本实验中 M=128，K=576，N=1024。输出元素定义为式 (1)："))
    P.append(p_text("equation",
        "O[m, n] = Σ_{k=0}^{K-1} W[m, k] · A[k, n]            (1)"))
    P.append(p_text("BodyText",
        "由于 A 高度稀疏，对固定输出列 n，只有满足 A[k,n]≠0 的 k 才对结果有贡献。"
        "将 A 按列以 CSR 形式压缩，仅保存非零值及其行索引 k，则式 (1) 可改写为对非零集合的外积累加，"
        "见式 (2)："))
    P.append(p_text("equation",
        "O[:, n] = Σ_{k∈nz(n)} A[k, n] · W[:, k]            (2)"))
    P.append(p_text("BodyText",
        "式 (2) 表明：以一个非零激活为中心，读取其对应的整列权重 W[:,k]，即可一次性更新该输出列的全部 "
        "M 个累加器。这一外积视角是本文硬件数据流的基础——它把对零值的乘法完全跳过，"
        "并使权重访问与累加都呈规则的逐行并行结构，便于流水化与无冲突累加。"))

    # ---------------- III. Method -----------------------------------------
    P.append(p_text("Heading1", "稠密权重固定PE加速架构"))

    P.append(p_text("Heading2", "整体数据流"))
    P.append(p_text("BodyText",
        "加速器以输出列为外层循环。每开始处理一列 n，控制器先清零 128 个累加器；随后按列主序 CSR "
        "依次取出该列的非零激活 (k, v)；对每个非零激活读取稠密权重列 W[:,k]，并令 128 个处理单元 "
        "(PE) 并行执行 acc[m] += v · W[m,k]；该列处理完毕后按行顺序输出 128 个结果。"
        "这种 output-column-stationary 策略复用同一激活对所有输出行的贡献，避免逐输出点重复扫描激活列。"))
    P.append(p_text("BodyText",
        "与前一版最关键的区别在于累加器组织：本文让每个输出行拥有专属累加器，权重列 W[:,k] 的第 m 字节"
        "天然对应第 m 个 PE，因此累加是 128 路定向写、互不冲突，不存在变址写回，"
        "从而彻底消除了导致 70k LUT 与时序违例的交叉开关。"))

    P.append(p_text("Heading2", "四级流水线"))
    P.append(p_text("BodyText",
        "片上 BRAM 为同步读、具有一个周期读延迟，且“由激活索引 k 去取权重列”是一次链式访问"
        "（先读 a_idx，再以其为地址读 wd）。为使稳态吞吐达到每周期一个非零激活，本文构建四级流水线："
        "S_A 发射读地址；S_B 取得激活值 v 与索引 k，并发起权重列读取；S_C 将 v 对齐打一拍；"
        "S_D 取得权重列 W[:,k] 并驱动 128 个 PE 完成乘加。各级以 valid 寄存器 (vA…vD) 串联，"
        "填充 4 拍后稳态每拍完成一次 128 路 MAC。"))
    P.append(p_text("BodyText",
        "乘法采用 8×8 位有符号乘法并显式标注 (* use_dsp = \"no\" *)，强制综合器用 LUT 实现，"
        "使 DSP 占用降到 1 个，远低于 3% 的约束上限。"))

    P.append(p_text("Heading2", "Ping-pong 双缓冲累加"))
    P.append(p_text("BodyText",
        "为隐藏结果输出开销，128 个累加器实现为两组 bank (acc0/acc1)。当 compute 引擎在当前 bank 上"
        "累加第 n 列时，emit 引擎在另一 bank 上一边逐行读出第 n−1 列结果、一边清零以备复用。"
        "每完成一列即翻转 bank 指针，使除最后一列外的全部输出延迟都被计算过程吸收，因而实测周期"
        "(273,073) 优于不考虑重叠的解析模型预测 (288,303)。"))

    P.append(p_text("Heading2", "BRAM 存储与控制"))
    P.append(p_text("BodyText",
        "所有矩阵数据由 testbench 经统一的 load 端口写入 DUT 内部 BRAM。RTL 中的 simple_dual_port_bram "
        "以同步读写数组描述存储并标注 (* ram_style = \"block\" *)，引导 Vivado 推断 Block RAM。"
        "主控制器由有限状态机实现，状态包括空闲、清零、读列指针、流水计算、列结束翻转 bank、"
        "排空与完成。稠密权重以单条 1024-bit 宽字保存，128 个 PE 各取其 8-bit 切片，"
        "这是固定 PE 阵列免交叉开关的存储前提。"))

    # ---------------- IV. Data deployment ---------------------------------
    P.append(p_text("Heading1", "数据部署与稀疏压缩"))
    P.append(p_text("BodyText",
        "激活矩阵按输出列以 CSR 压缩，保存非零值 a_values、行索引 a_indices 以及每列起止指针 a_ptr。"
        "权重矩阵按 K 维重排为稠密列存储 wd_by_k：第 k 条字宽 1024 bit，依次拼接第 k 列上 128 个输出行的"
        "8-bit 权重，使 PE m 直接读取 bit 区间 [m·8, m·8+8)。各存储体的位宽与深度见表 I。"))
    P.append(table(
        ["数据", "含义", "位宽", "深度"],
        [
            ["wd_by_k", "按 K 维打包的稠密权重列", "1024", "576"],
            ["a_values", "非零激活值", "8", "262,575"],
            ["a_indices", "非零激活的 K 维行索引", "10", "262,575"],
            ["a_ptr", "每列非零起止指针", "19", "1,025"],
        ],
        widths=[70, 150, 45, 70]))
    P.append(p_text("tablehead", "表 I  各 BRAM 存储体的位宽与深度", jc="center"))
    P.append(p_text("BodyText",
        "该格式的核心取舍是用一块宽权重 BRAM 换取无交叉开关的并行累加：wd_by_k 虽然位宽较大，"
        "但深度仅为 K=576，且按列读取规则、命中率高；激活侧仅保存非零值与索引，跳过了全部零值乘法。"))

    # ---------------- V. Experiments --------------------------------------
    P.append(p_text("Heading1", "实验测试与结果"))
    P.append(p_text("BodyText",
        "实验使用 Vivado 2019.2，目标器件 xc7a200tfbg676-2，时钟约束 100 MHz。仿真流程为：testbench "
        "先将各 .mem 文件写入对应 BRAM，再拉高 start 启动计算，最后将硬件逐行输出与 output_col.mem 中的"
        "参考结果逐点比较。为避免中文路径在 Vivado 2019.2 下的兼容问题，工程与数据均置于纯英文路径下。"))
    P.append(p_text("BodyText",
        "功能验证分两级：先用前 16 列做快速回归，再用全量 1024 列做完整验证。两级均输出 0 mismatch；"
        "全量验证覆盖 131,072 个输出点，总计算周期为 273,073，与 Python 周期精确模型互相印证。"
        "综合后资源与时序见表 II，与前一版位图并行方案的对比见表 III。"))
    P.append(table(
        ["指标", "数值"],
        [
            ["验证规模", "全量 1024 列"],
            ["输出点数", "131,072"],
            ["Mismatch", "0"],
            ["总计算周期", "273,073"],
            ["LUT", "28,212"],
            ["FF", "8,996"],
            ["BRAM", "192"],
            ["DSP", "1"],
            ["时序 (WNS@100MHz)", "+4.353 ns（收敛）"],
        ],
        widths=[150, 130]))
    P.append(p_text("tablehead", "表 II  本文设计的仿真与综合结果", jc="center"))
    P.append(p_text("BodyText",
        "课程性能指标按 式 (3) 计算："))
    P.append(p_text("equation",
        "Index = [ 1 / (FF + 0.25·LUT + 100·BRAM) ] · (Fmax / Cycles)            (3)"))
    P.append(p_text("BodyText",
        "代入真实综合数据：分母 = 8,996 + 0.25×28,212 + 100×192 = 35,249；以 Fmax=100 MHz、"
        "Cycles=273,073 计算，得 Index ≈ (1/35,249)×(1.0×10^8/273,073) ≈ 0.0104，落入 [0.01, 0.015) 区间。"
        "值得注意的是综合后 WNS=+4.353 ns，说明关键路径仍有较大裕量，实际可达频率约 177 MHz；"
        "若按可达频率重新计算，指标可进一步提升至约 0.018。"))
    P.append(table(
        ["方案", "周期数", "LUT", "FF", "BRAM", "时序"],
        [
            ["位图并行（前一版）", "6,357,983", "70,101", "5,417", "121.5", "WNS=−3.572 ns（违例）"],
            ["稠密 PE（本文）", "273,073", "28,212", "8,996", "192", "WNS=+4.353 ns（收敛）"],
        ],
        widths=[95, 70, 50, 45, 45, 95]))
    P.append(p_text("tablehead", "表 III  与前一版位图并行方案的对比", jc="center"))
    P.append(p_text("BodyText",
        "对比可见，本文方案在周期上较位图并行方案降低约 95.7%，且 LUT 从 70,101 降到 28,212，"
        "更重要的是把 100 MHz 下的时序从违例转为收敛。BRAM 由 121.5 升至 192，是用一块宽权重存储"
        "换取无交叉开关并行累加所付出的代价，但综合权衡后性能指标显著优于前一版。"))

    # ---------------- VI. Analysis ----------------------------------------
    P.append(p_text("Heading1", "分析与讨论"))
    P.append(p_text("Heading2", "时序与资源折衷"))
    P.append(p_text("BodyText",
        "前一版的根本问题在于把高并行度堆叠在单个组合更新状态内：16 个 lane 同时对 128 深累加器堆变址"
        "读改写，综合器需要为之构造庞大的多路选择与写仲裁网络，既抬高 LUT 又拉长关键路径。"
        "本文用“固定 PE + 独立累加器 + 流水线”将并行度沿时间展开而非沿组合逻辑展开，"
        "使每一级的组合深度仅为一次乘加，因而在保持高吞吐的同时获得正的时序裕量。"))
    P.append(p_text("Heading2", "工作负载敏感性"))
    P.append(p_text("BodyText",
        "稀疏加速器的利用率依赖工作负载分布。本数据集各输出列的非零激活数不均，但由于流水线稳态吞吐与"
        "列内非零数线性相关，且双缓冲吸收了输出延迟，整体周期主要由总非零数 262,575 与流水填充、"
        "列指针读取等固定开销共同决定。对更稀疏的负载，可进一步增大每周期消费的非零数 (width>1) 以摊薄"
        "固定开销；对更稠密的负载，当前 width=1 已能保持较高的 PE 利用率。"))
    P.append(p_text("Heading2", "与其他方案对比"))
    P.append(p_text("BodyText",
        "与逐输出点 intersection 匹配方案相比，外积方案避免了对同一激活列的重复扫描，更适合本实验 128 个"
        "输出行的场景。与完全展开的稀疏乘法阵列相比，本文方案对输出存储的访问集中于 128 个本地累加器，"
        "规避了同周期向多个随机地址写回的带宽冲突；代价是需在列内维护累加状态，并为每个输出行配备 PE。"
        "综合来看，本文在资源、频率与周期三者之间取得了更均衡的折衷。"))

    # ---------------- VII. Conclusion -------------------------------------
    P.append(p_text("Heading1", "结论"))
    P.append(p_text("BodyText",
        "本文针对 VGG-16 第三卷积层的稀疏矩阵乘法，设计并验证了一种基于稠密权重与固定 PE 阵列的外积"
        "加速器。通过让每个输出行独占累加器，本文消除了前一版位图并行方案中导致 70k LUT 与时序违例的"
        "累加器交叉开关；通过四级流水线与 ping-pong 双缓冲，实现稳态每周期一个非零激活的吞吐并隐藏输出"
        "延迟；通过 LUT 乘法器满足 DSP 约束。全量 1024 列仿真输出 131,072 个结果全部正确，总周期 273,073；"
        "综合后 LUT 28,212、FF 8,996、BRAM 192、DSP 1，100 MHz 时序收敛，性能指标约 0.0104。"
        "结果表明，稀疏加速的关键不仅在于减少乘法次数，更在于选择与数据流相匹配的存储组织与并行展开方式，"
        "从而在资源、频率与周期之间取得良好平衡。"))

    # ---------------- Acknowledgment --------------------------------------
    P.append(p_text("Heading5", "致谢"))
    P.append(p_text("BodyText",
        "作者感谢数字系统设计课程教师与助教在实验讲解、Vivado 使用与论文写作方面提供的帮助。"))

    # ---------------- References ------------------------------------------
    P.append(p_text("Heading5", "参考文献"))
    refs = [
        "K. Chellapilla, S. Puri, and P. Simard, \u201cHigh performance convolutional neural networks for document processing,\u201d in Proc. ICFHR, 2006.",
        "S. Han, J. Pool, J. Tran, and W. J. Dally, \u201cLearning both weights and connections for efficient neural networks,\u201d in Proc. NeurIPS, 2015.",
        "S. Han et al., \u201cEIE: Efficient inference engine on compressed deep neural network,\u201d in Proc. ISCA, 2016.",
        "J.-F. Zhang et al., \u201cSNAP: An efficient sparse neural acceleration processor for unstructured sparse deep neural network inference,\u201d IEEE J. Solid-State Circuits, 2021.",
        "AMD Xilinx, \u201cBlock Memory Generator v8.4 Product Guide (PG058),\u201d 2021.",
        "\u6570\u5b57\u7cfb\u7edf\u8bbe\u8ba1\u8bfe\u7a0b\u7ec4, \u201cLab-3 \u9635\u5217+\u5b58\u50a8\u5668\u7cfb\u7edf\u8bbe\u8ba1\u5b9e\u9a8c\u6307\u5357,\u201d 2026.",
    ]
    for i, r in enumerate(refs, 1):
        P.append(p_runs("references", [run(f"[{i}] "), run(r)]))

    # final body section (2-column to match the body we set)
    P.append(sect(2, space="18pt", last=True))
    return "".join(P)


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = (ROOT / "generated" / "_tpl_document.xml").read_text(encoding="utf-8")
    prefix = doc[: doc.find("<w:body>") + len("<w:body>")]
    new_doc = prefix + build_body() + "</w:body></w:document>"

    # repackage: copy every part from template, replace document.xml
    with zipfile.ZipFile(TPL) as zin:
        names = zin.namelist()
        with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zout:
            for n in names:
                data = zin.read(n)
                if n == "word/document.xml":
                    data = new_doc.encode("utf-8")
                zout.writestr(n, data)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
