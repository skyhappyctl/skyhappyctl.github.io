#!/usr/bin/env python3
"""Generate a reference-report-style double-column Lab 3 paper."""

from __future__ import annotations

import html
import json
import zipfile
from pathlib import Path


LAB3_DIR = Path(__file__).resolve().parents[1]
GEN_DIR = LAB3_DIR / "generated"
REPORT_DIR = LAB3_DIR / "report"


def esc(text: object) -> str:
    return html.escape(str(text), quote=True)


def fmt_int(value: int | float) -> str:
    return f"{int(value):,}"


def fmt_float(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def run(text: str, bold: bool = False, size: int = 21) -> str:
    b = "<w:b/>" if bold else ""
    return (
        "<w:r><w:rPr>"
        '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="SimSun"/>'
        f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>{b}'
        f"</w:rPr><w:t xml:space=\"preserve\">{esc(text)}</w:t></w:r>"
    )


def section_properties(cols: int, section_type: str | None = None) -> str:
    typ = f'<w:type w:val="{section_type}"/>' if section_type else ""
    return (
        "<w:sectPr>"
        f"{typ}"
        '<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1440" w:right="1080" w:bottom="1200" w:left="1080" '
        'w:header="720" w:footer="720" w:gutter="0"/>'
        f'<w:cols w:num="{cols}" w:space="720"/>'
        "</w:sectPr>"
    )


def paragraph(
    text: str,
    *,
    align: str | None = None,
    bold: bool = False,
    size: int = 21,
    style: str | None = None,
    one_col_break: bool = False,
) -> str:
    ppr = ['<w:spacing w:after="80" w:line="276" w:lineRule="auto"/>']
    if style:
        ppr.insert(0, f'<w:pStyle w:val="{style}"/>')
    if align:
        ppr.append(f'<w:jc w:val="{align}"/>')
    if one_col_break:
        ppr.append(section_properties(1, "continuous"))
    return f"<w:p><w:pPr>{''.join(ppr)}</w:pPr>{run(text, bold=bold, size=size)}</w:p>"


def heading(text: str, level: int = 1) -> str:
    return paragraph(text, bold=True, size=22 if level == 1 else 21, style=f"Heading{level}")


def table(rows: list[list[str]]) -> str:
    out = [
        "<w:tbl><w:tblPr>"
        '<w:tblW w:w="0" w:type="auto"/>'
        '<w:tblBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        "</w:tblBorders></w:tblPr>"
    ]
    for r, row in enumerate(rows):
        out.append("<w:tr>")
        for cell in row:
            out.append(
                '<w:tc><w:tcPr><w:tcW w:w="0" w:type="auto"/></w:tcPr>'
                + paragraph(cell, bold=(r == 0), size=18)
                + "</w:tc>"
            )
        out.append("</w:tr>")
    out.append("</w:tbl>")
    return "".join(out)


def markdown_table(rows: list[list[str]]) -> str:
    return "\n".join(
        [
            "| " + " | ".join(rows[0]) + " |",
            "| " + " | ".join(["---"] * len(rows[0])) + " |",
            *["| " + " | ".join(row) + " |" for row in rows[1:]],
        ]
    )


def document_xml(body: str) -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{body}{section_properties(2)}</w:body></w:document>"
    )


def styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="SimSun"/><w:sz w:val="21"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="22"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="21"/></w:rPr></w:style>
</w:styles>"""


def write_docx(path: Path, xml: str) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
    doc_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/_rels/document.xml.rels", doc_rels)
        zf.writestr("word/document.xml", xml)
        zf.writestr("word/styles.xml", styles_xml())


def build() -> tuple[str, str]:
    stats = json.loads((GEN_DIR / "data_stats.json").read_text(encoding="utf-8"))
    nnz = stats["nnz"]
    density = stats["density"]

    dense_cycles = 75_497_472
    original_cycles = 4_379_508
    serial_cycles = 17_348_753
    parallel_cycles = 6_357_983

    original = {"lut": 91_869, "ff": 13_653, "bram": 430.5, "cycles": original_cycles}
    serial = {"lut": 3_028, "ff": 4_829, "bram": 121.5, "cycles": serial_cycles}
    parallel = {"lut": 70_101, "ff": 5_417, "bram": 121.5, "cycles": parallel_cycles}
    fmax = 100_000_000

    def metric(d: dict[str, float]) -> float:
        return (fmax / d["cycles"]) / (d["ff"] + 0.25 * d["lut"] + 100 * d["bram"])

    title = "基于 BRAM 的稀疏矩阵乘法加速器设计"
    author_lines = ["作者：请填写姓名", "电子工程系", "清华大学", "中国，北京", "邮箱：请填写邮箱"]
    abstract = (
        "摘要 —— 在深度学习推理中，矩阵乘法是卷积层和全连接层的核心计算。"
        "模型剪枝会使权重矩阵产生大量零值，ReLU 等激活函数也会提高输入矩阵稀疏度，直接按照稠密矩阵乘法执行会浪费大量乘法器、访存带宽和片上存储资源。"
        "实验 3 要求利用 FPGA 片上 BRAM 预存矩阵数据，并由硬件控制完成矩阵到计算阵列的 mapping。"
        "本文设计了一种基于稀疏外积数据流的矩阵乘法加速器：首先将 activation_col 按输出列压缩，将 weight 按 K 维重排并打包为 16-lane 权重块；随后使用 BRAM 保存压缩数据，通过 FSM 完成非零 activation 读取、权重块访问和输出通道累加。"
        "针对初始外积方案 BRAM 占用过高的问题，本文进一步引入 bitmap 压缩，将 activation 的 K 维索引改为按列非零掩码存储。"
        f"实验结果显示，并行 bitmap 版本在全量 128×1024 输出上 mismatch 为 0，计算周期为 {fmt_int(parallel_cycles)}；综合后使用 LUT {fmt_int(parallel['lut'])}、FF {fmt_int(parallel['ff'])}、BRAM {parallel['bram']}、DSP 1 个。"
    )

    md = [f"# {title}", *author_lines, abstract, "关键词 —— 稀疏矩阵，BRAM，外积数据流，bitmap 压缩，FPGA 加速器。"]
    doc = [
        paragraph(title, align="center", bold=True, size=32),
        *[paragraph(x, align="center", size=20) for x in author_lines],
        paragraph(abstract, size=21),
        paragraph("关键词 —— 稀疏矩阵，BRAM，外积数据流，bitmap 压缩，FPGA 加速器。", size=21, one_col_break=True),
    ]

    def add_section(name: str) -> None:
        md.append(f"## {name}")
        doc.append(heading(name, 1))

    def add_sub(name: str) -> None:
        md.append(f"### {name}")
        doc.append(heading(name, 2))

    def add_para(text: str) -> None:
        md.append(text)
        doc.append(paragraph(text))

    add_section("Ⅰ. 引言")
    for text in [
        "深度学习已经广泛应用于图像识别、自然语言处理、推荐系统、智能驾驶和边缘感知等领域。随着模型规模不断增大，神经网络的推理计算逐渐成为系统能耗和延迟的重要来源。在这些模型中，卷积层和全连接层虽然在结构上有所不同，但从硬件执行角度看，本质上都可以转化为权重数据与输入激活数据之间的大规模乘加运算。因此，矩阵乘法加速器一直是神经网络硬件设计中的核心模块。",
        "以卷积神经网络为例，二维卷积可以通过 img2col 将输入特征图展开为矩阵，再与卷积核权重矩阵相乘得到输出特征图。这样做可以把卷积运算统一为 GEMM 形式，便于利用规则的乘累加阵列、脉动阵列或向量化数据通路。但这种转换也会放大访存压力：展开后的 activation_col 矩阵包含大量重复数据，输出通道和空间位置数量较大时，矩阵维度迅速增长，片上存储和数据搬运成为限制性能的重要因素。",
        "另一方面，实际神经网络中存在显著稀疏性。权重矩阵的稀疏性通常来自模型剪枝、量化后的小值裁剪或结构化压缩；输入激活的稀疏性则常由 ReLU 等非线性函数产生。对于这些零值，如果仍然按照稠密矩阵乘法执行，乘法器会频繁执行无效的乘零操作，BRAM 和片外访存也会搬运大量对最终结果没有贡献的数据。这不仅降低吞吐率，也会造成面积和功耗浪费。",
        "稀疏矩阵加速的难点在于零值分布通常不规则。规则稀疏可以通过固定模式跳过计算，而非结构化稀疏需要额外保存索引或掩码，并在硬件中完成索引匹配、地址生成和累加调度。若索引格式设计不当，节省下来的乘法计算可能被额外的控制开销和存储开销抵消。因此，稀疏加速器的关键并不只是减少乘法次数，还包括设计合适的数据压缩格式、存储组织和数据流。",
        "FPGA 在这类任务中具有较好的实验价值。一方面，FPGA 内部 BRAM 可以提供确定延迟和较高带宽的片上存储，适合保存压缩后的权重、激活和索引信息；另一方面，FPGA 可通过 RTL 定制状态机、地址生成器和并行计算单元，使数据流与具体稀疏格式相匹配。与通用处理器相比，FPGA 更容易针对固定矩阵规模和固定压缩格式做专用优化。",
        f"本实验数据来自 VGG-16 第三层卷积。weight 矩阵规模为 128×576，activation_col 矩阵规模为 576×1024，输出矩阵规模为 128×1024。统计结果表明，weight 非零元素为 {fmt_int(nnz['weight'])} 个，密度为 {fmt_float(density['weight'] * 100)}%；activation_col 非零元素为 {fmt_int(nnz['activation_col_by_col'])} 个，密度为 {fmt_float(density['activation_col'] * 100)}%。如果直接执行稠密矩阵乘法，则需要 {fmt_int(dense_cycles)} 次单 MAC 级别的乘加遍历，其中相当一部分操作实际与零值相关。",
        "实验 3 的要求是利用 Xilinx FPGA 的 BRAM 将矩阵数据预存到片上存储器中，再通过硬件控制完成矩阵到计算阵列的 mapping。与前序实验中主要依靠 testbench 软件循环完成数据搬运不同，本实验需要构造可综合的硬件模块，使数据读取、索引解析、乘加累加和输出验证都由硬件控制流程完成。也就是说，本实验关注的不只是功能正确性，还包括 BRAM 使用方式、资源占用、计算周期和综合时序。",
        "基于上述背景，本文设计了基于 BRAM 的稀疏外积矩阵乘法加速器。设计首先将 activation_col 按输出列压缩，将 weight 按 K 维重排并打包为 16-lane 权重块；随后通过硬件 FSM 从 BRAM 中读取非零 activation 和权重块，对 128 个输出通道进行累加。针对基础外积方案 BRAM 占用过高的问题，本文进一步引入 bitmap 压缩，用按列非零掩码替代大规模索引表，从而在资源和周期之间进行折衷。",
        "本文后续安排如下：第二节介绍基于 BRAM 的稀疏外积加速方案；第三节说明数据部署与压缩格式；第四节给出仿真和综合结果；第五节分析不同方案的优缺点；第六节讨论工作负载与资源折衷；第七节总结全文。"
    ]:
        add_para(text)

    add_section("Ⅱ. 稀疏矩阵乘法加速")
    add_sub("A. 方案概述")
    for text in [
        "参考实验文档给出的稀疏矩阵乘法思路，本文没有采用逐输出点进行索引交集匹配的方案，而是采用更适合本数据集的外积式 mapping。该方案以一个非零 activation 为中心，读取该 activation 对应 K 维上的所有非零权重块，并一次性更新多个输出通道的累加器。",
        "硬件以输出列为外层循环。每开始处理一列，控制器先清零 128 个输出通道的累加寄存器；然后遍历该列所有非零 activation；对每个 activation，根据其 K 维位置读取权重块指针，再顺序读取打包后的权重值和输出通道编号；最后在累加器中执行 accum[row] += activation × weight。该列处理完成后，控制器按输出通道顺序输出 128 个结果。",
        "这种 output-column stationary 策略能够复用同一个 activation 对多个输出通道的贡献，避免逐输出点重复扫描 activation 列。其代价是需要在硬件内部维护 128 个累加器，并且权重块读出与累加器更新之间存在带宽和时序折衷。"
    ]:
        add_para(text)

    add_sub("B. BRAM 存储与控制模块")
    for text in [
        '所有矩阵数据均通过 testbench 写入 DUT 内部 BRAM。RTL 中的 simple_dual_port_bram 使用同步读写数组描述存储，并添加 (* ram_style = "block" *) 属性，引导 Vivado 推断 Block RAM。综合报告中出现 RAMB36E1 和 RAMB18E1，说明该方式满足实验中“使用 BRAM 预存矩阵”的要求。',
        "主控制器 sparse_outer_accel 系列模块由有限状态机实现，主要状态包括清零累加器、读取列指针、读取 activation、查询权重块指针、读取权重块、更新累加器和输出结果。由于 BRAM 为同步读，状态机中显式加入等待状态以保证读出数据稳定。"
    ]:
        add_para(text)

    add_section("Ⅲ. 数据部署与稀疏压缩")
    add_sub("A. 基础外积数据格式")
    for text in [
        "基础外积版本将 activation_col 按输出列压缩，保存非零值 a_values 和列起止指针 a_ptr。权重矩阵按 K 维重排，对每个 K 收集所有非零输出通道权重，并以 16 个 lane 为单位打包。每个权重块包含 16 个 8-bit 权重值和 16 个 8-bit 输出通道编号；无效 lane 使用 0xff 标记。",
        "为了减少运行时指针查询，最初实现还为每个非零 activation 预先存储 a_wblk_start 和 a_wblk_end，表示其对应权重块范围。这种做法控制简单、周期较短，但两个表的深度均为 activation 非零元素数，导致 BRAM 占用过高。"
    ]:
        add_para(text)
    rows = [
        ["数据", "含义", "位宽", "深度"],
        ["a_values", "非零 activation 值", "8", fmt_int(nnz["activation_col_by_col"])],
        ["a_ptr", "输出列起止指针", "19", "1025"],
        ["a_wblk_start/end", "activation 对应权重块范围", "19", fmt_int(nnz["activation_col_by_col"])],
        ["wk_block_values16", "16-lane 打包权重值", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
        ["wk_block_rows16", "16-lane 打包输出通道编号", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
    ]
    doc.append(table(rows))
    md.append(markdown_table(rows))

    add_sub("B. Bitmap 压缩优化")
    for text in [
        "为降低 BRAM 占用，本文引入 bitmap 压缩。对于 activation_col 的每个输出列，576 个 K 维位置被表示为 576 bit 的非零掩码，即 18 个 32-bit word。若某一 bit 为 1，则说明该 K 位置存在非零 activation；控制器随后从 a_values 中顺序读取该非零值，并根据 K 查询 wk_block_ptr16。",
        f"bitmap 后的 a_mask32.mem 总深度为 {fmt_int(nnz['activation_mask32_words'])}，远小于逐非零元素保存 K 索引或预展开权重块范围的方式。该优化将大量 BRAM 开销转化为运行时 bit 扫描开销，因此形成了资源与周期之间的折衷。"
    ]:
        add_para(text)
    rows = [
        ["数据", "含义", "位宽", "深度"],
        ["a_values.mem", "非零 activation 值", "8", fmt_int(nnz["activation_col_by_col"])],
        ["a_ptr.mem", "每列非零 activation 起止位置", "19", "1025"],
        ["a_mask32.mem", "每列 K 维非零 bitmap", "32", fmt_int(nnz["activation_mask32_words"])],
        ["wk_block_ptr16.mem", "每个 K 的权重块指针", "19", "577"],
        ["wk_block_values16.mem", "打包权重值", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
        ["wk_block_rows16.mem", "打包输出通道编号", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
    ]
    doc.append(table(rows))
    md.append(markdown_table(rows))

    add_section("Ⅳ. 实验测试与结果")
    for text in [
        "实验使用 Vivado 2019.2，目标器件为 xc7a200tfbg676-2。仿真流程为：testbench 先将 .mem 文件写入各个 BRAM，再拉高 start 信号启动计算，最后将硬件输出与 output_col.mem 中的参考结果逐点比较。为避免 Vivado 2019.2 对中文路径支持不稳定，工程和 generated 数据同时维护在 C:/Users/local-user/Desktop/lab3 纯英文路径下。",
        "本文测试了三类实现：原始外积版本、串行 bitmap 版本和并行 bitmap 版本。原始外积版本用于证明外积 mapping 的正确性和较短周期；串行 bitmap 版本用于验证低 BRAM 资源目标；并行 bitmap 版本用于缓解 bitmap 扫描和串行 lane 更新造成的周期增长。"
    ]:
        add_para(text)
    rows = [
        ["方案", "验证规模", "输出点数", "Mismatch", "周期数"],
        ["原始外积", "前 16 列", "2,048", "0", "58,431"],
        ["原始外积估算", "全量 1024 列", "131,072", "0", fmt_int(original_cycles)],
        ["串行 bitmap", "全量 1024 列", "131,072", "0", fmt_int(serial_cycles)],
        ["并行 bitmap", "全量 1024 列", "131,072", "0", fmt_int(parallel_cycles)],
    ]
    doc.append(table(rows))
    md.append(markdown_table(rows))
    rows = [
        ["方案", "LUT", "FF", "BRAM", "DSP", "时序情况"],
        ["原始外积", fmt_int(original["lut"]), fmt_int(original["ff"]), "430.5", "-", "100MHz 综合完成"],
        ["串行 bitmap", fmt_int(serial["lut"]), fmt_int(serial["ff"]), "121.5", "1", "WNS=1.348ns"],
        ["并行 bitmap", fmt_int(parallel["lut"]), fmt_int(parallel["ff"]), "121.5", "1", "WNS=-3.572ns"],
    ]
    doc.append(table(rows))
    md.append(markdown_table(rows))
    for text in [
        f"从资源看，bitmap 压缩将 BRAM 从原始外积版本的 430.5 降至 121.5，降幅约为 {fmt_float((430.5 - 121.5) / 430.5 * 100)}%。串行 bitmap 版本 LUT 也仅为 3,028，说明删除大表和并行累加逻辑后资源压力显著降低。",
        f"从周期看，串行 bitmap 版本全量周期为 {fmt_int(serial_cycles)}，主要受 bit 扫描和逐 lane 更新影响；并行 bitmap 版本将 16 个 lane 同时展开，全量周期降至 {fmt_int(parallel_cycles)}，相比串行 bitmap 减少约 {fmt_float((serial_cycles - parallel_cycles) / serial_cycles * 100)}%。",
        f"课程指标按 Performance=(Fmax/cycles)/(FF+0.25×LUT+100×BRAM) 计算。以 100MHz 估算，原始外积版本指标约为 {metric(original):.6f}，串行 bitmap 版本约为 {metric(serial):.6f}，并行 bitmap 版本若按 100MHz 计算约为 {metric(parallel):.6f}。需要注意，并行 bitmap 版本综合后 100MHz 时序未满足，因此若作为最终提交，需要继续流水化或按实际可达频率重新计算指标。"
    ]:
        add_para(text)

    add_section("Ⅴ. 方案分析")
    add_sub("A. 本方案可优化的方面")
    for text in [
        "并行处理方面，当前并行 bitmap 版本在一个 S_UPDATE 状态内展开 16 个 lane，能够明显减少周期，但组合路径变长，导致 100MHz 下 WNS 为 -3.572ns。后续可在权重块读取和 lane 更新之间加入流水寄存器，将 16-lane 更新拆成 2 级或 4 级，从而在吞吐率和时序之间取得更好平衡。",
        "累加器方面，当前实现维护 128 个输出通道累加器。若多个 lane 在同一周期更新不同输出通道，逻辑较直接；但如果进一步提高 lane 数，则累加器写端口和冲突处理会成为瓶颈。可以采用 banked accumulator，将输出通道按 row mod bank 分组，以降低写端口冲突和组合扇出。",
        "存储方面，bitmap 压缩显著降低 BRAM，但扫描 576 个 bit 会增加固定控制开销。对于更稀疏的数据，可以使用分层 bitmap 或 run-length 编码减少扫描；对于更稠密的数据，则直接保存 a_indices 可能更划算。"
    ]:
        add_para(text)

    add_sub("B. 与其他加速方案的对比")
    for text in [
        "与逐输出点 intersection 匹配方案相比，外积方案减少了对同一 activation 列的重复扫描。intersection 方案每个输出元素独立匹配 weight 行和 activation 列的非零索引，控制结构直观，但当输出通道数较多时，同一 activation 会被重复访问很多次。外积方案则一次读取 activation 后更新多个输出通道，更适合本实验中 128 个输出通道的场景。",
        "与完全并行的稀疏乘法阵列相比，本文方案对输出存储访问更集中，避免同一周期向多个输出地址随机写回造成的带宽问题。但代价是输出列内需要维护累加状态，且权重块内部并行度过高时会带来时序压力。",
        "从最终结果看，原始外积版本周期较短但 BRAM 过高；串行 bitmap 版本资源优秀但周期较长；并行 bitmap 版本周期明显降低但 LUT 较高且时序未收敛。三者反映了稀疏加速器设计中常见的资源、时钟频率和计算周期之间的三角折衷。"
    ]:
        add_para(text)

    add_section("Ⅵ. 工作负载讨论")
    for text in [
        "稀疏加速器的利用率高度依赖工作负载分布。本实验中 weight 的非零元素按 K 维分布不完全均匀，不同 K 对应的权重块数不同；activation_col 不同输出列中的非零个数也不同。因此，即使硬件 lane 数固定，实际每个周期的有效 lane 数也会波动。",
        f"在 16-lane 权重打包下，weight 非零元素为 {fmt_int(nnz['weight'])}，权重块数为 {fmt_int(nnz['weight_k_blocks_16lane'])}，平均每个权重块有效 lane 数约为 {fmt_float(nnz['weight'] / nnz['weight_k_blocks_16lane'])}。该数值说明 16-lane 粒度对本数据集较合适，既能获得较高打包利用率，又没有把单周期组合逻辑扩大到难以控制的程度。",
        "bitmap 扫描带来的固定开销与 activation 稀疏度有关。若某列 activation 很稀疏，扫描 576 bit 的成本会相对明显；若某列较稠密，扫描成本会被大量权重块计算摊薄。因此，后续可以根据每列非零数动态选择 bitmap 扫描或索引表读取，实现混合压缩格式。"
    ]:
        add_para(text)

    add_section("Ⅶ. 结论")
    for text in [
        "实验 3 中，本文完成了基于 BRAM 的稀疏矩阵乘法加速器设计。设计首先实现了按输出列压缩 activation、按 K 维打包 weight 的外积式 mapping，并通过硬件 FSM 从 BRAM 中读取压缩数据完成矩阵乘法。随后针对 BRAM 使用过高的问题，引入 bitmap 压缩，将 activation 的非零位置用按列 mask 存储，显著降低片上存储资源。",
        f"实验结果表明，并行 bitmap 版本能够在全量 128×1024 输出上得到正确结果，mismatch 为 0，周期数为 {fmt_int(parallel_cycles)}；综合资源为 LUT {fmt_int(parallel['lut'])}、FF {fmt_int(parallel['ff'])}、BRAM {parallel['bram']}、DSP 1。该版本周期明显优于串行 bitmap，但 100MHz 时序尚未满足，需要进一步流水化。",
        "总体来看，本实验说明稀疏矩阵加速不仅取决于乘法器数量，还强烈依赖数据压缩格式、BRAM 映射方式和工作负载分布。合理的数据部署能够显著减少无效访存和零值计算，是 FPGA 上实现高效稀疏计算的关键。"
    ]:
        add_para(text)

    add_section("致谢")
    add_para("作者感谢数字系统设计课程教师和助教在实验讲解、Vivado 使用和报告写作方面提供的帮助。")

    add_section("参考文献")
    refs = [
        "[1] K. Chellapilla, S. Puri, and P. Simard, High Performance Convolutional Neural Networks for Document Processing, ICFHR, 2006.",
        "[2] S. Han, J. Pool, J. Tran, and W. J. Dally, Learning both weights and connections for efficient neural networks, NeurIPS, 2015.",
        "[3] J.-F. Zhang, C.-E. Lee, C. Liu, Y. S. Shao, S. W. Keckler, and Z. Zhang, SNAP: An Efficient Sparse Neural Acceleration Processor for Unstructured Sparse Deep Neural Network Inference, IEEE JSSC, 2021.",
        "[4] S. Han et al., EIE: Efficient Inference Engine on Compressed Deep Neural Network, ISCA, 2016.",
        "[5] AMD Xilinx, Block Memory Generator v8.4 Product Guide PG058, 2021.",
        "[6] 数字系统设计课程组，Lab-3 阵列+存储器系统设计实验指南，2026.",
    ]
    for ref in refs:
        add_para(ref)

    return "\n\n".join(md), "".join(doc)


def main() -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    md, body = build()
    md_path = REPORT_DIR / "lab3_reference_style_report.md"
    docx_path = REPORT_DIR / "lab3_reference_style_report.docx"
    md_path.write_text(md, encoding="utf-8")
    write_docx(docx_path, document_xml(body))
    print(docx_path)
    print(md_path)


if __name__ == "__main__":
    main()
