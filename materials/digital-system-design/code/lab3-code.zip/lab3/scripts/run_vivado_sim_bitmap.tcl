set script_dir [file dirname [file normalize [info script]]]
set lab3_dir [file normalize [file join $script_dir ..]]
set root_dir [file normalize [file join $lab3_dir ..]]

cd $root_dir
set rtl_dir [file join $lab3_dir rtl]
set sim_dir [file join $lab3_dir sim]
set vivado_bin [file dirname [file normalize [info nameofexecutable]]]

exec [file join $vivado_bin xvlog.bat] -sv \
    [file join $rtl_dir simple_dual_port_bram.sv] \
    [file join $rtl_dir sparse_outer_accel_bitmap.sv] \
    [file join $sim_dir tb_sparse_outer_accel_bitmap.sv]

exec [file join $vivado_bin xelab.bat] tb_sparse_outer_accel_bitmap -s tb_sparse_outer_accel_bitmap
exec [file join $vivado_bin xsim.bat] tb_sparse_outer_accel_bitmap -runall
