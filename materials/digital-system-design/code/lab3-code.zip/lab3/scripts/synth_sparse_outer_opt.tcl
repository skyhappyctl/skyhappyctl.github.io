set script_dir [file dirname [file normalize [info script]]]
set lab3_dir [file normalize [file join $script_dir ..]]
set rtl_dir [file join $lab3_dir rtl]
set constraint_dir [file join $lab3_dir constraints]

read_verilog -sv [file join $rtl_dir simple_dual_port_bram.sv]
read_verilog -sv [file join $rtl_dir sparse_outer_accel_opt.sv]
read_xdc [file join $constraint_dir sparse_outer_accel.xdc]

synth_design -top sparse_outer_accel_opt -part xc7a200tfbg676-2
report_utilization -file [file join $lab3_dir generated sparse_outer_opt_utilization.rpt]
report_timing_summary -file [file join $lab3_dir generated sparse_outer_opt_timing.rpt]
