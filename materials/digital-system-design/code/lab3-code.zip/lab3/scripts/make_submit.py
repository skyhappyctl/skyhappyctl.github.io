# -*- coding: utf-8 -*-
"""Assemble a clean submission folder for both accelerator schemes.

Layout:
  submit/
    dense_pe/            final design (dense weight + 128 fixed PEs)
      rtl/  sim/  data/  scripts/  constraints/
    bitmap_parallel/     comparison design (16-lane bitmap)
      rtl/  sim/  data/  scripts/  constraints/
    report/              paper docx
    figures/             architecture diagrams (svg + png)
    synth_evidence/      Vivado utilization / timing screenshots + rpt
    README.txt
"""
import shutil
from pathlib import Path

ROOT = Path(r"C:/Users/local-user/Desktop/lab3")
SUB = ROOT / "submit"

# wipe & recreate
if SUB.exists():
    shutil.rmtree(SUB)

def cp(src: Path, dst_dir: Path):
    dst_dir.mkdir(parents=True, exist_ok=True)
    if not src.exists():
        print("  !! MISSING:", src)
        return
    shutil.copy2(src, dst_dir / src.name)
    print("  +", dst_dir.relative_to(SUB) / src.name)

# ---------------- dense_pe (final) ----------------
print("[dense_pe]")
d = SUB / "dense_pe"
cp(ROOT / "rtl/sparse_outer_accel_dense_pe.sv", d / "rtl")
cp(ROOT / "rtl/simple_dual_port_bram.sv",       d / "rtl")
cp(ROOT / "sim/tb_sparse_outer_accel_dense_pe.sv", d / "sim")
cp(ROOT / "constraints/sparse_outer_accel.xdc", d / "constraints")
cp(ROOT / "scripts/synth_dense_pe.tcl",         d / "scripts")
for m in ["wd_by_k.mem", "a_values.mem", "a_indices.mem", "a_ptr.mem",
          "output_col.mem", "sparse_config.svh"]:
    cp(ROOT / "generated" / m, d / "data")

# ---------------- bitmap_parallel (comparison) ----------------
print("[bitmap_parallel]")
b = SUB / "bitmap_parallel"
cp(ROOT / "rtl/sparse_outer_accel_bitmap_parallel.sv", b / "rtl")
cp(ROOT / "rtl/simple_dual_port_bram.sv",              b / "rtl")
cp(ROOT / "sim/tb_sparse_outer_accel_bitmap_parallel.sv", b / "sim")
cp(ROOT / "constraints/sparse_outer_accel.xdc",        b / "constraints")
cp(ROOT / "scripts/synth_sparse_outer_bitmap_parallel.tcl", b / "scripts")
for m in ["a_values.mem", "a_ptr.mem", "a_mask32.mem",
          "wk_block_ptr16.mem", "wk_block_values16.mem", "wk_block_rows16.mem",
          "output_col.mem", "sparse_config.svh"]:
    cp(ROOT / "generated" / m, b / "data")

# ---------------- shared data-prep + model scripts ----------------
print("[scripts]")
cp(ROOT / "scripts/prepare_sparse_data.py", SUB / "scripts")
cp(ROOT / "scripts/model_dense_pe.py",      SUB / "scripts")

# ---------------- report ----------------
print("[report]")
cp(ROOT / "论文/稀疏矩阵乘法加速器设计_陈天乐_无25_0.docx", SUB / "report")

# ---------------- figures ----------------
print("[figures]")
for f in ["架构示意图.png", "位图并行.png"]:
    cp(ROOT / "论文/架构示意图" / f, SUB / "figures")

# ---------------- synthesis evidence ----------------
print("[synth_evidence]")
for f in ["资源利用.png", "时序报告.png", "仿真数据.png"]:
    cp(ROOT / "论文/实验数据" / f, SUB / "synth_evidence")
# include the previous design's real rpt files as comparison evidence
cp(ROOT / "generated/sparse_outer_bitmap_parallel_utilization.rpt", SUB / "synth_evidence")
cp(ROOT / "generated/sparse_outer_bitmap_parallel_timing.rpt",      SUB / "synth_evidence")

print("\nDONE ->", SUB)
