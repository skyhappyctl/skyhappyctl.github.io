set script_dir [file dirname [file normalize [info script]]]
set lab3_dir [file normalize [file join $script_dir ..]]
set root_dir [file normalize [file join $lab3_dir ..]]
set rtl_dir [file join $lab3_dir rtl]
set constraint_dir [file join $lab3_dir constraints]

read_verilog -sv [file join $rtl_dir simple_dual_port_bram.sv]
read_verilog -sv [file join $rtl_dir sparse_outer_accel.sv]
read_xdc [file join $constraint_dir sparse_outer_accel.xdc]

# Change the part to match the board used in the course project if needed.
synth_design -top sparse_outer_accel -part xc7a200tfbg676-2
report_utilization -file [file join $lab3_dir generated sparse_outer_utilization.rpt]
report_timing_summary -file [file join $lab3_dir generated sparse_outer_timing.rpt]
