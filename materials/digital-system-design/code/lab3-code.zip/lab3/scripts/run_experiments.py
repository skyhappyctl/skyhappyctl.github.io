#!/usr/bin/env python3
"""Run software experiments for the Lab 3 sparse accelerator design."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from prepare_sparse_data import (
    ADDR_W,
    K_SIZE,
    LAB3_DIR,
    GEN_DIR,
    OUT_COLS,
    OUT_ROWS,
    WEIGHT_LANES,
    compress_activation_by_col,
    compress_weight,
    compress_weight_by_k_packed,
    read_matrix,
)


def build_slices(
    values: list[int], indices: list[int], ptr: list[int]
) -> list[tuple[list[int], list[int]]]:
    out: list[tuple[list[int], list[int]]] = []
    for i in range(len(ptr) - 1):
        begin, end = ptr[i], ptr[i + 1]
        out.append((values[begin:end], indices[begin:end]))
    return out


def dot_sparse(
    w_values: list[int],
    w_indices: list[int],
    a_values: list[int],
    a_indices: list[int],
) -> int:
    i = 0
    j = 0
    acc = 0
    while i < len(w_indices) and j < len(a_indices):
        wi = w_indices[i]
        ai = a_indices[j]
        if wi == ai:
            acc += w_values[i] * a_values[j]
            i += 1
            j += 1
        elif wi < ai:
            i += 1
        else:
            j += 1
    return acc


def verify_all_outputs(
    w_rows: list[tuple[list[int], list[int]]],
    a_cols: list[tuple[list[int], list[int]]],
    reference: list[list[int]],
) -> dict[str, object]:
    mismatches = 0
    first_mismatch: dict[str, int] | None = None
    for r, (w_values, w_indices) in enumerate(w_rows):
        for c, (a_values, a_indices) in enumerate(a_cols):
            got = dot_sparse(w_values, w_indices, a_values, a_indices)
            exp = reference[r][c]
            if got != exp:
                mismatches += 1
                if first_mismatch is None:
                    first_mismatch = {
                        "row": r,
                        "col": c,
                        "got": got,
                        "expected": exp,
                    }
    return {
        "checked_outputs": OUT_ROWS * OUT_COLS,
        "mismatches": mismatches,
        "first_mismatch": first_mismatch,
    }


def estimate_block_cycles(
    w_rows: list[tuple[list[int], list[int]]],
    a_cols: list[tuple[list[int], list[int]]],
    block_n: int,
) -> dict[str, float | int]:
    total_cycles = 0
    block_pairs = 0
    useful_macs = 0
    comparator_lanes = 0
    max_pairs_per_output = 0
    empty_outputs = 0

    for w_values, w_indices in w_rows:
        del w_values
        for a_values, a_indices in a_cols:
            del a_values
            out_pairs = 0
            out_macs = 0
            w_pos = 0
            a_pos = 0

            # PTR_ADDR0, PTR_DATA0, PTR_DATA1, INIT
            cycles = 4
            while w_pos < len(w_indices) and a_pos < len(a_indices):
                w_count = min(block_n, len(w_indices) - w_pos)
                a_count = min(block_n, len(a_indices) - a_pos)
                w_block = w_indices[w_pos : w_pos + w_count]
                a_block = a_indices[a_pos : a_pos + a_count]
                matches = len(set(w_block).intersection(a_block))

                out_pairs += 1
                out_macs += matches
                block_pairs += 1
                comparator_lanes += block_n * block_n

                # CHECK + two-cycle BRAM read per lane + MATCH +
                # max(1, match_count) accumulation cycles + ADVANCE.
                cycles += 1 + 2 * block_n + 1 + max(1, matches) + 1

                w_last = w_block[-1]
                a_last = a_block[-1]
                if w_last <= a_last:
                    w_pos += w_count
                if a_last <= w_last:
                    a_pos += a_count

            if out_pairs == 0:
                empty_outputs += 1
            # Final CHECK + EMIT.
            cycles += 2
            total_cycles += cycles
            useful_macs += out_macs
            max_pairs_per_output = max(max_pairs_per_output, out_pairs)

    dense_cycles = OUT_ROWS * OUT_COLS * K_SIZE
    return {
        "block_n": block_n,
        "estimated_cycles": total_cycles,
        "dense_1mac_cycles": dense_cycles,
        "speedup_vs_dense_1mac": dense_cycles / total_cycles,
        "block_pairs": block_pairs,
        "max_block_pairs_per_output": max_pairs_per_output,
        "empty_outputs": empty_outputs,
        "useful_macs": useful_macs,
        "comparator_lane_evaluations": comparator_lanes,
        "avg_cycles_per_output": total_cycles / (OUT_ROWS * OUT_COLS),
        "avg_useful_macs_per_output": useful_macs / (OUT_ROWS * OUT_COLS),
    }


def estimate_outer_cycles(
    a_ptr: list[int],
    a_wblk_start: list[int],
    a_wblk_end: list[int],
    lanes: int,
    w_blocks: int,
) -> dict[str, float | int]:
    total_weight_block_visits = 0
    for begin, end in zip(a_wblk_start, a_wblk_end):
        total_weight_block_visits += end - begin

    total_a_nnz = len(a_wblk_start)
    clear_cycles = OUT_COLS * OUT_ROWS
    emit_cycles = OUT_COLS * OUT_ROWS * 2
    ptr_cycles = OUT_COLS * 5
    activation_cycles = total_a_nnz * 4
    weight_block_cycles = total_weight_block_visits * 4
    total_cycles = clear_cycles + emit_cycles + ptr_cycles + activation_cycles + weight_block_cycles

    dense_cycles = OUT_ROWS * OUT_COLS * K_SIZE
    return {
        "lanes": lanes,
        "estimated_cycles": total_cycles,
        "dense_1mac_cycles": dense_cycles,
        "speedup_vs_dense_1mac": dense_cycles / total_cycles,
        "activation_nnz": total_a_nnz,
        "weight_block_visits": total_weight_block_visits,
        "weight_blocks": w_blocks,
        "avg_cycles_per_output": total_cycles / (OUT_ROWS * OUT_COLS),
        "avg_weight_blocks_per_activation": total_weight_block_visits / total_a_nnz,
        "avg_weight_lanes_used": 20644 / w_blocks,
    }


def compress_weight_block_bounds_for_activation(
    a_indices: list[int], weight: list[list[int]], lanes: int
) -> tuple[list[int], list[int], int]:
    _, _, wk_block_ptr = compress_weight_by_k_packed(weight, lanes)
    starts: list[int] = []
    ends: list[int] = []
    for idx in a_indices:
        starts.append(wk_block_ptr[idx])
        ends.append(wk_block_ptr[idx + 1])
    return starts, ends, wk_block_ptr[-1]


def performance_index(
    ff: int, lut: int, bram: int, fmax_mhz: float, cycles: int
) -> float:
    return (1.0 / (ff + 0.25 * lut + 100 * bram)) * (fmax_mhz / cycles)


def main() -> None:
    # Ensure generated BRAM images exist and are consistent with the source data.
    import prepare_sparse_data

    prepare_sparse_data.main()

    weight = read_matrix(LAB3_DIR / "weight.txt")
    activation_col = read_matrix(LAB3_DIR / "activation_col.txt")
    reference = read_matrix(LAB3_DIR / "output_col.txt")
    w_values, w_indices, w_ptr = compress_weight(weight)
    a_values, a_indices, a_ptr = compress_activation_by_col(activation_col)
    a_wblk_start, a_wblk_end, w_blocks = compress_weight_block_bounds_for_activation(
        a_indices, weight, WEIGHT_LANES
    )
    w_rows = build_slices(w_values, w_indices, w_ptr)
    a_cols = build_slices(a_values, a_indices, a_ptr)

    verification = verify_all_outputs(w_rows, a_cols, reference)
    estimates = [estimate_block_cycles(w_rows, a_cols, n) for n in (4, 8, 16, 32)]
    outer_estimate = estimate_outer_cycles(
        a_ptr, a_wblk_start, a_wblk_end, WEIGHT_LANES, w_blocks
    )

    # Placeholder synthesis numbers make the report formula reproducible before
    # a Vivado run. Replace them with post-synthesis report values when available.
    assumed_resource_case = {
        "note": "Replace with Vivado post-synthesis numbers for final submission.",
        "ff": 9800,
        "lut": 12500,
        "bram": 160,
        "fmax_mhz": 100.0,
        "cycles_from": "software FSM estimate for outer-product design, LANES=16",
    }
    assumed_resource_case["performance_index"] = performance_index(
        assumed_resource_case["ff"],
        assumed_resource_case["lut"],
        assumed_resource_case["bram"],
        assumed_resource_case["fmax_mhz"],
        int(outer_estimate["estimated_cycles"]),
    )

    results = {
        "verification": verification,
        "address_width": ADDR_W,
        "estimates": estimates,
        "outer_estimate": outer_estimate,
        "assumed_resource_case": assumed_resource_case,
    }
    GEN_DIR.mkdir(parents=True, exist_ok=True)
    (GEN_DIR / "experiment_results.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    with (GEN_DIR / "cycle_estimates.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(estimates[0].keys()))
        writer.writeheader()
        writer.writerows(estimates)

    table_lines = [
        "| BLOCK_N | Estimated cycles | Speedup vs dense | Block pairs | Useful MACs | Avg cycles/output |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for item in estimates:
        table_lines.append(
            "| {block_n} | {estimated_cycles} | {speedup_vs_dense_1mac:.3f} | "
            "{block_pairs} | {useful_macs} | {avg_cycles_per_output:.2f} |".format(
                **item
            )
        )
    table_lines.extend(
        [
            "",
            "| Design | Lanes | Estimated cycles | Speedup vs dense | Activation nnz | Weight block visits | Avg cycles/output |",
            "|---|---:|---:|---:|---:|---:|---:|",
            "| Outer product | {lanes} | {estimated_cycles} | {speedup_vs_dense_1mac:.3f} | {activation_nnz} | {weight_block_visits} | {avg_cycles_per_output:.2f} |".format(
                **outer_estimate
            ),
        ]
    )
    (LAB3_DIR / "report" / "experiment_tables.md").write_text(
        "\n".join(table_lines) + "\n", encoding="utf-8"
    )

    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
