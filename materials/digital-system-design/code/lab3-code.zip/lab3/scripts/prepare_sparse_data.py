#!/usr/bin/env python3
"""Prepare sparse BRAM images for Lab 3.

The original files are dense decimal matrices:
  - weight.txt:        [128, 576]
  - activation_col.txt:[576, 1024]
  - output_col.txt:    [128, 1024]

This script converts them to compressed sparse column/row streams that can be
preloaded into BRAM through the testbench load port.
"""

from __future__ import annotations

import json
from pathlib import Path


LAB3_DIR = Path(__file__).resolve().parents[1]
GEN_DIR = LAB3_DIR / "generated"

K_SIZE = 64 * 3 * 3
OUT_ROWS = 128
OUT_COLS = 1024
DATA_W = 8
IDX_W = 10
ACC_W = 32
ADDR_W = 19
WEIGHT_LANES = 16
ROW_W = 8


def read_matrix(path: Path) -> list[list[int]]:
    rows: list[list[int]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append([int(x) for x in line.split()])
    return rows


def twos_hex(value: int, width: int) -> str:
    min_v = -(1 << (width - 1))
    max_v = (1 << (width - 1)) - 1
    if value < min_v or value > max_v:
        raise ValueError(f"value {value} does not fit in signed {width} bits")
    if value < 0:
        value = (1 << width) + value
    digits = (width + 3) // 4
    return f"{value:0{digits}x}"


def unsigned_hex(value: int, width: int) -> str:
    if value < 0 or value >= (1 << width):
        raise ValueError(f"value {value} does not fit in unsigned {width} bits")
    digits = (width + 3) // 4
    return f"{value:0{digits}x}"


def twos_unsigned(value: int, width: int) -> int:
    min_v = -(1 << (width - 1))
    max_v = (1 << (width - 1)) - 1
    if value < min_v or value > max_v:
        raise ValueError(f"value {value} does not fit in signed {width} bits")
    if value < 0:
        value = (1 << width) + value
    return value


def write_mem(path: Path, values: list[int], width: int, signed: bool = False) -> None:
    with path.open("w", encoding="ascii") as f:
        for value in values:
            if signed:
                f.write(twos_hex(value, width))
            else:
                f.write(unsigned_hex(value, width))
            f.write("\n")


def write_packed_mem(path: Path, values: list[int], width: int) -> None:
    with path.open("w", encoding="ascii") as f:
        digits = (width + 3) // 4
        for value in values:
            if value < 0 or value >= (1 << width):
                raise ValueError(f"packed value {value} does not fit in {width} bits")
            f.write(f"{value:0{digits}x}\n")


def compress_weight(weight: list[list[int]]) -> tuple[list[int], list[int], list[int]]:
    values: list[int] = []
    indices: list[int] = []
    ptr: list[int] = [0]
    for row in weight:
        for k, value in enumerate(row):
            if value != 0:
                values.append(value)
                indices.append(k)
        ptr.append(len(values))
    return values, indices, ptr


def pair_activation_by_col(
    activation_col: list[list[int]],
) -> tuple[list[int], list[int], list[int]]:
    """Column-major nonzeros packed two-per-word, padded to even count per col.

    Returns (pair_vals, pair_idxs, pair_ptr) where:
      pair_vals[p] = {v_hi[DATA_W], v_lo[DATA_W]}   (v two's complement)
      pair_idxs[p] = {k_hi[IDX_W],  k_lo[IDX_W]}
      pair_ptr[c]  = first pair index of column c (length OUT_COLS+1)
    A padding lane uses v=0 (contributes nothing) and k=0.
    """
    pair_vals: list[int] = []
    pair_idxs: list[int] = []
    pair_ptr: list[int] = [0]
    for col in range(OUT_COLS):
        nz: list[tuple[int, int]] = []
        for k in range(K_SIZE):
            v = activation_col[k][col]
            if v != 0:
                nz.append((k, v))
        if len(nz) % 2 == 1:
            nz.append((0, 0))  # pad with zero-valued lane
        for p in range(0, len(nz), 2):
            k_lo, v_lo = nz[p]
            k_hi, v_hi = nz[p + 1]
            vlo = twos_unsigned(v_lo, DATA_W)
            vhi = twos_unsigned(v_hi, DATA_W)
            pair_vals.append((vhi << DATA_W) | vlo)
            pair_idxs.append((k_hi << IDX_W) | k_lo)
        pair_ptr.append(len(pair_vals))
    return pair_vals, pair_idxs, pair_ptr


def dense_weight_by_k(weight: list[list[int]]) -> list[int]:
    """Pack the full weight column for each k into one wide word.

    For the dense-PE accelerator, lane `row` reads bits [row*DATA_W +: DATA_W]
    of word k to get W[row][k].  Word width = OUT_ROWS*DATA_W (1024 bits).
    """
    words: list[int] = []
    for k in range(K_SIZE):
        word = 0
        for row in range(OUT_ROWS):
            byte = twos_unsigned(weight[row][k], DATA_W)
            word |= byte << (row * DATA_W)
        words.append(word)
    return words


def compress_weight_by_k_packed(
    weight: list[list[int]], lanes: int
) -> tuple[list[int], list[int], list[int]]:
    packed_values: list[int] = []
    packed_rows: list[int] = []
    block_ptr: list[int] = [0]

    for k in range(K_SIZE):
        entries = [(row, weight[row][k]) for row in range(OUT_ROWS) if weight[row][k] != 0]
        for begin in range(0, len(entries), lanes):
            value_word = 0
            row_word = 0
            chunk = entries[begin : begin + lanes]
            for lane in range(lanes):
                if lane < len(chunk):
                    row, value = chunk[lane]
                    value_byte = twos_unsigned(value, DATA_W)
                    row_byte = row
                else:
                    value_byte = 0
                    row_byte = (1 << ROW_W) - 1
                value_word |= value_byte << (lane * DATA_W)
                row_word |= row_byte << (lane * ROW_W)
            packed_values.append(value_word)
            packed_rows.append(row_word)
        block_ptr.append(len(packed_values))

    return packed_values, packed_rows, block_ptr


def compress_activation_by_col(
    activation_col: list[list[int]],
) -> tuple[list[int], list[int], list[int]]:
    values: list[int] = []
    indices: list[int] = []
    ptr: list[int] = [0]
    for col in range(OUT_COLS):
        for k in range(K_SIZE):
            value = activation_col[k][col]
            if value != 0:
                values.append(value)
                indices.append(k)
        ptr.append(len(values))
    return values, indices, ptr


def activation_bitmap_by_col(activation_col: list[list[int]], word_bits: int) -> list[int]:
    words_per_col = (K_SIZE + word_bits - 1) // word_bits
    masks: list[int] = []
    for col in range(OUT_COLS):
        for word_idx in range(words_per_col):
            word = 0
            base_k = word_idx * word_bits
            for bit in range(word_bits):
                k = base_k + bit
                if k < K_SIZE and activation_col[k][col] != 0:
                    word |= 1 << bit
            masks.append(word)
    return masks


def activation_weight_block_bounds(
    a_indices: list[int], wk_block_ptr: list[int]
) -> tuple[list[int], list[int]]:
    starts: list[int] = []
    ends: list[int] = []
    for k in a_indices:
        starts.append(wk_block_ptr[k])
        ends.append(wk_block_ptr[k + 1])
    return starts, ends


def validate_shape(name: str, matrix: list[list[int]], rows: int, cols: int) -> None:
    if len(matrix) != rows:
        raise ValueError(f"{name}: expected {rows} rows, got {len(matrix)}")
    bad = [i for i, row in enumerate(matrix) if len(row) != cols]
    if bad:
        first = bad[0]
        raise ValueError(
            f"{name}: row {first} expected {cols} columns, got {len(matrix[first])}"
        )


def write_config(
    path: Path,
    w_nnz: int,
    a_nnz: int,
    w_blocks: int,
    a_mask_words: int,
    a_mask_word_bits: int,
    a_pairs: int,
) -> None:
    text = f"""`ifndef LAB3_SPARSE_CONFIG_SVH
`define LAB3_SPARSE_CONFIG_SVH

localparam int LAB3_OUT_ROWS = {OUT_ROWS};
localparam int LAB3_OUT_COLS = {OUT_COLS};
localparam int LAB3_K_SIZE = {K_SIZE};
localparam int LAB3_W_NNZ = {w_nnz};
localparam int LAB3_A_NNZ = {a_nnz};
localparam int LAB3_WEIGHT_LANES = {WEIGHT_LANES};
localparam int LAB3_W_BLOCKS16 = {w_blocks};
localparam int LAB3_A_MASK_WORDS = {a_mask_words};
localparam int LAB3_A_MASK_WORD_BITS = {a_mask_word_bits};
localparam int LAB3_A_PAIRS = {a_pairs};
localparam int LAB3_DATA_W = {DATA_W};
localparam int LAB3_IDX_W = {IDX_W};
localparam int LAB3_ROW_W = {ROW_W};
localparam int LAB3_ACC_W = {ACC_W};
localparam int LAB3_ADDR_W = {ADDR_W};

`endif
"""
    path.write_text(text, encoding="ascii")


def main() -> None:
    GEN_DIR.mkdir(parents=True, exist_ok=True)

    weight = read_matrix(LAB3_DIR / "weight.txt")
    activation_col = read_matrix(LAB3_DIR / "activation_col.txt")
    output_col = read_matrix(LAB3_DIR / "output_col.txt")

    validate_shape("weight.txt", weight, OUT_ROWS, K_SIZE)
    validate_shape("activation_col.txt", activation_col, K_SIZE, OUT_COLS)
    validate_shape("output_col.txt", output_col, OUT_ROWS, OUT_COLS)

    w_values, w_indices, w_ptr = compress_weight(weight)
    wk_block_values, wk_block_rows, wk_block_ptr = compress_weight_by_k_packed(
        weight, WEIGHT_LANES
    )
    a_values, a_indices, a_ptr = compress_activation_by_col(activation_col)
    wd_by_k = dense_weight_by_k(weight)
    a_pair_vals, a_pair_idxs, a_pair_ptr = pair_activation_by_col(activation_col)
    a_mask_word_bits = 32
    a_mask_words = activation_bitmap_by_col(activation_col, a_mask_word_bits)
    a_wblk_start, a_wblk_end = activation_weight_block_bounds(a_indices, wk_block_ptr)
    output_flat = [x for row in output_col for x in row]

    write_mem(GEN_DIR / "w_values.mem", w_values, DATA_W, signed=True)
    write_mem(GEN_DIR / "w_indices.mem", w_indices, IDX_W)
    write_mem(GEN_DIR / "w_ptr.mem", w_ptr, ADDR_W)
    write_mem(GEN_DIR / "a_values.mem", a_values, DATA_W, signed=True)
    write_mem(GEN_DIR / "a_indices.mem", a_indices, IDX_W)
    write_mem(GEN_DIR / "a_mask32.mem", a_mask_words, a_mask_word_bits)
    write_mem(GEN_DIR / "a_wblk_start.mem", a_wblk_start, ADDR_W)
    write_mem(GEN_DIR / "a_wblk_end.mem", a_wblk_end, ADDR_W)
    write_mem(GEN_DIR / "a_ptr.mem", a_ptr, ADDR_W)
    write_packed_mem(
        GEN_DIR / "wk_block_values16.mem", wk_block_values, WEIGHT_LANES * DATA_W
    )
    write_packed_mem(
        GEN_DIR / "wk_block_rows16.mem", wk_block_rows, WEIGHT_LANES * ROW_W
    )
    write_mem(GEN_DIR / "wk_block_ptr16.mem", wk_block_ptr, ADDR_W)
    write_packed_mem(GEN_DIR / "wd_by_k.mem", wd_by_k, OUT_ROWS * DATA_W)
    write_packed_mem(GEN_DIR / "a_pair_vals.mem", a_pair_vals, 2 * DATA_W)
    write_packed_mem(GEN_DIR / "a_pair_idxs.mem", a_pair_idxs, 2 * IDX_W)
    write_mem(GEN_DIR / "a_pair_ptr.mem", a_pair_ptr, ADDR_W)
    write_mem(GEN_DIR / "output_col.mem", output_flat, ACC_W, signed=True)
    write_config(
        GEN_DIR / "sparse_config.svh",
        len(w_values),
        len(a_values),
        len(wk_block_values),
        len(a_mask_words),
        a_mask_word_bits,
        len(a_pair_vals),
    )

    stats = {
        "shape": {
            "weight": [OUT_ROWS, K_SIZE],
            "activation_col": [K_SIZE, OUT_COLS],
            "output_col": [OUT_ROWS, OUT_COLS],
        },
        "nnz": {
            "weight": len(w_values),
            "activation_col_by_col": len(a_values),
            "weight_k_blocks_16lane": len(wk_block_values),
            "activation_mask32_words": len(a_mask_words),
        },
        "density": {
            "weight": len(w_values) / (OUT_ROWS * K_SIZE),
            "activation_col": len(a_values) / (K_SIZE * OUT_COLS),
        },
        "value_range": {
            "weight": [min(w_values), max(w_values)],
            "activation_col": [min(a_values), max(a_values)],
            "output_col": [min(output_flat), max(output_flat)],
        },
        "generated_files": [
            "w_values.mem",
            "w_indices.mem",
            "w_ptr.mem",
            "a_values.mem",
            "a_indices.mem",
            "a_mask32.mem",
            "a_wblk_start.mem",
            "a_wblk_end.mem",
            "a_ptr.mem",
            "wk_block_values16.mem",
            "wk_block_rows16.mem",
            "wk_block_ptr16.mem",
            "output_col.mem",
            "sparse_config.svh",
        ],
    }
    (GEN_DIR / "data_stats.json").write_text(
        json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(stats, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
