set script_dir [file dirname [file normalize [info script]]]
set lab3_dir [file normalize [file join $script_dir ..]]
set root_dir [file normalize [file join $lab3_dir ..]]

cd $root_dir
set rtl_dir [file join $lab3_dir rtl]
set sim_dir [file join $lab3_dir sim]

xvlog -sv -i [file join $lab3_dir generated] \
    [file join $rtl_dir simple_dual_port_bram.sv] \
    [file join $rtl_dir intersection_match_unit.sv] \
    [file join $rtl_dir sparse_matmul_accel.sv] \
    [file join $rtl_dir sparse_outer_accel.sv] \
    [file join $sim_dir tb_sparse_outer_accel.sv]

xelab tb_sparse_outer_accel -s tb_sparse_outer_accel
xsim tb_sparse_outer_accel -runall
