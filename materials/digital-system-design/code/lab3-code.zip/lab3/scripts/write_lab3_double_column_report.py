#!/usr/bin/env python3
"""Create a double-column Lab 3 report without external docx packages."""

from __future__ import annotations

import html
import json
import zipfile
from pathlib import Path


LAB3_DIR = Path(__file__).resolve().parents[1]
GEN_DIR = LAB3_DIR / "generated"
REPORT_DIR = LAB3_DIR / "report"


def esc(text: object) -> str:
    return html.escape(str(text), quote=True)


def fmt_int(value: int | float) -> str:
    return f"{int(value):,}"


def fmt_float(value: float, digits: int = 4) -> str:
    return f"{value:.{digits}f}"


def run(text: str, bold: bool = False, size: int = 21) -> str:
    b = "<w:b/>" if bold else ""
    return (
        "<w:r><w:rPr>"
        '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="SimSun"/>'
        f"<w:sz w:val=\"{size}\"/><w:szCs w:val=\"{size}\"/>{b}"
        f"</w:rPr><w:t xml:space=\"preserve\">{esc(text)}</w:t></w:r>"
    )


def paragraph(
    text: str,
    *,
    align: str | None = None,
    bold: bool = False,
    size: int = 21,
    style: str | None = None,
    section_break_one_col: bool = False,
) -> str:
    ppr = []
    if style:
        ppr.append(f'<w:pStyle w:val="{style}"/>')
    if align:
        ppr.append(f'<w:jc w:val="{align}"/>')
    ppr.append('<w:spacing w:after="80" w:line="276" w:lineRule="auto"/>')
    if section_break_one_col:
        ppr.append(section_properties(cols=1, section_type="continuous"))
    return f"<w:p><w:pPr>{''.join(ppr)}</w:pPr>{run(text, bold=bold, size=size)}</w:p>"


def heading(text: str, level: int = 1) -> str:
    if level == 1:
        return paragraph(text, align="left", bold=True, size=22, style="Heading1")
    return paragraph(text, align="left", bold=True, size=21, style="Heading2")


def table(rows: list[list[str]]) -> str:
    tbl_pr = (
        "<w:tblPr>"
        '<w:tblW w:w="0" w:type="auto"/>'
        '<w:tblBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        "</w:tblBorders></w:tblPr>"
    )
    out = ["<w:tbl>", tbl_pr]
    for r, row in enumerate(rows):
        out.append("<w:tr>")
        for cell in row:
            out.append(
                "<w:tc><w:tcPr><w:tcW w:w=\"0\" w:type=\"auto\"/></w:tcPr>"
                + paragraph(str(cell), bold=(r == 0), size=18)
                + "</w:tc>"
            )
        out.append("</w:tr>")
    out.append("</w:tbl>")
    return "".join(out)


def section_properties(cols: int, section_type: str | None = None) -> str:
    typ = f'<w:type w:val="{section_type}"/>' if section_type else ""
    return (
        "<w:sectPr>"
        f"{typ}"
        '<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1440" w:right="1080" w:bottom="1200" w:left="1080" '
        'w:header="720" w:footer="720" w:gutter="0"/>'
        f'<w:cols w:num="{cols}" w:space="720"/>'
        "</w:sectPr>"
    )


def make_document_xml(body: str) -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{body}{section_properties(cols=2)}</w:body></w:document>"
    )


def styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="SimSun"/><w:sz w:val="21"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/><w:basedOn w:val="Normal"/>
    <w:rPr><w:b/><w:sz w:val="22"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/><w:basedOn w:val="Normal"/>
    <w:rPr><w:b/><w:sz w:val="21"/></w:rPr>
  </w:style>
</w:styles>"""


def write_docx(path: Path, document_xml: str) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
    doc_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/_rels/document.xml.rels", doc_rels)
        zf.writestr("word/document.xml", document_xml)
        zf.writestr("word/styles.xml", styles_xml())


def load_stats() -> dict:
    return json.loads((GEN_DIR / "data_stats.json").read_text(encoding="utf-8"))


def build_report() -> tuple[str, str]:
    stats = load_stats()
    nnz = stats["nnz"]
    density = stats["density"]

    dense_cycles = 75_497_472
    original_cycles = 4_379_508
    original_lut = 91_869
    original_ff = 13_653
    original_bram = 430.5
    serial_cycles = 17_348_753
    serial_lut = 3_028
    serial_ff = 4_829
    serial_bram = 121.5
    parallel_cycles = 6_357_983
    fmax = 100_000_000

    original_cost = original_ff + 0.25 * original_lut + 100 * original_bram
    serial_cost = serial_ff + 0.25 * serial_lut + 100 * serial_bram
    original_metric = (fmax / original_cycles) / original_cost
    serial_metric = (fmax / serial_cycles) / serial_cost

    md: list[str] = []
    doc: list[str] = []

    title = "基于 BRAM 的稀疏矩阵乘法映射与 Bitmap 压缩优化"
    author = "作者：请填写姓名、班级、学号"
    abstract = (
        "Lab-3 要求将矩阵数据预存到 FPGA 片上 BRAM 中，并通过硬件控制完成矩阵到计算阵列的 mapping。"
        "本文针对 VGG-16 第三层卷积展开后的矩阵乘法，设计并实现了一种基于稀疏外积数据流的 BRAM 加速器。"
        "基础版本将 activation_col 按输出列压缩，将权重矩阵按 K 维打包为 16-lane 权重块；进一步的 bitmap 版本用每列 576 bit 的非零掩码替代大规模 activation 索引表，显著降低 BRAM 占用。"
        "实验表明，原始外积版本在前 16 列仿真中输出 2048 点且 mismatch 为 0，全量估算周期为 4,379,508；低 BRAM bitmap 版本综合后 LUT 为 3028、FF 为 4829、BRAM 为 121.5，较原始版本的 430.5 个 BRAM 明显下降。"
        "为缓解串行 bitmap 版本周期较长的问题，本文还实现并验证了 16-lane 并行 bitmap 版本，全量行为仿真覆盖 131,072 个输出点，mismatch 为 0，周期数为 6,357,983。"
    )

    doc.extend([
        paragraph(title, align="center", bold=True, size=32),
        paragraph(author, align="center", size=21),
        paragraph("摘要", align="center", bold=True, size=22),
        paragraph(abstract, size=21),
        paragraph("关键词：BRAM；稀疏矩阵乘法；外积数据流；bitmap 压缩；FPGA 加速器", size=21, section_break_one_col=True),
    ])
    md.extend([f"# {title}", author, "## 摘要", abstract, "关键词：BRAM；稀疏矩阵乘法；外积数据流；bitmap 压缩；FPGA 加速器"])

    sections: list[tuple[str, list[str]]] = [
        (
            "I. 引言",
            [
                "卷积神经网络中的卷积层通常可以通过 img2col 展开为矩阵乘法。本实验数据来自 VGG-16 第三层卷积，权重矩阵维度为 128×576，activation_col 矩阵维度为 576×1024，输出矩阵维度为 128×1024。若直接按照稠密矩阵乘法遍历，则需要执行大量与零值相关的无效乘加。",
                f"对原始数据统计可知，weight 中非零元素为 {fmt_int(nnz['weight'])} 个，密度为 {fmt_float(density['weight'] * 100, 2)}%；activation_col 中非零元素为 {fmt_int(nnz['activation_col_by_col'])} 个，密度为 {fmt_float(density['activation_col'] * 100, 2)}%。这种稀疏性说明，本实验不适合直接保存和遍历完整稠密矩阵，而应采用压缩存储和稀疏计算。",
                "课程要求的关键点是使用 Xilinx FPGA 的 BRAM 预存矩阵数据，并由硬件控制器完成数据读取、映射和计算。因此，本文重点设计可综合的 BRAM 存储结构、稀疏数据格式和有限状态机控制流程，而不是在 testbench 中直接完成矩阵乘法。"
            ],
        ),
        (
            "II. 设计方法",
            [
                "本文采用 output-column stationary 的稀疏外积数据流。硬件每次处理一个输出列，先清零 128 个输出通道累加器，然后遍历该列所有非零 activation。对于每个非零 activation，控制器根据其 K 维索引读取对应的权重块，并更新多个输出通道的累加值。",
                "权重矩阵按 K 维重排。对于每个 K，收集所有非零输出通道权重，并按 16 个 lane 打包为两个 128-bit BRAM word：一个保存 16 个 8-bit 权重值，另一个保存 16 个 8-bit 输出通道编号。无效 lane 使用 0xff 作为哨兵。",
                "原始外积版本为了减少运行时指针查询，为每个非零 activation 预存 a_wblk_start 和 a_wblk_end 两张大表。该方式周期较短，但两张表的深度均为 activation 非零元素数，导致 BRAM 占用很高。bitmap 优化版本删除这两张预展开表，并进一步用 a_mask32.mem 表示每列 activation 的非零位置，从而用少量 bitmap 扫描换取更低 BRAM 使用。"
            ],
        ),
    ]
    for h, paras in sections:
        doc.append(heading(h, 1))
        md.append(f"## {h}")
        for para in paras:
            doc.append(paragraph(para))
            md.append(para)

    doc.append(heading("A. BRAM 数据组织", 2))
    md.append("### A. BRAM 数据组织")
    bram_rows = [
        ["数据文件", "含义", "位宽", "深度"],
        ["a_values.mem", "非零 activation 值", "8", fmt_int(nnz["activation_col_by_col"])],
        ["a_ptr.mem", "每个输出列的 activation 起止指针", "19", "1025"],
        ["a_mask32.mem", "每列 activation 的 32-bit bitmap", "32", fmt_int(nnz.get("activation_mask32_words", 18432))],
        ["wk_block_ptr16.mem", "每个 K 对应权重块指针", "19", "577"],
        ["wk_block_values16.mem", "16-lane 打包权重值", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
        ["wk_block_rows16.mem", "16-lane 打包输出通道编号", "128", fmt_int(nnz["weight_k_blocks_16lane"])],
    ]
    doc.append(table(bram_rows))
    md.append(markdown_table(bram_rows))
    doc.append(paragraph('RTL 中 simple_dual_port_bram 使用同步读写数组描述存储，并添加 (* ram_style = "block" *) 属性，引导 Vivado 将这些存储综合为 Block RAM。综合报告中出现 RAMB36E1/RAMB18E1，说明该 BRAM 使用方式有效。'))

    doc.append(heading("B. 控制流程", 2))
    md.append("### B. 控制流程")
    control_text = (
        "控制器主要状态包括清零累加器、读取列指针、扫描 activation、读取权重块、更新累加器和输出结果。"
        "在 bitmap 版本中，控制器按列读取 18 个 32-bit mask word，对每一位判断 activation 是否非零。若该位为 1，则顺序读取 a_values 中对应的 activation 值，并根据 K 查询 wk_block_ptr16，之后读取权重值和输出通道编号。"
        "串行 bitmap 版本每个权重块内部逐 lane 更新，资源较低但周期较长；并行 bitmap 版本在 S_UPDATE 状态同时展开 16 个 lane，因此显著缩短计算周期。"
    )
    doc.append(paragraph(control_text))
    md.append(control_text)

    doc.append(heading("III. 实验设置与结果", 1))
    md.append("## III. 实验设置与结果")
    exp_text = (
        "实验平台为 Vivado 2019.2，目标器件为 xc7a200tfbg676-2，时钟约束为 10 ns。"
        "行为仿真通过 testbench 将 .mem 文件写入 DUT 内部 BRAM，然后拉高 start 信号启动硬件计算。输出结果与 output_col.mem 逐点比较。"
        "为避免 Vivado 2019.2 对中文路径解析不稳定，仿真和综合时同时维护了 C:/Users/local-user/Desktop/lab3 这一纯英文路径副本。"
    )
    doc.append(paragraph(exp_text))
    md.append(exp_text)

    sim_rows = [
        ["版本", "验证规模", "输出点数", "Mismatch", "周期数"],
        ["原始外积", "前 16 列", "2,048", "0", "58,431"],
        ["串行 bitmap", "全量 1024 列", "131,072", "0", fmt_int(serial_cycles)],
        ["并行 bitmap", "全量 1024 列", "131,072", "0", fmt_int(parallel_cycles)],
    ]
    doc.append(table(sim_rows))
    md.append(markdown_table(sim_rows))

    resource_rows = [
        ["版本", "LUT", "FF", "BRAM", "DSP", "说明"],
        ["原始外积", fmt_int(original_lut), fmt_int(original_ff), "430.5", "未计入", "BRAM 占用高"],
        ["串行 bitmap", fmt_int(serial_lut), fmt_int(serial_ff), "121.5", "1", "已完成综合"],
        ["并行 bitmap", "待综合报告更新", "待综合报告更新", "约同 bitmap 存储规模", "待更新", "已完成全量仿真"],
    ]
    doc.append(table(resource_rows))
    md.append(markdown_table(resource_rows))

    metric_text = (
        "课程指标定义为 Performance = (Fmax / cycles) / (FF + 0.25×LUT + 100×BRAM)。"
        f"原始外积版本按 100 MHz、{fmt_int(original_cycles)} cycles、LUT={fmt_int(original_lut)}、FF={fmt_int(original_ff)}、BRAM={original_bram} 计算，指标约为 {fmt_float(original_metric, 6)}。"
        f"已完成综合的低 BRAM 串行 bitmap 版本按 100 MHz、{fmt_int(serial_cycles)} cycles、LUT={fmt_int(serial_lut)}、FF={fmt_int(serial_ff)}、BRAM={serial_bram} 计算，指标约为 {fmt_float(serial_metric, 6)}。"
        "虽然串行 bitmap 版本周期增加，但资源下降显著；并行 bitmap 版本则在保持 bitmap 存储结构的基础上将全量周期降低到 6,357,983，后续完成综合后可用于替换最终评分指标。"
    )
    doc.append(paragraph(metric_text))
    md.append(metric_text)

    doc.append(heading("IV. 分析与讨论", 1))
    md.append("## IV. 分析与讨论")
    analysis_paras = [
        "原始外积版本的优势是运行时控制简单：每个 activation 可以直接读取预计算好的权重块起止地址，因此不需要扫描 bitmap，也不需要额外查询 K 维指针。但是，该方式把 a_wblk_start 和 a_wblk_end 都展开到 activation 非零元素粒度，导致 BRAM 数量达到 430.5，在目标器件上占用 86.10%。",
        "bitmap 版本把 activation 的 K 维位置改为按列 bitmask 表示。对于 576 个 K 位置，每列只需要 18 个 32-bit word，1024 列合计 18,432 个 word，远小于逐非零元素保存 10-bit index 的方式。因此，综合后的 BRAM 降至 121.5，LUT 也从 91,869 降至 3,028。",
        "串行 bitmap 版本周期长的原因有两点：第一，每列需要扫描 576 个 bit；第二，每个权重块内部 16 个 lane 被串行更新。并行 bitmap 版本保留 bitmap 压缩，同时在更新状态并行展开 16 个 lane，因此全量周期从 17,348,753 降至 6,357,983，约减少 63.35%。",
        "从设计取舍看，若评分更看重 BRAM 和综合稳定性，串行 bitmap 版本更稳；若评分更看重周期和吞吐率，则应继续完成并行 bitmap 版本综合，并根据综合报告更新 LUT、FF、BRAM 和最终指标。"
    ]
    for para in analysis_paras:
        doc.append(paragraph(para))
        md.append(para)

    doc.append(heading("V. 结论", 1))
    md.append("## V. 结论")
    conclusion = (
        "本文完成了一个基于 BRAM 的稀疏矩阵乘法映射加速器，并围绕 BRAM 占用和计算周期进行了两阶段优化。"
        "原始外积方案能够正确完成矩阵计算，但 BRAM 占用过高；bitmap 压缩方案显著降低片上存储资源，并通过并行 lane 更新缓解周期增加问题。"
        "行为仿真结果表明，最终并行 bitmap 版本在全量 128×1024 输出上 mismatch 为 0，周期数为 6,357,983。"
        "该实验说明，针对稀疏矩阵乘法，数据格式和 BRAM 映射方式对 FPGA 加速器的资源与性能具有决定性影响。"
    )
    doc.append(paragraph(conclusion))
    md.append(conclusion)

    doc.append(heading("参考文献", 1))
    md.append("## 参考文献")
    refs = [
        "[1] 数字系统设计课程组. Lab-3 阵列+存储器系统设计实验指南, 2026.",
        "[2] K. Simonyan and A. Zisserman, Very Deep Convolutional Networks for Large-Scale Image Recognition, arXiv:1409.1556, 2014.",
        "[3] Y.-H. Chen, T. Krishna, J. S. Emer, and V. Sze, Eyeriss: An Energy-Efficient Reconfigurable Accelerator for Deep Convolutional Neural Networks, IEEE JSSC, 2017.",
        "[4] A. Parashar et al., SCNN: An Accelerator for Compressed-sparse Convolutional Neural Networks, ISCA, 2017.",
        "[5] S. Han et al., EIE: Efficient Inference Engine on Compressed Deep Neural Network, ISCA, 2016.",
        "[6] AMD Xilinx, Block Memory Generator v8.4 Product Guide PG058, 2021.",
    ]
    for ref in refs:
        doc.append(paragraph(ref, size=19))
        md.append(ref)

    return "\n\n".join(md), "".join(doc)


def markdown_table(rows: list[list[str]]) -> str:
    header = "| " + " | ".join(rows[0]) + " |"
    sep = "| " + " | ".join(["---"] * len(rows[0])) + " |"
    body = ["| " + " | ".join(row) + " |" for row in rows[1:]]
    return "\n".join([header, sep, *body])


def main() -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    md, doc_body = build_report()
    md_path = REPORT_DIR / "lab3_double_column_report.md"
    docx_path = REPORT_DIR / "lab3_double_column_report.docx"
    md_path.write_text(md, encoding="utf-8")
    write_docx(docx_path, make_document_xml(doc_body))
    print(docx_path)
    print(md_path)


if __name__ == "__main__":
    main()
