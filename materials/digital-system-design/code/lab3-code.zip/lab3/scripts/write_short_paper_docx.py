#!/usr/bin/env python3
"""Generate a short Word paper draft for Lab 3 without third-party packages."""

from __future__ import annotations

import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.sax.saxutils import escape


LAB3_DIR = Path(__file__).resolve().parents[1]
REPORT_DIR = LAB3_DIR / "report"
GEN_DIR = LAB3_DIR / "generated"


def load_json(name: str) -> dict:
    return json.loads((GEN_DIR / name).read_text(encoding="utf-8"))


def fmt_int(x: int | float) -> str:
    return f"{int(x):,}"


def fmt_float(x: float, digits: int = 3) -> str:
    return f"{x:.{digits}f}"


def text_run(text: str, bold: bool = False, italic: bool = False) -> str:
    props = []
    if bold:
        props.append("<w:b/>")
    if italic:
        props.append("<w:i/>")
    prop_xml = f"<w:rPr>{''.join(props)}</w:rPr>" if props else ""
    return f'<w:r>{prop_xml}<w:t xml:space="preserve">{escape(text)}</w:t></w:r>'


def paragraph(
    text: str,
    style: str | None = None,
    align: str | None = None,
    bold: bool = False,
    italic: bool = False,
) -> str:
    ppr = []
    if style:
        ppr.append(f'<w:pStyle w:val="{style}"/>')
    if align:
        ppr.append(f'<w:jc w:val="{align}"/>')
    ppr_xml = f"<w:pPr>{''.join(ppr)}</w:pPr>" if ppr else ""
    return f"<w:p>{ppr_xml}{text_run(text, bold=bold, italic=italic)}</w:p>"


def table(rows: list[list[str]]) -> str:
    cells = []
    for row in rows:
        row_xml = []
        for cell in row:
            row_xml.append(
                "<w:tc><w:tcPr><w:tcW w:w=\"2400\" w:type=\"dxa\"/></w:tcPr>"
                f"{paragraph(cell)}</w:tc>"
            )
        cells.append(f"<w:tr>{''.join(row_xml)}</w:tr>")
    borders = (
        "<w:tblPr><w:tblBorders>"
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        "</w:tblBorders></w:tblPr>"
    )
    return f"<w:tbl>{borders}{''.join(cells)}</w:tbl>"


def section_properties() -> str:
    return (
        "<w:sectPr>"
        '<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
        'w:header="720" w:footer="720" w:gutter="0"/>'
        '<w:cols w:space="720"/>'
        "</w:sectPr>"
    )


def document_xml(body_xml: str) -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" '
        'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
        'xmlns:o="urn:schemas-microsoft-com:office:office" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
        'xmlns:v="urn:schemas-microsoft-com:vml" '
        'xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        'xmlns:w10="urn:schemas-microsoft-com:office:word" '
        'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
        'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
        'xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" '
        'xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" '
        'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" '
        'mc:Ignorable="w14 wp14">'
        f"<w:body>{body_xml}{section_properties()}</w:body></w:document>"
    )


def styles_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
        '<w:name w:val="Normal"/>'
        '<w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr>'
        '<w:rPr><w:rFonts w:ascii="Times New Roman" w:eastAsia="宋体" w:hAnsi="Times New Roman"/>'
        '<w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:styleId="Title">'
        '<w:name w:val="Title"/><w:basedOn w:val="Normal"/>'
        '<w:pPr><w:jc w:val="center"/><w:spacing w:after="180"/></w:pPr>'
        '<w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:eastAsia="黑体" w:hAnsi="Times New Roman"/>'
        '<w:sz w:val="32"/><w:szCs w:val="32"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:styleId="Heading1">'
        '<w:name w:val="heading 1"/><w:basedOn w:val="Normal"/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/></w:pPr>'
        '<w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:eastAsia="黑体" w:hAnsi="Times New Roman"/>'
        '<w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:styleId="Heading2">'
        '<w:name w:val="heading 2"/><w:basedOn w:val="Normal"/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="120" w:after="80"/></w:pPr>'
        '<w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:eastAsia="黑体" w:hAnsi="Times New Roman"/>'
        '<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>'
        "</w:styles>"
    )


def static_file(name: str) -> str:
    if name == "[Content_Types].xml":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
            '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            "</Types>"
        )
    if name == "_rels/.rels":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            "</Relationships>"
        )
    if name == "word/_rels/document.xml.rels":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
            "</Relationships>"
        )
    if name == "word/settings.xml":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:defaultTabStop w:val="420"/></w:settings>'
        )
    if name == "docProps/app.xml":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
            'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
            "<Application>Codex</Application></Properties>"
        )
    if name == "docProps/core.xml":
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            "<dc:title>基于 BRAM 的稀疏卷积矩阵乘映射加速器设计</dc:title>"
            "<dc:creator>作者待填写</dc:creator>"
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
            "</cp:coreProperties>"
        )
    raise KeyError(name)


def build_content(stats: dict, results: dict) -> tuple[str, str]:
    nnz = stats["nnz"]
    density = stats["density"]
    outer = results["outer_estimate"]
    verification = results["verification"]
    estimates = results["estimates"]
    assumed = results["assumed_resource_case"]

    lines: list[str] = []
    body: list[str] = []

    title = "基于 BRAM 的稀疏卷积矩阵乘映射加速器设计"
    author = "作者：请填写姓名、班级、学号"

    body.append(paragraph(title, style="Title"))
    body.append(paragraph(author, align="center"))
    body.append(paragraph("Abstract", style="Heading1"))
    abstract = (
        "卷积神经网络中的卷积层可以通过 img2col 转换为矩阵乘法，但在 FPGA 上直接保存和遍历稠密矩阵会引入大量无效访存和乘加。"
        "本文针对 Lab-3 提供的 VGG-16 第三层卷积数据，设计了一种基于 BRAM 预存储的稀疏矩阵乘映射加速器。"
        "该设计将 activation_col 按输出列压缩，将权重按输入 K 维组织成 16-lane 外积块，并通过硬件控制器从 BRAM 中顺序读取非零激活及对应权重块，"
        "对 128 个输出通道累加生成输出列。软件参考实验验证了 131072 个输出点全部与 output_col.txt 一致；周期估算显示 16-lane 外积映射约需 "
        f"{fmt_int(outer['estimated_cycles'])} 个计算周期，相比单 MAC 稠密遍历的 {fmt_int(outer['dense_1mac_cycles'])} 周期约提升 "
        f"{fmt_float(outer['speedup_vs_dense_1mac'], 2)} 倍。"
    )
    body.append(paragraph(abstract))
    body.append(paragraph("Keywords: Sparse Matrix Multiplication; BRAM; FPGA; CNN Accelerator; Data Mapping"))

    body.append(paragraph("1. Introduction", style="Heading1"))
    body.append(paragraph(
        "CNN 推理中的卷积层通常占据主要计算量。课程前序 Lab 中，数据搬运、mapping 和控制逻辑主要由 testbench 以软件循环完成；"
        "而 Lab-3 要求将矩阵预存到 Xilinx FPGA 的 BRAM 中，并由硬件控制完成矩阵到阵列或计算单元的映射。"
        "因此，本实验的关键不只是完成矩阵乘法本身，还包括选择合适的数据布局，使 BRAM 读写、索引匹配和乘加单元之间形成可综合的数据流。"
    ))
    body.append(paragraph(
        f"实验数据来自 VGG-16 的第三层卷积。权重矩阵大小为 128 x 576，activation_col 矩阵大小为 576 x 1024，输出矩阵大小为 128 x 1024。"
        f"统计结果表明，权重非零数量为 {fmt_int(nnz['weight'])}，密度为 {fmt_float(density['weight'] * 100, 2)}%；"
        f"activation_col 非零数量为 {fmt_int(nnz['activation_col_by_col'])}，密度为 {fmt_float(density['activation_col'] * 100, 2)}%。"
        "虽然两个矩阵并非极端稀疏，但大量零值仍会让稠密遍历产生无效 MAC。本文的目标是在保证结果正确的前提下，用 BRAM 存储压缩数据，降低无效计算周期。"
    ))

    body.append(paragraph("2. Method", style="Heading1"))
    body.append(paragraph("2.1 Sparse Data Layout", style="Heading2"))
    body.append(paragraph(
        "设计采用两种压缩结构。第一种用于验证和对照：权重按输出通道压缩为 CSR-like 格式，activation_col 按列压缩为 CSC-like 格式，"
        "通过索引交集得到每个输出元素的有效乘加。第二种作为主设计：权重按照 K 维重新组织。对每一个 K，收集所有非零的输出通道权重，"
        "再按 16 个 lane 打包成权重块。每个块包含 16 个 8-bit 权重和 16 个 8-bit 输出通道编号，空 lane 用 0xff 作为无效标记。"
        "activation_col 的每个非零元素除保存数值外，还保存其对应 K 的权重块起止地址，因此硬件无需在运行时查询 K 到权重块的映射表。"
    ))
    body.append(table([
        ["BRAM Image", "Content", "Width", "Depth"],
        ["a_values.mem", "非零 activation 数值", "8 bit", fmt_int(nnz["activation_col_by_col"])],
        ["a_ptr.mem", "每个输出列的 activation 起止指针", "19 bit", "1025"],
        ["a_wblk_start/end.mem", "每个非零 activation 对应的权重块范围", "19 bit", fmt_int(nnz["activation_col_by_col"])],
        ["wk_block_values16.mem", "16-lane 打包权重值", "128 bit", fmt_int(nnz["weight_k_blocks_16lane"])],
        ["wk_block_rows16.mem", "16-lane 打包输出通道编号", "128 bit", fmt_int(nnz["weight_k_blocks_16lane"])],
    ]))
    body.append(paragraph("2.2 Hardware Mapping", style="Heading2"))
    body.append(paragraph(
        "主控制器 sparse_outer_accel 以输出列为外层循环。每处理一列时，首先清零 128 个输出通道累加寄存器；随后遍历该列的非零 activation。"
        "对于每个 activation，控制器读取 activation 数值和权重块起止地址，并顺序读取相关权重块。每个权重块在一个计算状态中展开为 16 个 lane，"
        "若 lane 的输出通道编号有效，则执行 accum[row] += activation * weight。该过程本质上是稀疏外积映射：一个非零 activation 同时更新多个输出通道，"
        "避免了逐输出元素做索引交集时的大量比较和重复读取。完成一列后，控制器顺序输出 128 个累加结果，进入下一列。"
    ))
    body.append(paragraph(
        "为了满足 Lab-3 对 BRAM 的要求，所有输入矩阵数据均通过 testbench 写入硬件 BRAM，再由 start 信号启动计算。"
        "RTL 中 simple_dual_port_bram 使用 ram_style=\"block\" 属性引导综合为 Block RAM；核心数据通路由 BRAM 读地址、同步读等待、权重块展开和多 lane 累加组成。"
        "另外保留 intersection_match_unit 和 sparse_matmul_accel 作为 CSR/CSC 交集式对照方案，用于说明不同 mapping 选择对周期数的影响。"
    ))

    body.append(paragraph("3. Experiments", style="Heading1"))
    body.append(paragraph(
        "实验脚本 prepare_sparse_data.py 负责从原始十进制矩阵生成 BRAM 初始化文件；run_experiments.py 使用同一压缩格式计算软件参考结果、检查正确性并估算 FSM 周期。"
        f"软件验证覆盖 {fmt_int(verification['checked_outputs'])} 个输出元素，mismatch 数为 {verification['mismatches']}。"
        "Vivado 2019.2 已可启动，但当前自动仿真脚本仍需在本机环境中继续排查 SystemVerilog 兼容性和综合报告导出；因此本文初稿中的资源与 Fmax 表项作为待替换项列出。"
    ))
    body.append(table([
        ["Design", "Key Parameter", "Estimated Cycles", "Speedup vs Dense", "Avg Cycles / Output"],
        ["Dense baseline", "1 MAC", fmt_int(outer["dense_1mac_cycles"]), "1.00x", fmt_float(outer["dense_1mac_cycles"] / (128 * 1024), 2)],
        ["Intersection", "BLOCK_N=16", fmt_int(estimates[2]["estimated_cycles"]), fmt_float(estimates[2]["speedup_vs_dense_1mac"], 2) + "x", fmt_float(estimates[2]["avg_cycles_per_output"], 2)],
        ["Outer product", "LANES=16", fmt_int(outer["estimated_cycles"]), fmt_float(outer["speedup_vs_dense_1mac"], 2) + "x", fmt_float(outer["avg_cycles_per_output"], 2)],
    ]))
    body.append(paragraph(
        "结果显示，交集式 mapping 虽然能够跳过零值，但每个输出元素都需要独立扫描权重行和 activation 列。"
        "在本数据集上，即使 BLOCK_N 增大到 32，估算周期仍高于稠密单 MAC baseline。相反，外积式 mapping 将一个 activation 的贡献广播到所有相关输出通道，"
        f"总权重块访问次数为 {fmt_int(outer['weight_block_visits'])}，平均每个非零 activation 访问 {fmt_float(outer['avg_weight_blocks_per_activation'], 2)} 个权重块，"
        f"每个 16-lane 权重块平均使用 {fmt_float(outer['avg_weight_lanes_used'], 2)} 个有效 lane，因此能够显著减少控制开销。"
    ))
    body.append(paragraph(
        "按照课程给出的性能指标公式：Performance = (1 / (FF + 0.25*LUT + 100*BRAM)) * (Fmax / Cycles)。"
        "在最终提交前，应使用 Vivado 综合后的 FF、LUT、BRAM 和 Fmax 替换下表的占位值。"
        f"若暂以 FF={fmt_int(assumed['ff'])}、LUT={fmt_int(assumed['lut'])}、BRAM={fmt_int(assumed['bram'])}、Fmax={assumed['fmax_mhz']} MHz 估算，"
        f"并使用外积方案周期数 {fmt_int(outer['estimated_cycles'])}，性能指标约为 {assumed['performance_index']:.3e}。"
        "该数值仅用于展示报告计算方法，不应作为最终综合结果。"
    ))

    body.append(paragraph("4. Conclusion", style="Heading1"))
    body.append(paragraph(
        "本文完成了面向 Lab-3 数据集的 BRAM 稀疏矩阵乘映射设计。相较于逐输出元素的索引交集方案，16-lane 外积式设计更适合本实验的矩阵形状，"
        "因为它复用了每个非零 activation 的读取结果，并将对应权重块直接映射到多个输出通道累加器。"
        "当前软件验证已证明压缩格式与参考输出完全一致，周期估算表明外积式 mapping 对单 MAC 稠密 baseline 具有约 17.24 倍的周期优势。"
        "后续工作主要包括完成 Vivado RTL 全量仿真、导出综合资源和时序报告，并据此更新性能指标。"
    ))
    body.append(paragraph("References", style="Heading1"))
    body.append(paragraph("[1] Lab-3 阵列+存储器系统设计实验指南，数字系统设计课程材料。"))
    body.append(paragraph("[2] K. Simonyan and A. Zisserman, Very Deep Convolutional Networks for Large-Scale Image Recognition, ICLR, 2015."))
    body.append(paragraph("[3] Y.-H. Chen et al., Eyeriss: An Energy-Efficient Reconfigurable Accelerator for Deep Convolutional Neural Networks, JSSC, 2017."))

    md_sections = [
        f"# {title}",
        author,
        "## Abstract",
        abstract,
        "**Keywords:** Sparse Matrix Multiplication; BRAM; FPGA; CNN Accelerator; Data Mapping",
        "## 1. Introduction",
        "CNN 推理中的卷积层通常占据主要计算量。课程前序 Lab 中，数据搬运、mapping 和控制逻辑主要由 testbench 以软件循环完成；而 Lab-3 要求将矩阵预存到 Xilinx FPGA 的 BRAM 中，并由硬件控制完成矩阵到阵列或计算单元的映射。",
        "## 2. Method",
        "设计采用 16-lane 稀疏外积数据流。activation_col 按输出列压缩，权重按 K 维打包为权重值和输出通道编号两个 128-bit BRAM image。",
        "## 3. Experiments",
        f"软件验证覆盖 {fmt_int(verification['checked_outputs'])} 个输出元素，mismatch={verification['mismatches']}。外积方案估算周期为 {fmt_int(outer['estimated_cycles'])}，相对稠密单 MAC baseline 加速 {fmt_float(outer['speedup_vs_dense_1mac'], 2)}x。",
        (REPORT_DIR / "experiment_tables.md").read_text(encoding="utf-8"),
        "## 4. Conclusion",
        "外积式 mapping 能够复用 activation 读取并并行更新多个输出通道，是本数据集上比索引交集更有效的 BRAM 数据流。最终提交前需要用 Vivado 综合报告替换资源和 Fmax 占位值。",
    ]
    return "\n\n".join(md_sections), "".join(body)


def write_docx(path: Path, doc_body: str) -> None:
    files = {
        "[Content_Types].xml": static_file("[Content_Types].xml"),
        "_rels/.rels": static_file("_rels/.rels"),
        "word/_rels/document.xml.rels": static_file("word/_rels/document.xml.rels"),
        "word/document.xml": document_xml(doc_body),
        "word/styles.xml": styles_xml(),
        "word/settings.xml": static_file("word/settings.xml"),
        "docProps/core.xml": static_file("docProps/core.xml"),
        "docProps/app.xml": static_file("docProps/app.xml"),
    }
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content.encode("utf-8"))


def main() -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    stats = load_json("data_stats.json")
    results = load_json("experiment_results.json")
    md, doc_body = build_content(stats, results)
    (REPORT_DIR / "lab3_short_paper.md").write_text(md, encoding="utf-8")
    write_docx(REPORT_DIR / "lab3_short_paper.docx", doc_body)
    print(REPORT_DIR / "lab3_short_paper.docx")
    print(REPORT_DIR / "lab3_short_paper.md")


if __name__ == "__main__":
    main()
