set root C:/Users/local-user/Desktop/lab3
set_param general.maxThreads 1
read_verilog -sv $root/rtl/simple_dual_port_bram.sv
read_verilog -sv $root/rtl/sparse_outer_accel_dense_pe.sv
read_xdc $root/constraints/sparse_outer_accel.xdc
synth_design -top sparse_outer_accel_dense_pe -part xc7a200tfbg676-2 -mode out_of_context
opt_design
report_utilization -file $root/generated/sparse_dense_pe_utilization.rpt
report_timing_summary -file $root/generated/sparse_dense_pe_timing.rpt
puts "SYNTH_DONE_OK"
