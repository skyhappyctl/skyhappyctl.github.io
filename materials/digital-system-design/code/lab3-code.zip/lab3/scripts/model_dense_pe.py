#!/usr/bin/env python3
"""Cycle/resource model for the dense-PE outer-product accelerator.

Goal: validate (before writing RTL) that a 128 fixed-PE design hits the
performance index target.  Index = (1/(FF + 0.25*LUT + 100*BRAM)) *
(Fmax / total_cycles).

The model reproduces the exact FSM throughput so the RTL cycle count can be
checked against it later.
"""

from __future__ import annotations

from pathlib import Path

GEN = Path(__file__).resolve().parents[1] / "generated"
OUT_ROWS = 128
OUT_COLS = 1024
K_SIZE = 576
MASK_WORD_BITS = 32
MASK_WORDS_PER_COL = (K_SIZE + MASK_WORD_BITS - 1) // MASK_WORD_BITS  # 18


def load_hex(name: str) -> list[int]:
    return [int(l, 16) for l in (GEN / name).read_text().split() if l.strip()]


def col_nnz() -> list[int]:
    ptr = load_hex("a_ptr.mem")
    return [ptr[i + 1] - ptr[i] for i in range(len(ptr) - 1)]


def model_cycles(nnz_per_col: list[int], width: int) -> dict:
    """width = number of activation nonzeros consumed per cycle in steady state.

    Per-column FSM:
      - 3 cyc: read a_ptr[c], a_ptr[c+1] (pipelined handshake)
      - mask scan: walk 18 mask words; reading a word = 1 cyc, then emit its
        set bits at `width` per cycle.  Empty words still cost 1 cyc to read.
      - emit of the 128 accumulators is double-buffered: overlaps next column
        compute, only the final column's emit is exposed.
    """
    PIPE_FILL = 4  # weight-read + multiply pipeline depth
    total = 0
    for nnz in nnz_per_col:
        ptr_cyc = 3
        mask_read_cyc = MASK_WORDS_PER_COL  # one read per mask word
        compute_cyc = (nnz + width - 1) // width
        total += ptr_cyc + mask_read_cyc + compute_cyc + PIPE_FILL
    total += OUT_ROWS  # exposed final-column emit (double buffered otherwise)
    return {"width": width, "total_cycles": total}


def perf_index(cycles: int, ff: int, lut: int, bram: int, fmax_hz: float) -> float:
    denom = ff + 0.25 * lut + 100 * bram
    return (1.0 / denom) * (fmax_hz / cycles)


def to_signed(v: int, bits: int) -> int:
    if v & (1 << (bits - 1)):
        return v - (1 << bits)
    return v


def verify_correctness() -> dict:
    """Replay the dense-PE dataflow in Python and compare to output_col.mem.

    Dataflow per column c:
      acc[0..127] = 0
      for each nonzero (k, a_val) of column c (found via bitmap + a_values):
          for row in 0..127: acc[row] += a_val * W[row][k]
      emit acc[row] for all rows.
    W[row][k] read from wd_by_k word k, byte `row`.
    """
    wd = load_hex("wd_by_k.mem")            # 576 words, 1024-bit each
    a_vals = load_hex("a_values.mem")       # signed 8-bit, two's comp hex
    a_ptr = load_hex("a_ptr.mem")
    masks = load_hex("a_mask32.mem")        # 1024*18 words
    ref = load_hex("output_col.mem")        # 128*1024 signed-32 hex

    mismatches = 0
    first = None
    for c in range(OUT_COLS):
        acc = [0] * OUT_ROWS
        base = a_ptr[c]
        # enumerate nonzero k from bitmap, in ascending order -> matches a_values order
        a_pos = base
        for w in range(MASK_WORDS_PER_COL):
            word = masks[c * MASK_WORDS_PER_COL + w]
            for bit in range(MASK_WORD_BITS):
                k = w * MASK_WORD_BITS + bit
                if k >= K_SIZE:
                    break
                if (word >> bit) & 1:
                    a_val = to_signed(a_vals[a_pos], 8)
                    a_pos += 1
                    wword = wd[k]
                    for row in range(OUT_ROWS):
                        wv = to_signed((wword >> (row * 8)) & 0xFF, 8)
                        acc[row] += a_val * wv
        for row in range(OUT_ROWS):
            exp = to_signed(ref[row * OUT_COLS + c], 32)
            if acc[row] != exp:
                mismatches += 1
                if first is None:
                    first = {"row": row, "col": c, "got": acc[row], "exp": exp}
    return {"checked": OUT_ROWS * OUT_COLS, "mismatches": mismatches, "first": first}


def main() -> None:
    nnz = col_nnz()
    print(f"cols={len(nnz)} total_nnz={sum(nnz)} min={min(nnz)} max={max(nnz)}")

    print("verifying dense-PE dataflow against output_col.mem ...")
    v = verify_correctness()
    print(f"  checked={v['checked']} mismatches={v['mismatches']} first={v['first']}")

    # BRAM estimates (RAMB36 = 36 Kbit). Width-packed where wide.
    bram_weight_1b = 29   # 576 deep x 1024-bit dense weight-by-k
    bram_avals = 64       # 262575 x 8-bit activation values
    bram_mask = 17        # 18432 x 32-bit column bitmaps
    base_bram = bram_avals + bram_mask

    configs = [
        # width, ff, lut, bram
        (1, 9000, 13000, base_bram + bram_weight_1b * 1),
        (2, 13000, 24000, base_bram + bram_weight_1b * 2),
        (4, 21000, 46000, base_bram + bram_weight_1b * 4),
    ]
    print(f"{'W':>2} {'cycles':>9} {'FF':>6} {'LUT':>6} {'BRAM':>5} "
          f"{'denom':>8} {'idx@100M':>9}")
    for width, ff, lut, bram in configs:
        cyc = model_cycles(nnz, width)["total_cycles"]
        idx = perf_index(cyc, ff, lut, bram, 100e6)
        denom = ff + 0.25 * lut + 100 * bram
        print(f"{width:>2} {cyc:>9} {ff:>6} {lut:>6} {bram:>5} "
              f"{denom:>8.0f} {idx:>9.5f}")


if __name__ == "__main__":
    main()
