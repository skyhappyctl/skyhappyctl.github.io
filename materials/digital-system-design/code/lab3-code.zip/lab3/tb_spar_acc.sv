`timescale 1ns/1ps
`define CLK_PERIOD 10 // 100MHz

module tb_spar_acc; // test bench

    parameter unit_n = 16;
    parameter BW_act_idx = 10;         // bit length of activation index
    parameter BW_weight_idx = 10;      // bit length of weight index
    parameter BW_idx = 5;              // bit length of index
    
    parameter BW_act_in = 8;           // bit length of activation
    parameter BW_weight_in = 8;        // bit length of weight
    parameter BW_out = 32;             // bit length of accu result
    
    parameter IA_W = 262575;
    parameter Weight_W = 20644;
    parameter OA_H = 128;
    parameter OA_W = 1024;

    // parameter inter_num = 4;
    // parameter mactree_num = 8;

    reg signed [BW_act_in - 1 : 0]         Input_activation_main_memory[IA_W - 1 : 0];
    reg [BW_act_idx - 1 : 0]               Input_activation_idx_memory[IA_W - 1 : 0];
    reg [BW_act_idx - 1 : 0]               Input_post_memory[OA_W - 1 : 0];
    
    reg signed [BW_weight_in - 1 : 0]      Weight_main_memory[Weight_W - 1 : 0];
    reg [BW_weight_idx - 1 : 0]            Weight_idx_memory[Weight_W - 1 : 0];
    reg [BW_weight_idx - 1 : 0]            Weight_post_memory[OA_H - 1 : 0];
    
    reg signed [BW_out - 1 : 0]            Output_activation_main_memory[OA_H - 1 : 0][OA_W - 1 : 0];
    reg signed [BW_out - 1 : 0]            reference_output[OA_H - 1 : 0][OA_W - 1 : 0];
    
    reg signed [BW_out - 1 : 0]            NextInput_activation_main_memory[OA_H * OA_W - 1 : 0];
    reg [BW_act_idx : 0]                   NextInput_activation_idx_memory[OA_H * OA_W - 1 : 0];
    reg [BW_act_idx : 0]                   NextInput_post_memory[OA_W - 1 : 0];
    
    reg clk;
    reg reset_n;
    reg unit_clear;
    reg unit_hold;

    reg [BW_act_idx - 1 : 0]               unit_actidx_in[unit_n - 1 : 0];
    reg [BW_weight_idx - 1 : 0]            unit_weightidx_in[unit_n - 1 : 0];

    reg [BW_idx - 1 : 0]           out_act_idx[unit_n - 1 : 0];
    reg [BW_idx - 1 : 0]           out_weight_idx[unit_n - 1 : 0];
    reg [BW_idx : 0]               cnt;
    
    reg signed [BW_out - 1 : 0] partial_sum;

    intersection_match_unit #(
    .unit_n(unit_n),
    .BW_act_idx(BW_act_idx),      
    .BW_weight_idx(BW_weight_idx)            
    )u_inter_match_unit(
    .clk(clk),
    .reset_n(reset_n),
    .unit_clear(unit_clear),
    .unit_hold(unit_hold),
    .unit_actidx_in(unit_actidx_in),
    .unit_weightidx_in(unit_weightidx_in),
    .out_act_idx(out_act_idx),
    .out_weight_idx(out_weight_idx),
    .cnt(cnt)
    );


    initial begin
        clk = 0;
        reset_n = 1;
        for (integer i = 0; i < unit_n; i = i + 1) begin
            unit_actidx_in[i] <= 577;
            unit_weightidx_in[i] <= 578;
        end
        forever begin
            #(`CLK_PERIOD/2) clk = ~clk;
        end
    end

    integer correct_num = 0; 
    integer IA_num = 0;
    integer W_num = 0;
    integer IA_loop = 0;
    integer W_loop = 0;
    integer IA_total = 0;
    integer W_total = 0;
    integer pp = 0;
    integer qq = 0;
    integer cntt = 0;
    integer total = 0;

    initial begin
        
        @(negedge clk); 
        
        reset_n = 0; 
        
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//a_sparse.txt", Input_activation_main_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//aw_idx.txt", Input_activation_idx_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//a_post.txt", Input_post_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//w_sparse.txt", Weight_main_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//ww_idx.txt", Weight_idx_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//w_post.txt", Weight_post_memory);
        $readmemb("C:/Users/local-user//vivado//pro3//tbdata//output_col.txt", reference_output);
        
        // loop nest
        @(negedge clk);
        
        reset_n = 1;
       
        for(integer m = 0; m < OA_W; m = m + 1) begin
            IA_num = Input_post_memory[m];
            W_total = 0;
            for(integer n = 0; n < OA_H; n = n + 1) begin
                W_num = Weight_post_memory[n];
                IA_loop = 0;
                W_loop = 0;
                partial_sum = 0;
                while(IA_loop < (IA_num / unit_n + 1) || W_loop < (W_num / unit_n + 1)) begin 

                    @(negedge clk) begin
                        unit_clear <= 0;
                        for (integer i = 0; i < unit_n; i = i + 1) begin
                            if (IA_loop * unit_n + i < IA_num) 
                                unit_actidx_in[i] <= Input_activation_idx_memory[IA_total + IA_loop * unit_n + i];
                            else
                                unit_actidx_in[i] <= 577;
                        end
                        for (integer i = 0; i < unit_n; i = i + 1) begin
                            if (W_loop * unit_n + i < W_num)
                                unit_weightidx_in[i] <= Weight_idx_memory[W_total + W_loop * unit_n + i];
                            else begin
                                unit_weightidx_in[i] <= 578;
                            end
                        end
                    end

                    @(negedge clk) begin
                        unit_hold <= 1;
                    end

                    @(negedge clk) begin           
                        for(integer i = 0; i < cnt; i = i + 1) begin
                            pp = IA_total + IA_loop * unit_n + out_act_idx[i];
                            qq = W_total + W_loop * unit_n + out_weight_idx[i];
                            partial_sum = partial_sum + Input_activation_main_memory[pp] * Weight_main_memory[qq];
                        end
                    end

                     @(negedge clk) begin
                        if((unit_actidx_in[unit_n - 1] < unit_weightidx_in[unit_n - 1]) && ((unit_weightidx_in[unit_n - 1] != 578)||(IA_loop < (IA_num / unit_n + 1))))begin
                            IA_loop = IA_loop + 1;
                        end
                        else begin
                            W_loop = W_loop + 1;
                        end
                        unit_hold <= 0;
                        unit_clear <= 1;
                     end

                end
                
                @(negedge clk) begin
                    Output_activation_main_memory[n][m] <= partial_sum;
                end
                W_total = W_total + W_num;
            end
            IA_total = IA_total + IA_num;
        end
       
        @(negedge clk);
        
        for(integer k = 0; k < OA_H; k = k + 1) begin
            for(integer p = 0; p < OA_W; p = p + 1) begin
                if(Output_activation_main_memory[k][p] == reference_output[k][p]) begin
                    correct_num = correct_num + 1;
                end
                else begin
                    $display("wrong at (%d %d), output %d, reference %d", k, p, Output_activation_main_memory[k][p], reference_output[k][p]);
                end
            end
        end
        
        $display("correct num: %d", correct_num);
        
        @(negedge clk);
        
        $finish(0);// important for getting the running time

        for(integer k = 0; k < OA_W; k = k + 1) begin
            cntt = 0;
            for(integer p = 0; p < OA_H; p = p + 1) begin
                if(Output_activation_main_memory[p][k] > 0) begin
                    NextInput_activation_main_memory [total] = Output_activation_main_memory[p][k];
                    NextInput_activation_idx_memory [total] = p;
                    cntt = cntt + 1;
                    total = total + 1;
                end
            NextInput_post_memory[k] = cntt;
            end
        end
    end
    
endmodule