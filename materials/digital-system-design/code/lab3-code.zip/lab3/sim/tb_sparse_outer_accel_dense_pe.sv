`timescale 1ns/1ps
`define CLK_PERIOD 10

// Testbench for sparse_outer_accel_dense_pe.
// Loads dense-weight-by-k + column-major activation CSR into BRAM, runs the
// accelerator, and checks every output against output_col.mem.
module tb_sparse_outer_accel_dense_pe;

    localparam int OUT_ROWS = 128;
    localparam int OUT_COLS = 1024;
    localparam int K_SIZE   = 576;
    localparam int A_NNZ    = 262575;
    localparam int DATA_W   = 8;
    localparam int IDX_W    = 10;
    localparam int ACC_W    = 32;
    localparam int ADDR_W   = 19;
    localparam int ROW_W    = 8;
    localparam int COL_W    = 10;
    localparam int WD_W     = OUT_ROWS * DATA_W;

`ifdef FULL_TEST
    localparam int TB_OUT_COLS = OUT_COLS;
`else
    localparam int TB_OUT_COLS = 16;
`endif

    localparam logic [3:0] MEM_WD    = 4'd0;
    localparam logic [3:0] MEM_A_VAL = 4'd1;
    localparam logic [3:0] MEM_A_IDX = 4'd2;
    localparam logic [3:0] MEM_A_PTR = 4'd3;
    localparam int MAX_LOAD_DEPTH = A_NNZ;

    logic clk;
    logic reset_n;
    logic load_we;
    logic [3:0] load_mem;
    logic [ADDR_W-1:0] load_addr;
    logic [WD_W-1:0] load_data;
    logic start;
    logic busy;
    logic done;
    logic output_valid;
    logic [ROW_W-1:0] output_row;
    logic [COL_W-1:0] output_col;
    logic signed [ACC_W-1:0] output_data;
    logic [63:0] cycle_count;

    logic [WD_W-1:0] preload_mem [0:MAX_LOAD_DEPTH-1];
    logic signed [ACC_W-1:0] reference_mem [0:OUT_ROWS*OUT_COLS-1];

    int output_count;
    int mismatch_count;
    logic check_enable;
    string data_dir;
    string ref_path;

    sparse_outer_accel_dense_pe #(
        .OUT_ROWS(OUT_ROWS), .OUT_COLS(TB_OUT_COLS), .K_SIZE(K_SIZE),
        .A_NNZ(A_NNZ), .DATA_W(DATA_W), .IDX_W(IDX_W), .ACC_W(ACC_W),
        .ADDR_W(ADDR_W), .ROW_W(ROW_W), .COL_W(COL_W)
    ) dut (
        .clk(clk), .reset_n(reset_n),
        .load_we(load_we), .load_mem(load_mem), .load_addr(load_addr), .load_data(load_data),
        .start(start), .busy(busy), .done(done),
        .output_valid(output_valid), .output_row(output_row), .output_col(output_col),
        .output_data(output_data), .cycle_count(cycle_count)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD / 2) clk = ~clk;
    end

    task automatic load_image(input logic [3:0] mem_id, input int count, input string fname);
        string path;
        begin
            path = {data_dir, "/", fname};
            $display("Loading %s into mem %0d (%0d words)", path, mem_id, count);
            $readmemh(path, preload_mem);
            @(negedge clk);
            load_mem <= mem_id;
            load_we  <= 1'b1;
            for (int i = 0; i < count; i++) begin
                load_addr <= i[ADDR_W-1:0];
                load_data <= preload_mem[i];
                @(negedge clk);
            end
            load_we   <= 1'b0;
            load_addr <= '0;
            load_data <= '0;
            @(negedge clk);
        end
    endtask

    initial begin
        data_dir = "C:/Users/local-user/Desktop/lab3/generated";
        void'($value$plusargs("DATA_DIR=%s", data_dir));

        reset_n = 1'b0;
        load_we = 1'b0; load_mem = '0; load_addr = '0; load_data = '0;
        start = 1'b0; check_enable = 1'b0;

        repeat (5) @(negedge clk);
        reset_n = 1'b1;

        load_image(MEM_WD,    K_SIZE,          "wd_by_k.mem");
        load_image(MEM_A_VAL, A_NNZ,           "a_values.mem");
        load_image(MEM_A_IDX, A_NNZ,           "a_indices.mem");
        load_image(MEM_A_PTR, TB_OUT_COLS + 1, "a_ptr.mem");

        ref_path = {data_dir, "/output_col.mem"};
        $display("Loading reference %s", ref_path);
        $readmemh(ref_path, reference_mem);

        @(negedge clk);
        start        <= 1'b1;
        check_enable <= 1'b1;
        @(negedge clk);
        start        <= 1'b0;

        wait(done);
        @(negedge clk);

        $display("LAB3_DENSE_PE_SIM_DONE outputs=%0d mismatches=%0d cycles=%0d cols=%0d",
                 output_count, mismatch_count, cycle_count, TB_OUT_COLS);
        if (mismatch_count == 0 && output_count == OUT_ROWS * TB_OUT_COLS) begin
            $display("LAB3_DENSE_PE_SIM_PASS");
            $finish(0);
        end else begin
            $display("LAB3_DENSE_PE_SIM_FAIL");
            $finish(1);
        end
    end

    always_ff @(posedge clk or negedge reset_n) begin
        int ref_index;
        logic signed [ACC_W-1:0] expected;
        if (!reset_n) begin
            output_count  <= 0;
            mismatch_count <= 0;
        end else if (check_enable && output_valid) begin
            output_count++;
            ref_index = output_row * OUT_COLS + output_col;
            expected  = reference_mem[ref_index];
            if (output_data !== expected) begin
                mismatch_count++;
                if (mismatch_count <= 16) begin
                    $display("Mismatch row=%0d col=%0d got=%0d expected=%0d",
                             output_row, output_col, output_data, expected);
                end
            end
        end
    end

endmodule
