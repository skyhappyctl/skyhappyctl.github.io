`timescale 1ns/1ps
`define CLK_PERIOD 10

module tb_sparse_outer_accel_bitmap;

    localparam int LAB3_OUT_ROWS = 128;
    localparam int LAB3_OUT_COLS = 1024;
    localparam int LAB3_K_SIZE = 576;
    localparam int LAB3_A_NNZ = 262575;
    localparam int LAB3_WEIGHT_LANES = 16;
    localparam int LAB3_W_BLOCKS16 = 1552;
    localparam int LAB3_DATA_W = 8;
    localparam int LAB3_IDX_W = 10;
    localparam int LAB3_ROW_W = 8;
    localparam int LAB3_ACC_W = 32;
    localparam int LAB3_ADDR_W = 19;
    localparam int LAB3_A_MASK_WORD_BITS = 32;
    localparam int MASK_WORDS_PER_COL =
        (LAB3_K_SIZE + LAB3_A_MASK_WORD_BITS - 1) / LAB3_A_MASK_WORD_BITS;

    localparam int LANES = LAB3_WEIGHT_LANES;
`ifdef FULL_TEST
    localparam int TB_OUT_COLS = LAB3_OUT_COLS;
`else
    localparam int TB_OUT_COLS = 16;
`endif
    localparam int TB_A_MASK_WORDS = TB_OUT_COLS * MASK_WORDS_PER_COL;

    localparam logic [3:0] MEM_A_VAL  = 4'd0;
    localparam logic [3:0] MEM_A_PTR  = 4'd1;
    localparam logic [3:0] MEM_A_MASK = 4'd2;
    localparam logic [3:0] MEM_WB_PTR = 4'd3;
    localparam logic [3:0] MEM_WB_VAL = 4'd4;
    localparam logic [3:0] MEM_WB_ROW = 4'd5;
    localparam int LOAD_W = LANES * LAB3_DATA_W;
    localparam int MAX_LOAD_DEPTH = LAB3_A_NNZ;

    logic clk;
    logic reset_n;
    logic load_we;
    logic [3:0] load_mem;
    logic [LAB3_ADDR_W-1:0] load_addr;
    logic [LOAD_W-1:0] load_data;
    logic start;
    logic busy;
    logic done;
    logic output_valid;
    logic [LAB3_ROW_W-1:0] output_row;
    logic [9:0] output_col;
    logic signed [LAB3_ACC_W-1:0] output_data;
    logic [63:0] cycle_count;

    logic [LOAD_W-1:0] preload_mem [0:MAX_LOAD_DEPTH-1];
    logic signed [LAB3_ACC_W-1:0] reference_mem [0:LAB3_OUT_ROWS*LAB3_OUT_COLS-1];

    int output_count;
    int mismatch_count;
    logic check_enable;
    string data_dir;
    string ref_path;
    int plusarg_ok;

    sparse_outer_accel_bitmap #(
        .LANES(LANES),
        .OUT_ROWS(LAB3_OUT_ROWS),
        .OUT_COLS(TB_OUT_COLS),
        .A_NNZ(LAB3_A_NNZ),
        .W_BLOCKS(LAB3_W_BLOCKS16),
        .K_SIZE(LAB3_K_SIZE),
        .MASK_WORDS(TB_A_MASK_WORDS),
        .MASK_WORD_BITS(LAB3_A_MASK_WORD_BITS),
        .DATA_W(LAB3_DATA_W),
        .IDX_W(LAB3_IDX_W),
        .ACC_W(LAB3_ACC_W),
        .ADDR_W(LAB3_ADDR_W),
        .ROW_W(LAB3_ROW_W),
        .COL_W(10)
    ) dut (
        .clk(clk),
        .reset_n(reset_n),
        .load_we(load_we),
        .load_mem(load_mem),
        .load_addr(load_addr),
        .load_data(load_data),
        .start(start),
        .busy(busy),
        .done(done),
        .output_valid(output_valid),
        .output_row(output_row),
        .output_col(output_col),
        .output_data(output_data),
        .cycle_count(cycle_count)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD / 2) clk = ~clk;
    end

    task automatic load_bram_image(
        input logic [3:0] mem_id,
        input int count,
        input string file_name
    );
        string path;
        begin
            path = {data_dir, "/", file_name};
            $display("Loading %s into memory %0d (%0d words)", path, mem_id, count);
            $readmemh(path, preload_mem);
            @(negedge clk);
            load_mem <= mem_id;
            load_we <= 1'b1;
            for (int i = 0; i < count; i++) begin
                load_addr <= i[LAB3_ADDR_W-1:0];
                load_data <= preload_mem[i];
                @(negedge clk);
            end
            load_we <= 1'b0;
            load_addr <= '0;
            load_data <= '0;
            @(negedge clk);
        end
    endtask

    initial begin
        data_dir = "C:/Users/local-user/Desktop/lab3/generated";
        plusarg_ok = $value$plusargs("DATA_DIR=%s", data_dir);

        reset_n = 1'b0;
        load_we = 1'b0;
        load_mem = '0;
        load_addr = '0;
        load_data = '0;
        start = 1'b0;
        check_enable = 1'b0;

        repeat (5) @(negedge clk);
        reset_n = 1'b1;

        load_bram_image(MEM_A_VAL, LAB3_A_NNZ, "a_values.mem");
        load_bram_image(MEM_A_PTR, TB_OUT_COLS + 1, "a_ptr.mem");
        load_bram_image(MEM_A_MASK, TB_A_MASK_WORDS, "a_mask32.mem");
        load_bram_image(MEM_WB_PTR, LAB3_K_SIZE + 1, "wk_block_ptr16.mem");
        load_bram_image(MEM_WB_VAL, LAB3_W_BLOCKS16, "wk_block_values16.mem");
        load_bram_image(MEM_WB_ROW, LAB3_W_BLOCKS16, "wk_block_rows16.mem");

        ref_path = {data_dir, "/output_col.mem"};
        $display("Loading %s into reference memory", ref_path);
        $readmemh(ref_path, reference_mem);

        @(negedge clk);
        start <= 1'b1;
        check_enable <= 1'b1;
        @(negedge clk);
        start <= 1'b0;

        wait(done);
        @(negedge clk);

        $display("LAB3_OUTER_BITMAP_SIM_DONE outputs=%0d mismatches=%0d cycles=%0d rows=%0d cols=%0d lanes=%0d",
                 output_count, mismatch_count, cycle_count, LAB3_OUT_ROWS, TB_OUT_COLS, LANES);
        if (mismatch_count == 0 && output_count == LAB3_OUT_ROWS * TB_OUT_COLS) begin
            $display("LAB3_OUTER_BITMAP_SIM_PASS");
            $finish(0);
        end else begin
            $display("LAB3_OUTER_BITMAP_SIM_FAIL");
            $finish(1);
        end
    end

    always_ff @(posedge clk or negedge reset_n) begin
        int ref_index;
        logic signed [LAB3_ACC_W-1:0] expected;

        if (!reset_n) begin
            output_count <= 0;
            mismatch_count <= 0;
        end else if (check_enable && output_valid) begin
            output_count++;
            ref_index = output_row * LAB3_OUT_COLS + output_col;
            expected = reference_mem[ref_index];
            if (output_data !== expected) begin
                mismatch_count++;
                if (mismatch_count <= 16) begin
                    $display("Mismatch row=%0d col=%0d got=%0d expected=%0d",
                             output_row, output_col, output_data, expected);
                end
            end
        end
    end

endmodule
