`timescale 1ns/1ps
`define CLK_PERIOD 10

`include "../generated/sparse_config.svh"

module tb_sparse_matmul_accel;

    localparam int BLOCK_N = 16;
`ifdef FULL_TEST
    localparam int TB_OUT_ROWS = LAB3_OUT_ROWS;
    localparam int TB_OUT_COLS = LAB3_OUT_COLS;
`else
    localparam int TB_OUT_ROWS = 8;
    localparam int TB_OUT_COLS = 16;
`endif

    localparam logic [2:0] MEM_W_VAL = 3'd0;
    localparam logic [2:0] MEM_W_IDX = 3'd1;
    localparam logic [2:0] MEM_W_PTR = 3'd2;
    localparam logic [2:0] MEM_A_VAL = 3'd3;
    localparam logic [2:0] MEM_A_IDX = 3'd4;
    localparam logic [2:0] MEM_A_PTR = 3'd5;
    localparam int MAX_LOAD_DEPTH = LAB3_A_NNZ;

    logic clk;
    logic reset_n;
    logic load_we;
    logic [2:0] load_mem;
    logic [LAB3_ADDR_W-1:0] load_addr;
    logic [31:0] load_data;
    logic start;
    logic busy;
    logic done;
    logic output_valid;
    logic [7:0] output_row;
    logic [9:0] output_col;
    logic signed [LAB3_ACC_W-1:0] output_data;
    logic [63:0] cycle_count;

    logic [31:0] preload_mem [0:MAX_LOAD_DEPTH-1];
    logic signed [LAB3_ACC_W-1:0] reference_mem [0:LAB3_OUT_ROWS*LAB3_OUT_COLS-1];

    int output_count;
    int mismatch_count;
    string data_dir;

    sparse_matmul_accel #(
        .BLOCK_N(BLOCK_N),
        .OUT_ROWS(TB_OUT_ROWS),
        .OUT_COLS(TB_OUT_COLS),
        .W_NNZ(LAB3_W_NNZ),
        .A_NNZ(LAB3_A_NNZ),
        .DATA_W(LAB3_DATA_W),
        .IDX_W(LAB3_IDX_W),
        .ACC_W(LAB3_ACC_W),
        .ADDR_W(LAB3_ADDR_W),
        .ROW_W(8),
        .COL_W(10),
        .CNT_W(6)
    ) dut (
        .clk(clk),
        .reset_n(reset_n),
        .load_we(load_we),
        .load_mem(load_mem),
        .load_addr(load_addr),
        .load_data(load_data),
        .start(start),
        .busy(busy),
        .done(done),
        .output_valid(output_valid),
        .output_row(output_row),
        .output_col(output_col),
        .output_data(output_data),
        .cycle_count(cycle_count)
    );

    initial begin
        clk = 1'b0;
        forever #(`CLK_PERIOD / 2) clk = ~clk;
    end

    task automatic load_bram_image(
        input logic [2:0] mem_id,
        input int count,
        input string file_name
    );
        string path;
        begin
            path = {data_dir, "/", file_name};
            $display("Loading %s into memory %0d (%0d words)", path, mem_id, count);
            $readmemh(path, preload_mem, 0, count - 1);
            @(negedge clk);
            load_mem <= mem_id;
            load_we <= 1'b1;
            for (int i = 0; i < count; i++) begin
                load_addr <= i[LAB3_ADDR_W-1:0];
                load_data <= preload_mem[i];
                @(negedge clk);
            end
            load_we <= 1'b0;
            load_addr <= '0;
            load_data <= '0;
            @(negedge clk);
        end
    endtask

    initial begin
        data_dir = "lab3/generated";
        void'($value$plusargs("DATA_DIR=%s", data_dir));

        reset_n = 1'b0;
        load_we = 1'b0;
        load_mem = '0;
        load_addr = '0;
        load_data = '0;
        start = 1'b0;
        output_count = 0;
        mismatch_count = 0;

        repeat (5) @(negedge clk);
        reset_n = 1'b1;

        load_bram_image(MEM_W_VAL, LAB3_W_NNZ, "w_values.mem");
        load_bram_image(MEM_W_IDX, LAB3_W_NNZ, "w_indices.mem");
        load_bram_image(MEM_W_PTR, LAB3_OUT_ROWS + 1, "w_ptr.mem");
        load_bram_image(MEM_A_VAL, LAB3_A_NNZ, "a_values.mem");
        load_bram_image(MEM_A_IDX, LAB3_A_NNZ, "a_indices.mem");
        load_bram_image(MEM_A_PTR, LAB3_OUT_COLS + 1, "a_ptr.mem");

        $readmemh({data_dir, "/output_col.mem"}, reference_mem);

        @(negedge clk);
        start <= 1'b1;
        @(negedge clk);
        start <= 1'b0;

        wait(done);
        @(negedge clk);

        $display("LAB3_SIM_DONE outputs=%0d mismatches=%0d cycles=%0d rows=%0d cols=%0d",
                 output_count, mismatch_count, cycle_count, TB_OUT_ROWS, TB_OUT_COLS);
        if (mismatch_count == 0 && output_count == TB_OUT_ROWS * TB_OUT_COLS) begin
            $display("LAB3_SIM_PASS");
            $finish(0);
        end else begin
            $display("LAB3_SIM_FAIL");
            $finish(1);
        end
    end

    always_ff @(posedge clk) begin
        int ref_index;
        logic signed [LAB3_ACC_W-1:0] expected;

        if (output_valid) begin
            output_count++;
            ref_index = output_row * LAB3_OUT_COLS + output_col;
            expected = reference_mem[ref_index];
            if (output_data !== expected) begin
                mismatch_count++;
                if (mismatch_count <= 16) begin
                    $display("Mismatch row=%0d col=%0d got=%0d expected=%0d",
                             output_row, output_col, output_data, expected);
                end
            end
        end
    end

endmodule
