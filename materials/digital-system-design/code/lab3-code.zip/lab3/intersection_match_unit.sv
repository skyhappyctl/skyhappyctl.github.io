module intersection_match_unit #(
    parameter unit_n = 32,
    parameter BW_act_idx = 10,         // bit length of activation index
    parameter BW_weight_idx = 10,       // bit length of weight index
    parameter BW_idx = 5
)(
    input clk,
    input reset_n,

    input unit_clear,
    input unit_hold,

    input [BW_act_idx - 1 : 0]            unit_actidx_in[unit_n - 1 : 0],
    input [BW_weight_idx - 1 : 0]         unit_weightidx_in[unit_n - 1 : 0],

    output reg [BW_idx - 1 : 0]           out_act_idx[unit_n - 1 : 0],
    output reg [BW_idx - 1 : 0]           out_weight_idx[unit_n - 1 : 0],
    output reg [BW_idx : 0]               cnt
);

/*
    reg [BW_act_idx - 1 : 0]            unit_actidx_in_reg[unit_n - 1 : 0];
    reg [BW_weight_idx - 1 : 0]         unit_weightidx_in_reg[unit_n - 1 : 0];
    
    reg unit_clear_reg; // for update


    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin 
            unit_clear_reg <= '0;
        end
        else begin
            unit_clear_reg <= unit_clear;
        end         
    end

    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin
            for (integer j = 0; j < unit_n; j = j + 1) begin
                unit_actidx_in_reg[j] <= 577;
                unit_weightidx_in_reg[j] <= 578;
            end
        end
        else begin
            for (integer j = 0; j < unit_n; j = j + 1) begin
                unit_actidx_in_reg[j] <= unit_actidx_in[j];
                unit_weightidx_in_reg[j] <= unit_weightidx_in[j];
            end
        end
    end
*/
    always @(posedge clk or negedge reset_n) begin
        if(~reset_n) begin
            for (integer j = 0; j < unit_n; j = j + 1) begin
                out_act_idx[j] <= 0;
                out_weight_idx[j] <= 0;
            end
            cnt <= 0;
        end
        
        else if(unit_hold) begin
            for (integer j = 0; j < unit_n; j = j + 1) begin
                out_act_idx[j] <= out_act_idx[j];
                out_weight_idx[j] <= out_weight_idx[j];
            end
            cnt <= cnt;
        end
        
        else if(unit_clear) begin
            for (integer j = 0; j < unit_n; j = j + 1) begin
                out_act_idx[j] <= 0;
                out_weight_idx[j] <= 0;
            end
            cnt <= 0;
        end

        else begin
            for (integer i = 0; i < unit_n; i = i + 1) begin
                for (integer j = 0; j < unit_n; j = j + 1) begin
                    if(unit_actidx_in[i] == unit_weightidx_in[j]) begin
                        out_act_idx[cnt] <= i;
                        out_weight_idx[cnt] <= j;
                        cnt = cnt + 1;
                    end
                end
            end
        end
    end

endmodule