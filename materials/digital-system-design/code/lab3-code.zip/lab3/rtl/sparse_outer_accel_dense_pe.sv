`timescale 1ns/1ps

// Dense-weight / fixed-PE outer-product sparse matmul accelerator.
//
// Dataflow (per output column c):
//   acc[0..OUT_ROWS-1] = 0
//   for each activation nonzero (k, v) of column c (column-major CSR):
//       read dense weight column W[:,k]  (OUT_ROWS bytes, one wide BRAM word)
//       for row in 0..OUT_ROWS-1:  acc[row] += v * W[row][k]
//   emit acc[row] for all rows
//
// Each of the OUT_ROWS PEs owns its accumulator -> no crossbar, unlike the
// previous bitmap_parallel design whose 16-lane indexed read/modify/write of a
// 128-deep register file produced a huge mux network (70k LUT, timing fail).
// Two accumulator banks (ping-pong) overlap the emit of one column with the
// compute of the next.  Multipliers map to LUTs (use_dsp="no") so DSP < 3%.
module sparse_outer_accel_dense_pe #(
    parameter int OUT_ROWS = 128,
    parameter int OUT_COLS = 1024,
    parameter int K_SIZE   = 576,
    parameter int A_NNZ    = 262575,
    parameter int DATA_W   = 8,
    parameter int IDX_W    = 10,
    parameter int ACC_W    = 32,
    parameter int ADDR_W   = 19,
    parameter int ROW_W    = 8,
    parameter int COL_W    = 10
)(
    input  logic                       clk,
    input  logic                       reset_n,

    input  logic                       load_we,
    input  logic [3:0]                 load_mem,
    input  logic [ADDR_W-1:0]          load_addr,
    input  logic [OUT_ROWS*DATA_W-1:0] load_data,

    input  logic                       start,
    output logic                       busy,
    output logic                       done,

    output logic                       output_valid,
    output logic [ROW_W-1:0]           output_row,
    output logic [COL_W-1:0]           output_col,
    output logic signed [ACC_W-1:0]    output_data,
    output logic [63:0]                cycle_count
);

    // load_mem selectors
    localparam logic [3:0] MEM_WD     = 4'd0; // dense weight by k (wide word)
    localparam logic [3:0] MEM_A_VAL  = 4'd1; // activation values (8-bit)
    localparam logic [3:0] MEM_A_IDX  = 4'd2; // activation k indices
    localparam logic [3:0] MEM_A_PTR  = 4'd3; // per-column nnz pointer

    localparam int WD_W = OUT_ROWS * DATA_W; // 1024
    localparam logic [COL_W-1:0] OUT_COLS_LAST = OUT_COLS[COL_W-1:0] - 1'b1;
    localparam logic [ROW_W-1:0] OUT_ROWS_LAST = OUT_ROWS[ROW_W-1:0] - 1'b1;

    // ---------------------------------------------------------------------
    // Memories (1-cycle read latency block RAM)
    // ---------------------------------------------------------------------
    logic [ADDR_W-1:0] wd_rd_addr;
    logic [ADDR_W-1:0] aval_rd_addr;
    logic [ADDR_W-1:0] aidx_rd_addr;
    logic [ADDR_W-1:0] aptr_rd_addr;

    logic [WD_W-1:0]   wd_rd_data;
    logic [DATA_W-1:0] aval_rd_data;
    logic [IDX_W-1:0]  aidx_rd_data;
    logic [ADDR_W-1:0] aptr_rd_data;

    simple_dual_port_bram #(.DATA_W(WD_W),   .ADDR_W(ADDR_W), .DEPTH(K_SIZE)) u_wd (
        .clk(clk), .wr_en(load_we && (load_mem==MEM_WD)), .wr_addr(load_addr),
        .wr_data(load_data[WD_W-1:0]), .rd_en(1'b1), .rd_addr(wd_rd_addr), .rd_data(wd_rd_data));

    simple_dual_port_bram #(.DATA_W(DATA_W), .ADDR_W(ADDR_W), .DEPTH(A_NNZ)) u_aval (
        .clk(clk), .wr_en(load_we && (load_mem==MEM_A_VAL)), .wr_addr(load_addr),
        .wr_data(load_data[DATA_W-1:0]), .rd_en(1'b1), .rd_addr(aval_rd_addr), .rd_data(aval_rd_data));

    simple_dual_port_bram #(.DATA_W(IDX_W),  .ADDR_W(ADDR_W), .DEPTH(A_NNZ)) u_aidx (
        .clk(clk), .wr_en(load_we && (load_mem==MEM_A_IDX)), .wr_addr(load_addr),
        .wr_data(load_data[IDX_W-1:0]), .rd_en(1'b1), .rd_addr(aidx_rd_addr), .rd_data(aidx_rd_data));

    simple_dual_port_bram #(.DATA_W(ADDR_W), .ADDR_W(ADDR_W), .DEPTH(OUT_COLS+1)) u_aptr (
        .clk(clk), .wr_en(load_we && (load_mem==MEM_A_PTR)), .wr_addr(load_addr),
        .wr_data(load_data[ADDR_W-1:0]), .rd_en(1'b1), .rd_addr(aptr_rd_addr), .rd_data(aptr_rd_data));

    // ---------------------------------------------------------------------
    // Ping-pong accumulator banks: one accumulates while the other emits.
    // ---------------------------------------------------------------------
    (* ram_style = "registers" *) logic signed [ACC_W-1:0] acc0 [0:OUT_ROWS-1];
    (* ram_style = "registers" *) logic signed [ACC_W-1:0] acc1 [0:OUT_ROWS-1];

    typedef enum logic [3:0] {
        S_IDLE, S_INIT_CLEAR, S_PTR0, S_PTR1, S_PTR2, S_PTR3,
        S_RUN, S_COLDONE, S_DRAIN, S_DONE
    } state_t;
    state_t state;

    logic              cbank;         // compute bank select (0->acc0, 1->acc1)
    logic [COL_W-1:0]  col;
    logic [ADDR_W-1:0] a_pos;
    logic [ADDR_W-1:0] a_end;
    logic signed [DATA_W-1:0] a_val_r;
    logic [WD_W-1:0]   wd_word_r;

    // emit engine (drains the non-compute bank in parallel with compute)
    logic              emit_busy;
    logic [COL_W-1:0]  emit_col;
    logic [ROW_W-1:0]  emit_row;
    logic              emit_bank;     // which bank the emit engine reads

    // ---------------------------------------------------------------------
    // Pipeline valid / payload registers.  Each registered-address BRAM read
    // takes 2 cycles (addr register -> BRAM output register), and there are
    // two chained reads (a_idx -> wd), so the MAC fires 4 stages after issue.
    //   stage A (issue)  : drive a_pos into a_idx/a_val address registers
    //   stage B (+2 cyc) : a_idx/a_val ready -> drive wd address, latch v
    //   stage D (+2 cyc) : wd column ready  -> 128 parallel MACs
    // v_b is piped one extra cycle (v_c) to line up with the wd output.
    // ---------------------------------------------------------------------
    logic                     vA, vB, vC, vD;
    logic signed [DATA_W-1:0] v_b, v_c;
    logic [ROW_W-1:0]         clr_row;

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state        <= S_IDLE;
            busy         <= 1'b0;
            done         <= 1'b0;
            output_valid <= 1'b0;
            output_row   <= '0;
            output_col   <= '0;
            output_data  <= '0;
            cycle_count  <= 64'd0;
            col          <= '0;
            cbank        <= 1'b0;
            a_pos        <= '0;
            a_end        <= '0;
            v_b          <= '0;
            v_c          <= '0;
            vA <= 1'b0; vB <= 1'b0; vC <= 1'b0; vD <= 1'b0;
            emit_busy    <= 1'b0;
            emit_col     <= '0;
            emit_row     <= '0;
            emit_bank    <= 1'b0;
            clr_row      <= '0;
            wd_rd_addr   <= '0;
            aval_rd_addr <= '0;
            aidx_rd_addr <= '0;
            aptr_rd_addr <= '0;
        end else begin
            done         <= 1'b0;
            output_valid <= 1'b0;
            if (busy) cycle_count <= cycle_count + 64'd1;

            // ---------------- emit / clear engine (runs concurrently) -----
            if (emit_busy) begin
                output_valid <= 1'b1;
                output_row   <= emit_row;
                output_col   <= emit_col;
                output_data  <= emit_bank ? acc1[emit_row] : acc0[emit_row];
                // clear as we drain so the bank is ready for reuse
                if (emit_bank) acc1[emit_row] <= '0;
                else           acc0[emit_row] <= '0;
                if (emit_row == OUT_ROWS_LAST) emit_busy <= 1'b0;
                else                           emit_row  <= emit_row + 1'b1;
            end

            // ---------------- compute pipeline ----------------------------
            // stage D: MAC (v_c aligned with wd_rd_data)
            if (vD) begin
                for (int row = 0; row < OUT_ROWS; row++) begin
                    logic signed [DATA_W-1:0]       wv;
                    (* use_dsp = "no" *) logic signed [2*DATA_W-1:0] prod;
                    wv   = $signed(wd_rd_data[row*DATA_W +: DATA_W]);
                    prod = v_c * wv;
                    if (cbank) acc1[row] <= acc1[row] + prod;
                    else       acc0[row] <= acc0[row] + prod;
                end
            end
            // stage C: align value with weight output
            if (vC) v_c <= v_b;
            // stage B: idx/val ready -> set up weight read + latch value
            if (vB) begin
                wd_rd_addr <= {{(ADDR_W-IDX_W){1'b0}}, aidx_rd_data};
                v_b        <= $signed(aval_rd_data);
            end

            case (state)
                S_IDLE: begin
                    busy <= 1'b0;
                    vA <= 1'b0; vB <= 1'b0; vC <= 1'b0; vD <= 1'b0;
                    if (start) begin
                        busy        <= 1'b1;
                        cycle_count <= 64'd0;
                        col         <= '0;
                        cbank       <= 1'b0;
                        emit_busy   <= 1'b0;
                        clr_row     <= '0;
                        state       <= S_INIT_CLEAR;
                    end
                end

                S_INIT_CLEAR: begin
                    acc0[clr_row] <= '0;
                    acc1[clr_row] <= '0;
                    if (clr_row == OUT_ROWS_LAST) begin
                        state      <= S_PTR0;
                    end else begin
                        clr_row <= clr_row + 1'b1;
                    end
                end

                S_PTR0: begin
                    aptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col};
                    state        <= S_PTR1;
                end
                S_PTR1: begin
                    // a_ptr[col] in flight; request a_ptr[col+1]
                    aptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col} + 1'b1;
                    state        <= S_PTR2;
                end
                S_PTR2: begin
                    a_pos <= aptr_rd_data;   // a_ptr[col]
                    state <= S_PTR3;
                end
                S_PTR3: begin
                    a_end <= aptr_rd_data;   // a_ptr[col+1]
                    vA <= 1'b0; vB <= 1'b0; vC <= 1'b0; vD <= 1'b0;
                    state <= S_RUN;
                end

                S_RUN: begin
                    // shift the pipeline (A->B->C->D)
                    vB <= vA;
                    vC <= vB;
                    vD <= vC;
                    // issue stage A while column has work
                    if (a_pos < a_end) begin
                        aidx_rd_addr <= a_pos;
                        aval_rd_addr <= a_pos;
                        a_pos <= a_pos + 1'b1;
                        vA <= 1'b1;
                    end else begin
                        vA <= 1'b0;
                        // column fully issued and pipeline drained?
                        if (!vA && !vB && !vC && !vD) begin
                            state <= S_COLDONE;
                        end
                    end
                end

                S_COLDONE: begin
                    // hand the finished compute bank to the emit engine
                    if (!emit_busy) begin
                        emit_bank <= cbank;
                        emit_col  <= col;
                        emit_row  <= '0;
                        emit_busy <= 1'b1;
                        cbank     <= ~cbank;
                        if (col == OUT_COLS_LAST) begin
                            state <= S_DRAIN;
                        end else begin
                            col   <= col + 1'b1;
                            state <= S_PTR0;
                        end
                    end
                end

                S_DRAIN: begin
                    // wait for the final column's emit to finish
                    if (!emit_busy) state <= S_DONE;
                end

                S_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
