`timescale 1ns/1ps

module intersection_match_unit #(
    parameter int unit_n = 16,
    parameter int BW_act_idx = 10,
    parameter int BW_weight_idx = 10,
    parameter int BW_idx = 5
)(
    input  logic clk,
    input  logic reset_n,

    input  logic unit_clear,
    input  logic unit_hold,

    input  logic [BW_act_idx - 1 : 0]       unit_actidx_in[unit_n - 1 : 0],
    input  logic [BW_weight_idx - 1 : 0]    unit_weightidx_in[unit_n - 1 : 0],

    output logic [BW_idx - 1 : 0]           out_act_idx[unit_n - 1 : 0],
    output logic [BW_idx - 1 : 0]           out_weight_idx[unit_n - 1 : 0],
    output logic [BW_idx : 0]               cnt
);

    always_ff @(posedge clk or negedge reset_n) begin
        int unsigned next_cnt;

        if (!reset_n) begin
            for (int j = 0; j < unit_n; j++) begin
                out_act_idx[j] <= '0;
                out_weight_idx[j] <= '0;
            end
            cnt <= '0;
        end else if (unit_hold) begin
            cnt <= cnt;
            for (int j = 0; j < unit_n; j++) begin
                out_act_idx[j] <= out_act_idx[j];
                out_weight_idx[j] <= out_weight_idx[j];
            end
        end else if (unit_clear) begin
            for (int j = 0; j < unit_n; j++) begin
                out_act_idx[j] <= '0;
                out_weight_idx[j] <= '0;
            end
            cnt <= '0;
        end else begin
            next_cnt = 0;
            for (int j = 0; j < unit_n; j++) begin
                out_act_idx[j] <= '0;
                out_weight_idx[j] <= '0;
            end

            for (int a = 0; a < unit_n; a++) begin
                for (int w = 0; w < unit_n; w++) begin
                    if ((unit_actidx_in[a] == unit_weightidx_in[w]) &&
                        (next_cnt < unit_n)) begin
                        out_act_idx[next_cnt[BW_idx-1:0]] <= a[BW_idx-1:0];
                        out_weight_idx[next_cnt[BW_idx-1:0]] <= w[BW_idx-1:0];
                        next_cnt++;
                    end
                end
            end
            cnt <= next_cnt[BW_idx:0];
        end
    end

endmodule
