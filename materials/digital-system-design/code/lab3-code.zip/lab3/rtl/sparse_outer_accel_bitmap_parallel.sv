`timescale 1ns/1ps

module sparse_outer_accel_bitmap_parallel #(
    parameter int LANES = 16,
    parameter int OUT_ROWS = 128,
    parameter int OUT_COLS = 1024,
    parameter int A_NNZ = 262575,
    parameter int W_BLOCKS = 1552,
    parameter int K_SIZE = 576,
    parameter int MASK_WORDS = 18432,
    parameter int MASK_WORD_BITS = 32,
    parameter int DATA_W = 8,
    parameter int IDX_W = 10,
    parameter int ACC_W = 32,
    parameter int ADDR_W = 19,
    parameter int ROW_W = 8,
    parameter int COL_W = 10
)(
    input  logic                    clk,
    input  logic                    reset_n,

    input  logic                    load_we,
    input  logic [3:0]              load_mem,
    input  logic [ADDR_W-1:0]       load_addr,
    input  logic [LANES*DATA_W-1:0] load_data,

    input  logic                    start,
    output logic                    busy,
    output logic                    done,

    output logic                    output_valid,
    output logic [ROW_W-1:0]        output_row,
    output logic [COL_W-1:0]        output_col,
    output logic signed [ACC_W-1:0] output_data,
    output logic [63:0]             cycle_count
);

    localparam logic [3:0] MEM_A_VAL  = 4'd0;
    localparam logic [3:0] MEM_A_PTR  = 4'd1;
    localparam logic [3:0] MEM_A_MASK = 4'd2;
    localparam logic [3:0] MEM_WB_PTR = 4'd3;
    localparam logic [3:0] MEM_WB_VAL = 4'd4;
    localparam logic [3:0] MEM_WB_ROW = 4'd5;

    localparam int PACK_W = LANES * DATA_W;
    localparam int PACK_ROW_W = LANES * ROW_W;
    localparam int LANE_IDX_W = (LANES <= 1) ? 1 : $clog2(LANES);
    localparam int MASK_WORD_COUNT = (K_SIZE + MASK_WORD_BITS - 1) / MASK_WORD_BITS;
    localparam int MASK_WORD_IDX_W = (MASK_WORD_COUNT <= 1) ? 1 : $clog2(MASK_WORD_COUNT + 1);
    localparam int MASK_BIT_IDX_W = (MASK_WORD_BITS <= 1) ? 1 : $clog2(MASK_WORD_BITS + 1);
    localparam int MASK_BIT_SEL_W = (MASK_WORD_BITS <= 1) ? 1 : $clog2(MASK_WORD_BITS);
    localparam int MASK_ADDR_W = (MASK_WORDS <= 1) ? 1 : $clog2(MASK_WORDS);
    localparam logic [ROW_W-1:0] ROW_SENTINEL = {ROW_W{1'b1}};
    localparam logic [ROW_W-1:0] OUT_ROWS_LAST = OUT_ROWS[ROW_W-1:0] - 1'b1;
    localparam logic [COL_W-1:0] OUT_COLS_LAST = OUT_COLS[COL_W-1:0] - 1'b1;

    typedef enum logic [4:0] {
        S_IDLE,
        S_CLEAR_ADDR,
        S_CLEAR_WRITE,
        S_PTR_ADDR0,
        S_PTR_WAIT0,
        S_PTR_DATA0,
        S_PTR_WAIT1,
        S_PTR_DATA1,
        S_MASK_ADDR,
        S_MASK_WAIT,
        S_MASK_DATA,
        S_SCAN_MASK,
        S_A_ADDR,
        S_A_WAIT,
        S_A_DATA,
        S_WPTR_ADDR0,
        S_WPTR_WAIT0,
        S_WPTR_DATA0,
        S_WPTR_WAIT1,
        S_WPTR_DATA1,
        S_WB_ADDR,
        S_WB_WAIT,
        S_WB_DATA,
        S_UPDATE,
        S_NEXT_A,
        S_EMIT_ADDR,
        S_EMIT_DATA,
        S_DONE
    } state_t;

    state_t state;

    logic [COL_W-1:0] col;
    logic [ROW_W-1:0] clear_row;
    logic [ROW_W-1:0] emit_row;
    logic [ADDR_W-1:0] a_pos;
    logic [ADDR_W-1:0] a_end;
    logic [ADDR_W-1:0] wb_pos;
    logic [ADDR_W-1:0] wb_end;
    logic [IDX_W-1:0] a_k_idx;
    logic [MASK_WORD_IDX_W-1:0] mask_word_idx;
    logic [MASK_BIT_IDX_W-1:0] mask_bit_idx;
    logic [LANE_IDX_W-1:0] lane_idx;
    logic [MASK_WORD_BITS-1:0] mask_word;

    logic [ADDR_W-1:0] a_val_rd_addr;
    logic [ADDR_W-1:0] a_ptr_rd_addr;
    logic [ADDR_W-1:0] a_mask_rd_addr;
    logic [ADDR_W-1:0] wb_ptr_rd_addr;
    logic [ADDR_W-1:0] wb_val_rd_addr;
    logic [ADDR_W-1:0] wb_row_rd_addr;

    logic [DATA_W-1:0] a_val_rd_data;
    logic [ADDR_W-1:0] a_ptr_rd_data;
    logic [MASK_WORD_BITS-1:0] a_mask_rd_data;
    logic [ADDR_W-1:0] wb_ptr_rd_data;
    logic [PACK_W-1:0] wb_val_rd_data;
    logic [PACK_ROW_W-1:0] wb_row_rd_data;

    logic signed [DATA_W-1:0] a_value;
    logic [PACK_W-1:0] wb_value_word;
    logic [PACK_ROW_W-1:0] wb_row_word;

    logic signed [ACC_W-1:0] accum [0:OUT_ROWS-1];
    logic [ADDR_W-1:0] mask_linear_addr;
    logic [IDX_W-1:0] scan_k;
    logic mask_bit_set;
    logic [ROW_W-1:0] update_lane_row;
    logic signed [DATA_W-1:0] update_lane_weight;

    simple_dual_port_bram #(
        .DATA_W(DATA_W),
        .ADDR_W(ADDR_W),
        .DEPTH(A_NNZ)
    ) u_a_val_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_VAL)),
        .wr_addr(load_addr),
        .wr_data(load_data[DATA_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_val_rd_addr),
        .rd_data(a_val_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(ADDR_W),
        .ADDR_W(ADDR_W),
        .DEPTH(OUT_COLS + 1)
    ) u_a_ptr_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_PTR)),
        .wr_addr(load_addr),
        .wr_data(load_data[ADDR_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_ptr_rd_addr),
        .rd_data(a_ptr_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(MASK_WORD_BITS),
        .ADDR_W(ADDR_W),
        .DEPTH(MASK_WORDS)
    ) u_a_mask_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_MASK)),
        .wr_addr(load_addr),
        .wr_data(load_data[MASK_WORD_BITS-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_mask_rd_addr),
        .rd_data(a_mask_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(ADDR_W),
        .ADDR_W(ADDR_W),
        .DEPTH(K_SIZE + 1)
    ) u_wb_ptr_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_WB_PTR)),
        .wr_addr(load_addr),
        .wr_data(load_data[ADDR_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(wb_ptr_rd_addr),
        .rd_data(wb_ptr_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(PACK_W),
        .ADDR_W(ADDR_W),
        .DEPTH(W_BLOCKS)
    ) u_wb_val_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_WB_VAL)),
        .wr_addr(load_addr),
        .wr_data(load_data[PACK_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(wb_val_rd_addr),
        .rd_data(wb_val_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(PACK_ROW_W),
        .ADDR_W(ADDR_W),
        .DEPTH(W_BLOCKS)
    ) u_wb_row_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_WB_ROW)),
        .wr_addr(load_addr),
        .wr_data(load_data[PACK_ROW_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(wb_row_rd_addr),
        .rd_data(wb_row_rd_data)
    );

    always_comb begin
        mask_linear_addr = {{(ADDR_W-COL_W){1'b0}}, col} * MASK_WORD_COUNT
                         + {{(ADDR_W-MASK_WORD_IDX_W){1'b0}}, mask_word_idx};
        scan_k = {{(IDX_W-MASK_WORD_IDX_W){1'b0}}, mask_word_idx} * MASK_WORD_BITS
               + {{(IDX_W-MASK_BIT_IDX_W){1'b0}}, mask_bit_idx};
        if (mask_bit_idx < MASK_WORD_BITS) begin
            mask_bit_set = mask_word[mask_bit_idx[MASK_BIT_SEL_W-1:0]];
        end else begin
            mask_bit_set = 1'b0;
        end
    end

    always_comb begin
        update_lane_row = wb_row_word[lane_idx*ROW_W +: ROW_W];
        update_lane_weight = $signed(wb_value_word[lane_idx*DATA_W +: DATA_W]);
    end

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= S_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            output_valid <= 1'b0;
            output_row <= '0;
            output_col <= '0;
            output_data <= '0;
            cycle_count <= 64'd0;
            col <= '0;
            clear_row <= '0;
            emit_row <= '0;
            a_pos <= '0;
            a_end <= '0;
            wb_pos <= '0;
            wb_end <= '0;
            a_k_idx <= '0;
            mask_word_idx <= '0;
            mask_bit_idx <= '0;
            lane_idx <= '0;
            mask_word <= '0;
            a_val_rd_addr <= '0;
            a_ptr_rd_addr <= '0;
            a_mask_rd_addr <= '0;
            wb_ptr_rd_addr <= '0;
            wb_val_rd_addr <= '0;
            wb_row_rd_addr <= '0;
            a_value <= '0;
            wb_value_word <= '0;
            wb_row_word <= '0;
        end else begin
            done <= 1'b0;
            output_valid <= 1'b0;

            if (busy) begin
                cycle_count <= cycle_count + 64'd1;
            end

            case (state)
                S_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        cycle_count <= 64'd0;
                        col <= '0;
                        clear_row <= '0;
                        state <= S_CLEAR_WRITE;
                    end
                end

                S_CLEAR_ADDR: begin
                    clear_row <= '0;
                    state <= S_CLEAR_WRITE;
                end

                S_CLEAR_WRITE: begin
                    accum[clear_row] <= '0;
                    if (clear_row == OUT_ROWS_LAST) begin
                        state <= S_PTR_ADDR0;
                    end else begin
                        clear_row <= clear_row + 1'b1;
                    end
                end

                S_PTR_ADDR0: begin
                    a_ptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col};
                    state <= S_PTR_WAIT0;
                end

                S_PTR_WAIT0: begin
                    state <= S_PTR_DATA0;
                end

                S_PTR_DATA0: begin
                    a_pos <= a_ptr_rd_data;
                    a_ptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col} + 1'b1;
                    state <= S_PTR_WAIT1;
                end

                S_PTR_WAIT1: begin
                    state <= S_PTR_DATA1;
                end

                S_PTR_DATA1: begin
                    a_end <= a_ptr_rd_data;
                    mask_word_idx <= '0;
                    mask_bit_idx <= '0;
                    state <= S_MASK_ADDR;
                end

                S_MASK_ADDR: begin
                    if (a_pos >= a_end || mask_word_idx >= MASK_WORD_COUNT) begin
                        emit_row <= '0;
                        state <= S_EMIT_ADDR;
                    end else begin
                        a_mask_rd_addr <= mask_linear_addr;
                        state <= S_MASK_WAIT;
                    end
                end

                S_MASK_WAIT: begin
                    state <= S_MASK_DATA;
                end

                S_MASK_DATA: begin
                    mask_word <= a_mask_rd_data;
                    mask_bit_idx <= '0;
                    state <= S_SCAN_MASK;
                end

                S_SCAN_MASK: begin
                    if (mask_bit_idx >= MASK_WORD_BITS) begin
                        mask_word_idx <= mask_word_idx + 1'b1;
                        state <= S_MASK_ADDR;
                    end else if (mask_bit_set && (scan_k < K_SIZE)) begin
                        a_k_idx <= scan_k;
                        state <= S_A_ADDR;
                    end else begin
                        mask_bit_idx <= mask_bit_idx + 1'b1;
                    end
                end

                S_A_ADDR: begin
                    a_val_rd_addr <= a_pos;
                    state <= S_A_WAIT;
                end

                S_A_WAIT: begin
                    state <= S_A_DATA;
                end

                S_A_DATA: begin
                    a_value <= $signed(a_val_rd_data);
                    wb_ptr_rd_addr <= {{(ADDR_W-IDX_W){1'b0}}, a_k_idx};
                    state <= S_WPTR_WAIT0;
                end

                S_WPTR_WAIT0: begin
                    state <= S_WPTR_DATA0;
                end

                S_WPTR_DATA0: begin
                    wb_pos <= wb_ptr_rd_data;
                    wb_ptr_rd_addr <= {{(ADDR_W-IDX_W){1'b0}}, a_k_idx} + 1'b1;
                    state <= S_WPTR_WAIT1;
                end

                S_WPTR_WAIT1: begin
                    state <= S_WPTR_DATA1;
                end

                S_WPTR_DATA1: begin
                    wb_end <= wb_ptr_rd_data;
                    state <= S_WB_ADDR;
                end

                S_WB_ADDR: begin
                    if (wb_pos >= wb_end) begin
                        state <= S_NEXT_A;
                    end else begin
                        wb_val_rd_addr <= wb_pos;
                        wb_row_rd_addr <= wb_pos;
                        state <= S_WB_WAIT;
                    end
                end

                S_WB_WAIT: begin
                    state <= S_WB_DATA;
                end

                S_WB_DATA: begin
                    wb_value_word <= wb_val_rd_data;
                    wb_row_word <= wb_row_rd_data;
                    state <= S_UPDATE;
                end

                S_UPDATE: begin
                    for (int lane = 0; lane < LANES; lane++) begin
                        logic [ROW_W-1:0] lane_row;
                        logic signed [DATA_W-1:0] lane_weight;
                        lane_row = wb_row_word[lane*ROW_W +: ROW_W];
                        lane_weight = $signed(wb_value_word[lane*DATA_W +: DATA_W]);
                        if (lane_row != ROW_SENTINEL) begin
                            accum[lane_row] <= accum[lane_row] + $signed(a_value) * $signed(lane_weight);
                        end
                    end
                    wb_pos <= wb_pos + 1'b1;
                    state <= S_WB_ADDR;
                end

                S_NEXT_A: begin
                    a_pos <= a_pos + 1'b1;
                    mask_bit_idx <= mask_bit_idx + 1'b1;
                    state <= S_SCAN_MASK;
                end

                S_EMIT_ADDR: begin
                    state <= S_EMIT_DATA;
                end

                S_EMIT_DATA: begin
                    output_valid <= 1'b1;
                    output_row <= emit_row;
                    output_col <= col;
                    output_data <= accum[emit_row];
                    if (emit_row == OUT_ROWS_LAST) begin
                        if (col == OUT_COLS_LAST) begin
                            state <= S_DONE;
                        end else begin
                            col <= col + 1'b1;
                            state <= S_CLEAR_ADDR;
                        end
                    end else begin
                        emit_row <= emit_row + 1'b1;
                        state <= S_EMIT_ADDR;
                    end
                end

                S_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= S_IDLE;
                end

                default: begin
                    state <= S_IDLE;
                end
            endcase
        end
    end

endmodule
