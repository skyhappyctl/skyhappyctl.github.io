`timescale 1ns/1ps

module simple_dual_port_bram #(
    parameter int DATA_W = 8,
    parameter int ADDR_W = 10,
    parameter int DEPTH = 1024
)(
    input  logic                    clk,
    input  logic                    wr_en,
    input  logic [ADDR_W-1:0]       wr_addr,
    input  logic [DATA_W-1:0]       wr_data,
    input  logic                    rd_en,
    input  logic [ADDR_W-1:0]       rd_addr,
    output logic [DATA_W-1:0]       rd_data
);

    (* ram_style = "block" *) logic [DATA_W-1:0] mem [0:DEPTH-1];

    always_ff @(posedge clk) begin
        if (wr_en && (wr_addr < DEPTH)) begin
            mem[wr_addr] <= wr_data;
        end

        if (rd_en) begin
            if (rd_addr < DEPTH) begin
                rd_data <= mem[rd_addr];
            end else begin
                rd_data <= '0;
            end
        end
    end

endmodule
