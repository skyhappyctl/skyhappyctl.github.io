`timescale 1ns/1ps

module sparse_matmul_accel #(
    parameter int BLOCK_N = 16,
    parameter int OUT_ROWS = 128,
    parameter int OUT_COLS = 1024,
    parameter int W_NNZ = 20644,
    parameter int A_NNZ = 262575,
    parameter int DATA_W = 8,
    parameter int IDX_W = 10,
    parameter int ACC_W = 32,
    parameter int ADDR_W = 19,
    parameter int ROW_W = 8,
    parameter int COL_W = 10,
    parameter int CNT_W = 6
)(
    input  logic                    clk,
    input  logic                    reset_n,

    input  logic                    load_we,
    input  logic [2:0]              load_mem,
    input  logic [ADDR_W-1:0]       load_addr,
    input  logic [31:0]             load_data,

    input  logic                    start,
    output logic                    busy,
    output logic                    done,

    output logic                    output_valid,
    output logic [ROW_W-1:0]        output_row,
    output logic [COL_W-1:0]        output_col,
    output logic signed [ACC_W-1:0] output_data,
    output logic [63:0]             cycle_count
);

    localparam logic [2:0] MEM_W_VAL = 3'd0;
    localparam logic [2:0] MEM_W_IDX = 3'd1;
    localparam logic [2:0] MEM_W_PTR = 3'd2;
    localparam logic [2:0] MEM_A_VAL = 3'd3;
    localparam logic [2:0] MEM_A_IDX = 3'd4;
    localparam logic [2:0] MEM_A_PTR = 3'd5;

    localparam logic [IDX_W-1:0] IDX_SENTINEL = {IDX_W{1'b1}};
    localparam logic [ADDR_W-1:0] BLOCK_N_ADDR = BLOCK_N[ADDR_W-1:0];
    localparam logic [CNT_W-1:0] BLOCK_N_CNT = BLOCK_N[CNT_W-1:0];
    localparam logic [ROW_W-1:0] OUT_ROWS_LAST = OUT_ROWS[ROW_W-1:0] - 1'b1;
    localparam logic [COL_W-1:0] OUT_COLS_LAST = OUT_COLS[COL_W-1:0] - 1'b1;

    typedef enum logic [3:0] {
        S_IDLE,
        S_PTR_ADDR0,
        S_PTR_DATA0,
        S_PTR_DATA1,
        S_INIT_DOT,
        S_CHECK,
        S_LOAD_ADDR,
        S_LOAD_DATA,
        S_MATCH,
        S_ACCUM,
        S_ADVANCE,
        S_EMIT
    } state_t;

    state_t state;

    logic [ROW_W-1:0] row;
    logic [COL_W-1:0] col;

    logic [ADDR_W-1:0] w_ptr_rd_addr;
    logic [ADDR_W-1:0] a_ptr_rd_addr;
    logic [ADDR_W-1:0] w_val_rd_addr;
    logic [ADDR_W-1:0] w_idx_rd_addr;
    logic [ADDR_W-1:0] a_val_rd_addr;
    logic [ADDR_W-1:0] a_idx_rd_addr;

    logic [ADDR_W-1:0] w_ptr_rd_data;
    logic [ADDR_W-1:0] a_ptr_rd_data;
    logic [DATA_W-1:0] w_val_rd_data;
    logic [IDX_W-1:0]  w_idx_rd_data;
    logic [DATA_W-1:0] a_val_rd_data;
    logic [IDX_W-1:0]  a_idx_rd_data;

    logic [ADDR_W-1:0] w_start;
    logic [ADDR_W-1:0] w_end;
    logic [ADDR_W-1:0] a_start;
    logic [ADDR_W-1:0] a_end;
    logic [ADDR_W-1:0] w_pos;
    logic [ADDR_W-1:0] a_pos;

    logic [CNT_W-1:0] w_blk_count;
    logic [CNT_W-1:0] a_blk_count;
    logic [CNT_W-1:0] load_i;
    logic [CNT_W-1:0] match_i;

    logic signed [ACC_W-1:0] acc;

    logic signed [DATA_W-1:0] w_val_buf [0:BLOCK_N-1];
    logic signed [DATA_W-1:0] a_val_buf [0:BLOCK_N-1];
    logic [IDX_W-1:0]         w_idx_buf [0:BLOCK_N-1];
    logic [IDX_W-1:0]         a_idx_buf [0:BLOCK_N-1];

    logic [IDX_W-1:0] w_last_idx;
    logic [IDX_W-1:0] a_last_idx;

    logic [IDX_W-1:0] match_act_in [0:BLOCK_N-1];
    logic [IDX_W-1:0] match_weight_in [0:BLOCK_N-1];
    logic [CNT_W-2:0] match_act_idx [0:BLOCK_N-1];
    logic [CNT_W-2:0] match_weight_idx [0:BLOCK_N-1];
    logic [CNT_W-1:0] match_cnt;

    logic match_clear;
    logic match_hold;

    assign match_clear = !((state == S_MATCH) || (state == S_ACCUM) || (state == S_ADVANCE));
    assign match_hold = (state == S_ACCUM) || (state == S_ADVANCE);

    always_comb begin
        for (int i = 0; i < BLOCK_N; i++) begin
            match_act_in[i] = a_idx_buf[i];
            match_weight_in[i] = w_idx_buf[i];
        end
    end

    always_comb begin
        w_last_idx = IDX_SENTINEL;
        a_last_idx = IDX_SENTINEL;
        if (w_blk_count != '0) begin
            w_last_idx = w_idx_buf[w_blk_count - 1'b1];
        end
        if (a_blk_count != '0) begin
            a_last_idx = a_idx_buf[a_blk_count - 1'b1];
        end
    end

    simple_dual_port_bram #(
        .DATA_W(DATA_W),
        .ADDR_W(ADDR_W),
        .DEPTH(W_NNZ)
    ) u_w_val_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_W_VAL)),
        .wr_addr(load_addr),
        .wr_data(load_data[DATA_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(w_val_rd_addr),
        .rd_data(w_val_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(IDX_W),
        .ADDR_W(ADDR_W),
        .DEPTH(W_NNZ)
    ) u_w_idx_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_W_IDX)),
        .wr_addr(load_addr),
        .wr_data(load_data[IDX_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(w_idx_rd_addr),
        .rd_data(w_idx_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(ADDR_W),
        .ADDR_W(ADDR_W),
        .DEPTH(OUT_ROWS + 1)
    ) u_w_ptr_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_W_PTR)),
        .wr_addr(load_addr),
        .wr_data(load_data[ADDR_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(w_ptr_rd_addr),
        .rd_data(w_ptr_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(DATA_W),
        .ADDR_W(ADDR_W),
        .DEPTH(A_NNZ)
    ) u_a_val_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_VAL)),
        .wr_addr(load_addr),
        .wr_data(load_data[DATA_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_val_rd_addr),
        .rd_data(a_val_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(IDX_W),
        .ADDR_W(ADDR_W),
        .DEPTH(A_NNZ)
    ) u_a_idx_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_IDX)),
        .wr_addr(load_addr),
        .wr_data(load_data[IDX_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_idx_rd_addr),
        .rd_data(a_idx_rd_data)
    );

    simple_dual_port_bram #(
        .DATA_W(ADDR_W),
        .ADDR_W(ADDR_W),
        .DEPTH(OUT_COLS + 1)
    ) u_a_ptr_bram (
        .clk(clk),
        .wr_en(load_we && (load_mem == MEM_A_PTR)),
        .wr_addr(load_addr),
        .wr_data(load_data[ADDR_W-1:0]),
        .rd_en(1'b1),
        .rd_addr(a_ptr_rd_addr),
        .rd_data(a_ptr_rd_data)
    );

    intersection_match_unit #(
        .unit_n(BLOCK_N),
        .BW_act_idx(IDX_W),
        .BW_weight_idx(IDX_W),
        .BW_idx(CNT_W - 1)
    ) u_intersection (
        .clk(clk),
        .reset_n(reset_n),
        .unit_clear(match_clear),
        .unit_hold(match_hold),
        .unit_actidx_in(match_act_in),
        .unit_weightidx_in(match_weight_in),
        .out_act_idx(match_act_idx),
        .out_weight_idx(match_weight_idx),
        .cnt(match_cnt)
    );

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= S_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            output_valid <= 1'b0;
            output_row <= '0;
            output_col <= '0;
            output_data <= '0;
            cycle_count <= 64'd0;
            row <= '0;
            col <= '0;
            w_ptr_rd_addr <= '0;
            a_ptr_rd_addr <= '0;
            w_val_rd_addr <= '0;
            w_idx_rd_addr <= '0;
            a_val_rd_addr <= '0;
            a_idx_rd_addr <= '0;
            w_start <= '0;
            w_end <= '0;
            a_start <= '0;
            a_end <= '0;
            w_pos <= '0;
            a_pos <= '0;
            w_blk_count <= '0;
            a_blk_count <= '0;
            load_i <= '0;
            match_i <= '0;
            acc <= '0;
            for (int i = 0; i < BLOCK_N; i++) begin
                w_val_buf[i] <= '0;
                a_val_buf[i] <= '0;
                w_idx_buf[i] <= IDX_SENTINEL;
                a_idx_buf[i] <= IDX_SENTINEL;
            end
        end else begin
            done <= 1'b0;
            output_valid <= 1'b0;

            if (busy) begin
                cycle_count <= cycle_count + 64'd1;
            end

            case (state)
                S_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        cycle_count <= 64'd0;
                        row <= '0;
                        col <= '0;
                        state <= S_PTR_ADDR0;
                    end
                end

                S_PTR_ADDR0: begin
                    w_ptr_rd_addr <= {{(ADDR_W-ROW_W){1'b0}}, row};
                    a_ptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col};
                    state <= S_PTR_DATA0;
                end

                S_PTR_DATA0: begin
                    w_start <= w_ptr_rd_data;
                    a_start <= a_ptr_rd_data;
                    w_ptr_rd_addr <= {{(ADDR_W-ROW_W){1'b0}}, row} + 1'b1;
                    a_ptr_rd_addr <= {{(ADDR_W-COL_W){1'b0}}, col} + 1'b1;
                    state <= S_PTR_DATA1;
                end

                S_PTR_DATA1: begin
                    w_end <= w_ptr_rd_data;
                    a_end <= a_ptr_rd_data;
                    state <= S_INIT_DOT;
                end

                S_INIT_DOT: begin
                    acc <= '0;
                    w_pos <= w_start;
                    a_pos <= a_start;
                    state <= S_CHECK;
                end

                S_CHECK: begin
                    if ((w_pos >= w_end) || (a_pos >= a_end)) begin
                        state <= S_EMIT;
                    end else begin
                        if ((w_end - w_pos) > BLOCK_N_ADDR) begin
                            w_blk_count <= BLOCK_N_CNT;
                        end else begin
                            w_blk_count <= (w_end - w_pos)[CNT_W-1:0];
                        end

                        if ((a_end - a_pos) > BLOCK_N_ADDR) begin
                            a_blk_count <= BLOCK_N_CNT;
                        end else begin
                            a_blk_count <= (a_end - a_pos)[CNT_W-1:0];
                        end

                        load_i <= '0;
                        state <= S_LOAD_ADDR;
                    end
                end

                S_LOAD_ADDR: begin
                    if (load_i < w_blk_count) begin
                        w_val_rd_addr <= w_pos + {{(ADDR_W-CNT_W){1'b0}}, load_i};
                        w_idx_rd_addr <= w_pos + {{(ADDR_W-CNT_W){1'b0}}, load_i};
                    end else begin
                        w_val_rd_addr <= '0;
                        w_idx_rd_addr <= '0;
                    end

                    if (load_i < a_blk_count) begin
                        a_val_rd_addr <= a_pos + {{(ADDR_W-CNT_W){1'b0}}, load_i};
                        a_idx_rd_addr <= a_pos + {{(ADDR_W-CNT_W){1'b0}}, load_i};
                    end else begin
                        a_val_rd_addr <= '0;
                        a_idx_rd_addr <= '0;
                    end
                    state <= S_LOAD_DATA;
                end

                S_LOAD_DATA: begin
                    if (load_i < w_blk_count) begin
                        w_val_buf[load_i] <= $signed(w_val_rd_data);
                        w_idx_buf[load_i] <= w_idx_rd_data;
                    end else begin
                        w_val_buf[load_i] <= '0;
                        w_idx_buf[load_i] <= IDX_SENTINEL;
                    end

                    if (load_i < a_blk_count) begin
                        a_val_buf[load_i] <= $signed(a_val_rd_data);
                        a_idx_buf[load_i] <= a_idx_rd_data;
                    end else begin
                        a_val_buf[load_i] <= '0;
                        a_idx_buf[load_i] <= IDX_SENTINEL;
                    end

                    if (load_i == (BLOCK_N - 1)) begin
                        state <= S_MATCH;
                    end else begin
                        load_i <= load_i + 1'b1;
                        state <= S_LOAD_ADDR;
                    end
                end

                S_MATCH: begin
                    match_i <= '0;
                    state <= S_ACCUM;
                end

                S_ACCUM: begin
                    if (match_cnt == '0) begin
                        state <= S_ADVANCE;
                    end else if (match_i < match_cnt) begin
                        acc <= acc +
                            ($signed(w_val_buf[match_weight_idx[match_i]]) *
                             $signed(a_val_buf[match_act_idx[match_i]]));
                        if ((match_i + 1'b1) >= match_cnt) begin
                            state <= S_ADVANCE;
                        end else begin
                            match_i <= match_i + 1'b1;
                        end
                    end else begin
                        state <= S_ADVANCE;
                    end
                end

                S_ADVANCE: begin
                    if (w_last_idx <= a_last_idx) begin
                        w_pos <= w_pos + {{(ADDR_W-CNT_W){1'b0}}, w_blk_count};
                    end
                    if (a_last_idx <= w_last_idx) begin
                        a_pos <= a_pos + {{(ADDR_W-CNT_W){1'b0}}, a_blk_count};
                    end
                    state <= S_CHECK;
                end

                S_EMIT: begin
                    output_valid <= 1'b1;
                    output_row <= row;
                    output_col <= col;
                    output_data <= acc;

                    if ((row == OUT_ROWS_LAST) &&
                        (col == OUT_COLS_LAST)) begin
                        busy <= 1'b0;
                        done <= 1'b1;
                        state <= S_IDLE;
                    end else begin
                        if (col == OUT_COLS_LAST) begin
                            col <= '0;
                            row <= row + 1'b1;
                        end else begin
                            col <= col + 1'b1;
                        end
                        state <= S_PTR_ADDR0;
                    end
                end

                default: begin
                    state <= S_IDLE;
                end
            endcase
        end
    end

endmodule
