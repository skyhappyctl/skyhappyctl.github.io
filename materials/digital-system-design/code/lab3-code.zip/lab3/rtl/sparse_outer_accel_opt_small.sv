`timescale 1ns/1ps

module sparse_outer_accel_opt_small (
    input  logic clk,
    input  logic reset_n,

    input  logic         load_we,
    input  logic [3:0]   load_mem,
    input  logic [18:0]  load_addr,
    input  logic [127:0] load_data,

    input  logic start,
    output logic busy,
    output logic done,

    output logic               output_valid,
    output logic [7:0]         output_row,
    output logic [9:0]         output_col,
    output logic signed [31:0] output_data,
    output logic [63:0]        cycle_count
);

    sparse_outer_accel_opt #(
        .LANES(16),
        .OUT_ROWS(128),
        .OUT_COLS(16),
        .A_NNZ(4096),
        .W_BLOCKS(512),
        .K_SIZE(576),
        .DATA_W(8),
        .IDX_W(10),
        .ACC_W(32),
        .ADDR_W(19),
        .ROW_W(8),
        .COL_W(10)
    ) u_accel (
        .clk(clk),
        .reset_n(reset_n),
        .load_we(load_we),
        .load_mem(load_mem),
        .load_addr(load_addr),
        .load_data(load_data),
        .start(start),
        .busy(busy),
        .done(done),
        .output_valid(output_valid),
        .output_row(output_row),
        .output_col(output_col),
        .output_data(output_data),
        .cycle_count(cycle_count)
    );

endmodule
