`ifndef LAB3_SPARSE_CONFIG_SVH
`define LAB3_SPARSE_CONFIG_SVH

localparam int LAB3_OUT_ROWS = 128;
localparam int LAB3_OUT_COLS = 1024;
localparam int LAB3_K_SIZE = 576;
localparam int LAB3_W_NNZ = 20644;
localparam int LAB3_A_NNZ = 262575;
localparam int LAB3_WEIGHT_LANES = 16;
localparam int LAB3_W_BLOCKS16 = 1552;
localparam int LAB3_A_MASK_WORDS = 18432;
localparam int LAB3_A_MASK_WORD_BITS = 32;
localparam int LAB3_A_PAIRS = 131538;
localparam int LAB3_DATA_W = 8;
localparam int LAB3_IDX_W = 10;
localparam int LAB3_ROW_W = 8;
localparam int LAB3_ACC_W = 32;
localparam int LAB3_ADDR_W = 19;

`endif
