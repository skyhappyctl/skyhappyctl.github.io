module async_fifo_tb;
    // Parameters
    parameter WR_CLK_PERIOD = 10; // 100MHz
    parameter RD_CLK_PERIOD = 20; // 50MHz
    parameter DEPTH = 16;
    
    // Signals
    reg wr_clk;
    reg rd_clk;
    reg rst_n;
    reg wr_en;
    reg rd_en;
    reg [15:0] data_in;
    wire [15:0] data_out;
    wire full;
    wire empty;
    wire almost_full;
    wire almost_empty;
    
    // Test variables
    reg [15:0] expected_data;
    integer error_count;
    integer test_case;
    integer i;
    
    // Instantiate DUT
    async_fifo dut (
        .wr_clk(wr_clk),
        .rd_clk(rd_clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .rd_en(rd_en),
        .data_in(data_in),
        .data_out(data_out),
        .full(full),
        .empty(empty),
        .almost_full(almost_full),
        .almost_empty(almost_empty)
    );
    
    // Clock generation
    always #(WR_CLK_PERIOD/2) wr_clk = ~wr_clk;
    always #(RD_CLK_PERIOD/2) rd_clk = ~rd_clk;
    
    // Waveform dumping
    initial begin
        $dumpfile("Out/wave.vcd");
        $dumpvars(0, async_fifo_tb);
    end
    
    // Test tasks
    task write_data(input [15:0] data);
        begin
            data_in = data;
            wr_en = 1;
            @(negedge wr_clk); // Ensure wr_en setup time
            @(posedge wr_clk);
            wr_en = 0;
        end
    endtask
    
    task read_data(output [15:0] data);
        begin
            rd_en = 1;
            @(posedge rd_clk);
            rd_en = 0;
            data = data_out;
        end
    endtask
    
    task reset_fifo;
        begin
            rst_n = 0;
            wr_en = 0;
            rd_en = 0;
            data_in = 0;
            @(posedge wr_clk);
            @(posedge rd_clk);
            @(posedge wr_clk);
            @(posedge rd_clk);
            rst_n = 1;
            @(posedge wr_clk);
            @(posedge rd_clk);
        end
    endtask
    
    task check_result(input actual, input expected, input string test_name);
        begin
            if (actual !== expected) begin
                $display("ERROR: %s - Expected: %b, Got: %b", test_name, expected, actual);
                error_count = error_count + 1;
            end
        end
    endtask
    
    task check_data_result(input [15:0] actual, input [15:0] expected, input string test_name);
        begin
            if (actual !== expected) begin
                $display("ERROR: %s - Expected: %h, Got: %h", test_name, expected, actual);
                error_count = error_count + 1;
            end
        end
    endtask
    
    // Main test sequence
    initial begin
        // Initialize
        wr_clk = 0;
        rd_clk = 0;
        error_count = 0;
        test_case = 0;
        
        $display("### SimulationResult");
        $display("'''markdown");
        
        // Test 1: Reset behavior
        test_case = 1;
        $display("Test %0d: Reset Behavior", test_case);
        reset_fifo();
        check_data_result(data_out, 16'h0, "Reset data_out");
        check_result(empty, 1'b1, "Reset empty flag");
        check_result(full, 1'b0, "Reset full flag");
        check_result(almost_empty, 1'b1, "Reset almost_empty flag");
        check_result(almost_full, 1'b0, "Reset almost_full flag");
        if (error_count == 0) begin
            $display("Test %0d: Reset Behavior - PASSED", test_case);
        end
        
        // Test 2: Basic write and read operations
        test_case = 2;
        $display("Test %0d: Basic Write and Read Operations", test_case);
        reset_fifo();
        
        // Write 4 data items
        write_data(16'h1234);
        write_data(16'hABCD);
        write_data(16'h5678);
        write_data(16'hEF01);
        
        // Add sufficient delay for synchronization (more cycles for async FIFO)
        repeat(8) @(posedge rd_clk);
        
        // Read them back
        read_data(expected_data);
        check_data_result(expected_data, 16'h1234, "First read");
        read_data(expected_data);
        check_data_result(expected_data, 16'hABCD, "Second read");
        read_data(expected_data);
        check_data_result(expected_data, 16'h5678, "Third read");
        read_data(expected_data);
        check_data_result(expected_data, 16'hEF01, "Fourth read");
        if (error_count == 0) begin
            $display("Test %0d: Basic Write and Read Operations - PASSED", test_case);
        end
        
        // Test 3: Asynchronous clock test
        test_case = 3;
        $display("Test %0d: Asynchronous Clock Test", test_case);
        reset_fifo();
        
        fork
            begin
                for (i = 0; i < 8; i = i + 1) begin
                    write_data(16'h1000 + i);
                end
            end
            begin
                // Add more delay to ensure first data is written and synchronized
                repeat(10) @(posedge rd_clk);
                for (i = 0; i < 8; i = i + 1) begin
                    read_data(expected_data);
                    check_data_result(expected_data, 16'h1000 + i, "Async read");
                end
            end
        join
        if (error_count == 0) begin
            $display("Test %0d: Asynchronous Clock Test - PASSED", test_case);
        end
        
        // Test 4: FIFO full condition
        test_case = 4;
        $display("Test %0d: FIFO Full Condition", test_case);
        reset_fifo();
        
        // Fill the FIFO
        for (i = 0; i < DEPTH; i = i + 1) begin
            write_data(16'h2000 + i);
            if (i == DEPTH-1) begin
                check_result(full, 1'b1, "FIFO should be full");
                check_result(almost_full, 1'b1, "FIFO should be almost full");
            end
        end
        
        // Try to write when full (should be ignored)
        data_in = 16'hBAD0;
        wr_en = 1;
        @(negedge wr_clk);
        @(posedge wr_clk);
        wr_en = 0;
        @(posedge wr_clk);
        check_result(full, 1'b1, "FIFO should remain full");
        if (error_count == 0) begin
            $display("Test %0d: FIFO Full Condition - PASSED", test_case);
        end
        
        // Test 5: FIFO empty condition
        test_case = 5;
        $display("Test %0d: FIFO Empty Condition", test_case);
        reset_fifo();
        
        // Fill the FIFO first
        for (i = 0; i < DEPTH; i = i + 1) begin
            write_data(16'h2000 + i);
        end
        
        // Add delay for synchronization
        repeat(8) @(posedge rd_clk);
        
        // Empty the FIFO
        for (i = 0; i < DEPTH; i = i + 1) begin
            read_data(expected_data);
            check_data_result(expected_data, 16'h2000 + i, "Emptying read");
            if (i == DEPTH-1) begin
                check_result(empty, 1'b1, "FIFO should be empty");
                check_result(almost_empty, 1'b1, "FIFO should be almost empty");
            end
        end
        
        // Try to read when empty
        rd_en = 1;
        @(posedge rd_clk);
        rd_en = 0;
        @(posedge rd_clk);
        check_result(empty, 1'b1, "FIFO should remain empty");
        if (error_count == 0) begin
            $display("Test %0d: FIFO Empty Condition - PASSED", test_case);
        end
        
        // Test 6: Almost-full/almost-empty threshold test
        test_case = 6;
        $display("Test %0d: Almost-Full/Almost-Empty Threshold Test", test_case);
        reset_fifo();
        
        // Write until almost full threshold (14)
        for (i = 0; i < 13; i = i + 1) begin
            write_data(16'h3000 + i);
        end
        check_result(almost_full, 1'b0, "Should not be almost full yet");
        write_data(16'h3000 + 13);
        check_result(almost_full, 1'b1, "Should be almost full at 14 entries");
        check_result(full, 1'b0, "Should not be full yet");
        
        // Add delay for synchronization
        repeat(8) @(posedge rd_clk);
        
        // Read until almost empty threshold (2)
        for (i = 0; i < 12; i = i + 1) begin
            read_data(expected_data);
            check_data_result(expected_data, 16'h3000 + i, "Threshold read");
        end
        // After reading 12 from 14, we have 2 left - should be almost empty
        check_result(almost_empty, 1'b1, "Should be almost empty at 2 entries");
        check_result(empty, 1'b0, "Should not be empty yet");
        
        read_data(expected_data);
        check_result(almost_empty, 1'b1, "Should still be almost empty at 1 entry");
        check_result(empty, 1'b0, "Should not be empty yet");
        
        if (error_count == 0) begin
            $display("Test %0d: Almost-Full/Almost-Empty Threshold Test - PASSED", test_case);
        end
        
        // Test 7: Concurrent read-write test
        test_case = 7;
        $display("Test %0d: Concurrent Read-Write Test", test_case);
        reset_fifo();
        
        fork
            begin
                for (i = 0; i < 10; i = i + 1) begin
                    write_data(16'h4000 + i);
                end
            end
            begin
                // Add more delay to ensure first data is written and synchronized
                repeat(12) @(posedge rd_clk);
                for (i = 0; i < 10; i = i + 1) begin
                    read_data(expected_data);
                    check_data_result(expected_data, 16'h4000 + i, "Concurrent read");
                end
            end
        join
        if (error_count == 0) begin
            $display("Test %0d: Concurrent Read-Write Test - PASSED", test_case);
        end
        
        // Test 8: Edge case test
        test_case = 8;
        $display("Test %0d: Edge Case Test", test_case);
        reset_fifo();
        
        // Write 15 entries (one before full)
        for (i = 0; i < 15; i = i + 1) begin
            write_data(16'h5000 + i);
        end
        check_result(full, 1'b0, "Should not be full at 15 entries");
        check_result(almost_full, 1'b1, "Should be almost full at 15 entries");
        
        // Write 16th entry (full)
        write_data(16'h5000 + 15);
        check_result(full, 1'b1, "Should be full at 16 entries");
        
        // Add delay for synchronization
        repeat(8) @(posedge rd_clk);
        
        // Read 14 entries - should have 2 left (almost empty)
        for (i = 0; i < 14; i = i + 1) begin
            read_data(expected_data);
            check_data_result(expected_data, 16'h5000 + i, "Edge case read");
        end
        check_result(almost_empty, 1'b1, "Should be almost empty at 2 entries");
        
        // Read 1 more entry - should have 1 left (still almost empty)
        read_data(expected_data);
        check_result(almost_empty, 1'b1, "Should still be almost empty at 1 entry");
        
        // Read last entry - should be empty
        read_data(expected_data);
        check_result(empty, 1'b1, "Should be empty after reading all");
        check_result(almost_empty, 1'b1, "Should be almost empty at 0 entries");
        
        if (error_count == 0) begin
            $display("Test %0d: Edge Case Test - PASSED", test_case);
        end
        
        // Final result
        if (error_count == 0) begin
            $display("TestSuccessed: All tests passed!");
        end else begin
            $display("TestFailed: %0d errors found", error_count);
        end
        
        $display("'''");
        $finish;
    end

endmodule