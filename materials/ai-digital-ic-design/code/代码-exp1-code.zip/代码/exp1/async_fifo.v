module async_fifo (
    input wire wr_clk,
    input wire rd_clk,
    input wire rst_n,
    input wire wr_en,
    input wire rd_en,
    input wire [15:0] data_in,
    output reg [15:0] data_out,
    output wire full,
    output wire empty,
    output wire almost_full,
    output wire almost_empty
);

    // Parameters
    parameter DEPTH = 16;
    parameter WIDTH = 16;
    parameter ALMOST_FULL_THRESHOLD = 14;
    parameter ALMOST_EMPTY_THRESHOLD = 2;
    
    // Internal memory
    reg [WIDTH-1:0] memory [0:DEPTH-1];
    
    // Pointers (5 bits for depth 16)
    reg [4:0] wr_ptr_bin;
    reg [4:0] rd_ptr_bin;
    wire [4:0] wr_ptr_gray;
    wire [4:0] rd_ptr_gray;
    
    // Synchronized pointers
    reg [4:0] wr_ptr_gray_sync1, wr_ptr_gray_sync2;
    reg [4:0] rd_ptr_gray_sync1, rd_ptr_gray_sync2;
    
    // Binary synchronized pointers
    reg [4:0] wr_ptr_bin_sync;
    reg [4:0] rd_ptr_bin_sync;
    
    // FIFO counts
    reg [4:0] fifo_count_wr_domain;
    reg [4:0] fifo_count_rd_domain;
    
    // Convert binary to Gray code
    assign wr_ptr_gray = wr_ptr_bin ^ (wr_ptr_bin >> 1);
    assign rd_ptr_gray = rd_ptr_bin ^ (rd_ptr_bin >> 1);
    
    // Convert Gray code to binary
    function [4:0] gray2bin;
        input [4:0] gray;
        begin
            gray2bin[4] = gray[4];
            gray2bin[3] = gray[4] ^ gray[3];
            gray2bin[2] = gray[4] ^ gray[3] ^ gray[2];
            gray2bin[1] = gray[4] ^ gray[3] ^ gray[2] ^ gray[1];
            gray2bin[0] = gray[4] ^ gray[3] ^ gray[2] ^ gray[1] ^ gray[0];
        end
    endfunction
    
    // Write pointer synchronization (to read clock domain)
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr_gray_sync1 <= 0;
            wr_ptr_gray_sync2 <= 0;
            wr_ptr_bin_sync <= 0;
        end else begin
            wr_ptr_gray_sync1 <= wr_ptr_gray;
            wr_ptr_gray_sync2 <= wr_ptr_gray_sync1;
            wr_ptr_bin_sync <= gray2bin(wr_ptr_gray_sync2);
        end
    end
    
    // Read pointer synchronization (to write clock domain)
    always @(posedge wr_clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr_gray_sync1 <= 0;
            rd_ptr_gray_sync2 <= 0;
            rd_ptr_bin_sync <= 0;
        end else begin
            rd_ptr_gray_sync1 <= rd_ptr_gray;
            rd_ptr_gray_sync2 <= rd_ptr_gray_sync1;
            rd_ptr_bin_sync <= gray2bin(rd_ptr_gray_sync2);
        end
    end
    
    // Calculate FIFO count in write domain
    always @(*) begin
        if (wr_ptr_bin[4] == rd_ptr_bin_sync[4]) begin
            fifo_count_wr_domain = wr_ptr_bin[3:0] - rd_ptr_bin_sync[3:0];
        end else begin
            fifo_count_wr_domain = DEPTH - rd_ptr_bin_sync[3:0] + wr_ptr_bin[3:0];
        end
    end
    
    // Calculate FIFO count in read domain
    always @(*) begin
        if (wr_ptr_bin_sync[4] == rd_ptr_bin[4]) begin
            fifo_count_rd_domain = wr_ptr_bin_sync[3:0] - rd_ptr_bin[3:0];
        end else begin
            fifo_count_rd_domain = DEPTH - rd_ptr_bin[3:0] + wr_ptr_bin_sync[3:0];
        end
    end
    
    // Generate flags
    assign full = (fifo_count_wr_domain == DEPTH);
    assign empty = (fifo_count_rd_domain == 0);
    assign almost_full = (fifo_count_wr_domain >= ALMOST_FULL_THRESHOLD);
    assign almost_empty = (fifo_count_rd_domain <= ALMOST_EMPTY_THRESHOLD);
    
    // Write control logic
    always @(posedge wr_clk or negedge rst_n) begin
        integer i;
        if (!rst_n) begin
            wr_ptr_bin <= 0;
        end else begin
            if (wr_en && !full) begin
                memory[wr_ptr_bin[3:0]] <= data_in;
                wr_ptr_bin <= wr_ptr_bin + 1;
            end
        end
    end
    
    // Read control logic
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr_bin <= 0;
            data_out <= 0;
        end else begin
            if (rd_en && !empty) begin
                data_out <= memory[rd_ptr_bin[3:0]];
                rd_ptr_bin <= rd_ptr_bin + 1;
            end
        end
    end
    
    // Initialize memory (for simulation only)
    integer init_i;
    initial begin
        for (init_i = 0; init_i < DEPTH; init_i = init_i + 1) begin
            memory[init_i] = 0;
        end
    end

endmodule