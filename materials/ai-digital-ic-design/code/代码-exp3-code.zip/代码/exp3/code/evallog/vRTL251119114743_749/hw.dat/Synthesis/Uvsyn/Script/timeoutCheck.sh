#!/bin/bash
function timeoutCheck {
    timeout=$1
    finishlog=$2
    timeoutlog=$3
    pid=$4
    while [ $timeout -gt 0 ]
    do
        if [ -f $2 ]
        then
            exit
        else
            sleep 5
            let timeout=timeout-5
        fi
    done
    touch $timeoutlog
    touch $finishlog
    pstree -l -p $pid | awk 'BEGIN{ FS="(" ; RS=")" } NF>1 { print $NF }' |xargs kill -15 &> /dev/null
}
timeoutCheck $1 $2 $3 $4

