#!/bin/env python3

from multiprocessing import Process, Pool, Queue, Value, Manager
from collections import defaultdict
import threading, signal
import sys, os, time, stat, re, socket
import argparse
pwd = os.getcwd()
# global tasks
tasks = []
# global process variables
currentProcessCount = Value('i', 0)
processDict = {}
remainingTasks = []
maxProcesses = 41
firstRunTasks = []
secondRunTasks = []
parallelCheckInterval = 10
poolLog = open('hw.dat/Synthesis/Uvsyn/Log/Pool/process_pool_.log', 'w')

class TaskMgr:
    tasks = defaultdict(list)
    pwd = os.getcwd()
    @classmethod
    def register_task(cls, task):
        cls.tasks[task.fpga].append(task)
        for t in [t for t in cls.tasks[task.fpga] if t.pre_task]:
            pre_task = [x for x in cls.tasks[task.fpga] if x.task_name == t.pre_task]
            if pre_task:
                for _t in pre_task:
                    _t.post_tasks.add(t)
    @classmethod
    def get_task(cls, fpga, task_name):
        return [t for t in cls.tasks[fpga] if t.task_name == task_name]

class TaskRun:
    def __init__(self, run_dir, run_cmd, priority, job_log, submit_log, fpga, task_name, pre_task):
        self.run_dir = run_dir
        self.run_cmd = run_cmd
        self.priority = priority
        self.job_log = job_log
        self.submit_log = submit_log
        self.fpga = fpga
        self.task_name = task_name
        self.pre_task = pre_task
        self.post_tasks = set()
        self.register_task()
        self.job_id = None
    def register_task(self):
        TaskMgr.register_task(self)
    def no_fpga(self):
        return len(self.fpga) == 0
    def get_sibling_tasks(self):
        return [t for t in TaskMgr.tasks[self.fpga] if (self.task_name != t.task_name)]
    def get_pre_tasks(self):
        return TaskMgr.get_task(self.fpga, self.pre_task)
    def get_post_tasks(self):
        return self.post_tasks
    def is_done(self):
        return os.path.exists(os.path.join(TaskMgr.pwd, self.run_dir, "." + self.task_name + ".done"))
    def is_skip(self):
        return os.path.exists(os.path.join(TaskMgr.pwd, self.run_dir, "." + self.task_name + ".skip"))
    def is_timing_clean(self):
        return os.path.exists(os.path.join(TaskMgr.pwd, self.run_dir, "." + self.task_name + ".timingclean"))

taskPrioritLog = 'hw.dat/Synthesis/Uvsyn/Log/Pool/.tasksPriority.log'

def getCost(task):
    return -task.priority

def dumpRemainingTasks(remainingTasks):
    currentTimestamp = time.strftime('[%Y-%m-%d %H:%M:%S] ', time.localtime())
    with open(os.path.join(pwd, taskPrioritLog), 'a') as resortedTasksLog:
        resortedTasksLog.write(currentTimestamp + '\n')
        if (len(remainingTasks) > 0):
            for task in remainingTasks:
                resortedTasksLog.write(task.run_dir + ', ' + task.run_cmd + ', ')
                resortedTasksLog.write(str(task.priority) + ', ' + task.job_log + ', ')
                resortedTasksLog.write(task.submit_log + ', ' + task.fpga + ', ')
                resortedTasksLog.write(task.task_name + ', ' + task.pre_task + ', ')
                resortedTasksLog.write('\n')
                resortedTasksLog.flush()
        else:
            resortedTasksLog.write('Task list is empty\n')
        resortedTasksLog.write('\n')
        resortedTasksLog.flush()

def sortTasks(remainingTasks):
    remainingTasks = sorted(remainingTasks, key=getCost)
    dumpRemainingTasks(remainingTasks)
    return remainingTasks

# fpga like b0.f0
def increasePriority(remainingTasks, fpga):
    if (len(remainingTasks) > 0 and len(fpga) > 0):
        for task in remainingTasks:
            if (task.fpga == fpga):
                task.priority = task.priority + 10
    return remainingTasks

def resortTasks(remainingTasks, fpga):
    remainingTasks = increasePriority(remainingTasks, fpga)
    remainingTasks = sortTasks(remainingTasks)
    return remainingTasks

def removeTask(task, remainingTasks):
    # task cost could be changed
    for remainingTask in remainingTasks[:]:
        if (task.run_dir == remainingTask.run_dir):
            remainingTasks.remove(remainingTask)
            break
    # dumpRemainingTasks(remainingTasks)
    return remainingTasks

def generateRunScript(task):
    taskDir = os.path.join(pwd, task.run_dir)
    finishFilePath = os.path.join(taskDir, '.uv_dp_job_finish')
    if (os.path.exists(finishFilePath)):
        os.remove(finishFilePath)
    submitFilePath = os.path.join(taskDir, task.submit_log)
    if (os.path.exists(submitFilePath)):
        os.remove(submitFilePath)
    runFilePath = os.path.join(taskDir, 'run.sh')
    scriptFile = open(runFilePath, 'w')
    scriptFile.write('#!/bin/bash\n')
    scriptFile.write(task.run_cmd)
    scriptFile.write('\ndmesg -T | grep -C 10 -iE "uv_shell|vivado" | grep -C 10 "UID $(id -u)" > uv_dp_job_dmesg.log || true\n')
    scriptFile.write('\ntouch .uv_dp_job_finish\n')
    scriptFile.close()
    os.chmod(runFilePath, stat.S_IRWXU|stat.S_IRGRP|stat.S_IROTH)

def getAvailableTaskDirs(task):
    availableTaskDirs = []
    parentDir = os.path.dirname(task.run_dir)
    for availableTask in tasks:
        availableTaskParentDir = os.path.dirname(availableTask.run_dir)
        if (parentDir == availableTaskParentDir):
            availableTaskDirs.append(os.path.basename(availableTask.run_dir))
    return availableTaskDirs

# return value: 0: invalid input, 1: not any task is done, 2: the current task is done, 3: the other task is done 
def checkAnyTaskisDone(task):
    if task.no_fpga():
        return 0
    if task.is_done():
        return 2
    for t in task.get_sibling_tasks():
        if t.is_done():
            return 3
    return 1

# return value: false: invalid input, false: no task need skip, true: current task need skip 
def checkCurrentTaskisSkip(task):
    if task.no_fpga():
        return False
    return task.is_skip()

# return value: 0: invalid input, 1: no .timingclean, 2: the current task is timingclean, 3: the other task is timing clean 
def checkAnyTaskisTimingClean(task):
    if task.no_fpga():
        return 0
    if task.is_timing_clean():
        return 2
    for t in task.get_sibling_tasks():
        if t.is_timing_clean():
            return 3
    return 1

def checkTaskNeedKill(task):
    if task.no_fpga():
        return False
    # check whether there is any .xxx.pythonkill
    killFilePath = os.path.join(pwd, task.run_dir, '.' + task.task_name + '.pythonkill')
    exploreFilePath = os.path.join(pwd, task.run_dir, '.' + task.task_name + '.explore')
    if (os.path.exists(killFilePath) or os.path.exists(exploreFilePath) or (checkAnyTaskisTimingClean(task) == 3)):
        return True
    return False

# Return value: False: no need to kill this task, True: need to kill this task
def checkTaskStatus(task):
    if task.no_fpga():
        return False
    return (checkAnyTaskisDone(task) == 3) or checkTaskNeedKill(task)

def touchTasksFinish(tasks):
    # iterater all the tasks to check the .xxx.finish
    for task in tasks:
        runDir = os.path.join(pwd, task.run_dir)
        taskDir = os.path.basename(runDir)
        finishFilePath = os.path.join(runDir, '.' + taskDir + '.finish')
        if (not os.path.exists(finishFilePath)):
            os.system('touch '+ finishFilePath)

# The task should be the first task for specified fpga
# return value: 0: invalid input, 1: the first task is done or timingclean or precompilefail , no need to submit,
# 2: the first task is failed, .explore touched, need to submit, 3: the first task is not finished, waiting for next check
# jobId is not used for local run
def checkNeedtoStart2ndRunTasks(task, jobId):
    if task.no_fpga():
        return 0
    # check whether there is any .xxx.done
    doneFilePath = os.path.join(pwd, task.run_dir, '.' + task.task_name + '.done')
    timingcleanFilePath = os.path.join(pwd, task.run_dir, '.' + task.task_name + '.timingclean')
    precompilefailPilePath = os.path.join(pwd, task.run_dir, '.'+ task.task_name + '.precompilefail')
    if (os.path.exists(doneFilePath) or os.path.exists(timingcleanFilePath) or os.path.exists(precompilefailPilePath)):
        return 1
    exploreFilePath = os.path.join(pwd, task.run_dir, '.' + task.task_name + '.explore')
    if (os.path.exists(exploreFilePath)):
        # ONLY kill the first run task
        if (killTask_Localhost(task, jobId)):
            return 2
    # The 1st task is not finished, waiting for next check
    return 3

# The task should be the second run task for specified fpga
# return value: 0: invalid input, 1: the first task is done or timingclean or precompilefail , no need to submit,
# 2: the first task is failed, .explore touched, need to submit, 3: the first task is not finished, waiting for next check
# jobId is not used for local run
def getFirstRunTaskStatus(secondRunTask):
    if ((not secondRunTask) or len(secondRunTask.fpga) == 0):
        return 0
    for firstRunTask in firstRunTasks:
        if (firstRunTask.fpga == secondRunTask.fpga and (secondRunTask.pre_task == firstRunTask.task_name or secondRunTask.pre_task == 'explore')):
            jobId = ''
            return checkNeedtoStart2ndRunTasks(firstRunTask, jobId)
    return 0

# fullTaskName: like b0.f0.Task_stragety_0
def writeSubmittedTask(taskId, fullTaskName, taskLog, host = 'localhost'):
    with open(os.path.join(pwd, 'hw.dat/Synthesis/Uvsyn/Log/Pool/submitted_tasks.log'), 'a') as submittedTaskLog:
        currentTimestamp = time.strftime('[%Y-%m-%d %H:%M:%S] ', time.localtime()) 
        submittedTaskLog.write(currentTimestamp + '    ' + fullTaskName + '    '+ str(taskId) + '    ' + taskLog + '    ' + host + '\n')
        submittedTaskLog.flush()

def removeLocalProcess(currentProcess):
    global processDict
    global remainingTasks
    global secondRunTasks
    if (not currentProcess.is_alive()):
        if (currentProcess in list(processDict.keys())):
            runningTask = processDict[currentProcess]
            if (len(runningTask.fpga) > 0 and len(secondRunTasks) > 0):
                remainingTasks = resortTasks(remainingTasks, runningTask.fpga)
            del processDict[currentProcess]
            currentProcessCount.value = currentProcessCount.value - 1

# jobId is not used for local run
def killTask_Localhost(task, jobId):
    for currentProcess in list(processDict.keys()):
        # Check the process is alive or not, if yes, kill it
        # task cost could be changed
        if (task.run_dir == processDict[currentProcess].run_dir):
            if (currentProcess.is_alive()):
                os.system('pstree -l -p ' + str(currentProcess.pid) + ' | awk \'BEGIN{ FS="(" ; RS=")" } NF>1 { print $NF }\' |xargs kill -15 &> /dev/null')
                # touch .killed file to rundir
                os.system('touch '+task.run_dir+'/'+task.job_log[:-3]+'killed')
            removeLocalProcess(currentProcess)
            break
    return True

def killAllTasks_Localhost():
    for currentProcess in list(processDict.keys()):
        killTask_Localhost(processDict[currentProcess], '')
    return True

def submitTask_Localhost(task):
    global remainingTasks
    while (maxProcesses > 0 and currentProcessCount.value >= maxProcesses):
        # waiting process done
        time.sleep(parallelCheckInterval)
        for currentProcess in list(processDict.keys()):
            # Check the process is alive or not, if not, remove it first
            runningTask = processDict[currentProcess]
            if (not currentProcess.is_alive()):
                removeLocalProcess(currentProcess)
        # replace task with the first task in resorted tasks list
        if (len(remainingTasks) > 0 and remainingTasks[0].priority > task.priority):
            task = remainingTasks[0]
    # Start new processs
    currentProcess = Process(target=runTask_Localhost, args=(task,))
    currentProcessCount.value = currentProcessCount.value + 1
    processDict[currentProcess] = task
    currentProcess.start()
    return ['localhost', str(currentProcess.pid), task]

def runTask_Localhost(task):
    rundir = task.run_dir
    localtimestamp = time.localtime()
    currentTimestamp = time.strftime('[%Y-%m-%d %H:%M:%S] ', localtimestamp) 
    print(time.strftime('[%Y-%m-%d %H:%M:%S] ', localtimestamp) + 'INFO: Task %s is submitted with pid: %s' % (rundir, os.getpid()))
    fullTaskName = task.task_name
    if (len(task.fpga) > 0):
        fullTaskName = task.fpga + '.' + task.task_name
    writeSubmittedTask(os.getpid(), fullTaskName, task.run_dir + '/' + task.job_log, 'localhost')
    os.chdir(pwd)
    os.chdir(rundir)
    generateRunScript(task)
    submitlog = open(os.path.join(pwd, task.run_dir, task.submit_log), 'w')
    submitlog.write(str(int(time.mktime(localtimestamp))) + '\n' + currentTimestamp)
    submitlog.close()
    start = time.time()
    os.system('./run.sh')
    os.chdir(pwd)
    end = time.time()
    costTime = end - start
    printLog((rundir, costTime))
    print(time.strftime('[%Y-%m-%d %H:%M:%S] ', time.localtime()) + 'INFO: Task %s runs %0.2f seconds' % (rundir, costTime))

def printLog(results):
    poolLog.write('Task %s runs %0.2f seconds.' % (results[0], results[1]))
    poolLog.write('\n')
    poolLog.flush()

def checkTaskDone_Localhost():
    localhostTasksDone = False
    if (len(processDict) > 0):
        for currentProcess in list(processDict.keys()):
            # Check the process is alive or not, if not, remove it first
            task = processDict[currentProcess]
            if (not currentProcess.is_alive()):
                removeLocalProcess(currentProcess)
            elif (checkTaskStatus(task)):
                # This fpga is already done or need to kill, kill the process
                killTask_Localhost(task, '')
    if (len(processDict) == 0):
        localhostTasksDone = True
    return localhostTasksDone

def submitAllTasks_Localhost():
    for task in tasks:
        if (task.pre_task):
            secondRunTasks.append(task)
        else:
            firstRunTasks.append(task)

    # Submit the first run tasks
    global remainingTasks
    remainingTasks = sortTasks(firstRunTasks[:])
    while (len(remainingTasks) > 0):
        task = remainingTasks[0]
        # First to check whether this task need to submit or not
        if (checkAnyTaskisDone(task) == 2):
            # this task is done in last run, do nothing
            removeTask(task, remainingTasks)
            continue
        if (checkCurrentTaskisSkip(task)):
            # if ask the task skip, do nothing
            removeTask(task, remainingTasks)
            continue
        if ((checkAnyTaskisDone(task) == 3) or (checkAnyTaskisTimingClean(task) == 3)):
            removeTask(task, remainingTasks)
            # one task is done or timing clean, no need to submit
            killedLogPath = os.path.join(pwd, task.run_dir, task.job_log[:-3]+'killed')
            skipLogPath = os.path.join(pwd, task.run_dir, task.job_log[:-3]+'skip')
            if (os.path.exists(killedLogPath) or os.path.exists(skipLogPath)):
                continue
            # touch .skip for this task if no .killed or .skip
            os.system('touch '+ os.path.join(pwd, task.run_dir, task.job_log[:-3]+'skip'))
            continue
        [host, jobId, task] = submitTask_Localhost(task)
        removeTask(task, remainingTasks)

    # Start to handle the second run tasks
    # Check the first run task result then to start the 2nd run task
    remainingTasks = sortTasks(secondRunTasks[:])
    while (len(remainingTasks) > 0):
        time.sleep(parallelCheckInterval)
        for firstRunTask in firstRunTasks:
            checkStatus = checkNeedtoStart2ndRunTasks(firstRunTask, '')
            if (checkStatus == 0):
                # invalid input, continue
                continue
            elif (checkStatus == 1): 
                # the first task is done or timing clean, touch .skip to ignore 2nd run tasks
                for secondRunTask in secondRunTasks[:]:
                    if (secondRunTask.fpga == firstRunTask.fpga and (secondRunTask.pre_task == firstRunTask.task_name or secondRunTask.pre_task == 'explore')):
                        skipFilePath = os.path.join(pwd, secondRunTask.run_dir, secondRunTask.job_log[:-3]+'skip')
                        if (not os.path.exists(skipFilePath)):
                            os.system('touch '+ skipFilePath)
                        removeTask(secondRunTask, remainingTasks)
            elif (checkStatus == 2):
                # the first is failed, .explore touched, ready to submit 2nd run tasks in order
                if (len(remainingTasks) > 0):
                    secondRunTask = getFirstResortedTask()
                    if (getFirstRunTaskStatus(secondRunTask) != 2):
                        # not ready to submit
                        continue
                    # check there is any second run task is done or timingclean first
                    taskisDone = checkAnyTaskisDone(secondRunTask)
                    taskisTimingClean = checkAnyTaskisTimingClean(secondRunTask)
                    if (taskisDone == 2 or taskisDone == 3 or taskisTimingClean == 2 or taskisTimingClean == 3):
                        # no need to submit
                        for remainTask in remainingTasks[:]:
                            if (secondRunTask.fpga == remainTask.fpga and (secondRunTask.pre_task == remainTask.pre_task or secondRunTask.pre_task == 'explore')):
                                skipFilePath = os.path.join(pwd, remainTask.run_dir, remainTask.job_log[:-3]+'skip')
                                if (not os.path.exists(skipFilePath)):
                                    os.system('touch '+ skipFilePath)
                                removeTask(remainTask, remainingTasks)
                    else:
                        [host, jobId, secondRunTask] = submitTask_Localhost(secondRunTask)
                        if (host == 'farm' and len(jobId) == 0):
                            return False
                        removeTask(secondRunTask, remainingTasks)
            elif (checkStatus == 3):
                # the first task is not finished, waiting for next check
                continue

def getFirstResortedTask():
    global remainingTasks
    global processDict
    if (maxProcesses > 0):
        for currentProcess in list(processDict.keys()):
            # Check the process is alive or not, if not, remove it first
            runningTask = processDict[currentProcess]
            # If any task is done or has .exlore/.pythonkill, need to kill this task first
            if checkTaskStatus(runningTask):
                killTask_Localhost(runningTask, '')
            if (not currentProcess.is_alive()):
                removeLocalProcess(currentProcess)
    return remainingTasks[0]

def waitTasksDone():
    while (not checkTaskDone_Localhost()):
        time.sleep(parallelCheckInterval)

if __name__=='__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-fpga',type=str,nargs='*',default=[])
    args = parser.parse_args()
    fpgaList = args.fpga
    # print(fpgaList)

    if(os.path.isfile('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool__kill.py')):
        os.remove('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool__kill.py')

    killpy = open('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool__kill.py', "w")
    killpy.write('#!/bin/env python3\n')
    killpy.write('import os\n')
    killpy.write('os.system(\'pstree -l -p %s | awk \\\'BEGIN{ FS="(" ; RS=")" } NF>1 { print $NF }\\\' |xargs kill -15 &> /dev/null\')\n' % os.getpid())
    killpy.close()
    os.chmod('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool__kill.py', stat.S_IRWXU|stat.S_IRGRP|stat.S_IROTH)

    if(os.path.isfile('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool_.finish.log')):
        os.remove('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool_.finish.log')

    tasks = [
              TaskRun('hw.dat/Synthesis/Uvsyn/Rundir/uvsyn_worker_0', 'make -ki all > .parallel_tasks.log 2>&1', 0, '.uvsyn_worker_0.log', '.uvsyn_worker_0.submit', '', 'uvsyn_worker_0', ''),
              TaskRun('hw.dat/Synthesis/Uvsyn/Rundir/uvsyn_worker_1', 'make -ki all > .parallel_tasks.log 2>&1', 0, '.uvsyn_worker_1.log', '.uvsyn_worker_1.submit', '', 'uvsyn_worker_1', ''),
            ]

    # Only run tasks for specified fpgas, if it is empty, run all
    if (len(fpgaList) > 0):
        for task in tasks[:]:
            if (task.fpga not in fpgaList):
                tasks.remove(task)

    poolStart = time.time()
    currentProcessCount = Value('i', 0)

    # submit all tasks
    submitAllTasks_Localhost()

    # Check all tasks status
    waitTasksDone()

    # all jobs are done, if the jobs are killed, then no .xxx.finish in the rundir
    # need to touch it to avoid dead loop
    touchTasksFinish(tasks)

    msg = 'All processes finished.'
    print(msg)
    poolLog.write(msg+'\n')
    poolLog.flush()

    poolEnd = time.time()
    msg = 'Pool runs %0.2f seconds.' % (poolEnd - poolStart)
    print(msg)
    poolLog.write(msg+'\n')
    poolLog.flush()

    poolLog.close()
    finishlog = open('hw.dat/Synthesis/Uvsyn/Script/Pool/.process_pool_.finish.log', 'w')
    finishlog.close()
