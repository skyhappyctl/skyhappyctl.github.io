import os, fcntl, time, socket, struct, json, subprocess

class ModRequester:
    def __init__(self):
        self.sock = None
        self.pack_head_len = 4
        self.req_code = b''

    def init(self, files_dir):
        print('************* INIT_REQUESTER *************', flush=True)
        waiting_time = 20
        socket_info_ready = os.path.join(files_dir, 'socket_info.ready')
        socket_info_file = os.path.join(files_dir, 'socket_info.json')
        while os.path.exists(socket_info_ready) == False:
            if waiting_time <= 0:
                print(f'ModRequester initialize Failed : Socket info ready flag {socket_info_ready} waiting timeout.', flush=True)
                return False
            else:
                print(f'Waiting for socket info ready flag {socket_info_ready}.', flush=True)
                waiting_time -= 1
                time.sleep(1)
        with open(socket_info_file, 'r') as f:
            socket_info = json.load(f)
        for addr in socket_info['server_addr']:
            ip = addr['ip']
            flow_info = addr['flowInfo']
            scope_id = addr['scopeId']
            isIpv6 = addr['isIpv6']
            port = addr['port']
            try:
                self.sock = socket.socket(socket.AF_INET6 if isIpv6 else socket.AF_INET, socket.SOCK_STREAM)
                self.sock.settimeout(5)
                # connect
                print(f"Try connect to dispatch server: [{ip}|{flow_info}|{scope_id}]:{port}", flush=True)
                self.sock.connect((ip, port, flow_info, scope_id) if isIpv6 else (ip, port))
                peerName = self.sock.getpeername()
                localName = self.sock.getsockname()
                print('Successfully connect to dispatch server : ', peerName, flush = True)
                print('The local address is  : ', localName, flush = True)
                # send confirm info
                confirm_str = socket_info['confirm_str']
                confirm_message = struct.pack('>I', len(confirm_str)) + confirm_str.encode('utf-8')
                self.sock.sendall(confirm_message)
                # get request code from server
                response = self.sock.recv(self.pack_head_len)
                if not response:
                    raise Exception("No response. Connection closed by server.")
                req_code_size = struct.unpack('>I', response)[0]
                response = self.sock.recv(req_code_size)
                if not response:
                    raise Exception("No response. Connection closed by server.")
                req_code_str = response.decode('utf-8')
                self.req_code = struct.pack('>I', len(req_code_str) + 1) + b'\x02' + response
                break
            except Exception as e:
                print(f"Can not connect to mod dispatch server, reason : {e}, exit!", flush=True)
                self.sock.close()
                self.sock = None
        print('******************************************', flush=True)
        return (self.req_code != b'')

    def get_next(self):
        mod_name = '/invalid_mod'
        if self.sock is None:
            return mod_name # return invalid name.
        try:
            self.sock.sendall(self.req_code)
            response = self.sock.recv(self.pack_head_len)
            if not response:
                raise Exception("No response. Connection closed by server.")
            mod_name_size = struct.unpack('>I', response)[0]
            response = self.sock.recv(mod_name_size)
            if not response:
                raise Exception("No response. Connection closed by server.")
            mod_name = response.decode('utf-8')
            self.sock.sendall(struct.pack('>I', 1) + b'\x03')
        except Exception as e:
            print(f"Can not get next module from mod dispatch server, server : {e}, exit!", flush=True)
            self.sock.close()
            self.sock = None
            mod_name = '/invalid_mod'
        return mod_name

    def report_back(self, mod, result):
        if self.sock is None:
            return False
        ret_code = b'\x01' if result == 0 else b'\x00'
        success_code = struct.pack('>I', len(curr_mod) + 2) + b'\x01' + ret_code + mod.encode('utf-8')
        try:
            self.sock.sendall(success_code)
        except Exception as e:
            print(f"Can not send back module result to server, reason : {e}, exit!", flush=True)
            self.sock.close()
            self.sock = None
            return False
        return True

# common vars
work_dir = os.path.abspath('.')
worker_name = os.path.basename(work_dir)
parallel_run_dir = os.path.join(work_dir, '..')
worker_status = True

# create job.list
job_list_file = os.path.join(work_dir, 'job.list')
with open(job_list_file, 'w') as f:
    pass

# define time & counters
total_block_time = 0.0 # how much time is cost to get module to synth
total_synth_time = 0.0 # how much time is cost to synth modules
total_pproc_time = 0.0 # how much time is cost to post process
total_counter = 0

retry_times = 5
while retry_times > 0:
    # build & init mod requester
    mod_requester = ModRequester()
    retry_times -= 1
    init_success = mod_requester.init(parallel_run_dir)
    if not init_success:
        print(f'Failed to initialize mod requester, will retry for {retry_times} times.', flush=True)
        time.sleep(5)
        continue
    print(f'Successfully initialize mod requester.', flush=True)
    retry_times = 5

    # main synth loop
    while 1:
        os.chdir(work_dir)
        # Get next module to process.
        pre_time = time.time()
        curr_mod = mod_requester.get_next()
        post_block_time = time.time()
        if curr_mod == '/invalid_mod':
            break
        block_time = post_block_time - pre_time
        process_msg = f'=========== Process module : [{curr_mod}] ==========='
        print(process_msg, flush=True)
        print(f'- Scheduling this module spends {block_time * 1000:.2f}ms', flush=True)

        module_dir = os.path.join(parallel_run_dir, curr_mod)
        os.chdir(module_dir)

        # do synth of module
        exit_code = -1
        with open('./make.log', 'w') as logf:
            exit_code = subprocess.run(['make', 'all', f'WORKER={worker_name}'], stdout=logf, stderr=subprocess.STDOUT).returncode
        post_synth_time = time.time()
        synth_time = post_synth_time - post_block_time
        print(f'- Synthesis for {synth_time:.2f}s', flush=True)

        # export module name and time to job.list
        export_result_cmd = f'echo "{curr_mod} {synth_time}" >> {job_list_file}'
        os.system(export_result_cmd)
        post_update_job_list_time = time.time()
        update_job_list_time = post_update_job_list_time - post_synth_time
        print(f'- Update job.list spends {update_job_list_time * 1000:.2f}ms', flush=True)

        # report back result
        mod_requester.report_back(curr_mod, exit_code) # do not care the result, since report back is unreliable
        post_time = time.time()
        report_back_time = post_time - post_update_job_list_time
        print(f'- Report back to server spends {report_back_time * 1000:.2f}ms', flush=True)
        print(f'- Runs from [{pre_time}] to [{post_time}], spends [{post_time - pre_time}]s', flush=True)
        print('=' * len(process_msg), flush=True)

        total_block_time += block_time
        total_synth_time += synth_time
        total_pproc_time += (post_update_job_list_time + report_back_time)
        total_counter += 1

    if mod_requester.sock is None:
        print(f'mod requester meet some error, retry connect.', flush=True)
        time.sleep(5)
        continue
    else:
        print(f'All modules synthnesized.', flush=True)
        break
os.chdir(work_dir)
if total_counter == 0:
    print('This worker does not synthesize any module.', flush=True)
else:
    print('==========================[Final Report]==========================', flush=True)
    print(f'==*== Synth Module Number   : {total_counter}', flush=True)
    print(f'==*== Total   Block time(s) : {total_block_time:.5f}', flush=True)
    print(f'==*== Average Block time(s) : {total_block_time / total_counter:.5f}', flush=True)
    print(f'==*== Total   Synth time(s) : {total_synth_time:.5f}', flush=True)
    print(f'==*== Average Synth time(s) : {total_synth_time / total_counter:.5f}', flush=True)
    print(f'==*== Block / Synth         : {(total_block_time / total_synth_time) * 100:.2f}%', flush=True)
exit(0)
