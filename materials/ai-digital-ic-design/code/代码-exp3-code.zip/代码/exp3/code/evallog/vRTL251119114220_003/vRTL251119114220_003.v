module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);

    // Internal registers for pipelining
    reg [15:0] computed_C;
    reg [15:0] A_reg, B_reg;
    reg Ready_reg;
    
    // Pipeline stage 1 registers
    reg sign_A_p1, sign_B_p1;
    reg [4:0] exp_A_p1, exp_B_p1;
    reg [9:0] mant_A_p1, mant_B_p1;
    reg is_nan_A_p1, is_inf_A_p1, is_zero_A_p1;
    reg is_nan_B_p1, is_inf_B_p1, is_zero_B_p1;
    
    // Pipeline stage 2 registers  
    reg sign_prod_p2;
    reg [21:0] product_sig_p2;
    reg [6:0] exp_prod_p2;
    reg special_case_p2;
    reg [2:0] special_result_p2;
    
    // Pipeline stage 3 registers
    reg [4:0] shift_amount_p3;
    reg [21:0] normalized_sig_p3;
    reg [6:0] exp_after_norm_p3;
    
    // Wire declarations
    wire sign_A = A[15];
    wire [4:0] exp_A = A[14:10];
    wire [9:0] mant_A = A[9:0];
    wire sign_B = B[15];
    wire [4:0] exp_B = B[14:10];
    wire [9:0] mant_B = B[9:0];
    wire is_nan_A = (exp_A == 5'b11111) && (mant_A != 10'b0);
    wire is_inf_A = (exp_A == 5'b11111) && (mant_A == 10'b0);
    wire is_zero_A = (exp_A == 5'b0) && (mant_A == 10'b0);
    wire is_nan_B = (exp_B == 5'b11111) && (mant_B != 10'b0);
    wire is_inf_B = (exp_B == 5'b11111) && (mant_B == 10'b0);
    wire is_zero_B = (exp_B == 5'b0) && (mant_B == 10'b0);
    
    // Pipeline stage 1: Input and special case detection
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            A_reg <= 16'b0;
            B_reg <= 16'b0;
            Ready_reg <= 1'b0;
            sign_A_p1 <= 1'b0;
            sign_B_p1 <= 1'b0;
            exp_A_p1 <= 5'b0;
            exp_B_p1 <= 5'b0;
            mant_A_p1 <= 10'b0;
            mant_B_p1 <= 10'b0;
            is_nan_A_p1 <= 1'b0;
            is_inf_A_p1 <= 1'b0;
            is_zero_A_p1 <= 1'b0;
            is_nan_B_p1 <= 1'b0;
            is_inf_B_p1 <= 1'b0;
            is_zero_B_p1 <= 1'b0;
        end else begin
            A_reg <= A;
            B_reg <= B;
            Ready_reg <= Ready;
            sign_A_p1 <= sign_A;
            sign_B_p1 <= sign_B;
            exp_A_p1 <= exp_A;
            exp_B_p1 <= exp_B;
            mant_A_p1 <= mant_A;
            mant_B_p1 <= mant_B;
            is_nan_A_p1 <= is_nan_A;
            is_inf_A_p1 <= is_inf_A;
            is_zero_A_p1 <= is_zero_A;
            is_nan_B_p1 <= is_nan_B;
            is_inf_B_p1 <= is_inf_B;
            is_zero_B_p1 <= is_zero_B;
        end
    end
    
    // Pipeline stage 2: Multiplication and exponent calculation
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sign_prod_p2 <= 1'b0;
            product_sig_p2 <= 22'b0;
            exp_prod_p2 <= 7'b0;
            special_case_p2 <= 1'b0;
            special_result_p2 <= 3'b0;
        end else if (Ready_reg) begin
            sign_prod_p2 <= sign_A_p1 ^ sign_B_p1;
            
            // Handle special cases
            if (is_nan_A_p1 || is_nan_B_p1) begin
                special_case_p2 <= 1'b1;
                special_result_p2 <= 3'b001; // NaN
            end else if ((is_inf_A_p1 && is_zero_B_p1) || (is_zero_A_p1 && is_inf_B_p1)) begin
                special_case_p2 <= 1'b1;
                special_result_p2 <= 3'b001; // NaN
            end else if (is_inf_A_p1 || is_inf_B_p1) begin
                special_case_p2 <= 1'b1;
                special_result_p2 <= 3'b010; // Infinity
            end else if (is_zero_A_p1 || is_zero_B_p1) begin
                special_case_p2 <= 1'b1;
                special_result_p2 <= 3'b011; // Zero
            end else begin
                special_case_p2 <= 1'b0;
                special_result_p2 <= 3'b000;
                
                // Calculate significands
                wire [10:0] sig_A = (exp_A_p1 == 5'b0) ? {1'b0, mant_A_p1} : {1'b1, mant_A_p1};
                wire [10:0] sig_B = (exp_B_p1 == 5'b0) ? {1'b0, mant_B_p1} : {1'b1, mant_B_p1};
                product_sig_p2 <= sig_A * sig_B;
                
                // Calculate exponent
                wire [5:0] exp_A_adj = (exp_A_p1 == 5'b0) ? 6'b100001 : {1'b0, exp_A_p1};
                wire [5:0] exp_B_adj = (exp_B_p1 == 5'b0) ? 6'b100001 : {1'b0, exp_B_p1};
                wire [6:0] exp_sum = exp_A_adj + exp_B_adj;
                exp_prod_p2 <= exp_sum - 7'b0011110;
            end
        end
    end
    
    // Pipeline stage 3: Normalization
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_amount_p3 <= 5'b0;
            normalized_sig_p3 <= 22'b0;
            exp_after_norm_p3 <= 7'b0;
        end else if (Ready_reg) begin
            if (special_case_p2) begin
                shift_amount_p3 <= 5'b0;
                normalized_sig_p3 <= 22'b0;
                exp_after_norm_p3 <= 7'b0;
            end else begin
                // Normalization logic
                if (product_sig_p2[21]) begin
                    shift_amount_p3 <= 5'b0;
                    normalized_sig_p3 <= product_sig_p2;
                end else if (product_sig_p2[20]) begin
                    shift_amount_p3 <= 5'b1;
                    normalized_sig_p3 <= product_sig_p2 << 1;
                end else if (product_sig_p2[19]) begin
                    shift_amount_p3 <= 5'b10;
                    normalized_sig_p3 <= product_sig_p2 << 2;
                end else if (product_sig_p2[18]) begin
                    shift_amount_p3 <= 5'b11;
                    normalized_sig_p3 <= product_sig_p2 << 3;
                end else begin
                    shift_amount_p3 <= 5'b0;
                    normalized_sig_p3 <= product_sig_p2;
                end
                
                exp_after_norm_p3 <= exp_prod_p2 - {2'b0, shift_amount_p3};
            end
        end
    end
    
    // Pipeline stage 4: Rounding and final result
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            computed_C <= 16'b0;
        end else if (Ready_reg) begin
            if (special_case_p2) begin
                case (special_result_p2)
                    3'b001: computed_C <= {1'b0, 5'b11111, 10'b1}; // NaN
                    3'b010: computed_C <= {sign_prod_p2, 5'b11111, 10'b0}; // Infinity
                    3'b011: computed_C <= {sign_prod_p2, 5'b0, 10'b0}; // Zero
                    default: computed_C <= 16'b0;
                endcase
            end else begin
                // Rounding logic
                wire [9:0] mant_part = normalized_sig_p3[20:11];
                wire G = normalized_sig_p3[10];
                wire R = normalized_sig_p3[9];
                wire S = |normalized_sig_p3[8:0];
                
                wire round_up;
                if (G && (R || S)) begin
                    round_up = 1'b1;
                end else if (G && !(R || S) && mant_part[0]) begin
                    round_up = 1'b1;
                end else begin
                    round_up = 1'b0;
                end
                
                wire [10:0] rounded_mant = {1'b0, mant_part} + round_up;
                wire [9:0] final_mant;
                wire [6:0] final_exp;
                
                if (rounded_mant[10]) begin
                    final_mant = rounded_mant[10:1];
                    final_exp = exp_after_norm_p3 + 7'b1;
                end else begin
                    final_mant = rounded_mant[9:0];
                    final_exp = exp_after_norm_p3;
                end
                
                if (final_exp[6] || (final_exp[5:0] > 6'b001111)) begin
                    computed_C <= {sign_prod_p2, 5'b11111, 10'b0}; // Overflow to infinity
                end else if (final_exp[5:0] < 6'b000001) begin
                    computed_C <= {sign_prod_p2, 5'b0, 10'b0}; // Underflow to zero
                end else begin
                    computed_C <= {sign_prod_p2, final_exp[4:0], final_mant};
                end
            end
        end
    end
    
    // Valid signal generation with pipeline delay
    reg [3:0] valid_pipeline;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_pipeline <= 4'b0;
            C <= 16'b0;
            Valid <= 1'b0;
        end else begin
            valid_pipeline <= {valid_pipeline[2:0], Ready};
            if (valid_pipeline[3]) begin
                C <= computed_C;
                Valid <= 1'b1;
            end else begin
                Valid <= 1'b0;
            end
        end
    end

endmodule