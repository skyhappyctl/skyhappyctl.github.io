create_working_space hw.dat
set_option syn.uvsyn.writeVerilog 1
set_option time.use_unit_delay 1
set_option syn.uvsyn.llmFlow true
config_message -name {ELB-028} -severity ERROR

read_verilog -f flist
elaborate_design
synthesize_design
exit