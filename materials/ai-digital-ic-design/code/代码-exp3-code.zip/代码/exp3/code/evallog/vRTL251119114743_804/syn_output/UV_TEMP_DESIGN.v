(* uvDesignStatus = "1296" *)
(* uvTop = "1" *)
module fp_multiplier(clk, rst_n, Ready, Valid, A, B, C);

input [15 : 0] A;
input [15 : 0] B;
output [15 : 0] C;

input clk;
input rst_n;
input Ready;
output Valid;

wire n2;
wire sign_prod_reg_uv_rename;
wire n269;
wire n_218;
wire n_219;
wire n_220;
wire n_221;
wire n_222;
wire n_223;
wire n_217;
wire n_224;
wire n_213;
wire n_214;
wire n_211;
wire n_210;
wire n_206;
wire n_208;
wire n_203;
wire n_207;
wire n_204;
wire n_201;
wire n_140;
wire n_194;
wire n_195;
wire n_192;
wire n_133;
wire n_190;
wire n_161;
wire n_158;
wire n_159;
wire n_187;
wire n_188;
wire n_160;
wire n_184;
wire n_185;
wire n_136;
wire n_181;
wire n_182;
wire n_179;
wire n_177;
wire n_175;
wire n_172;
wire n_173;
wire n_169;
wire n_147;
wire n_170;
wire n_146;
wire n_167;
wire n_164;
wire n_120;
wire n_124;
wire n_121;
wire n_122;
wire n_148;
wire n_119;
wire n_118;
wire n_144;
wire n_149;
wire n_123;
wire n_150;
wire n_145;
wire n_153;
wire n_151;
wire n_137;
wire n_142;
wire n_154;
wire n_152;
wire n_143;
wire n_127;
wire n_128;
wire n_126;
wire n_129;
wire n_135;
wire n_134;
wire n_138;
wire n_130;
wire n_116;
wire n_117;
wire n_125;
wire n_139;
wire n_131;
wire n_132;
wire n_155;
wire n_157;
wire n_156;
wire n_141;
wire n_165;
wire n_163;
wire n_162;
wire n_108;
wire n_109;
wire n_110;
wire n_112;
wire n_111;
wire n_97;
wire n_96;
wire n_99;
wire n_98;
wire n_103;
wire n_102;
wire n_105;
wire n_101;
wire n_104;
wire n_113;
wire n_107;
wire \computed_C[15] ;
wire \computed_C[14] ;
wire \computed_C[13] ;
wire \computed_C[12] ;
wire \computed_C[11] ;
wire \computed_C[10] ;
wire \computed_C[9] ;
wire \computed_C[8] ;
wire \computed_C[7] ;
wire \computed_C[6] ;
wire \computed_C[5] ;
wire \computed_C[4] ;
wire \computed_C[3] ;
wire \computed_C[2] ;
wire \computed_C[1] ;
wire \computed_C[0] ;
wire \exp_prod[6] ;
wire \exp_prod[5] ;
wire \exp_prod[4] ;
wire \exp_prod[3] ;
wire \exp_prod[2] ;
wire \exp_prod[1] ;
wire \exp_prod_reg_uv_rename[6] ;
wire \exp_prod_reg_uv_rename[5] ;
wire \exp_prod_reg_uv_rename[4] ;
wire \exp_prod_reg_uv_rename[3] ;
wire \exp_prod_reg_uv_rename[2] ;
wire \exp_prod_reg_uv_rename[1] ;
wire \exp_prod_reg_uv_rename[0] ;
wire \exp_sum[0] ;
wire \n309[2] ;
wire \n309[1] ;
wire \n309[0] ;
wire \product_sig[21] ;
wire \product_sig[20] ;
wire \product_sig[19] ;
wire \product_sig[18] ;
wire \product_sig[17] ;
wire \product_sig[16] ;
wire \product_sig[15] ;
wire \product_sig[14] ;
wire \product_sig[13] ;
wire \product_sig[12] ;
wire \product_sig[11] ;
wire \product_sig[10] ;
wire \product_sig[9] ;
wire \product_sig[8] ;
wire \product_sig[7] ;
wire \product_sig[6] ;
wire \product_sig[5] ;
wire \product_sig[4] ;
wire \product_sig[3] ;
wire \product_sig[2] ;
wire \product_sig[1] ;
wire \product_sig[0] ;
wire \product_sig_reg_uv_rename[21] ;
wire \product_sig_reg_uv_rename[20] ;
wire \product_sig_reg_uv_rename[19] ;
wire \product_sig_reg_uv_rename[18] ;
wire \product_sig_reg_uv_rename[17] ;
wire \product_sig_reg_uv_rename[16] ;
wire \product_sig_reg_uv_rename[15] ;
wire \product_sig_reg_uv_rename[14] ;
wire \product_sig_reg_uv_rename[13] ;
wire \product_sig_reg_uv_rename[12] ;
wire \product_sig_reg_uv_rename[11] ;
wire \product_sig_reg_uv_rename[10] ;
wire \product_sig_reg_uv_rename[9] ;
wire \product_sig_reg_uv_rename[8] ;
wire \product_sig_reg_uv_rename[7] ;
wire \product_sig_reg_uv_rename[6] ;
wire \product_sig_reg_uv_rename[5] ;
wire \product_sig_reg_uv_rename[4] ;
wire \product_sig_reg_uv_rename[3] ;
wire \product_sig_reg_uv_rename[2] ;
wire \product_sig_reg_uv_rename[1] ;
wire \product_sig_reg_uv_rename[0] ;
wire \sig_A[10] ;
wire \sig_B[10] ;
wire \special_case_reg_uv_rename[2] ;
wire \special_case_reg_uv_rename[1] ;
wire \special_case_reg_uv_rename[0] ;
wire Valid;
wire Ready;
wire rst_n;
wire clk;
wire [15 : 0] A;
wire [15 : 0] B;
wire [15 : 0] C;


LUT2 #(.INIT(4'h6))
uv_inst_1064(.I0(A[15]), .I1(B[15]), .O(n269));
LUT3 #(.INIT(8'h10))
uv_inst_1065(.I0(\special_case_reg_uv_rename[2] ), .I1(\special_case_reg_uv_rename[1] ), .I2(\special_case_reg_uv_rename[0] ), .O(n_217));
LUT3 #(.INIT(8'he3))
uv_inst_1066(.I0(n_220), .I1(n_122), .I2(n_121), .O(n_222));
LUT3 #(.INIT(8'h53))
uv_inst_1067(.I0(n_222), .I1(n_221), .I2(n_116), .O(n_223));
LUT3 #(.INIT(8'h40))
uv_inst_1068(.I0(n_163), .I1(n_223), .I2(n_164), .O(n_224));
LUT3 #(.INIT(8'hf4))
uv_inst_1069(.I0(n_162), .I1(n_224), .I2(n_217), .O(\computed_C[0] ));
LUT3 #(.INIT(8'h40))
uv_inst_1070(.I0(n_213), .I1(\sig_B[10] ), .I2(\sig_A[10] ), .O(\exp_prod[6] ));
LUT3 #(.INIT(8'h69))
uv_inst_1071(.I0(n_214), .I1(\sig_B[10] ), .I2(\sig_A[10] ), .O(\exp_prod[5] ));
LUT3 #(.INIT(8'h21))
uv_inst_1072(.I0(n_203), .I1(n_208), .I2(n_206), .O(n_211));
LUT2 #(.INIT(4'h9))
uv_inst_1073(.I0(A[13]), .I1(B[13]), .O(n_206));
LUT2 #(.INIT(4'h8))
uv_inst_1074(.I0(A[12]), .I1(B[12]), .O(n_203));
LUT2 #(.INIT(4'h9))
uv_inst_1075(.I0(A[12]), .I1(B[12]), .O(n_204));
LUT3 #(.INIT(8'h69))
uv_inst_1076(.I0(n_201), .I1(A[11]), .I2(B[11]), .O(\exp_prod[1] ));
LUT3 #(.INIT(8'h10))
uv_inst_1077(.I0(n_109), .I1(n_111), .I2(n_107), .O(\n309[2] ));
LUT2 #(.INIT(4'h2))
uv_inst_1078(.I0(n_113), .I1(\n309[2] ), .O(\n309[1] ));
LUT2 #(.INIT(4'h4))
uv_inst_1079(.I0(n_132), .I1(n_139), .O(n_140));
LUT2 #(.INIT(4'h1))
uv_inst_1080(.I0(n_194), .I1(n_163), .O(n_195));
LUT3 #(.INIT(8'hb4))
uv_inst_1081(.I0(\exp_prod_reg_uv_rename[0] ), .I1(n_116), .I2(n_130), .O(n_133));
LUT3 #(.INIT(8'h14))
uv_inst_1082(.I0(\special_case_reg_uv_rename[2] ), .I1(\special_case_reg_uv_rename[1] ), .I2(\special_case_reg_uv_rename[0] ), .O(n_187));
LUT3 #(.INIT(8'h80))
uv_inst_1083(.I0(n_147), .I1(n_158), .I2(n_138), .O(n_161));
LUT3 #(.INIT(8'h14))
uv_inst_1084(.I0(n_163), .I1(n_161), .I2(n_129), .O(n_188));
LUT3 #(.INIT(8'h80))
uv_inst_1085(.I0(n_141), .I1(n_147), .I2(n_158), .O(n_159));
LUT3 #(.INIT(8'h47))
uv_inst_1086(.I0(n_136), .I1(n_116), .I2(n_135), .O(n_184));
LUT3 #(.INIT(8'h10))
uv_inst_1087(.I0(n_162), .I1(n_163), .I2(n_185), .O(\computed_C[9] ));
LUT3 #(.INIT(8'hca))
uv_inst_1088(.I0(\product_sig_reg_uv_rename[19] ), .I1(\product_sig_reg_uv_rename[17] ), .I2(n_117), .O(n_136));
LUT3 #(.INIT(8'h53))
uv_inst_1089(.I0(n_137), .I1(n_136), .I2(n_116), .O(n_181));
LUT3 #(.INIT(8'h90))
uv_inst_1090(.I0(n_155), .I1(n_181), .I2(n_164), .O(n_182));
LUT3 #(.INIT(8'h10))
uv_inst_1091(.I0(n_162), .I1(n_163), .I2(n_182), .O(\computed_C[8] ));
LUT3 #(.INIT(8'h10))
uv_inst_1092(.I0(n_162), .I1(n_163), .I2(n_179), .O(\computed_C[7] ));
LUT2 #(.INIT(4'h6))
uv_inst_1093(.I0(n_154), .I1(n_152), .O(n_177));
LUT3 #(.INIT(8'h10))
uv_inst_1094(.I0(n_162), .I1(n_163), .I2(n_175), .O(\computed_C[5] ));
LUT3 #(.INIT(8'hc5))
uv_inst_1095(.I0(n_149), .I1(n_148), .I2(n_116), .O(n_172));
LUT3 #(.INIT(8'h10))
uv_inst_1096(.I0(n_162), .I1(n_163), .I2(n_173), .O(\computed_C[4] ));
LUT3 #(.INIT(8'hca))
uv_inst_1097(.I0(n_148), .I1(n_144), .I2(n_116), .O(n_169));
LUT2 #(.INIT(4'h8))
uv_inst_1098(.I0(n_123), .I1(n_145), .O(n_147));
LUT3 #(.INIT(8'h90))
uv_inst_1099(.I0(n_147), .I1(n_169), .I2(n_164), .O(n_170));
LUT3 #(.INIT(8'h10))
uv_inst_1100(.I0(n_162), .I1(n_163), .I2(n_170), .O(\computed_C[3] ));
LUT3 #(.INIT(8'hca))
uv_inst_1101(.I0(n_144), .I1(n_119), .I2(n_116), .O(n_146));
LUT3 #(.INIT(8'h10))
uv_inst_1102(.I0(n_162), .I1(n_163), .I2(n_167), .O(\computed_C[2] ));
LUT3 #(.INIT(8'h10))
uv_inst_1103(.I0(\special_case_reg_uv_rename[1] ), .I1(\special_case_reg_uv_rename[0] ), .I2(\special_case_reg_uv_rename[2] ), .O(n_164));
LUT3 #(.INIT(8'h35))
uv_inst_1104(.I0(n_119), .I1(n_118), .I2(n_116), .O(n_120));
LUT3 #(.INIT(8'hb0))
uv_inst_1105(.I0(n_116), .I1(n_118), .I2(n_123), .O(n_124));
LUT3 #(.INIT(8'h60))
uv_inst_1106(.I0(n_124), .I1(n_120), .I2(n_164), .O(n_165));
LUT3 #(.INIT(8'h38))
uv_inst_1107(.I0(\exp_prod_reg_uv_rename[4] ), .I1(\exp_prod_reg_uv_rename[5] ), .I2(\exp_prod_reg_uv_rename[6] ), .O(n_163));
LUT3 #(.INIT(8'h35))
uv_inst_1108(.I0(\product_sig_reg_uv_rename[10] ), .I1(\product_sig_reg_uv_rename[8] ), .I2(n_117), .O(n_121));
LUT3 #(.INIT(8'h35))
uv_inst_1109(.I0(\product_sig_reg_uv_rename[9] ), .I1(\product_sig_reg_uv_rename[7] ), .I2(n_117), .O(n_122));
LUT3 #(.INIT(8'h7))
uv_inst_1110(.I0(n_116), .I1(n_122), .I2(n_121), .O(n_123));
LUT3 #(.INIT(8'h35))
uv_inst_1111(.I0(\product_sig_reg_uv_rename[14] ), .I1(\product_sig_reg_uv_rename[12] ), .I2(n_117), .O(n_148));
LUT3 #(.INIT(8'h35))
uv_inst_1112(.I0(\product_sig_reg_uv_rename[12] ), .I1(\product_sig_reg_uv_rename[10] ), .I2(n_117), .O(n_119));
LUT3 #(.INIT(8'h35))
uv_inst_1113(.I0(\product_sig_reg_uv_rename[11] ), .I1(\product_sig_reg_uv_rename[9] ), .I2(n_117), .O(n_118));
LUT3 #(.INIT(8'h35))
uv_inst_1114(.I0(\product_sig_reg_uv_rename[13] ), .I1(\product_sig_reg_uv_rename[11] ), .I2(n_117), .O(n_144));
LUT3 #(.INIT(8'hca))
uv_inst_1115(.I0(\product_sig_reg_uv_rename[15] ), .I1(\product_sig_reg_uv_rename[13] ), .I2(n_117), .O(n_149));
LUT3 #(.INIT(8'h35))
uv_inst_1116(.I0(n_151), .I1(n_149), .I2(n_116), .O(n_153));
LUT3 #(.INIT(8'hca))
uv_inst_1117(.I0(\product_sig_reg_uv_rename[16] ), .I1(\product_sig_reg_uv_rename[14] ), .I2(n_117), .O(n_151));
LUT3 #(.INIT(8'h53))
uv_inst_1118(.I0(n_151), .I1(n_142), .I2(n_116), .O(n_152));
LUT3 #(.INIT(8'hca))
uv_inst_1119(.I0(\product_sig_reg_uv_rename[18] ), .I1(\product_sig_reg_uv_rename[16] ), .I2(n_117), .O(n_137));
LUT3 #(.INIT(8'hca))
uv_inst_1120(.I0(\product_sig_reg_uv_rename[17] ), .I1(\product_sig_reg_uv_rename[15] ), .I2(n_117), .O(n_142));
LUT3 #(.INIT(8'h53))
uv_inst_1121(.I0(n_142), .I1(n_137), .I2(n_116), .O(n_143));
LUT3 #(.INIT(8'h10))
uv_inst_1122(.I0(n_143), .I1(n_152), .I2(n_154), .O(n_155));
LUT3 #(.INIT(8'h40))
uv_inst_1123(.I0(n_141), .I1(n_128), .I2(n_138), .O(n_157));
LUT2 #(.INIT(4'h4))
uv_inst_1124(.I0(n_125), .I1(n_126), .O(n_127));
LUT3 #(.INIT(8'h41))
uv_inst_1125(.I0(\exp_prod_reg_uv_rename[5] ), .I1(n_127), .I2(\exp_prod_reg_uv_rename[4] ), .O(n_128));
LUT2 #(.INIT(4'h1))
uv_inst_1126(.I0(\exp_prod_reg_uv_rename[3] ), .I1(\exp_prod_reg_uv_rename[2] ), .O(n_126));
LUT2 #(.INIT(4'h9))
uv_inst_1127(.I0(n_116), .I1(\exp_prod_reg_uv_rename[0] ), .O(n_129));
LUT3 #(.INIT(8'hac))
uv_inst_1128(.I0(\product_sig_reg_uv_rename[20] ), .I1(\product_sig_reg_uv_rename[18] ), .I2(\product_sig_reg_uv_rename[21] ), .O(n_135));
LUT2 #(.INIT(4'h4))
uv_inst_1129(.I0(n_134), .I1(n_135), .O(n_138));
LUT2 #(.INIT(4'h9))
uv_inst_1130(.I0(n_117), .I1(\exp_prod_reg_uv_rename[1] ), .O(n_130));
LUT3 #(.INIT(8'he1))
uv_inst_1131(.I0(n_125), .I1(\exp_prod_reg_uv_rename[2] ), .I2(\exp_prod_reg_uv_rename[3] ), .O(n_131));
LUT2 #(.INIT(4'h6))
uv_inst_1132(.I0(n_125), .I1(\exp_prod_reg_uv_rename[2] ), .O(n_132));
LUT3 #(.INIT(8'h40))
uv_inst_1133(.I0(n_132), .I1(n_131), .I2(n_139), .O(n_141));
LUT3 #(.INIT(8'h10))
uv_inst_1134(.I0(n_162), .I1(n_163), .I2(n_165), .O(\computed_C[1] ));
LUT2 #(.INIT(4'h8))
uv_inst_1135(.I0(n_108), .I1(B[14]), .O(n_109));
LUT2 #(.INIT(4'h8))
uv_inst_1136(.I0(n_110), .I1(A[14]), .O(n_111));
LUT2 #(.INIT(4'hb))
uv_inst_1137(.I0(B[10]), .I1(n_99), .O(\sig_B[10] ));
LUT2 #(.INIT(4'h4))
uv_inst_1138(.I0(\sig_B[10] ), .I1(n_98), .O(n_101));
LUT2 #(.INIT(4'hb))
uv_inst_1139(.I0(A[10]), .I1(n_105), .O(\sig_A[10] ));
LUT3 #(.INIT(8'hb))
uv_inst_1140(.I0(\sig_A[10] ), .I1(n_104), .I2(n_101), .O(n_107));
LUT2 #(.INIT(4'h7))
uv_inst_1141(.I0(n_107), .I1(n_113), .O(\n309[0] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
special_case_reg_uv_rename_reg_0_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\n309[0] ), .Q(\special_case_reg_uv_rename[0] ));
dsp_single_mult_11u_11u_22 mult_370(.a({\sig_A[10] , 
A[9], 
A[8], 
A[7], 
A[6], 
A[5], 
A[4], 
A[3], 
A[2], 
A[1], 
A[0]}), 
.b({\sig_B[10] , 
B[9], 
B[8], 
B[7], 
B[6], 
B[5], 
B[4], 
B[3], 
B[2], 
B[1], 
B[0]}), 
.o({\product_sig[21] , 
\product_sig[20] , 
\product_sig[19] , 
\product_sig[18] , 
\product_sig[17] , 
\product_sig[16] , 
\product_sig[15] , 
\product_sig[14] , 
\product_sig[13] , 
\product_sig[12] , 
\product_sig[11] , 
\product_sig[10] , 
\product_sig[9] , 
\product_sig[8] , 
\product_sig[7] , 
\product_sig[6] , 
\product_sig[5] , 
\product_sig[4] , 
\product_sig[3] , 
\product_sig[2] , 
\product_sig[1] , 
\product_sig[0] }));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_0_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_sum[0] ), .Q(\exp_prod_reg_uv_rename[0] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_0_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[0] ), .Q(\product_sig_reg_uv_rename[0] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
Valid_reg(.C(clk), .CE(n2), .CLR(rst_n), .D(Ready), .Q(Valid));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_1_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[1] ), .Q(C[1]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_2_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[2] ), .Q(C[2]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_3_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[3] ), .Q(C[3]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_4_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[4] ), .Q(C[4]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_5_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[5] ), .Q(C[5]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_6_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[6] ), .Q(C[6]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_7_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[7] ), .Q(C[7]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_8_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[8] ), .Q(C[8]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_9_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[9] ), .Q(C[9]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_10_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[10] ), .Q(C[10]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_11_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[11] ), .Q(C[11]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_12_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[12] ), .Q(C[12]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_13_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[13] ), .Q(C[13]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_14_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[14] ), .Q(C[14]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_15_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[15] ), .Q(C[15]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_1_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[1] ), .Q(\product_sig_reg_uv_rename[1] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_2_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[2] ), .Q(\product_sig_reg_uv_rename[2] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_3_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[3] ), .Q(\product_sig_reg_uv_rename[3] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_4_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[4] ), .Q(\product_sig_reg_uv_rename[4] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_5_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[5] ), .Q(\product_sig_reg_uv_rename[5] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_6_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[6] ), .Q(\product_sig_reg_uv_rename[6] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_7_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[7] ), .Q(\product_sig_reg_uv_rename[7] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_8_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[8] ), .Q(\product_sig_reg_uv_rename[8] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_9_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[9] ), .Q(\product_sig_reg_uv_rename[9] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_10_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[10] ), .Q(\product_sig_reg_uv_rename[10] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_11_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[11] ), .Q(\product_sig_reg_uv_rename[11] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_12_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[12] ), .Q(\product_sig_reg_uv_rename[12] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_13_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[13] ), .Q(\product_sig_reg_uv_rename[13] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_14_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[14] ), .Q(\product_sig_reg_uv_rename[14] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_15_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[15] ), .Q(\product_sig_reg_uv_rename[15] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_16_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[16] ), .Q(\product_sig_reg_uv_rename[16] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_17_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[17] ), .Q(\product_sig_reg_uv_rename[17] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_18_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[18] ), .Q(\product_sig_reg_uv_rename[18] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_19_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[19] ), .Q(\product_sig_reg_uv_rename[19] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_20_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[20] ), .Q(\product_sig_reg_uv_rename[20] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
product_sig_reg_uv_rename_reg_21_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\product_sig[21] ), .Q(\product_sig_reg_uv_rename[21] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
special_case_reg_uv_rename_reg_1_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\n309[1] ), .Q(\special_case_reg_uv_rename[1] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
special_case_reg_uv_rename_reg_2_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\n309[2] ), .Q(\special_case_reg_uv_rename[2] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_1_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[1] ), .Q(\exp_prod_reg_uv_rename[1] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_2_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[2] ), .Q(\exp_prod_reg_uv_rename[2] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_3_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[3] ), .Q(\exp_prod_reg_uv_rename[3] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_4_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[4] ), .Q(\exp_prod_reg_uv_rename[4] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_5_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[5] ), .Q(\exp_prod_reg_uv_rename[5] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
exp_prod_reg_uv_rename_reg_6_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\exp_prod[6] ), .Q(\exp_prod_reg_uv_rename[6] ));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_0_(.C(clk), .CE(n2), .CLR(rst_n), .D(\computed_C[0] ), .Q(C[0]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
sign_prod_reg_uv_rename_reg(.C(clk), .CE(Ready), .CLR(rst_n), .D(n269), .Q(sign_prod_reg_uv_rename));
LUT4 #(.INIT(16'hf08f))
uv_inst_1060(.I0(n_220), .I1(n_122), .I2(n_118), .I3(n_121), .O(n_221));
LUT4 #(.INIT(16'h1))
uv_inst_1059(.I0(\product_sig_reg_uv_rename[6] ), .I1(\product_sig_reg_uv_rename[2] ), .I2(\product_sig_reg_uv_rename[1] ), .I3(\product_sig_reg_uv_rename[0] ), .O(n_218));
LUT4 #(.INIT(16'h100))
uv_inst_1058(.I0(\product_sig_reg_uv_rename[5] ), .I1(\product_sig_reg_uv_rename[4] ), .I2(\product_sig_reg_uv_rename[3] ), .I3(n_218), .O(n_219));
LUT4 #(.INIT(16'hf100))
uv_inst_1057(.I0(\product_sig_reg_uv_rename[8] ), .I1(\product_sig_reg_uv_rename[7] ), .I2(n_117), .I3(n_219), .O(n_220));
LUT4 #(.INIT(16'hfee8))
uv_inst_1052(.I0(n_210), .I1(n_211), .I2(A[14]), .I3(B[14]), .O(n_213));
LUT4 #(.INIT(16'h7ee8))
uv_inst_1050(.I0(n_210), .I1(n_211), .I2(A[14]), .I3(B[14]), .O(n_214));
LUT4 #(.INIT(16'heee8))
uv_inst_1047(.I0(A[13]), .I1(B[13]), .I2(n_207), .I3(n_203), .O(n_210));
LUT4 #(.INIT(16'h6996))
\exp_prod[4]_uv_inst_1046 (.I0(n_210), .I1(n_211), .I2(A[14]), .I3(B[14]), .O(\exp_prod[4] ));
LUT4 #(.INIT(16'h7eeb))
uv_inst_1044(.I0(n_204), .I1(n_201), .I2(A[11]), .I3(B[11]), .O(n_208));
LUT4 #(.INIT(16'he8))
uv_inst_1042(.I0(n_201), .I1(A[11]), .I2(B[11]), .I3(n_204), .O(n_207));
LUT4 #(.INIT(16'he11e))
\exp_prod[3]_uv_inst_1041 (.I0(n_207), .I1(n_203), .I2(n_208), .I3(n_206), .O(\exp_prod[3] ));
LUT4 #(.INIT(16'h78e1))
\exp_prod[2]_uv_inst_1039 (.I0(n_201), .I1(A[11]), .I2(n_204), .I3(B[11]), .O(\exp_prod[2] ));
LUT4 #(.INIT(16'heee0))
uv_inst_1038(.I0(A[10]), .I1(n_105), .I2(n_99), .I3(B[10]), .O(n_201));
LUT4 #(.INIT(16'h1c00))
\computed_C[15]_uv_inst_1034 (.I0(\special_case_reg_uv_rename[0] ), .I1(\special_case_reg_uv_rename[1] ), .I2(\special_case_reg_uv_rename[2] ), .I3(sign_prod_reg_uv_rename), .O(\computed_C[15] ));
LUT4 #(.INIT(16'hffe0))
\computed_C[14]_uv_inst_1033 (.I0(n_163), .I1(n_160), .I2(n_164), .I3(n_187), .O(\computed_C[14] ));
LUT4 #(.INIT(16'h7f80))
uv_inst_1031(.I0(n_140), .I1(n_147), .I2(n_158), .I3(n_131), .O(n_194));
LUT4 #(.INIT(16'hffb0))
\computed_C[13]_uv_inst_1029 (.I0(n_160), .I1(n_195), .I2(n_164), .I3(n_187), .O(\computed_C[13] ));
LUT4 #(.INIT(16'h708))
uv_inst_1028(.I0(n_155), .I1(n_139), .I2(n_163), .I3(n_132), .O(n_192));
LUT4 #(.INIT(16'hffb0))
\computed_C[12]_uv_inst_1027 (.I0(n_160), .I1(n_192), .I2(n_164), .I3(n_187), .O(\computed_C[12] ));
LUT4 #(.INIT(16'hb04))
uv_inst_1025(.I0(n_129), .I1(n_161), .I2(n_163), .I3(n_133), .O(n_190));
LUT4 #(.INIT(16'hffb0))
\computed_C[11]_uv_inst_1024 (.I0(n_160), .I1(n_190), .I2(n_164), .I3(n_187), .O(\computed_C[11] ));
LUT4 #(.INIT(16'h100))
uv_inst_1020(.I0(n_143), .I1(n_152), .I2(n_153), .I3(n_150), .O(n_158));
LUT4 #(.INIT(16'he7be))
uv_inst_1018(.I0(\exp_prod_reg_uv_rename[5] ), .I1(n_159), .I2(n_127), .I3(\exp_prod_reg_uv_rename[4] ), .O(n_160));
LUT4 #(.INIT(16'hffb0))
\computed_C[10]_uv_inst_1017 (.I0(n_160), .I1(n_188), .I2(n_164), .I3(n_187), .O(\computed_C[10] ));
LUT4 #(.INIT(16'h4f00))
uv_inst_1015(.I0(n_181), .I1(n_155), .I2(n_184), .I3(n_164), .O(n_185));
LUT4 #(.INIT(16'h4b00))
uv_inst_1009(.I0(n_152), .I1(n_154), .I2(n_143), .I3(n_164), .O(n_179));
LUT4 #(.INIT(16'h100))
\computed_C[6]_uv_inst_1006 (.I0(n_162), .I1(n_177), .I2(n_163), .I3(n_164), .O(\computed_C[6] ));
LUT4 #(.INIT(16'h8700))
uv_inst_1005(.I0(n_147), .I1(n_150), .I2(n_153), .I3(n_164), .O(n_175));
LUT4 #(.INIT(16'h4b00))
uv_inst_1002(.I0(n_169), .I1(n_147), .I2(n_172), .I3(n_164), .O(n_173));
LUT4 #(.INIT(16'h8700))
uv_inst_995(.I0(n_124), .I1(n_120), .I2(n_146), .I3(n_164), .O(n_167));
LUT4 #(.INIT(16'h30a))
uv_inst_984(.I0(n_149), .I1(n_144), .I2(n_148), .I3(n_116), .O(n_150));
LUT4 #(.INIT(16'hb))
uv_inst_980(.I0(n_116), .I1(n_144), .I2(n_118), .I3(n_119), .O(n_145));
LUT4 #(.INIT(16'h4000))
uv_inst_977(.I0(n_153), .I1(n_145), .I2(n_150), .I3(n_123), .O(n_154));
LUT4 #(.INIT(16'h7f00))
uv_inst_965(.I0(n_129), .I1(n_130), .I2(n_126), .I3(n_128), .O(n_156));
LUT4 #(.INIT(16'h3f7))
uv_inst_963(.I0(\product_sig_reg_uv_rename[16] ), .I1(\product_sig_reg_uv_rename[17] ), .I2(\product_sig_reg_uv_rename[20] ), .I3(\product_sig_reg_uv_rename[19] ), .O(n_134));
LUT4 #(.INIT(16'h1800))
uv_inst_960(.I0(n_130), .I1(n_116), .I2(\exp_prod_reg_uv_rename[0] ), .I3(n_138), .O(n_139));
LUT4 #(.INIT(16'hf4))
uv_inst_958(.I0(\product_sig_reg_uv_rename[19] ), .I1(\product_sig_reg_uv_rename[18] ), .I2(\product_sig_reg_uv_rename[20] ), .I3(\product_sig_reg_uv_rename[21] ), .O(n_116));
LUT4 #(.INIT(16'he))
uv_inst_957(.I0(\product_sig_reg_uv_rename[18] ), .I1(\product_sig_reg_uv_rename[19] ), .I2(\product_sig_reg_uv_rename[21] ), .I3(\product_sig_reg_uv_rename[20] ), .O(n_117));
LUT4 #(.INIT(16'hd4dd))
uv_inst_956(.I0(n_117), .I1(\exp_prod_reg_uv_rename[1] ), .I2(\exp_prod_reg_uv_rename[0] ), .I3(n_116), .O(n_125));
LUT4 #(.INIT(16'hb33))
uv_inst_953(.I0(n_141), .I1(n_156), .I2(n_157), .I3(n_155), .O(n_162));
VCC n2_uv_inst_951(.P(n2));
LUT4 #(.INIT(16'h356))
\exp_sum[0]_uv_inst_950 (.I0(n_99), .I1(n_105), .I2(A[10]), .I3(B[10]), .O(\exp_sum[0] ));
LUT4 #(.INIT(16'h8000))
uv_inst_949(.I0(B[13]), .I1(B[12]), .I2(B[11]), .I3(B[10]), .O(n_108));
LUT4 #(.INIT(16'h4f00))
uv_inst_947(.I0(\sig_A[10] ), .I1(n_104), .I2(n_98), .I3(n_109), .O(n_112));
LUT4 #(.INIT(16'h8000))
uv_inst_946(.I0(A[13]), .I1(A[12]), .I2(A[11]), .I3(A[10]), .O(n_110));
LUT4 #(.INIT(16'h4f))
uv_inst_944(.I0(n_101), .I1(n_104), .I2(n_111), .I3(n_112), .O(n_113));
LUT4 #(.INIT(16'h1))
uv_inst_943(.I0(B[9]), .I1(B[8]), .I2(B[7]), .I3(B[6]), .O(n_97));
LUT4 #(.INIT(16'h1))
uv_inst_942(.I0(B[3]), .I1(B[2]), .I2(B[1]), .I3(B[0]), .O(n_96));
LUT4 #(.INIT(16'h1000))
uv_inst_941(.I0(B[5]), .I1(B[4]), .I2(n_96), .I3(n_97), .O(n_98));
LUT4 #(.INIT(16'h1))
uv_inst_940(.I0(B[14]), .I1(B[13]), .I2(B[12]), .I3(B[11]), .O(n_99));
LUT4 #(.INIT(16'h1))
uv_inst_937(.I0(A[9]), .I1(A[8]), .I2(A[7]), .I3(A[6]), .O(n_103));
LUT4 #(.INIT(16'h1))
uv_inst_936(.I0(A[3]), .I1(A[2]), .I2(A[1]), .I3(A[0]), .O(n_102));
LUT4 #(.INIT(16'h1000))
uv_inst_935(.I0(A[5]), .I1(A[4]), .I2(n_102), .I3(n_103), .O(n_104));
LUT4 #(.INIT(16'h1))
uv_inst_934(.I0(A[14]), .I1(A[13]), .I2(A[12]), .I3(A[11]), .O(n_105));

endmodule

module dsp_single_mult_11u_11u_22(a, b, o);

input [10 : 0] a;
input [10 : 0] b;
output [21 : 0] o;


wire n2;
wire uv_net_0;
wire uv_net_1;
wire uv_net_2;
wire uv_net_3;
wire uv_net_4;
wire uv_net_5;
wire uv_net_6;
wire uv_net_7;
wire uv_net_8;
wire uv_net_9;
wire uv_net_10;
wire uv_net_11;
wire uv_net_12;
wire uv_net_13;
wire uv_net_14;
wire uv_net_15;
wire uv_net_16;
wire uv_net_17;
wire uv_net_18;
wire uv_net_19;
wire uv_net_20;
wire uv_net_21;
wire uv_net_22;
wire uv_net_23;
wire uv_net_24;
wire uv_net_25;
wire uv_net_26;
wire uv_net_27;
wire uv_net_28;
wire uv_net_29;
wire uv_net_60;
wire uv_net_61;
wire uv_net_62;
wire uv_net_63;
wire uv_net_64;
wire uv_net_65;
wire uv_net_66;
wire uv_net_67;
wire uv_net_68;
wire uv_net_69;
wire uv_net_70;
wire uv_net_71;
wire uv_net_72;
wire uv_net_73;
wire uv_net_74;
wire uv_net_75;
wire uv_net_76;
wire uv_net_77;
wire uv_net_96;
wire uv_net_97;
wire uv_net_98;
wire uv_net_99;
wire uv_net_100;
wire uv_net_101;
wire uv_net_102;
wire uv_net_103;
wire uv_net_104;
wire uv_net_105;
wire uv_net_106;
wire uv_net_107;
wire uv_net_108;
wire uv_net_109;
wire uv_net_110;
wire uv_net_111;
wire uv_net_112;
wire uv_net_113;
wire uv_net_114;
wire uv_net_115;
wire uv_net_116;
wire uv_net_117;
wire uv_net_118;
wire uv_net_119;
wire uv_net_120;
wire uv_net_121;
wire uv_net_122;
wire uv_net_123;
wire uv_net_124;
wire uv_net_125;
wire uv_net_126;
wire uv_net_127;
wire uv_net_128;
wire uv_net_129;
wire uv_net_130;
wire uv_net_131;
wire uv_net_132;
wire uv_net_133;
wire uv_net_134;
wire uv_net_135;
wire uv_net_136;
wire uv_net_137;
wire uv_net_138;
wire uv_net_139;
wire uv_net_140;
wire uv_net_141;
wire uv_net_142;
wire uv_net_143;
wire [10 : 0] a;
wire [10 : 0] b;
wire [21 : 0] o;


GND uv_net_143_uv_inst_193(.G(uv_net_143));
DSP48_MULT_27X18_CAS_NONE_0 mult_0_mult_slice_10_0_10_00(.A_IN({n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
a[10], 
a[9], 
a[8], 
a[7], 
a[6], 
a[5], 
a[4], 
a[3], 
a[2], 
a[1], 
a[0]}), 
.A_CIN({uv_net_0, 
uv_net_1, 
uv_net_2, 
uv_net_3, 
uv_net_4, 
uv_net_5, 
uv_net_6, 
uv_net_7, 
uv_net_8, 
uv_net_9, 
uv_net_10, 
uv_net_11, 
uv_net_12, 
uv_net_13, 
uv_net_14, 
uv_net_15, 
uv_net_16, 
uv_net_17, 
uv_net_18, 
uv_net_19, 
uv_net_20, 
uv_net_21, 
uv_net_22, 
uv_net_23, 
uv_net_24, 
uv_net_25, 
uv_net_26, 
uv_net_27, 
uv_net_28, 
uv_net_29}), 
.B_IN({n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
b[10], 
b[9], 
b[8], 
b[7], 
b[6], 
b[5], 
b[4], 
b[3], 
b[2], 
b[1], 
b[0]}), 
.B_CIN({uv_net_60, 
uv_net_61, 
uv_net_62, 
uv_net_63, 
uv_net_64, 
uv_net_65, 
uv_net_66, 
uv_net_67, 
uv_net_68, 
uv_net_69, 
uv_net_70, 
uv_net_71, 
uv_net_72, 
uv_net_73, 
uv_net_74, 
uv_net_75, 
uv_net_76, 
uv_net_77}), 
.P_OUT({UV_unconnected_hier0_P_OUT_47, 
UV_unconnected_hier0_P_OUT_46, 
UV_unconnected_hier0_P_OUT_45, 
UV_unconnected_hier0_P_OUT_44, 
UV_unconnected_hier0_P_OUT_43, 
UV_unconnected_hier0_P_OUT_42, 
UV_unconnected_hier0_P_OUT_41, 
UV_unconnected_hier0_P_OUT_40, 
UV_unconnected_hier0_P_OUT_39, 
UV_unconnected_hier0_P_OUT_38, 
UV_unconnected_hier0_P_OUT_37, 
UV_unconnected_hier0_P_OUT_36, 
UV_unconnected_hier0_P_OUT_35, 
UV_unconnected_hier0_P_OUT_34, 
UV_unconnected_hier0_P_OUT_33, 
UV_unconnected_hier0_P_OUT_32, 
UV_unconnected_hier0_P_OUT_31, 
UV_unconnected_hier0_P_OUT_30, 
UV_unconnected_hier0_P_OUT_29, 
UV_unconnected_hier0_P_OUT_28, 
UV_unconnected_hier0_P_OUT_27, 
UV_unconnected_hier0_P_OUT_26, 
UV_unconnected_hier0_P_OUT_25, 
UV_unconnected_hier0_P_OUT_24, 
UV_unconnected_hier0_P_OUT_23, 
UV_unconnected_hier0_P_OUT_22, 
o[21], 
o[20], 
o[19], 
o[18], 
o[17], 
o[16], 
o[15], 
o[14], 
o[13], 
o[12], 
o[11], 
o[10], 
o[9], 
o[8], 
o[7], 
o[6], 
o[5], 
o[4], 
o[3], 
o[2], 
o[1], 
o[0]}), 
.P_CIN({uv_net_96, 
uv_net_97, 
uv_net_98, 
uv_net_99, 
uv_net_100, 
uv_net_101, 
uv_net_102, 
uv_net_103, 
uv_net_104, 
uv_net_105, 
uv_net_106, 
uv_net_107, 
uv_net_108, 
uv_net_109, 
uv_net_110, 
uv_net_111, 
uv_net_112, 
uv_net_113, 
uv_net_114, 
uv_net_115, 
uv_net_116, 
uv_net_117, 
uv_net_118, 
uv_net_119, 
uv_net_120, 
uv_net_121, 
uv_net_122, 
uv_net_123, 
uv_net_124, 
uv_net_125, 
uv_net_126, 
uv_net_127, 
uv_net_128, 
uv_net_129, 
uv_net_130, 
uv_net_131, 
uv_net_132, 
uv_net_133, 
uv_net_134, 
uv_net_135, 
uv_net_136, 
uv_net_137, 
uv_net_138, 
uv_net_139, 
uv_net_140, 
uv_net_141, 
uv_net_142, 
uv_net_143}));
GND uv_net_142_uv_inst_192(.G(uv_net_142));
GND uv_net_141_uv_inst_191(.G(uv_net_141));
GND uv_net_140_uv_inst_190(.G(uv_net_140));
GND uv_net_139_uv_inst_189(.G(uv_net_139));
GND uv_net_138_uv_inst_188(.G(uv_net_138));
GND uv_net_137_uv_inst_187(.G(uv_net_137));
GND uv_net_136_uv_inst_186(.G(uv_net_136));
GND uv_net_135_uv_inst_185(.G(uv_net_135));
GND uv_net_134_uv_inst_184(.G(uv_net_134));
GND uv_net_133_uv_inst_183(.G(uv_net_133));
GND uv_net_132_uv_inst_182(.G(uv_net_132));
GND uv_net_131_uv_inst_181(.G(uv_net_131));
GND uv_net_130_uv_inst_180(.G(uv_net_130));
GND uv_net_129_uv_inst_179(.G(uv_net_129));
GND uv_net_128_uv_inst_178(.G(uv_net_128));
GND uv_net_127_uv_inst_177(.G(uv_net_127));
GND uv_net_126_uv_inst_176(.G(uv_net_126));
GND uv_net_125_uv_inst_175(.G(uv_net_125));
GND uv_net_124_uv_inst_174(.G(uv_net_124));
GND uv_net_123_uv_inst_173(.G(uv_net_123));
GND uv_net_122_uv_inst_172(.G(uv_net_122));
GND uv_net_121_uv_inst_171(.G(uv_net_121));
GND uv_net_120_uv_inst_170(.G(uv_net_120));
GND uv_net_119_uv_inst_169(.G(uv_net_119));
GND uv_net_118_uv_inst_168(.G(uv_net_118));
GND uv_net_117_uv_inst_167(.G(uv_net_117));
GND uv_net_116_uv_inst_166(.G(uv_net_116));
GND uv_net_115_uv_inst_165(.G(uv_net_115));
GND uv_net_114_uv_inst_164(.G(uv_net_114));
GND uv_net_113_uv_inst_163(.G(uv_net_113));
GND uv_net_112_uv_inst_162(.G(uv_net_112));
GND uv_net_111_uv_inst_161(.G(uv_net_111));
GND uv_net_110_uv_inst_160(.G(uv_net_110));
GND uv_net_109_uv_inst_159(.G(uv_net_109));
GND uv_net_108_uv_inst_158(.G(uv_net_108));
GND uv_net_107_uv_inst_157(.G(uv_net_107));
GND uv_net_106_uv_inst_156(.G(uv_net_106));
GND uv_net_105_uv_inst_155(.G(uv_net_105));
GND uv_net_104_uv_inst_154(.G(uv_net_104));
GND uv_net_103_uv_inst_153(.G(uv_net_103));
GND uv_net_102_uv_inst_152(.G(uv_net_102));
GND uv_net_101_uv_inst_151(.G(uv_net_101));
GND uv_net_100_uv_inst_150(.G(uv_net_100));
GND uv_net_99_uv_inst_149(.G(uv_net_99));
GND uv_net_98_uv_inst_148(.G(uv_net_98));
GND uv_net_97_uv_inst_147(.G(uv_net_97));
GND uv_net_96_uv_inst_146(.G(uv_net_96));
GND uv_net_77_uv_inst_145(.G(uv_net_77));
GND uv_net_76_uv_inst_144(.G(uv_net_76));
GND uv_net_75_uv_inst_143(.G(uv_net_75));
GND uv_net_74_uv_inst_142(.G(uv_net_74));
GND uv_net_73_uv_inst_141(.G(uv_net_73));
GND uv_net_72_uv_inst_140(.G(uv_net_72));
GND uv_net_71_uv_inst_139(.G(uv_net_71));
GND uv_net_70_uv_inst_138(.G(uv_net_70));
GND uv_net_69_uv_inst_137(.G(uv_net_69));
GND uv_net_68_uv_inst_136(.G(uv_net_68));
GND uv_net_67_uv_inst_135(.G(uv_net_67));
GND uv_net_66_uv_inst_134(.G(uv_net_66));
GND uv_net_65_uv_inst_133(.G(uv_net_65));
GND uv_net_64_uv_inst_132(.G(uv_net_64));
GND uv_net_63_uv_inst_131(.G(uv_net_63));
GND uv_net_62_uv_inst_130(.G(uv_net_62));
GND uv_net_61_uv_inst_129(.G(uv_net_61));
GND uv_net_60_uv_inst_128(.G(uv_net_60));
GND uv_net_29_uv_inst_127(.G(uv_net_29));
GND uv_net_28_uv_inst_126(.G(uv_net_28));
GND uv_net_27_uv_inst_125(.G(uv_net_27));
GND uv_net_26_uv_inst_124(.G(uv_net_26));
GND uv_net_25_uv_inst_123(.G(uv_net_25));
GND uv_net_24_uv_inst_122(.G(uv_net_24));
GND uv_net_23_uv_inst_121(.G(uv_net_23));
GND uv_net_22_uv_inst_120(.G(uv_net_22));
GND uv_net_21_uv_inst_119(.G(uv_net_21));
GND uv_net_20_uv_inst_118(.G(uv_net_20));
GND uv_net_19_uv_inst_117(.G(uv_net_19));
GND uv_net_18_uv_inst_116(.G(uv_net_18));
GND uv_net_17_uv_inst_115(.G(uv_net_17));
GND uv_net_16_uv_inst_114(.G(uv_net_16));
GND uv_net_15_uv_inst_113(.G(uv_net_15));
GND uv_net_14_uv_inst_112(.G(uv_net_14));
GND uv_net_13_uv_inst_111(.G(uv_net_13));
GND uv_net_12_uv_inst_110(.G(uv_net_12));
GND uv_net_11_uv_inst_109(.G(uv_net_11));
GND uv_net_10_uv_inst_108(.G(uv_net_10));
GND uv_net_9_uv_inst_107(.G(uv_net_9));
GND uv_net_8_uv_inst_106(.G(uv_net_8));
GND uv_net_7_uv_inst_105(.G(uv_net_7));
GND uv_net_6_uv_inst_104(.G(uv_net_6));
GND uv_net_5_uv_inst_103(.G(uv_net_5));
GND uv_net_4_uv_inst_102(.G(uv_net_4));
GND uv_net_3_uv_inst_101(.G(uv_net_3));
GND uv_net_2_uv_inst_100(.G(uv_net_2));
GND uv_net_1_uv_inst_99(.G(uv_net_1));
GND uv_net_0_uv_inst_98(.G(uv_net_0));
GND n2_uv_inst_97(.G(n2));

endmodule

module DSP48_MULT_27X18_CAS_NONE_0(A_IN, A_CIN, B_IN, B_CIN, P_OUT, P_CIN);

input [26 : 0] A_IN;
input [29 : 0] A_CIN;
input [17 : 0] B_IN;
input [17 : 0] B_CIN;
output [47 : 0] P_OUT;
input [47 : 0] P_CIN;


wire n1;
wire n2;
wire [26 : 0] A_IN;
wire [29 : 0] A_CIN;
wire [17 : 0] B_IN;
wire [17 : 0] B_CIN;
wire [47 : 0] P_OUT;
wire [47 : 0] P_CIN;


GND i1(.G(n1));
VCC i2(.P(n2));
DSP48E2 #(.ACASCREG(0), .ADREG(0), .ALUMODEREG(0), .AMULTSEL("A"), .AREG(0), .AUTORESET_PATDET("NO_RESET"), .AUTORESET_PRIORITY("RESET"), .A_INPUT("DIRECT"), .BCASCREG(0), .BMULTSEL("B"), .BREG(0), .B_INPUT("DIRECT"), .CARRYINREG(0), .CARRYINSELREG(0), .CREG(0), .DREG(0), .INMODEREG(0), .MASK(48'b001111111111111111111111111111111111111111111111), .MREG(0), .OPMODEREG(0), .PATTERN(48'b000000000000000000000000000000000000000000000000), .PREADDINSEL("A"), .PREG(0), .RND(48'b000000000000000000000000000000000000000000000000), .SEL_MASK("MASK"), .SEL_PATTERN("PATTERN"), .USE_MULT("MULTIPLY"), .USE_PATTERN_DETECT("NO_PATDET"), .USE_SIMD("ONE48"), .USE_WIDEXOR("FALSE"), .XORSIMD("XOR24_48_96"))
_TECHMAP_REPLACE_(.CARRYCASCOUT(), .MULTSIGNOUT(), .OVERFLOW(), .PATTERNBDETECT(), .PATTERNDETECT(), .UNDERFLOW(), .CARRYCASCIN(n1), .CARRYIN(n1), .CEA1(n1), .CEA2(n1), .CEAD(n1), .CEALUMODE(n1), .CEB1(n1), .CEB2(n1), .CEC(n1), .CECARRYIN(n1), .CECTRL(n1), .CED(n1), .CEINMODE(n1), .CEM(n1), .CEP(n1), .CLK(n1), .MULTSIGNIN(n1), .RSTA(n1), .RSTALLCARRYIN(n1), .RSTALUMODE(n1), .RSTB(n1), .RSTC(n1), .RSTCTRL(n1), .RSTD(n1), .RSTINMODE(n1), .RSTM(n1), .RSTP(n1), 
.ACOUT() , 
.BCOUT() , 
.CARRYOUT() , 
.P({UV_unconnected_leaf_inst2_P_47, 
UV_unconnected_leaf_inst2_P_46, 
UV_unconnected_leaf_inst2_P_45, 
UV_unconnected_leaf_inst2_P_44, 
UV_unconnected_leaf_inst2_P_43, 
UV_unconnected_leaf_inst2_P_42, 
UV_unconnected_leaf_inst2_P_41, 
UV_unconnected_leaf_inst2_P_40, 
UV_unconnected_leaf_inst2_P_39, 
UV_unconnected_leaf_inst2_P_38, 
UV_unconnected_leaf_inst2_P_37, 
UV_unconnected_leaf_inst2_P_36, 
UV_unconnected_leaf_inst2_P_35, 
UV_unconnected_leaf_inst2_P_34, 
UV_unconnected_leaf_inst2_P_33, 
UV_unconnected_leaf_inst2_P_32, 
UV_unconnected_leaf_inst2_P_31, 
UV_unconnected_leaf_inst2_P_30, 
UV_unconnected_leaf_inst2_P_29, 
UV_unconnected_leaf_inst2_P_28, 
UV_unconnected_leaf_inst2_P_27, 
UV_unconnected_leaf_inst2_P_26, 
UV_unconnected_leaf_inst2_P_25, 
UV_unconnected_leaf_inst2_P_24, 
UV_unconnected_leaf_inst2_P_23, 
UV_unconnected_leaf_inst2_P_22, 
P_OUT[21], 
P_OUT[20], 
P_OUT[19], 
P_OUT[18], 
P_OUT[17], 
P_OUT[16], 
P_OUT[15], 
P_OUT[14], 
P_OUT[13], 
P_OUT[12], 
P_OUT[11], 
P_OUT[10], 
P_OUT[9], 
P_OUT[8], 
P_OUT[7], 
P_OUT[6], 
P_OUT[5], 
P_OUT[4], 
P_OUT[3], 
P_OUT[2], 
P_OUT[1], 
P_OUT[0]}), 
.PCOUT() , 
.XOROUT() , 
.A({A_IN[26], 
A_IN[26], 
A_IN[26], 
A_IN[26], 
A_IN[25], 
A_IN[24], 
A_IN[23], 
A_IN[22], 
A_IN[21], 
A_IN[20], 
A_IN[19], 
A_IN[18], 
A_IN[17], 
A_IN[16], 
A_IN[15], 
A_IN[14], 
A_IN[13], 
A_IN[12], 
A_IN[11], 
A_IN[10], 
A_IN[9], 
A_IN[8], 
A_IN[7], 
A_IN[6], 
A_IN[5], 
A_IN[4], 
A_IN[3], 
A_IN[2], 
A_IN[1], 
A_IN[0]}), 
.ACIN({A_CIN[29], 
A_CIN[28], 
A_CIN[27], 
A_CIN[26], 
A_CIN[25], 
A_CIN[24], 
A_CIN[23], 
A_CIN[22], 
A_CIN[21], 
A_CIN[20], 
A_CIN[19], 
A_CIN[18], 
A_CIN[17], 
A_CIN[16], 
A_CIN[15], 
A_CIN[14], 
A_CIN[13], 
A_CIN[12], 
A_CIN[11], 
A_CIN[10], 
A_CIN[9], 
A_CIN[8], 
A_CIN[7], 
A_CIN[6], 
A_CIN[5], 
A_CIN[4], 
A_CIN[3], 
A_CIN[2], 
A_CIN[1], 
A_CIN[0]}), 
.ALUMODE({n1, 
n1, 
n1, 
n1}), 
.B({B_IN[17], 
B_IN[16], 
B_IN[15], 
B_IN[14], 
B_IN[13], 
B_IN[12], 
B_IN[11], 
B_IN[10], 
B_IN[9], 
B_IN[8], 
B_IN[7], 
B_IN[6], 
B_IN[5], 
B_IN[4], 
B_IN[3], 
B_IN[2], 
B_IN[1], 
B_IN[0]}), 
.BCIN({B_CIN[17], 
B_CIN[16], 
B_CIN[15], 
B_CIN[14], 
B_CIN[13], 
B_CIN[12], 
B_CIN[11], 
B_CIN[10], 
B_CIN[9], 
B_CIN[8], 
B_CIN[7], 
B_CIN[6], 
B_CIN[5], 
B_CIN[4], 
B_CIN[3], 
B_CIN[2], 
B_CIN[1], 
B_CIN[0]}), 
.C({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1}), 
.CARRYINSEL({n1, 
n1, 
n1}), 
.D({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1}), 
.INMODE({n1, 
n1, 
n1, 
n1, 
n1}), 
.OPMODE({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n2, 
n1, 
n2}), 
.PCIN({P_CIN[47], 
P_CIN[46], 
P_CIN[45], 
P_CIN[44], 
P_CIN[43], 
P_CIN[42], 
P_CIN[41], 
P_CIN[40], 
P_CIN[39], 
P_CIN[38], 
P_CIN[37], 
P_CIN[36], 
P_CIN[35], 
P_CIN[34], 
P_CIN[33], 
P_CIN[32], 
P_CIN[31], 
P_CIN[30], 
P_CIN[29], 
P_CIN[28], 
P_CIN[27], 
P_CIN[26], 
P_CIN[25], 
P_CIN[24], 
P_CIN[23], 
P_CIN[22], 
P_CIN[21], 
P_CIN[20], 
P_CIN[19], 
P_CIN[18], 
P_CIN[17], 
P_CIN[16], 
P_CIN[15], 
P_CIN[14], 
P_CIN[13], 
P_CIN[12], 
P_CIN[11], 
P_CIN[10], 
P_CIN[9], 
P_CIN[8], 
P_CIN[7], 
P_CIN[6], 
P_CIN[5], 
P_CIN[4], 
P_CIN[3], 
P_CIN[2], 
P_CIN[1], 
P_CIN[0]}));

endmodule

