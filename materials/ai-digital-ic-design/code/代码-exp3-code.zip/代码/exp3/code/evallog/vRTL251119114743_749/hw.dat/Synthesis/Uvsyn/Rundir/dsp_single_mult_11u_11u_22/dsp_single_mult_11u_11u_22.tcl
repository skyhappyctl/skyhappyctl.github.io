set FILE_DIR "../../../../../"
set edif_dir "../../../../../hw.dat/Synthesis/Uvsyn/Edif/dsp_single_mult_11u_11u_22"
set uvsyn_db "$FILE_DIR/hw.dat/Synthesis/Rtl_elab/Eldb/dsp_single_mult_11u_11u_22.eldb"
set script_tcl ""
source ../../Script/hwSyn_uvsyn.tcl
set_option syn.dsp.mult.inputSize 1
set_option syn.disable.extractRegEn 0
set_option syn.techmap.travLevel 5
set_option syn.techmap.travBranch 64
set_option syn.enable.csr 0
set_option syn.csr.threshold 8
set_option syn.enable.srlMap 0
set_option syn.srlMap.minSize 2
set_option syn.srlMap.style reg_srl_reg
set_option syn.dsp.map 1
set_option syn.enable.csa 0
set_option syn.keepSignal 1
set_option syn.disable.protectRegClk 0
# Load uvsyn script tcl
if {[llength $script_tcl] > 0} {
    source $script_tcl
}

load_netlist $uvsyn_db
synth_netlist -output $edif_dir
set fp [open .SYNTH_PASS w+]
exit
