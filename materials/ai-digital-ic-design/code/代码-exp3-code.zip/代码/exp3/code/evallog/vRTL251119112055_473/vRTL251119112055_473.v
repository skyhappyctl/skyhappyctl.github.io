module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);

    reg [15:0] computed_C;

    wire sign_A = A[15];
    wire [4:0] exp_A = A[14:10];
    wire [9:0] mant_A = A[9:0];

    wire sign_B = B[15];
    wire [4:0] exp_B = B[14:10];
    wire [9:0] mant_B = B[9:0];

    wire is_nan_A = (exp_A == 5'b11111) && (mant_A != 10'b0);
    wire is_inf_A = (exp_A == 5'b11111) && (mant_A == 10'b0);
    wire is_zero_A = (exp_A == 5'b0) && (mant_A == 10'b0);

    wire is_nan_B = (exp_B == 5'b11111) && (mant_B != 10'b0);
    wire is_inf_B = (exp_B == 5'b11111) && (mant_B == 10'b0);
    wire is_zero_B = (exp_B == 5'b0) && (mant_B == 10'b0);

    // 将原来在always块内部的wire声明移到外部
    wire [10:0] sig_A = (exp_A == 5'b0) ? {1'b0, mant_A} : {1'b1, mant_A};
    wire [10:0] sig_B = (exp_B == 5'b0) ? {1'b0, mant_B} : {1'b1, mant_B};
    wire [21:0] product_sig = sig_A * sig_B;
    wire [5:0] exp_A_adj = (exp_A == 5'b0) ? 6'b100001 : {1'b0, exp_A};
    wire [5:0] exp_B_adj = (exp_B == 5'b0) ? 6'b100001 : {1'b0, exp_B};
    wire [6:0] exp_sum = exp_A_adj + exp_B_adj;
    wire [6:0] exp_prod = exp_sum - 7'b0011110;

    always @(*) begin
        computed_C = 16'b0;

        if (is_nan_A || is_nan_B) begin
            computed_C = {1'b0, 5'b11111, 10'b1};
        end else if ((is_inf_A && is_zero_B) || (is_zero_A && is_inf_B)) begin
            computed_C = {1'b0, 5'b11111, 10'b1};
        end else if (is_inf_A || is_inf_B) begin
            computed_C = {sign_A ^ sign_B, 5'b11111, 10'b0};
        end else if (is_zero_A || is_zero_B) begin
            computed_C = {sign_A ^ sign_B, 5'b0, 10'b0};
        end else begin
            reg [4:0] shift_amount;
            reg [21:0] normalized_sig;
            
            if (product_sig[21]) begin
                shift_amount = 5'b0;
                normalized_sig = product_sig;
            end else if (product_sig[20]) begin
                shift_amount = 5'b1;
                normalized_sig = product_sig << 1;
            end else if (product_sig[19]) begin
                shift_amount = 5'b10;
                normalized_sig = product_sig << 2;
            end else if (product_sig[18]) begin
                shift_amount = 5'b11;
                normalized_sig = product_sig << 3;
            end else begin
                shift_amount = 5'b0;
                normalized_sig = product_sig;
            end

            wire [6:0] exp_after_norm = exp_prod - {2'b0, shift_amount};

            wire [9:0] mant_part = normalized_sig[20:11];
            wire G = normalized_sig[10];
            wire R = normalized_sig[9];
            wire S = |normalized_sig[8:0];

            wire round_up;
            if (G && (R || S)) begin
                round_up = 1'b1;
            end else if (G && !(R || S) && mant_part[0]) begin
                round_up = 1'b1;
            end else begin
                round_up = 1'b0;
            end

            wire [10:0] rounded_mant = {1'b0, mant_part} + round_up;
            wire [9:0] final_mant;
            wire [6:0] final_exp;
            
            if (rounded_mant[10]) begin
                final_mant = rounded_mant[10:1];
                final_exp = exp_after_norm + 7'b1;
            end else begin
                final_mant = rounded_mant[9:0];
                final_exp = exp_after_norm;
            end

            if (final_exp[6] || final_exp[5:0] > 6'b001111) begin
                computed_C = {sign_A ^ sign_B, 5'b11111, 10'b0};
            end else if (final_exp[5:0] < 6'b000001) begin
                computed_C = {sign_A ^ sign_B, 5'b0, 10'b0};
            end else begin
                computed_C = {sign_A ^ sign_B, final_exp[4:0], final_mant};
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            C <= 16'b0;
            Valid <= 1'b0;
        end else begin
            if (Ready) begin
                C <= computed_C;
                Valid <= 1'b1;
            end else begin
                Valid <= 1'b0;
            end
        end
    end
endmodule