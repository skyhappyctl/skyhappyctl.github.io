#!/bin/bash
make -ki all > .parallel_tasks.log 2>&1
dmesg -T | grep -C 10 -iE "uv_shell|vivado" | grep -C 10 "UID $(id -u)" > uv_dp_job_dmesg.log || true

touch .uv_dp_job_finish
