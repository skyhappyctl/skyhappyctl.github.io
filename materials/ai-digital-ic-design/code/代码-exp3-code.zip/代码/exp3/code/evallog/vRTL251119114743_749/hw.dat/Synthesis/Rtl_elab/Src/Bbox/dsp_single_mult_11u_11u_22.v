(* dont_touch = "yes" *)
(* DSP_WRAP_MOD = "1" *)
module dsp_single_mult_11u_11u_22(a, b, o);
input [10:0] a;
input [10:0] b;
output [21:0] o;
endmodule
