module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);

    // Internal registers and wires
    reg [15:0] computed_C;
    
    // Input decomposition
    wire sign_A;
    wire [4:0] exp_A;
    wire [9:0] mant_A;
    wire sign_B;
    wire [4:0] exp_B;
    wire [9:0] mant_B;
    
    // Special case detection
    wire is_nan_A;
    wire is_inf_A;
    wire is_zero_A;
    wire is_nan_B;
    wire is_inf_B;
    wire is_zero_B;
    
    // Computation signals - stage 1
    wire [10:0] sig_A;
    wire [10:0] sig_B;
    wire [21:0] product_sig;
    wire [5:0] exp_A_adj;
    wire [5:0] exp_B_adj;
    wire [6:0] exp_sum;
    wire [6:0] exp_prod;
    
    // Normalization signals - stage 2
    wire [4:0] shift_amount;
    wire [21:0] normalized_sig;
    wire [6:0] exp_after_norm;
    
    // Rounding signals - stage 3
    wire [9:0] mant_part;
    wire G;
    wire R;
    wire S;
    wire round_up;
    wire [10:0] rounded_mant;
    wire [9:0] final_mant;
    wire [6:0] final_exp;
    
    // Pipeline registers
    reg [1:0] special_case_stage1;
    reg sign_prod_stage1;
    reg [21:0] product_sig_stage1;
    reg [6:0] exp_prod_stage1;
    
    reg [1:0] special_case_stage2;
    reg sign_prod_stage2;
    reg [21:0] normalized_sig_stage2;
    reg [6:0] exp_after_norm_stage2;
    
    // Assign input decomposition
    assign sign_A = A[15];
    assign exp_A = A[14:10];
    assign mant_A = A[9:0];
    assign sign_B = B[15];
    assign exp_B = B[14:10];
    assign mant_B = B[9:0];
    
    // Special case detection
    assign is_nan_A = (exp_A == 5'b11111) && (mant_A != 10'b0);
    assign is_inf_A = (exp_A == 5'b11111) && (mant_A == 10'b0);
    assign is_zero_A = (exp_A == 5'b0) && (mant_A == 10'b0);
    assign is_nan_B = (exp_B == 5'b11111) && (mant_B != 10'b0);
    assign is_inf_B = (exp_B == 5'b11111) && (mant_B == 10'b0);
    assign is_zero_B = (exp_B == 5'b0) && (mant_B == 10'b0);
    
    // Stage 1: Basic computation
    assign sig_A = (exp_A == 5'b0) ? {1'b0, mant_A} : {1'b1, mant_A};
    assign sig_B = (exp_B == 5'b0) ? {1'b0, mant_B} : {1'b1, mant_B};
    assign product_sig = sig_A * sig_B;
    assign exp_A_adj = (exp_A == 5'b0) ? 6'b100001 : {1'b0, exp_A};
    assign exp_B_adj = (exp_B == 5'b0) ? 6'b100001 : {1'b0, exp_B};
    assign exp_sum = exp_A_adj + exp_B_adj;
    assign exp_prod = exp_sum - 7'b0011110;
    
    // Stage 1 pipeline register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            special_case_stage1 <= 2'b00;
            sign_prod_stage1 <= 1'b0;
            product_sig_stage1 <= 22'b0;
            exp_prod_stage1 <= 7'b0;
        end else if (Ready) begin
            // Encode special cases
            if (is_nan_A || is_nan_B) begin
                special_case_stage1 <= 2'b01; // NaN
            end else if ((is_inf_A && is_zero_B) || (is_zero_A && is_inf_B)) begin
                special_case_stage1 <= 2'b01; // NaN
            end else if (is_inf_A || is_inf_B) begin
                special_case_stage1 <= 2'b10; // Infinity
            end else if (is_zero_A || is_zero_B) begin
                special_case_stage1 <= 2'b11; // Zero
            end else begin
                special_case_stage1 <= 2'b00; // Normal case
            end
            
            sign_prod_stage1 <= sign_A ^ sign_B;
            product_sig_stage1 <= product_sig;
            exp_prod_stage1 <= exp_prod;
        end
    end
    
    // Stage 2: Normalization
    assign shift_amount = (product_sig_stage1[21]) ? 5'b0 :
                         (product_sig_stage1[20]) ? 5'b1 :
                         (product_sig_stage1[19]) ? 5'b10 :
                         (product_sig_stage1[18]) ? 5'b11 : 5'b0;
                         
    assign normalized_sig = product_sig_stage1 << shift_amount;
    assign exp_after_norm = exp_prod_stage1 - {2'b0, shift_amount};
    
    // Stage 2 pipeline register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            special_case_stage2 <= 2'b00;
            sign_prod_stage2 <= 1'b0;
            normalized_sig_stage2 <= 22'b0;
            exp_after_norm_stage2 <= 7'b0;
        end else begin
            special_case_stage2 <= special_case_stage1;
            sign_prod_stage2 <= sign_prod_stage1;
            normalized_sig_stage2 <= normalized_sig;
            exp_after_norm_stage2 <= exp_after_norm;
        end
    end
    
    // Stage 3: Rounding and final computation
    assign mant_part = normalized_sig_stage2[20:11];
    assign G = normalized_sig_stage2[10];
    assign R = normalized_sig_stage2[9];
    assign S = |normalized_sig_stage2[8:0];
    
    assign round_up = (G && (R || S)) ? 1'b1 :
                     (G && !(R || S) && mant_part[0]) ? 1'b1 : 1'b0;
                     
    assign rounded_mant = {1'b0, mant_part} + round_up;
    assign final_mant = rounded_mant[10] ? rounded_mant[10:1] : rounded_mant[9:0];
    assign final_exp = rounded_mant[10] ? (exp_after_norm_stage2 + 7'b1) : exp_after_norm_stage2;
    
    // Final result computation
    always @(*) begin
        computed_C = 16'b0;
        
        case (special_case_stage2)
            2'b01: computed_C = {1'b0, 5'b11111, 10'b1}; // NaN
            2'b10: computed_C = {sign_prod_stage2, 5'b11111, 10'b0}; // Infinity
            2'b11: computed_C = {sign_prod_stage2, 5'b0, 10'b0}; // Zero
            default: begin
                if (final_exp[6] || final_exp[5:0] > 6'b001111) begin
                    computed_C = {sign_prod_stage2, 5'b11111, 10'b0};
                end else if (final_exp[5:0] < 6'b000001) begin
                    computed_C = {sign_prod_stage2, 5'b0, 10'b0};
                end else begin
                    computed_C = {sign_prod_stage2, final_exp[4:0], final_mant};
                end
            end
        endcase
    end
    
    // Output register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            C <= 16'b0;
            Valid <= 1'b0;
        end else begin
            C <= computed_C;
            Valid <= Ready; // Valid follows Ready with pipeline delay
        end
    end

endmodule