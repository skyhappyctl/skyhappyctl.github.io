// SourceInfo: /home/aieda_stu36/THU_AI_EDA-main/exp3/evallog/vRTL251119114743_779/vRTL251119114743_779.v:1
`default_nettype wire
module fp_multiplier (
    input clk /* verific hw_Asychronous_control_signal="true" */ , 
    input rst_n /* verific hw_Asychronous_control_signal="true" */ , 
    input [15:0] A, 
    input [15:0] B, 
    input Ready, 
    output reg [15:0] C, 
    output reg Valid) ;
endmodule
