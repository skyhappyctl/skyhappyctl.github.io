set clocks {clk}
foreach clk $clocks {
  create_clock -name $clk -per 50 $clk
  set_input_delay -clock $clk 0 [all_inputs]
  set_output_delay -clock $clk 0 [all_outputs]
}
set_max_delay 100 -from [all_inputs] -to [all_outputs]