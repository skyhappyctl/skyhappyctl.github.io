create_working_space hw.dat
set_option syn.uvsyn.writeVerilog 1
set_option time.use_unit_delay 1
set_option syn.uvsyn.llmFlow true
config_message -name {ELB-028} -severity ERROR

# 如果设计里面是纯组合逻辑，没有时钟，create一个虚拟时钟：
if [file exist timing.tcl] {
    set_constraint_files ./timing.tcl
} else {
    # 动态生成 timing_virt.tcl 文件
    puts "No user timing.tcl found, creating virtual clock constrant file timing_virt.tcl"
    set fd [open "timing_virt.tcl" w]
    puts $fd "create_clock -name vir -p 50"
    puts $fd "set_output_delay 0 \[all_outputs\] -clock \[get_clocks -name vir\]"
    puts $fd "set_max_delay 100 -from \[all_inputs\] -to \[all_outputs\]"
    close $fd
}

read_verilog -f flist
elaborate_design fp_multiplier
synthesize_design
### resource report  ###  
read_netlist
link_design -eco -top fp_multiplier
sweep_design
report_resource -area
#for logic level report

if [file exists timing.tcl] {
    # 如果 timing.tcl 文件存在，则加载 timing.tcl 文件
    source timing.tcl
} else {
    # 如果 timing.tcl 文件不存在，则加载 timing_virt.tcl 文件
    source timing_virt.tcl
}

report_path -est -logic_level -max_path 1 -json tim_rpt.json
write_netlist syn_output
exit