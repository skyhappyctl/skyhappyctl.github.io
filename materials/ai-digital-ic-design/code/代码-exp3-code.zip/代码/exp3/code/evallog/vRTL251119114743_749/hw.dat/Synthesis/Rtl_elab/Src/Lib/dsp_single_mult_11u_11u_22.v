`define MOD_NAME dsp_single_mult_11u_11u_22

//
// Verific Verilog Description of module dsp_single_mult_11u_11u_22
//

(* dont_touch="yes", DSP_WRAP_MOD=1 *) module `MOD_NAME (a, 
            b, o);
    input [10:0]a;
    input [10:0]b;
    output [21:0]o;
    
    
    assign {o} = {a} * {b};
    
endmodule
