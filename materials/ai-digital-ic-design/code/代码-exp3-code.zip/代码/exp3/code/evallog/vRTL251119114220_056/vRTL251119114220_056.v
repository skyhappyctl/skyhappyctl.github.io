module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);

    // Internal registers
    reg [15:0] computed_C;
    reg sign_prod;
    reg [21:0] product_sig;
    reg [6:0] exp_prod;
    reg special_case;
    reg [2:0] special_result;
    
    // Wire declarations
    wire sign_A = A[15];
    wire [4:0] exp_A = A[14:10];
    wire [9:0] mant_A = A[9:0];
    wire sign_B = B[15];
    wire [4:0] exp_B = B[14:10];
    wire [9:0] mant_B = B[9:0];
    wire is_nan_A = (exp_A == 5'b11111) && (mant_A != 10'b0);
    wire is_inf_A = (exp_A == 5'b11111) && (mant_A == 10'b0);
    wire is_zero_A = (exp_A == 5'b0) && (mant_A == 10'b0);
    wire is_nan_B = (exp_B == 5'b11111) && (mant_B != 10'b0);
    wire is_inf_B = (exp_B == 5'b11111) && (mant_B == 10'b0);
    wire is_zero_B = (exp_B == 5'b0) && (mant_B == 10'b0);
    
    // Stage 1: Special case detection and multiplication
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sign_prod <= 1'b0;
            product_sig <= 22'b0;
            exp_prod <= 7'b0;
            special_case <= 1'b0;
            special_result <= 3'b0;
        end else if (Ready) begin
            sign_prod <= sign_A ^ sign_B;
            
            // Handle special cases
            if (is_nan_A || is_nan_B) begin
                special_case <= 1'b1;
                special_result <= 3'b001; // NaN
            end else if ((is_inf_A && is_zero_B) || (is_zero_A && is_inf_B)) begin
                special_case <= 1'b1;
                special_result <= 3'b001; // NaN
            end else if (is_inf_A || is_inf_B) begin
                special_case <= 1'b1;
                special_result <= 3'b010; // Infinity
            end else if (is_zero_A || is_zero_B) begin
                special_case <= 1'b1;
                special_result <= 3'b011; // Zero
            end else begin
                special_case <= 1'b0;
                special_result <= 3'b000;
                
                // Calculate significands and product
                wire [10:0] sig_A = (exp_A == 5'b0) ? {1'b0, mant_A} : {1'b1, mant_A};
                wire [10:0] sig_B = (exp_B == 5'b0) ? {1'b0, mant_B} : {1'b1, mant_B};
                product_sig <= sig_A * sig_B;
                
                // Calculate exponent
                wire [5:0] exp_A_adj = (exp_A == 5'b0) ? 6'b100001 : {1'b0, exp_A};
                wire [5:0] exp_B_adj = (exp_B == 5'b0) ? 6'b100001 : {1'b0, exp_B};
                wire [6:0] exp_sum = exp_A_adj + exp_B_adj;
                exp_prod <= exp_sum - 7'b0011110;
            end
        end
    end
    
    // Stage 2: Normalization, rounding and final result
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            computed_C <= 16'b0;
        end else if (Ready) begin
            if (special_case) begin
                case (special_result)
                    3'b001: computed_C <= {1'b0, 5'b11111, 10'b1}; // NaN
                    3'b010: computed_C <= {sign_prod, 5'b11111, 10'b0}; // Infinity
                    3'b011: computed_C <= {sign_prod, 5'b0, 10'b0}; // Zero
                    default: computed_C <= 16'b0;
                endcase
            end else begin
                // Normalization
                reg [4:0] shift_amount;
                reg [21:0] normalized_sig;
                
                if (product_sig[21]) begin
                    shift_amount = 5'b0;
                    normalized_sig = product_sig;
                end else if (product_sig[20]) begin
                    shift_amount = 5'b1;
                    normalized_sig = product_sig << 1;
                end else if (product_sig[19]) begin
                    shift_amount = 5'b10;
                    normalized_sig = product_sig << 2;
                end else if (product_sig[18]) begin
                    shift_amount = 5'b11;
                    normalized_sig = product_sig << 3;
                end else begin
                    shift_amount = 5'b0;
                    normalized_sig = product_sig;
                end
                
                wire [6:0] exp_after_norm = exp_prod - {2'b0, shift_amount};
                
                // Rounding
                wire [9:0] mant_part = normalized_sig[20:11];
                wire G = normalized_sig[10];
                wire R = normalized_sig[9];
                wire S = |normalized_sig[8:0];
                
                wire round_up;
                if (G && (R || S)) begin
                    round_up = 1'b1;
                end else if (G && !(R || S) && mant_part[0]) begin
                    round_up = 1'b1;
                end else begin
                    round_up = 1'b0;
                end
                
                wire [10:0] rounded_mant = {1'b0, mant_part} + round_up;
                wire [9:0] final_mant;
                wire [6:0] final_exp;
                
                if (rounded_mant[10]) begin
                    final_mant = rounded_mant[10:1];
                    final_exp = exp_after_norm + 7'b1;
                end else begin
                    final_mant = rounded_mant[9:0];
                    final_exp = exp_after_norm;
                end
                
                // Final result
                if (final_exp[6] || (final_exp[5:0] > 6'b001111)) begin
                    computed_C <= {sign_prod, 5'b11111, 10'b0};
                end else if (final_exp[5:0] < 6'b000001) begin
                    computed_C <= {sign_prod, 5'b0, 10'b0};
                end else begin
                    computed_C <= {sign_prod, final_exp[4:0], final_mant};
                end
            end
        end
    end
    
    // Valid signal with 2-cycle delay
    reg [1:0] valid_pipeline;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_pipeline <= 2'b0;
            C <= 16'b0;
            Valid <= 1'b0;
        end else begin
            valid_pipeline <= {valid_pipeline[0], Ready};
            if (valid_pipeline[1]) begin
                C <= computed_C;
                Valid <= 1'b1;
            end else begin
                Valid <= 1'b0;
            end
        end
    end

endmodule