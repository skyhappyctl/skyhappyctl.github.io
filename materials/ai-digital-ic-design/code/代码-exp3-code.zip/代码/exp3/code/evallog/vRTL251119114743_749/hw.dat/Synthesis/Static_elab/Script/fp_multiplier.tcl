set_top -name {fp_multiplier} -src {Src/fp_multiplier.v} -lib work -type sverilog -ref -noecho 
