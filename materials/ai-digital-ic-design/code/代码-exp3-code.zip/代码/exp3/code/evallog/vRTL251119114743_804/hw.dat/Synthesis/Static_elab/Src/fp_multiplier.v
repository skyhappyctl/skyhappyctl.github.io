// SourceInfo: /home/aieda_stu36/THU_AI_EDA-main/exp3/evallog/vRTL251119114743_804/vRTL251119114743_804.v:1
`default_nettype wire

module fp_multiplier (
    input clk /* verific hw_Asychronous_control_signal="true" */ , 
    input rst_n /* verific hw_Asychronous_control_signal="true" */ , 
    input [15:0] A, 
    input [15:0] B, 
    input Ready, 
    output reg [15:0] C, 
    output reg Valid) ;
    reg [15:0] computed_C ; 
    wire sign_A = A[15] ; 
    wire [4:0] exp_A = A[14:10] ; 
    wire [9:0] mant_A = A[9:0] ; 
    wire sign_B = B[15] ; 
    wire [4:0] exp_B = B[14:10] ; 
    wire [9:0] mant_B = B[9:0] ; 
    wire is_nan_A = ((exp_A == 5'b11111) && (mant_A != 10'b0)) ; 
    wire is_inf_A = ((exp_A == 5'b11111) && (mant_A == 10'b0)) ; 
    wire is_zero_A = ((exp_A == 5'b0) && (mant_A == 10'b0)) ; 
    wire is_nan_B = ((exp_B == 5'b11111) && (mant_B != 10'b0)) ; 
    wire is_inf_B = ((exp_B == 5'b11111) && (mant_B == 10'b0)) ; 
    wire is_zero_B = ((exp_B == 5'b0) && (mant_B == 10'b0)) ; 
    wire [10:0] sig_A = ((exp_A == 5'b0) ? {1'b0,mant_A} : {1'b1,mant_A}) ; 
    wire [10:0] sig_B = ((exp_B == 5'b0) ? {1'b0,mant_B} : {1'b1,mant_B}) ; 
    wire [21:0] product_sig = (sig_A * sig_B) ; 
    wire [5:0] exp_A_adj = ((exp_A == 5'b0) ? 6'b100001 : {1'b0,exp_A}) ; 
    wire [5:0] exp_B_adj = ((exp_B == 5'b0) ? 6'b100001 : {1'b0,exp_B}) ; 
    wire [6:0] exp_sum = (exp_A_adj + exp_B_adj) ; 
    wire [6:0] exp_prod = (exp_sum - 7'b011110) ; 
    reg [21:0] product_sig_reg_uv_rename ; 
    reg [6:0] exp_prod_reg_uv_rename ; 
    reg sign_prod_reg_uv_rename ; 
    reg [2:0] special_case_reg_uv_rename ; 
    always
        @(posedge clk or negedge rst_n)
        begin
            if ((!rst_n)) 
                begin
                    product_sig_reg_uv_rename <=  22'b0 ;
                    exp_prod_reg_uv_rename <=  7'b0 ;
                    sign_prod_reg_uv_rename <=  1'b0 ;
                    special_case_reg_uv_rename <=  3'b0 ;
                end
            else
                if (Ready) 
                    begin
                        product_sig_reg_uv_rename <=  product_sig ;
                        exp_prod_reg_uv_rename <=  exp_prod ;
                        sign_prod_reg_uv_rename <=  (sign_A ^ sign_B) ;
                        if ((is_nan_A || is_nan_B)) 
                            begin
                                special_case_reg_uv_rename <=  3'b01 ;
                            end
                        else
                            if (((is_inf_A && is_zero_B) || (is_zero_A && is_inf_B))) 
                                begin
                                    special_case_reg_uv_rename <=  3'b01 ;
                                end
                            else
                                if ((is_inf_A || is_inf_B)) 
                                    begin
                                        special_case_reg_uv_rename <=  3'b010 ;
                                    end
                                else
                                    if ((is_zero_A || is_zero_B)) 
                                        begin
                                            special_case_reg_uv_rename <=  3'b011 ;
                                        end
                                    else
                                        begin
                                            special_case_reg_uv_rename <=  3'b100 ;
                                        end
                    end
        end
    wire [4:0] shift_amount ; 
    wire [21:0] normalized_sig ; 
    wire [6:0] exp_after_norm ; 
    wire [9:0] mant_part ; 
    wire G, R, S ; 
    wire round_up ; 
    wire [10:0] rounded_mant ; 
    wire [9:0] final_mant ; 
    wire [6:0] final_exp ; 
    assign shift_amount = (product_sig_reg_uv_rename[21] ? 5'b0 : (product_sig_reg_uv_rename[20] ? 5'b01 : (product_sig_reg_uv_rename[19] ? 5'b010 : (product_sig_reg_uv_rename[18] ? 5'b011 : 5'b0)))) ; 
    assign normalized_sig = (product_sig_reg_uv_rename << shift_amount) ; 
    assign exp_after_norm = (exp_prod_reg_uv_rename - {2'b0,shift_amount}) ; 
    assign mant_part = normalized_sig[20:11] ; 
    assign G = normalized_sig[10] ; 
    assign R = normalized_sig[9] ; 
    assign S = (|normalized_sig[8:0]) ; 
    assign round_up = (G && ((R || S) || mant_part[0])) ; 
    assign rounded_mant = ({1'b0,mant_part} + round_up) ; 
    assign final_mant = (rounded_mant[10] ? rounded_mant[10:1] : rounded_mant[9:0]) ; 
    assign final_exp = (rounded_mant[10] ? (exp_after_norm + 7'b01) : exp_after_norm) ; 
    always
        @(*)
        begin
            computed_C = 16'b0 ;
            case (special_case_reg_uv_rename)
            3'b01 : 
                computed_C = {1'b0,5'b11111,10'b01} ;
            3'b010 : 
                computed_C = {sign_prod_reg_uv_rename,5'b11111,10'b0} ;
            3'b011 : 
                computed_C = {sign_prod_reg_uv_rename,5'b0,10'b0} ;
            3'b100 : 
                begin
                    if ((final_exp[6] || (final_exp[5:0] > 6'b01111))) 
                        begin
                            computed_C = {sign_prod_reg_uv_rename,5'b11111,10'b0} ;
                        end
                    else
                        if ((final_exp[5:0] < 6'b01)) 
                            begin
                                computed_C = {sign_prod_reg_uv_rename,5'b0,10'b0} ;
                            end
                        else
                            begin
                                computed_C = {sign_prod_reg_uv_rename,final_exp[4:0],final_mant} ;
                            end
                end
            default : 
                computed_C = 16'b0 ;
            endcase 
        end
    always
        @(posedge clk or negedge rst_n)
        begin
            if ((!rst_n)) 
                begin
                    C <=  16'b0 ;
                    Valid <=  1'b0 ;
                end
            else
                begin
                    C <=  computed_C ;
                    Valid <=  Ready ;
                end
        end
endmodule


