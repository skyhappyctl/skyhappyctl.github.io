(* uvTop = "1" *)
(* dont_touch = "yes" *)
(* use_dsp = "no" *)
module fp_multiplier(clk, rst_n, A, B, Ready, C, Valid);
input [15:0] A;
input [15:0] B;
output [15:0] C;
input clk;
input rst_n;
input Ready;
output Valid;
endmodule
