(* uvDesignStatus = "1296" *)
(* uvTop = "1" *)
module fp_multiplier(clk, rst_n, Ready, Valid, A, B, C);

input [15 : 0] A;
input [15 : 0] B;
output [15 : 0] C;

input clk;
input rst_n;
input Ready;
output Valid;

wire n2;
wire n_189;
wire n_184;
wire n_185;
wire n_186;
wire n_187;
wire n_190;
wire n_188;
wire n_191;
wire n_101;
wire n_102;
wire n_157;
wire n_159;
wire n_158;
wire n_155;
wire n_156;
wire n_176;
wire n_140;
wire n_174;
wire n_141;
wire n_172;
wire n_139;
wire n_170;
wire n_168;
wire n_132;
wire n_166;
wire n_131;
wire n_128;
wire n_164;
wire n_126;
wire n_162;
wire n_149;
wire n_154;
wire n_148;
wire n_152;
wire n_98;
wire n_96;
wire n_99;
wire n_97;
wire n_92;
wire n_91;
wire n_93;
wire n_88;
wire n_87;
wire n_89;
wire n_94;
wire n_90;
wire n_100;
wire n_95;
wire n_85;
wire n_119;
wire n_138;
wire n_137;
wire n_136;
wire n_135;
wire n_144;
wire n_142;
wire n_145;
wire n_143;
wire n_129;
wire n_130;
wire n_84;
wire n_125;
wire n_122;
wire n_123;
wire n_79;
wire n_81;
wire n_82;
wire n_133;
wire n_127;
wire n_124;
wire n_83;
wire n_121;
wire n_150;
wire n_146;
wire n_134;
wire n_104;
wire n_113;
wire n_112;
wire n_107;
wire n_78;
wire n_109;
wire n_80;
wire n_106;
wire n_105;
wire n_147;
wire n_108;
wire n_110;
wire n_111;
wire n_114;
wire n_117;
wire n_115;
wire n_116;
wire n_120;
wire n_151;
wire n_118;
wire n_160;
wire n_103;
wire n_86;
wire n_153;
wire n_76;
wire n_74;
wire \computed_C[15] ;
wire \computed_C[14] ;
wire \computed_C[13] ;
wire \computed_C[12] ;
wire \computed_C[11] ;
wire \computed_C[10] ;
wire \computed_C[9] ;
wire \computed_C[8] ;
wire \computed_C[7] ;
wire \computed_C[6] ;
wire \computed_C[5] ;
wire \computed_C[4] ;
wire \computed_C[3] ;
wire \computed_C[2] ;
wire \computed_C[1] ;
wire \computed_C[0] ;
wire \product_sig[21] ;
wire \product_sig[20] ;
wire \product_sig[19] ;
wire \product_sig[18] ;
wire \product_sig[17] ;
wire \product_sig[16] ;
wire \product_sig[15] ;
wire \product_sig[14] ;
wire \product_sig[13] ;
wire \product_sig[12] ;
wire \product_sig[11] ;
wire \product_sig[10] ;
wire \product_sig[9] ;
wire \product_sig[8] ;
wire \product_sig[7] ;
wire \product_sig[6] ;
wire \product_sig[5] ;
wire \product_sig[4] ;
wire \product_sig[3] ;
wire \product_sig[2] ;
wire \product_sig[1] ;
wire \product_sig[0] ;
wire \sig_A[10] ;
wire \sig_B[10] ;
wire Valid;
wire Ready;
wire rst_n;
wire clk;
wire [15 : 0] A;
wire [15 : 0] B;
wire [15 : 0] C;


LUT3 #(.INIT(8'h40))
uv_inst_839(.I0(n_80), .I1(n_82), .I2(n_81), .O(n_189));
LUT3 #(.INIT(8'he))
uv_inst_840(.I0(\product_sig[7] ), .I1(\product_sig[8] ), .I2(n_78), .O(n_185));
LUT3 #(.INIT(8'h10))
uv_inst_841(.I0(n_185), .I1(\product_sig[5] ), .I2(n_184), .O(n_186));
LUT3 #(.INIT(8'hd0))
uv_inst_842(.I0(n_89), .I1(n_94), .I2(n_97), .O(n_101));
LUT3 #(.INIT(8'h60))
uv_inst_843(.I0(A[15]), .I1(B[15]), .I2(n_102), .O(\computed_C[15] ));
LUT3 #(.INIT(8'h8f))
uv_inst_844(.I0(n_95), .I1(n_153), .I2(n_100), .O(\computed_C[14] ));
LUT2 #(.INIT(4'h6))
uv_inst_845(.I0(n_157), .I1(n_148), .O(n_159));
LUT3 #(.INIT(8'h78))
uv_inst_846(.I0(n_134), .I1(n_146), .I2(n_121), .O(n_155));
LUT2 #(.INIT(4'h9))
uv_inst_847(.I0(n_152), .I1(n_143), .O(n_156));
LUT3 #(.INIT(8'h70))
uv_inst_848(.I0(n_142), .I1(n_134), .I2(n_145), .O(n_176));
LUT3 #(.INIT(8'h53))
uv_inst_849(.I0(n_138), .I1(n_135), .I2(n_80), .O(n_140));
LUT3 #(.INIT(8'hc5))
uv_inst_850(.I0(n_138), .I1(n_137), .I2(n_80), .O(n_141));
LUT3 #(.INIT(8'hb4))
uv_inst_851(.I0(n_139), .I1(n_134), .I2(n_141), .O(n_172));
LUT3 #(.INIT(8'hca))
uv_inst_852(.I0(n_137), .I1(n_123), .I2(n_80), .O(n_139));
LUT2 #(.INIT(4'h6))
uv_inst_853(.I0(n_134), .I1(n_139), .O(n_170));
LUT3 #(.INIT(8'hd))
uv_inst_854(.I0(n_80), .I1(n_129), .I2(n_130), .O(n_132));
LUT3 #(.INIT(8'h4b))
uv_inst_855(.I0(n_131), .I1(n_128), .I2(n_132), .O(n_166));
LUT3 #(.INIT(8'hca))
uv_inst_856(.I0(n_129), .I1(n_125), .I2(n_80), .O(n_131));
LUT2 #(.INIT(4'h8))
uv_inst_857(.I0(n_83), .I1(n_127), .O(n_128));
LUT2 #(.INIT(4'h6))
uv_inst_858(.I0(n_128), .I1(n_131), .O(n_164));
LUT3 #(.INIT(8'hca))
uv_inst_859(.I0(n_125), .I1(n_84), .I2(n_80), .O(n_126));
LUT3 #(.INIT(8'h4b))
uv_inst_860(.I0(n_85), .I1(n_83), .I2(n_126), .O(n_162));
LUT3 #(.INIT(8'h96))
uv_inst_861(.I0(n_111), .I1(n_108), .I2(n_110), .O(n_149));
LUT3 #(.INIT(8'h40))
uv_inst_862(.I0(n_121), .I1(n_149), .I2(n_143), .O(n_154));
LUT3 #(.INIT(8'h40))
uv_inst_863(.I0(n_145), .I1(n_142), .I2(n_134), .O(n_152));
LUT2 #(.INIT(4'h8))
uv_inst_864(.I0(n_98), .I1(A[14]), .O(n_99));
LUT2 #(.INIT(4'h8))
uv_inst_865(.I0(n_96), .I1(B[14]), .O(n_97));
LUT2 #(.INIT(4'h1))
uv_inst_866(.I0(n_97), .I1(n_99), .O(n_100));
LUT2 #(.INIT(4'h4))
uv_inst_867(.I0(\sig_A[10] ), .I1(n_93), .O(n_94));
LUT2 #(.INIT(4'h4))
uv_inst_868(.I0(\sig_B[10] ), .I1(n_89), .O(n_90));
LUT2 #(.INIT(4'h1))
uv_inst_869(.I0(n_90), .I1(n_94), .O(n_95));
LUT2 #(.INIT(4'h8))
uv_inst_870(.I0(n_95), .I1(n_100), .O(n_103));
LUT3 #(.INIT(8'hca))
uv_inst_871(.I0(n_84), .I1(n_82), .I2(n_80), .O(n_85));
LUT2 #(.INIT(4'h6))
uv_inst_872(.I0(n_83), .I1(n_85), .O(n_86));
LUT3 #(.INIT(8'hbd))
uv_inst_873(.I0(n_107), .I1(A[14]), .I2(B[14]), .O(n_119));
LUT3 #(.INIT(8'h96))
uv_inst_874(.I0(\sig_A[10] ), .I1(\sig_B[10] ), .I2(n_119), .O(n_120));
LUT3 #(.INIT(8'h41))
uv_inst_875(.I0(n_147), .I1(n_110), .I2(n_108), .O(n_150));
LUT3 #(.INIT(8'hca))
uv_inst_876(.I0(\product_sig[18] ), .I1(\product_sig[16] ), .I2(n_78), .O(n_138));
LUT3 #(.INIT(8'h35))
uv_inst_877(.I0(\product_sig[17] ), .I1(\product_sig[15] ), .I2(n_78), .O(n_137));
LUT3 #(.INIT(8'h7))
uv_inst_878(.I0(\product_sig[19] ), .I1(\product_sig[17] ), .I2(n_80), .O(n_136));
LUT3 #(.INIT(8'hca))
uv_inst_879(.I0(\product_sig[19] ), .I1(\product_sig[17] ), .I2(n_78), .O(n_135));
LUT3 #(.INIT(8'hd))
uv_inst_880(.I0(\product_sig[18] ), .I1(\product_sig[21] ), .I2(\product_sig[20] ), .O(n_144));
LUT3 #(.INIT(8'h3a))
uv_inst_881(.I0(n_144), .I1(n_135), .I2(n_80), .O(n_145));
LUT3 #(.INIT(8'h69))
uv_inst_882(.I0(n_105), .I1(n_106), .I2(n_80), .O(n_143));
LUT3 #(.INIT(8'h10))
uv_inst_883(.I0(n_143), .I1(n_145), .I2(n_142), .O(n_146));
LUT3 #(.INIT(8'h35))
uv_inst_884(.I0(\product_sig[14] ), .I1(\product_sig[12] ), .I2(n_78), .O(n_129));
LUT3 #(.INIT(8'h35))
uv_inst_885(.I0(\product_sig[12] ), .I1(\product_sig[10] ), .I2(n_78), .O(n_84));
LUT3 #(.INIT(8'h35))
uv_inst_886(.I0(\product_sig[13] ), .I1(\product_sig[11] ), .I2(n_78), .O(n_125));
LUT3 #(.INIT(8'h35))
uv_inst_887(.I0(\product_sig[15] ), .I1(\product_sig[13] ), .I2(n_78), .O(n_122));
LUT3 #(.INIT(8'h35))
uv_inst_888(.I0(\product_sig[16] ), .I1(\product_sig[14] ), .I2(n_78), .O(n_123));
LUT3 #(.INIT(8'h35))
uv_inst_889(.I0(n_123), .I1(n_122), .I2(n_80), .O(n_124));
LUT3 #(.INIT(8'h35))
uv_inst_890(.I0(\product_sig[10] ), .I1(\product_sig[8] ), .I2(n_78), .O(n_79));
LUT3 #(.INIT(8'h35))
uv_inst_891(.I0(\product_sig[9] ), .I1(\product_sig[7] ), .I2(n_78), .O(n_81));
LUT3 #(.INIT(8'h35))
uv_inst_892(.I0(\product_sig[11] ), .I1(\product_sig[9] ), .I2(n_78), .O(n_82));
LUT2 #(.INIT(4'h4))
uv_inst_893(.I0(n_112), .I1(n_113), .O(n_114));
LUT2 #(.INIT(4'h9))
uv_inst_894(.I0(A[14]), .I1(B[14]), .O(n_104));
LUT3 #(.INIT(8'h69))
uv_inst_895(.I0(n_107), .I1(A[13]), .I2(B[13]), .O(n_113));
LUT3 #(.INIT(8'he8))
uv_inst_896(.I0(n_107), .I1(A[12]), .I2(B[12]), .O(n_112));
LUT2 #(.INIT(4'h6))
uv_inst_897(.I0(n_112), .I1(n_113), .O(n_147));
LUT3 #(.INIT(8'h69))
uv_inst_898(.I0(n_107), .I1(A[12]), .I2(B[12]), .O(n_108));
LUT2 #(.INIT(4'h1))
uv_inst_899(.I0(n_74), .I1(A[10]), .O(n_106));
LUT2 #(.INIT(4'h1))
uv_inst_900(.I0(n_76), .I1(B[10]), .O(n_105));
LUT2 #(.INIT(4'hb))
uv_inst_901(.I0(B[10]), .I1(n_76), .O(\sig_B[10] ));
LUT2 #(.INIT(4'hb))
uv_inst_902(.I0(A[10]), .I1(n_74), .O(\sig_A[10] ));
dsp_single_mult_11u_11u_22 mult_252(.a({\sig_A[10] , 
A[9], 
A[8], 
A[7], 
A[6], 
A[5], 
A[4], 
A[3], 
A[2], 
A[1], 
A[0]}), 
.b({\sig_B[10] , 
B[9], 
B[8], 
B[7], 
B[6], 
B[5], 
B[4], 
B[3], 
B[2], 
B[1], 
B[0]}), 
.o({\product_sig[21] , 
\product_sig[20] , 
\product_sig[19] , 
\product_sig[18] , 
\product_sig[17] , 
\product_sig[16] , 
\product_sig[15] , 
\product_sig[14] , 
\product_sig[13] , 
\product_sig[12] , 
\product_sig[11] , 
\product_sig[10] , 
\product_sig[9] , 
\product_sig[8] , 
\product_sig[7] , 
\product_sig[6] , 
\product_sig[5] , 
\product_sig[4] , 
\product_sig[3] , 
\product_sig[2] , 
\product_sig[1] , 
\product_sig[0] }));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_1_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[1] ), .Q(C[1]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_2_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[2] ), .Q(C[2]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_3_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[3] ), .Q(C[3]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_4_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[4] ), .Q(C[4]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_5_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[5] ), .Q(C[5]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_6_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[6] ), .Q(C[6]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_7_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[7] ), .Q(C[7]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_8_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[8] ), .Q(C[8]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_9_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[9] ), .Q(C[9]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_10_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[10] ), .Q(C[10]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_11_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[11] ), .Q(C[11]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_12_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[12] ), .Q(C[12]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_13_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[13] ), .Q(C[13]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_14_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[14] ), .Q(C[14]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_15_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[15] ), .Q(C[15]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
C_reg_0_(.C(clk), .CE(Ready), .CLR(rst_n), .D(\computed_C[0] ), .Q(C[0]));
FDCE #(.INIT(1'h0), .IS_CLR_INVERTED(1'b1))
Valid_reg(.C(clk), .CE(n2), .CLR(rst_n), .D(Ready), .Q(Valid));
VCC n2_uv_inst_837(.P(n2));
LUT4 #(.INIT(16'h1000))
uv_inst_835(.I0(\product_sig[6] ), .I1(\product_sig[1] ), .I2(n_186), .I3(n_189), .O(n_190));
LUT4 #(.INIT(16'h1))
uv_inst_834(.I0(\product_sig[4] ), .I1(\product_sig[3] ), .I2(\product_sig[2] ), .I3(\product_sig[0] ), .O(n_184));
LUT4 #(.INIT(16'hef))
uv_inst_831(.I0(\product_sig[6] ), .I1(\product_sig[1] ), .I2(n_186), .I3(n_81), .O(n_187));
LUT4 #(.INIT(16'h3a00))
uv_inst_830(.I0(n_82), .I1(n_187), .I2(n_80), .I3(n_79), .O(n_188));
LUT4 #(.INIT(16'h100))
uv_inst_829(.I0(n_188), .I1(n_190), .I2(n_83), .I3(n_103), .O(n_191));
LUT4 #(.INIT(16'h40ff))
\computed_C[0]_uv_inst_828 (.I0(n_153), .I1(n_191), .I2(n_160), .I3(n_102), .O(\computed_C[0] ));
LUT4 #(.INIT(16'h4f))
uv_inst_826(.I0(n_90), .I1(n_93), .I2(n_99), .I3(n_101), .O(n_102));
LUT4 #(.INIT(16'h4000))
uv_inst_823(.I0(n_149), .I1(n_146), .I2(n_134), .I3(n_121), .O(n_157));
LUT4 #(.INIT(16'he0ff))
\computed_C[13]_uv_inst_821 (.I0(n_159), .I1(n_153), .I2(n_95), .I3(n_100), .O(\computed_C[13] ));
LUT4 #(.INIT(16'h807f))
uv_inst_820(.I0(n_134), .I1(n_146), .I2(n_121), .I3(n_149), .O(n_158));
LUT4 #(.INIT(16'he0ff))
\computed_C[12]_uv_inst_819 (.I0(n_158), .I1(n_153), .I2(n_95), .I3(n_100), .O(\computed_C[12] ));
LUT4 #(.INIT(16'he0ff))
\computed_C[11]_uv_inst_817 (.I0(n_155), .I1(n_153), .I2(n_95), .I3(n_100), .O(\computed_C[11] ));
LUT4 #(.INIT(16'he0ff))
\computed_C[10]_uv_inst_815 (.I0(n_156), .I1(n_153), .I2(n_95), .I3(n_100), .O(\computed_C[10] ));
LUT4 #(.INIT(16'h1000))
\computed_C[9]_uv_inst_813 (.I0(n_153), .I1(n_176), .I2(n_103), .I3(n_160), .O(\computed_C[9] ));
LUT4 #(.INIT(16'hef10))
uv_inst_811(.I0(n_139), .I1(n_141), .I2(n_134), .I3(n_140), .O(n_174));
LUT4 #(.INIT(16'h1000))
\computed_C[8]_uv_inst_810 (.I0(n_153), .I1(n_174), .I2(n_103), .I3(n_160), .O(\computed_C[8] ));
LUT4 #(.INIT(16'h1000))
\computed_C[7]_uv_inst_807 (.I0(n_153), .I1(n_172), .I2(n_103), .I3(n_160), .O(\computed_C[7] ));
LUT4 #(.INIT(16'h1000))
\computed_C[6]_uv_inst_804 (.I0(n_153), .I1(n_170), .I2(n_103), .I3(n_160), .O(\computed_C[6] ));
LUT4 #(.INIT(16'h807f))
uv_inst_803(.I0(n_83), .I1(n_127), .I2(n_133), .I3(n_124), .O(n_168));
LUT4 #(.INIT(16'h1000))
\computed_C[5]_uv_inst_802 (.I0(n_153), .I1(n_168), .I2(n_103), .I3(n_160), .O(\computed_C[5] ));
LUT4 #(.INIT(16'h4000))
\computed_C[4]_uv_inst_799 (.I0(n_153), .I1(n_160), .I2(n_103), .I3(n_166), .O(\computed_C[4] ));
LUT4 #(.INIT(16'h1000))
\computed_C[3]_uv_inst_795 (.I0(n_153), .I1(n_164), .I2(n_103), .I3(n_160), .O(\computed_C[3] ));
LUT4 #(.INIT(16'h4000))
\computed_C[2]_uv_inst_792 (.I0(n_153), .I1(n_160), .I2(n_103), .I3(n_162), .O(\computed_C[2] ));
LUT4 #(.INIT(16'h8e71))
uv_inst_789(.I0(n_111), .I1(n_110), .I2(n_108), .I3(n_147), .O(n_148));
LUT4 #(.INIT(16'hef))
uv_inst_787(.I0(n_152), .I1(n_148), .I2(n_154), .I3(n_151), .O(n_160));
LUT4 #(.INIT(16'h8000))
uv_inst_786(.I0(A[13]), .I1(A[12]), .I2(A[11]), .I3(A[10]), .O(n_98));
LUT4 #(.INIT(16'h8000))
uv_inst_784(.I0(B[13]), .I1(B[12]), .I2(B[11]), .I3(B[10]), .O(n_96));
LUT4 #(.INIT(16'h1))
uv_inst_781(.I0(A[9]), .I1(A[8]), .I2(A[7]), .I3(A[6]), .O(n_92));
LUT4 #(.INIT(16'h1))
uv_inst_780(.I0(A[3]), .I1(A[2]), .I2(A[1]), .I3(A[0]), .O(n_91));
LUT4 #(.INIT(16'h1000))
uv_inst_779(.I0(A[5]), .I1(A[4]), .I2(n_91), .I3(n_92), .O(n_93));
LUT4 #(.INIT(16'h1))
uv_inst_777(.I0(B[9]), .I1(B[8]), .I2(B[7]), .I3(B[6]), .O(n_88));
LUT4 #(.INIT(16'h1))
uv_inst_776(.I0(B[3]), .I1(B[2]), .I2(B[1]), .I3(B[0]), .O(n_87));
LUT4 #(.INIT(16'h1000))
uv_inst_775(.I0(B[5]), .I1(B[4]), .I2(n_87), .I3(n_88), .O(n_89));
LUT4 #(.INIT(16'h8e71))
uv_inst_767(.I0(n_105), .I1(n_106), .I2(n_80), .I3(n_109), .O(n_121));
LUT4 #(.INIT(16'h10))
uv_inst_762(.I0(n_136), .I1(n_137), .I2(n_138), .I3(n_123), .O(n_142));
LUT4 #(.INIT(16'hc0a))
uv_inst_755(.I0(\product_sig[15] ), .I1(\product_sig[13] ), .I2(n_80), .I3(n_78), .O(n_130));
LUT4 #(.INIT(16'hf4))
uv_inst_754(.I0(n_125), .I1(n_80), .I2(n_130), .I3(n_129), .O(n_133));
LUT4 #(.INIT(16'h305))
uv_inst_751(.I0(n_125), .I1(n_82), .I2(n_84), .I3(n_80), .O(n_127));
LUT4 #(.INIT(16'h305))
uv_inst_744(.I0(n_82), .I1(n_81), .I2(n_79), .I3(n_80), .O(n_83));
LUT4 #(.INIT(16'h8000))
uv_inst_743(.I0(n_83), .I1(n_124), .I2(n_127), .I3(n_133), .O(n_134));
LUT4 #(.INIT(16'h8000))
uv_inst_742(.I0(n_134), .I1(n_146), .I2(n_150), .I3(n_121), .O(n_151));
LUT4 #(.INIT(16'h1ff7))
uv_inst_740(.I0(A[13]), .I1(B[13]), .I2(n_104), .I3(n_107), .O(n_117));
LUT4 #(.INIT(16'hfe8f))
uv_inst_738(.I0(A[13]), .I1(B[13]), .I2(n_104), .I3(n_107), .O(n_116));
LUT4 #(.INIT(16'h100))
uv_inst_734(.I0(\product_sig[21] ), .I1(\product_sig[20] ), .I2(\product_sig[19] ), .I3(\product_sig[18] ), .O(n_107));
LUT4 #(.INIT(16'he88e))
uv_inst_732(.I0(A[11]), .I1(B[11]), .I2(n_78), .I3(n_80), .O(n_110));
LUT4 #(.INIT(16'he))
uv_inst_731(.I0(\product_sig[18] ), .I1(\product_sig[19] ), .I2(\product_sig[21] ), .I3(\product_sig[20] ), .O(n_78));
LUT4 #(.INIT(16'h9669))
uv_inst_730(.I0(n_78), .I1(n_80), .I2(A[11]), .I3(B[11]), .O(n_109));
LUT4 #(.INIT(16'hf4))
uv_inst_729(.I0(\product_sig[19] ), .I1(\product_sig[18] ), .I2(\product_sig[20] ), .I3(\product_sig[21] ), .O(n_80));
LUT4 #(.INIT(16'h7100))
uv_inst_726(.I0(n_105), .I1(n_106), .I2(n_80), .I3(n_109), .O(n_111));
LUT4 #(.INIT(16'h71))
uv_inst_725(.I0(n_111), .I1(n_110), .I2(n_108), .I3(n_147), .O(n_115));
LUT4 #(.INIT(16'hc095))
uv_inst_724(.I0(n_115), .I1(n_116), .I2(n_117), .I3(n_114), .O(n_118));
LUT4 #(.INIT(16'h6f7e))
uv_inst_723(.I0(n_118), .I1(n_151), .I2(n_120), .I3(n_116), .O(n_153));
LUT4 #(.INIT(16'h1000))
\computed_C[1]_uv_inst_722 (.I0(n_153), .I1(n_86), .I2(n_103), .I3(n_160), .O(\computed_C[1] ));
LUT4 #(.INIT(16'h1))
uv_inst_721(.I0(B[14]), .I1(B[13]), .I2(B[12]), .I3(B[11]), .O(n_76));
LUT4 #(.INIT(16'h1))
uv_inst_719(.I0(A[14]), .I1(A[13]), .I2(A[12]), .I3(A[11]), .O(n_74));

endmodule

module dsp_single_mult_11u_11u_22(a, b, o);

input [10 : 0] a;
input [10 : 0] b;
output [21 : 0] o;


wire n2;
wire uv_net_0;
wire uv_net_1;
wire uv_net_2;
wire uv_net_3;
wire uv_net_4;
wire uv_net_5;
wire uv_net_6;
wire uv_net_7;
wire uv_net_8;
wire uv_net_9;
wire uv_net_10;
wire uv_net_11;
wire uv_net_12;
wire uv_net_13;
wire uv_net_14;
wire uv_net_15;
wire uv_net_16;
wire uv_net_17;
wire uv_net_18;
wire uv_net_19;
wire uv_net_20;
wire uv_net_21;
wire uv_net_22;
wire uv_net_23;
wire uv_net_24;
wire uv_net_25;
wire uv_net_26;
wire uv_net_27;
wire uv_net_28;
wire uv_net_29;
wire uv_net_60;
wire uv_net_61;
wire uv_net_62;
wire uv_net_63;
wire uv_net_64;
wire uv_net_65;
wire uv_net_66;
wire uv_net_67;
wire uv_net_68;
wire uv_net_69;
wire uv_net_70;
wire uv_net_71;
wire uv_net_72;
wire uv_net_73;
wire uv_net_74;
wire uv_net_75;
wire uv_net_76;
wire uv_net_77;
wire uv_net_96;
wire uv_net_97;
wire uv_net_98;
wire uv_net_99;
wire uv_net_100;
wire uv_net_101;
wire uv_net_102;
wire uv_net_103;
wire uv_net_104;
wire uv_net_105;
wire uv_net_106;
wire uv_net_107;
wire uv_net_108;
wire uv_net_109;
wire uv_net_110;
wire uv_net_111;
wire uv_net_112;
wire uv_net_113;
wire uv_net_114;
wire uv_net_115;
wire uv_net_116;
wire uv_net_117;
wire uv_net_118;
wire uv_net_119;
wire uv_net_120;
wire uv_net_121;
wire uv_net_122;
wire uv_net_123;
wire uv_net_124;
wire uv_net_125;
wire uv_net_126;
wire uv_net_127;
wire uv_net_128;
wire uv_net_129;
wire uv_net_130;
wire uv_net_131;
wire uv_net_132;
wire uv_net_133;
wire uv_net_134;
wire uv_net_135;
wire uv_net_136;
wire uv_net_137;
wire uv_net_138;
wire uv_net_139;
wire uv_net_140;
wire uv_net_141;
wire uv_net_142;
wire uv_net_143;
wire [10 : 0] a;
wire [10 : 0] b;
wire [21 : 0] o;


GND uv_net_143_uv_inst_193(.G(uv_net_143));
DSP48_MULT_27X18_CAS_NONE_0 mult_0_mult_slice_10_0_10_00(.A_IN({n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
a[10], 
a[9], 
a[8], 
a[7], 
a[6], 
a[5], 
a[4], 
a[3], 
a[2], 
a[1], 
a[0]}), 
.A_CIN({uv_net_0, 
uv_net_1, 
uv_net_2, 
uv_net_3, 
uv_net_4, 
uv_net_5, 
uv_net_6, 
uv_net_7, 
uv_net_8, 
uv_net_9, 
uv_net_10, 
uv_net_11, 
uv_net_12, 
uv_net_13, 
uv_net_14, 
uv_net_15, 
uv_net_16, 
uv_net_17, 
uv_net_18, 
uv_net_19, 
uv_net_20, 
uv_net_21, 
uv_net_22, 
uv_net_23, 
uv_net_24, 
uv_net_25, 
uv_net_26, 
uv_net_27, 
uv_net_28, 
uv_net_29}), 
.B_IN({n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
n2, 
b[10], 
b[9], 
b[8], 
b[7], 
b[6], 
b[5], 
b[4], 
b[3], 
b[2], 
b[1], 
b[0]}), 
.B_CIN({uv_net_60, 
uv_net_61, 
uv_net_62, 
uv_net_63, 
uv_net_64, 
uv_net_65, 
uv_net_66, 
uv_net_67, 
uv_net_68, 
uv_net_69, 
uv_net_70, 
uv_net_71, 
uv_net_72, 
uv_net_73, 
uv_net_74, 
uv_net_75, 
uv_net_76, 
uv_net_77}), 
.P_OUT({UV_unconnected_hier0_P_OUT_47, 
UV_unconnected_hier0_P_OUT_46, 
UV_unconnected_hier0_P_OUT_45, 
UV_unconnected_hier0_P_OUT_44, 
UV_unconnected_hier0_P_OUT_43, 
UV_unconnected_hier0_P_OUT_42, 
UV_unconnected_hier0_P_OUT_41, 
UV_unconnected_hier0_P_OUT_40, 
UV_unconnected_hier0_P_OUT_39, 
UV_unconnected_hier0_P_OUT_38, 
UV_unconnected_hier0_P_OUT_37, 
UV_unconnected_hier0_P_OUT_36, 
UV_unconnected_hier0_P_OUT_35, 
UV_unconnected_hier0_P_OUT_34, 
UV_unconnected_hier0_P_OUT_33, 
UV_unconnected_hier0_P_OUT_32, 
UV_unconnected_hier0_P_OUT_31, 
UV_unconnected_hier0_P_OUT_30, 
UV_unconnected_hier0_P_OUT_29, 
UV_unconnected_hier0_P_OUT_28, 
UV_unconnected_hier0_P_OUT_27, 
UV_unconnected_hier0_P_OUT_26, 
UV_unconnected_hier0_P_OUT_25, 
UV_unconnected_hier0_P_OUT_24, 
UV_unconnected_hier0_P_OUT_23, 
UV_unconnected_hier0_P_OUT_22, 
o[21], 
o[20], 
o[19], 
o[18], 
o[17], 
o[16], 
o[15], 
o[14], 
o[13], 
o[12], 
o[11], 
o[10], 
o[9], 
o[8], 
o[7], 
o[6], 
o[5], 
o[4], 
o[3], 
o[2], 
o[1], 
o[0]}), 
.P_CIN({uv_net_96, 
uv_net_97, 
uv_net_98, 
uv_net_99, 
uv_net_100, 
uv_net_101, 
uv_net_102, 
uv_net_103, 
uv_net_104, 
uv_net_105, 
uv_net_106, 
uv_net_107, 
uv_net_108, 
uv_net_109, 
uv_net_110, 
uv_net_111, 
uv_net_112, 
uv_net_113, 
uv_net_114, 
uv_net_115, 
uv_net_116, 
uv_net_117, 
uv_net_118, 
uv_net_119, 
uv_net_120, 
uv_net_121, 
uv_net_122, 
uv_net_123, 
uv_net_124, 
uv_net_125, 
uv_net_126, 
uv_net_127, 
uv_net_128, 
uv_net_129, 
uv_net_130, 
uv_net_131, 
uv_net_132, 
uv_net_133, 
uv_net_134, 
uv_net_135, 
uv_net_136, 
uv_net_137, 
uv_net_138, 
uv_net_139, 
uv_net_140, 
uv_net_141, 
uv_net_142, 
uv_net_143}));
GND uv_net_142_uv_inst_192(.G(uv_net_142));
GND uv_net_141_uv_inst_191(.G(uv_net_141));
GND uv_net_140_uv_inst_190(.G(uv_net_140));
GND uv_net_139_uv_inst_189(.G(uv_net_139));
GND uv_net_138_uv_inst_188(.G(uv_net_138));
GND uv_net_137_uv_inst_187(.G(uv_net_137));
GND uv_net_136_uv_inst_186(.G(uv_net_136));
GND uv_net_135_uv_inst_185(.G(uv_net_135));
GND uv_net_134_uv_inst_184(.G(uv_net_134));
GND uv_net_133_uv_inst_183(.G(uv_net_133));
GND uv_net_132_uv_inst_182(.G(uv_net_132));
GND uv_net_131_uv_inst_181(.G(uv_net_131));
GND uv_net_130_uv_inst_180(.G(uv_net_130));
GND uv_net_129_uv_inst_179(.G(uv_net_129));
GND uv_net_128_uv_inst_178(.G(uv_net_128));
GND uv_net_127_uv_inst_177(.G(uv_net_127));
GND uv_net_126_uv_inst_176(.G(uv_net_126));
GND uv_net_125_uv_inst_175(.G(uv_net_125));
GND uv_net_124_uv_inst_174(.G(uv_net_124));
GND uv_net_123_uv_inst_173(.G(uv_net_123));
GND uv_net_122_uv_inst_172(.G(uv_net_122));
GND uv_net_121_uv_inst_171(.G(uv_net_121));
GND uv_net_120_uv_inst_170(.G(uv_net_120));
GND uv_net_119_uv_inst_169(.G(uv_net_119));
GND uv_net_118_uv_inst_168(.G(uv_net_118));
GND uv_net_117_uv_inst_167(.G(uv_net_117));
GND uv_net_116_uv_inst_166(.G(uv_net_116));
GND uv_net_115_uv_inst_165(.G(uv_net_115));
GND uv_net_114_uv_inst_164(.G(uv_net_114));
GND uv_net_113_uv_inst_163(.G(uv_net_113));
GND uv_net_112_uv_inst_162(.G(uv_net_112));
GND uv_net_111_uv_inst_161(.G(uv_net_111));
GND uv_net_110_uv_inst_160(.G(uv_net_110));
GND uv_net_109_uv_inst_159(.G(uv_net_109));
GND uv_net_108_uv_inst_158(.G(uv_net_108));
GND uv_net_107_uv_inst_157(.G(uv_net_107));
GND uv_net_106_uv_inst_156(.G(uv_net_106));
GND uv_net_105_uv_inst_155(.G(uv_net_105));
GND uv_net_104_uv_inst_154(.G(uv_net_104));
GND uv_net_103_uv_inst_153(.G(uv_net_103));
GND uv_net_102_uv_inst_152(.G(uv_net_102));
GND uv_net_101_uv_inst_151(.G(uv_net_101));
GND uv_net_100_uv_inst_150(.G(uv_net_100));
GND uv_net_99_uv_inst_149(.G(uv_net_99));
GND uv_net_98_uv_inst_148(.G(uv_net_98));
GND uv_net_97_uv_inst_147(.G(uv_net_97));
GND uv_net_96_uv_inst_146(.G(uv_net_96));
GND uv_net_77_uv_inst_145(.G(uv_net_77));
GND uv_net_76_uv_inst_144(.G(uv_net_76));
GND uv_net_75_uv_inst_143(.G(uv_net_75));
GND uv_net_74_uv_inst_142(.G(uv_net_74));
GND uv_net_73_uv_inst_141(.G(uv_net_73));
GND uv_net_72_uv_inst_140(.G(uv_net_72));
GND uv_net_71_uv_inst_139(.G(uv_net_71));
GND uv_net_70_uv_inst_138(.G(uv_net_70));
GND uv_net_69_uv_inst_137(.G(uv_net_69));
GND uv_net_68_uv_inst_136(.G(uv_net_68));
GND uv_net_67_uv_inst_135(.G(uv_net_67));
GND uv_net_66_uv_inst_134(.G(uv_net_66));
GND uv_net_65_uv_inst_133(.G(uv_net_65));
GND uv_net_64_uv_inst_132(.G(uv_net_64));
GND uv_net_63_uv_inst_131(.G(uv_net_63));
GND uv_net_62_uv_inst_130(.G(uv_net_62));
GND uv_net_61_uv_inst_129(.G(uv_net_61));
GND uv_net_60_uv_inst_128(.G(uv_net_60));
GND uv_net_29_uv_inst_127(.G(uv_net_29));
GND uv_net_28_uv_inst_126(.G(uv_net_28));
GND uv_net_27_uv_inst_125(.G(uv_net_27));
GND uv_net_26_uv_inst_124(.G(uv_net_26));
GND uv_net_25_uv_inst_123(.G(uv_net_25));
GND uv_net_24_uv_inst_122(.G(uv_net_24));
GND uv_net_23_uv_inst_121(.G(uv_net_23));
GND uv_net_22_uv_inst_120(.G(uv_net_22));
GND uv_net_21_uv_inst_119(.G(uv_net_21));
GND uv_net_20_uv_inst_118(.G(uv_net_20));
GND uv_net_19_uv_inst_117(.G(uv_net_19));
GND uv_net_18_uv_inst_116(.G(uv_net_18));
GND uv_net_17_uv_inst_115(.G(uv_net_17));
GND uv_net_16_uv_inst_114(.G(uv_net_16));
GND uv_net_15_uv_inst_113(.G(uv_net_15));
GND uv_net_14_uv_inst_112(.G(uv_net_14));
GND uv_net_13_uv_inst_111(.G(uv_net_13));
GND uv_net_12_uv_inst_110(.G(uv_net_12));
GND uv_net_11_uv_inst_109(.G(uv_net_11));
GND uv_net_10_uv_inst_108(.G(uv_net_10));
GND uv_net_9_uv_inst_107(.G(uv_net_9));
GND uv_net_8_uv_inst_106(.G(uv_net_8));
GND uv_net_7_uv_inst_105(.G(uv_net_7));
GND uv_net_6_uv_inst_104(.G(uv_net_6));
GND uv_net_5_uv_inst_103(.G(uv_net_5));
GND uv_net_4_uv_inst_102(.G(uv_net_4));
GND uv_net_3_uv_inst_101(.G(uv_net_3));
GND uv_net_2_uv_inst_100(.G(uv_net_2));
GND uv_net_1_uv_inst_99(.G(uv_net_1));
GND uv_net_0_uv_inst_98(.G(uv_net_0));
GND n2_uv_inst_97(.G(n2));

endmodule

module DSP48_MULT_27X18_CAS_NONE_0(A_IN, A_CIN, B_IN, B_CIN, P_OUT, P_CIN);

input [26 : 0] A_IN;
input [29 : 0] A_CIN;
input [17 : 0] B_IN;
input [17 : 0] B_CIN;
output [47 : 0] P_OUT;
input [47 : 0] P_CIN;


wire n1;
wire n2;
wire [26 : 0] A_IN;
wire [29 : 0] A_CIN;
wire [17 : 0] B_IN;
wire [17 : 0] B_CIN;
wire [47 : 0] P_OUT;
wire [47 : 0] P_CIN;


GND i1(.G(n1));
VCC i2(.P(n2));
DSP48E2 #(.ACASCREG(0), .ADREG(0), .ALUMODEREG(0), .AMULTSEL("A"), .AREG(0), .AUTORESET_PATDET("NO_RESET"), .AUTORESET_PRIORITY("RESET"), .A_INPUT("DIRECT"), .BCASCREG(0), .BMULTSEL("B"), .BREG(0), .B_INPUT("DIRECT"), .CARRYINREG(0), .CARRYINSELREG(0), .CREG(0), .DREG(0), .INMODEREG(0), .MASK(48'b001111111111111111111111111111111111111111111111), .MREG(0), .OPMODEREG(0), .PATTERN(48'b000000000000000000000000000000000000000000000000), .PREADDINSEL("A"), .PREG(0), .RND(48'b000000000000000000000000000000000000000000000000), .SEL_MASK("MASK"), .SEL_PATTERN("PATTERN"), .USE_MULT("MULTIPLY"), .USE_PATTERN_DETECT("NO_PATDET"), .USE_SIMD("ONE48"), .USE_WIDEXOR("FALSE"), .XORSIMD("XOR24_48_96"))
_TECHMAP_REPLACE_(.CARRYCASCOUT(), .MULTSIGNOUT(), .OVERFLOW(), .PATTERNBDETECT(), .PATTERNDETECT(), .UNDERFLOW(), .CARRYCASCIN(n1), .CARRYIN(n1), .CEA1(n1), .CEA2(n1), .CEAD(n1), .CEALUMODE(n1), .CEB1(n1), .CEB2(n1), .CEC(n1), .CECARRYIN(n1), .CECTRL(n1), .CED(n1), .CEINMODE(n1), .CEM(n1), .CEP(n1), .CLK(n1), .MULTSIGNIN(n1), .RSTA(n1), .RSTALLCARRYIN(n1), .RSTALUMODE(n1), .RSTB(n1), .RSTC(n1), .RSTCTRL(n1), .RSTD(n1), .RSTINMODE(n1), .RSTM(n1), .RSTP(n1), 
.ACOUT() , 
.BCOUT() , 
.CARRYOUT() , 
.P({UV_unconnected_leaf_inst2_P_47, 
UV_unconnected_leaf_inst2_P_46, 
UV_unconnected_leaf_inst2_P_45, 
UV_unconnected_leaf_inst2_P_44, 
UV_unconnected_leaf_inst2_P_43, 
UV_unconnected_leaf_inst2_P_42, 
UV_unconnected_leaf_inst2_P_41, 
UV_unconnected_leaf_inst2_P_40, 
UV_unconnected_leaf_inst2_P_39, 
UV_unconnected_leaf_inst2_P_38, 
UV_unconnected_leaf_inst2_P_37, 
UV_unconnected_leaf_inst2_P_36, 
UV_unconnected_leaf_inst2_P_35, 
UV_unconnected_leaf_inst2_P_34, 
UV_unconnected_leaf_inst2_P_33, 
UV_unconnected_leaf_inst2_P_32, 
UV_unconnected_leaf_inst2_P_31, 
UV_unconnected_leaf_inst2_P_30, 
UV_unconnected_leaf_inst2_P_29, 
UV_unconnected_leaf_inst2_P_28, 
UV_unconnected_leaf_inst2_P_27, 
UV_unconnected_leaf_inst2_P_26, 
UV_unconnected_leaf_inst2_P_25, 
UV_unconnected_leaf_inst2_P_24, 
UV_unconnected_leaf_inst2_P_23, 
UV_unconnected_leaf_inst2_P_22, 
P_OUT[21], 
P_OUT[20], 
P_OUT[19], 
P_OUT[18], 
P_OUT[17], 
P_OUT[16], 
P_OUT[15], 
P_OUT[14], 
P_OUT[13], 
P_OUT[12], 
P_OUT[11], 
P_OUT[10], 
P_OUT[9], 
P_OUT[8], 
P_OUT[7], 
P_OUT[6], 
P_OUT[5], 
P_OUT[4], 
P_OUT[3], 
P_OUT[2], 
P_OUT[1], 
P_OUT[0]}), 
.PCOUT() , 
.XOROUT() , 
.A({A_IN[26], 
A_IN[26], 
A_IN[26], 
A_IN[26], 
A_IN[25], 
A_IN[24], 
A_IN[23], 
A_IN[22], 
A_IN[21], 
A_IN[20], 
A_IN[19], 
A_IN[18], 
A_IN[17], 
A_IN[16], 
A_IN[15], 
A_IN[14], 
A_IN[13], 
A_IN[12], 
A_IN[11], 
A_IN[10], 
A_IN[9], 
A_IN[8], 
A_IN[7], 
A_IN[6], 
A_IN[5], 
A_IN[4], 
A_IN[3], 
A_IN[2], 
A_IN[1], 
A_IN[0]}), 
.ACIN({A_CIN[29], 
A_CIN[28], 
A_CIN[27], 
A_CIN[26], 
A_CIN[25], 
A_CIN[24], 
A_CIN[23], 
A_CIN[22], 
A_CIN[21], 
A_CIN[20], 
A_CIN[19], 
A_CIN[18], 
A_CIN[17], 
A_CIN[16], 
A_CIN[15], 
A_CIN[14], 
A_CIN[13], 
A_CIN[12], 
A_CIN[11], 
A_CIN[10], 
A_CIN[9], 
A_CIN[8], 
A_CIN[7], 
A_CIN[6], 
A_CIN[5], 
A_CIN[4], 
A_CIN[3], 
A_CIN[2], 
A_CIN[1], 
A_CIN[0]}), 
.ALUMODE({n1, 
n1, 
n1, 
n1}), 
.B({B_IN[17], 
B_IN[16], 
B_IN[15], 
B_IN[14], 
B_IN[13], 
B_IN[12], 
B_IN[11], 
B_IN[10], 
B_IN[9], 
B_IN[8], 
B_IN[7], 
B_IN[6], 
B_IN[5], 
B_IN[4], 
B_IN[3], 
B_IN[2], 
B_IN[1], 
B_IN[0]}), 
.BCIN({B_CIN[17], 
B_CIN[16], 
B_CIN[15], 
B_CIN[14], 
B_CIN[13], 
B_CIN[12], 
B_CIN[11], 
B_CIN[10], 
B_CIN[9], 
B_CIN[8], 
B_CIN[7], 
B_CIN[6], 
B_CIN[5], 
B_CIN[4], 
B_CIN[3], 
B_CIN[2], 
B_CIN[1], 
B_CIN[0]}), 
.C({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1}), 
.CARRYINSEL({n1, 
n1, 
n1}), 
.D({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n1}), 
.INMODE({n1, 
n1, 
n1, 
n1, 
n1}), 
.OPMODE({n1, 
n1, 
n1, 
n1, 
n1, 
n1, 
n2, 
n1, 
n2}), 
.PCIN({P_CIN[47], 
P_CIN[46], 
P_CIN[45], 
P_CIN[44], 
P_CIN[43], 
P_CIN[42], 
P_CIN[41], 
P_CIN[40], 
P_CIN[39], 
P_CIN[38], 
P_CIN[37], 
P_CIN[36], 
P_CIN[35], 
P_CIN[34], 
P_CIN[33], 
P_CIN[32], 
P_CIN[31], 
P_CIN[30], 
P_CIN[29], 
P_CIN[28], 
P_CIN[27], 
P_CIN[26], 
P_CIN[25], 
P_CIN[24], 
P_CIN[23], 
P_CIN[22], 
P_CIN[21], 
P_CIN[20], 
P_CIN[19], 
P_CIN[18], 
P_CIN[17], 
P_CIN[16], 
P_CIN[15], 
P_CIN[14], 
P_CIN[13], 
P_CIN[12], 
P_CIN[11], 
P_CIN[10], 
P_CIN[9], 
P_CIN[8], 
P_CIN[7], 
P_CIN[6], 
P_CIN[5], 
P_CIN[4], 
P_CIN[3], 
P_CIN[2], 
P_CIN[1], 
P_CIN[0]}));

endmodule

