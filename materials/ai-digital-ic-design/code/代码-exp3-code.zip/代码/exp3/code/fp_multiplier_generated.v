module fp_multiplier
(
    input wire clk,
    input wire rst_n,
    input wire [15:0] A,
    input wire [15:0] B,
    output reg [15:0] C,
    input wire valid,
    output reg ready
);

    // Internal registers for pipeline
    reg [15:0] A_reg, B_reg;
    reg valid_reg;
    reg [1:0] state;
    
    // FP16 format: 1-bit sign, 5-bit exponent, 10-bit fraction
    wire sign_a = A[15];
    wire sign_b = B[15];
    wire [4:0] exp_a = A[14:10];
    wire [4:0] exp_b = B[14:10];
    wire [9:0] frac_a = A[9:0];
    wire [9:0] frac_b = B[9:0];
    
    // Special case detection
    wire a_is_zero = (exp_a == 5'b0) && (frac_a == 10'b0);
    wire b_is_zero = (exp_b == 5'b0) && (frac_b == 10'b0);
    wire a_is_inf = (exp_a == 5'b11111) && (frac_a == 10'b0);
    wire b_is_inf = (exp_b == 5'b11111) && (frac_b == 10'b0);
    wire a_is_nan = (exp_a == 5'b11111) && (frac_a != 10'b0);
    wire b_is_nan = (exp_b == 5'b11111) && (frac_b != 10'b0);
    wire a_is_subnormal = (exp_a == 5'b0) && (frac_a != 10'b0);
    wire b_is_subnormal = (exp_b == 5'b0) && (frac_b != 10'b0);
    
    // Pipeline stage 1: Special case handling and mantissa multiplication preparation
    reg stage1_valid;
    reg stage1_sign;
    reg [5:0] stage1_exp_sum; // 6 bits for sum + bias adjustment
    reg [20:0] stage1_mant_product; // 11x11 = 22 bits, but we use 21 for calculation
    reg stage1_is_zero, stage1_is_inf, stage1_is_nan;
    
    // Pipeline stage 2: Normalization and rounding
    reg stage2_valid;
    reg [15:0] stage2_result;
    
    // FSM states
    localparam IDLE = 2'b00;
    localparam STAGE1 = 2'b01;
    localparam STAGE2 = 2'b10;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            ready <= 1'b1;
            valid_reg <= 1'b0;
            A_reg <= 16'b0;
            B_reg <= 16'b0;
            stage1_valid <= 1'b0;
            stage2_valid <= 1'b0;
            C <= 16'b0;
        end else begin
            case (state)
                IDLE: begin
                    ready <= 1'b1;
                    if (valid && ready) begin
                        A_reg <= A;
                        B_reg <= B;
                        valid_reg <= 1'b1;
                        state <= STAGE1;
                        ready <= 1'b0;
                        
                        // Stage 1 calculations
                        stage1_sign <= sign_a ^ sign_b;
                        
                        // Handle special cases
                        if (a_is_nan || b_is_nan) begin
                            stage1_is_nan <= 1'b1;
                            stage1_is_zero <= 1'b0;
                            stage1_is_inf <= 1'b0;
                            stage1_exp_sum <= 6'b0;
                            stage1_mant_product <= 21'b0;
                        end else if ((a_is_zero && b_is_inf) || (a_is_inf && b_is_zero)) begin
                            stage1_is_nan <= 1'b1;
                            stage1_is_zero <= 1'b0;
                            stage1_is_inf <= 1'b0;
                            stage1_exp_sum <= 6'b0;
                            stage1_mant_product <= 21'b0;
                        end else if (a_is_zero || b_is_zero) begin
                            stage1_is_zero <= 1'b1;
                            stage1_is_inf <= 1'b0;
                            stage1_is_nan <= 1'b0;
                            stage1_exp_sum <= 6'b0;
                            stage1_mant_product <= 21'b0;
                        end else if (a_is_inf || b_is_inf) begin
                            stage1_is_inf <= 1'b1;
                            stage1_is_zero <= 1'b0;
                            stage1_is_nan <= 1'b0;
                            stage1_exp_sum <= 6'b0;
                            stage1_mant_product <= 21'b0;
                        end else begin
                            // Normal multiplication
                            stage1_is_zero <= 1'b0;
                            stage1_is_inf <= 1'b0;
                            stage1_is_nan <= 1'b0;
                            
                            // Add exponents and subtract bias (15 for FP16)
                            stage1_exp_sum <= {1'b0, exp_a} + {1'b0, exp_b} - 6'd15;
                            
                            // Multiply mantissas (with hidden bit)
                            wire [10:0] mant_a = (a_is_subnormal) ? {1'b0, frac_a} : {1'b1, frac_a};
                            wire [10:0] mant_b = (b_is_subnormal) ? {1'b0, frac_b} : {1'b1, frac_b};
                            stage1_mant_product <= mant_a * mant_b;
                        end
                        
                        stage1_valid <= 1'b1;
                    end
                end
                
                STAGE1: begin
                    if (stage1_valid) begin
                        // Stage 2: Normalization and rounding
                        if (stage1_is_nan) begin
                            stage2_result <= {stage1_sign, 5'b11111, 10'b1}; // Quiet NaN
                        end else if (stage1_is_inf) begin
                            stage2_result <= {stage1_sign, 5'b11111, 10'b0}; // Infinity
                        end else if (stage1_is_zero) begin
                            stage2_result <= {stage1_sign, 15'b0}; // Zero
                        end else begin
                            // Normal case: normalize and round
                            reg [4:0] final_exp;
                            reg [9:0] final_frac;
                            reg [20:0] normalized_mant;
                            
                            // Check for overflow in exponent
                            if (stage1_exp_sum[5] || (stage1_exp_sum[4:0] > 5'd30)) begin
                                // Overflow - return infinity
                                stage2_result <= {stage1_sign, 5'b11111, 10'b0};
                            end else if (stage1_exp_sum[4:0] == 5'b0) begin
                                // Underflow - return zero
                                stage2_result <= {stage1_sign, 15'b0};
                            end else begin
                                // Normal case
                                normalized_mant = stage1_mant_product;
                                final_exp = stage1_exp_sum[4:0];
                                
                                // Normalize: product is in [1,4) range, so we may need to shift
                                if (normalized_mant[20]) begin
                                    normalized_mant = normalized_mant >> 1;
                                    final_exp = final_exp + 1;
                                    
                                    // Check for exponent overflow after normalization
                                    if (final_exp > 5'd30) begin
                                        stage2_result <= {stage1_sign, 5'b11111, 10'b0};
                                    end else begin
                                        // Round to nearest even (simplified)
                                        final_frac = normalized_mant[19:10];
                                        if (normalized_mant[9] && (normalized_mant[8:0] != 9'b0 || normalized_mant[10])) begin
                                            final_frac = final_frac + 1;
                                            if (final_frac == 10'b0) begin // Carry occurred
                                                final_exp = final_exp + 1;
                                                if (final_exp > 5'd30) begin
                                                    stage2_result <= {stage1_sign, 5'b11111, 10'b0};
                                                end else begin
                                                    stage2_result <= {stage1_sign, final_exp, final_frac};
                                                end
                                            end else begin
                                                stage2_result <= {stage1_sign, final_exp, final_frac};
                                            end
                                        end else begin
                                            stage2_result <= {stage1_sign, final_exp, final_frac};
                                        end
                                    end
                                end else begin
                                    // No normalization needed
                                    final_frac = normalized_mant[18:9];
                                    if (normalized_mant[8] && (normalized_mant[7:0] != 8'b0 || normalized_mant[9])) begin
                                        final_frac = final_frac + 1;
                                        if (final_frac == 10'b0) begin // Carry occurred
                                            final_exp = final_exp + 1;
                                            if (final_exp > 5'd30) begin
                                                stage2_result <= {stage1_sign, 5'b11111, 10'b0};
                                            end else begin
                                                stage2_result <= {stage1_sign, final_exp, final_frac};
                                            end
                                        end else begin
                                            stage2_result <= {stage1_sign, final_exp, final_frac};
                                        end
                                    end else begin
                                        stage2_result <= {stage1_sign, final_exp, final_frac};
                                    end
                                end
                            end
                        end
                        
                        stage2_valid <= 1'b1;
                        state <= STAGE2;
                    end
                end
                
                STAGE2: begin
                    if (stage2_valid) begin
                        C <= stage2_result;
                        stage2_valid <= 1'b0;
                        stage1_valid <= 1'b0;
                        valid_reg <= 1'b0;
                        state <= IDLE;
                    end
                end
            endcase
        end
    end

endmodule