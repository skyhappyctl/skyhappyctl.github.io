module fp_multiplier_tb;
    reg clk;
    reg rst_n;
    reg [15:0] A;
    reg [15:0] B;
    wire [15:0] C;
    reg valid;
    wire ready;
    
    // Test results
    integer test_count = 0;
    integer pass_count = 0;
    integer fail_count = 0;
    
    // Instantiate DUT
    fp_multiplier dut (
        .clk(clk),
        .rst_n(rst_n),
        .A(A),
        .B(B),
        .C(C),
        .valid(valid),
        .ready(ready)
    );
    
    // Clock generation
    always #5 clk = ~clk;
    
    // FP16 value definitions
    parameter FP16_ZERO = 16'h0000;
    parameter FP16_ONE = 16'h3C00;
    parameter FP16_TWO = 16'h4000;
    parameter FP16_THREE = 16'h4200;
    parameter FP16_NEG_TWO = 16'hC000;
    parameter FP16_NEG_THREE = 16'hC200;
    parameter FP16_INF = 16'h7C00;
    parameter FP16_NEG_INF = 16'hFC00;
    parameter FP16_NAN = 16'h7E00;
    parameter FP16_MAX = 16'h7BFF;  // 65504
    parameter FP16_MIN = 16'h0001;  // ~5.96e-8
    parameter FP16_SIX = 16'h4600;  // 6.0
    
    // Function to convert FP16 to real (simplified)
    function real fp16_to_real;
        input [15:0] fp16;
        reg sign;
        reg [4:0] exp;
        reg [9:0] frac;
        real result;
        integer i;
        real fraction_value;
    begin
        sign = fp16[15];
        exp = fp16[14:10];
        frac = fp16[9:0];
        
        if (exp == 5'b11111) begin
            if (frac == 10'b0) begin
                fp16_to_real = (sign) ? -$bitstoreal(64'h7FF0000000000000) : $bitstoreal(64'h7FF0000000000000);
            end else begin
                fp16_to_real = $bitstoreal(64'h7FF8000000000000); // NaN
            end
        end else if (exp == 5'b0) begin
            // Subnormal
            fraction_value = 0.0;
            for (i = 0; i < 10; i = i + 1) begin
                if (frac[9-i]) fraction_value = fraction_value + (2.0 ** (-i-1));
            end
            result = fraction_value * (2.0 ** -14);
            fp16_to_real = (sign) ? -result : result;
        end else begin
            // Normal
            fraction_value = 1.0;
            for (i = 0; i < 10; i = i + 1) begin
                if (frac[9-i]) fraction_value = fraction_value + (2.0 ** (-i-1));
            end
            result = fraction_value * (2.0 ** (exp - 15));
            fp16_to_real = (sign) ? -result : result;
        end
    end
    endfunction
    
    // Function to check if two FP16 values are equal (including special cases)
    function bit fp16_equal;
        input [15:0] a;
        input [15:0] b;
    begin
        // For NaN, we consider any NaN equal to any other NaN
        if ((a[14:10] == 5'b11111 && a[9:0] != 10'b0) && 
            (b[14:10] == 5'b11111 && b[9:0] != 10'b0)) begin
            fp16_equal = 1'b1;
        end else begin
            fp16_equal = (a === b);
        end
    end
    endfunction
    
    // Test task
    task test_multiply;
        input [15:0] a_val;
        input [15:0] b_val;
        input [15:0] expected;
        string test_name;
        real a_real, b_real, expected_real, result_real;
    begin
        test_count = test_count + 1;
        
        // Wait for ready
        @(posedge clk);
        while (!ready) @(posedge clk);
        
        // Apply inputs
        A = a_val;
        B = b_val;
        valid = 1'b1;
        
        // Wait for computation
        @(posedge clk);
        valid = 1'b0;
        
        // Wait for result (3 cycles for pipeline)
        repeat(3) @(posedge clk);
        
        // Convert to real for debug
        a_real = fp16_to_real(a_val);
        b_real = fp16_to_real(b_val);
        expected_real = fp16_to_real(expected);
        result_real = fp16_to_real(C);
        
        // Check result using fp16_equal function for proper NaN handling
        if (fp16_equal(C, expected)) begin
            pass_count = pass_count + 1;
            $display("PASS: Test %0d - A=%h, B=%h, Got=%h, Expected=%h", 
                     test_count, a_val, b_val, C, expected);
        end else begin
            fail_count = fail_count + 1;
            $display("FAIL: Test %0d - A=%h, B=%h, Got=%h, Expected=%h", 
                     test_count, a_val, b_val, C, expected);
            $display("      A_real=%f, B_real=%f, Got_real=%f, Expected_real=%f",
                     a_real, b_real, result_real, expected_real);
        end
    end
    endtask
    
    initial begin
        // Initialize
        clk = 0;
        rst_n = 0;
        valid = 0;
        A = 0;
        B = 0;
        
        // Generate waveform
        $dumpfile("Out/wave.vcd");
        $dumpvars(0, fp_multiplier_tb);
        
        // Reset
        #10 rst_n = 1;
        
        $display("Starting FP16 Multiplier Tests...");
        
        // Test 1: Basic Multiplication - Positive numbers
        test_multiply(FP16_TWO, FP16_THREE, FP16_SIX); // 2.0 * 3.0 = 6.0
        
        // Test 2: Negative numbers  
        test_multiply(FP16_NEG_TWO, FP16_THREE, 16'hC600); // -2.0 * 3.0 = -6.0
        
        // Test 3: Mixed signs
        test_multiply(FP16_NEG_TWO, FP16_NEG_THREE, FP16_SIX); // -2.0 * -3.0 = 6.0
        
        // Test 4: Zero multiplication
        test_multiply(FP16_ZERO, FP16_TWO, FP16_ZERO); // 0.0 * 2.0 = 0.0
        test_multiply(FP16_TWO, FP16_ZERO, FP16_ZERO); // 2.0 * 0.0 = 0.0
        
        // Test 5: Infinity multiplication
        test_multiply(FP16_INF, FP16_TWO, FP16_INF); // inf * 2.0 = inf
        test_multiply(FP16_NEG_INF, FP16_THREE, FP16_NEG_INF); // -inf * 3.0 = -inf
        
        // Test 6: NaN multiplication
        test_multiply(FP16_NAN, FP16_TWO, FP16_NAN); // NaN * 2.0 = NaN
        
        // Test 7: Infinity * Zero = NaN
        test_multiply(FP16_INF, FP16_ZERO, FP16_NAN);
        test_multiply(FP16_ZERO, FP16_INF, FP16_NAN);
        
        // Test 8: Subnormal numbers - expect underflow to zero
        test_multiply(FP16_MIN, FP16_MIN, FP16_ZERO); // Very small * very small = 0 (underflow)
        
        // Test 9: Overflow
        test_multiply(FP16_MAX, FP16_TWO, FP16_INF); // 65504 * 2.0 = inf (overflow)
        
        // Test 10: Edge case - maximum representable
        test_multiply(FP16_MAX, FP16_ONE, FP16_MAX); // 65504 * 1.0 = 65504
        
        // Additional test: 1.0 * 1.0 = 1.0
        test_multiply(FP16_ONE, FP16_ONE, FP16_ONE);
        
        // Final summary
        $display("\nTest Summary:");
        $display("Total Tests: %0d", test_count);
        $display("Passed: %0d", pass_count);
        $display("Failed: %0d", fail_count);
        
        if (fail_count == 0) begin
            $display("TestSuccessed");
        end else begin
            $display("TestFailed");
        end
        
        $finish;
    end

endmodule