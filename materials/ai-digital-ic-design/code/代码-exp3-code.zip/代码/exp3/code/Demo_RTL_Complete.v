/*
This is a multiplier for floating point
- Support IEEE 754 Half-Precision Floating-Point Format (FP16):
	- Handle all special cases (zero, infinity, NaN) as specified by IEEE 754.
	- Ensure correct rounding to the nearest even value.
- Use valid and ready signals for handshake. When valid is high, the input operands A and B are ready. When ready is high, the result C is valid.
*/
/*
module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);
// Internal registers for pipeline stages
    reg [15:0] A_reg, B_reg;
    reg ready_reg;
    reg [1:0] state;
    
    // Floating point components extraction
    wire sign_A, sign_B;
    wire [4:0] exp_A, exp_B;
    wire [9:0] frac_A, frac_B;
    
    // Stage 1 signals
    reg stage1_valid;
    reg sign_prod;
    reg [5:0] exp_sum;
    reg [21:0] frac_prod;
    reg is_zero_A, is_zero_B;
    reg is_inf_A, is_inf_B;
    reg is_nan_A, is_nan_B;
    
    // Stage 2 signals
    reg stage2_valid;
    reg [4:0] exp_adj;
    reg [10:0] frac_rounded;
    reg is_zero_prod, is_inf_prod, is_nan_prod;
    
    // Constants
    localparam [4:0] EXP_BIAS = 5'd15;
    localparam [4:0] EXP_MAX = 5'd31;
    localparam [4:0] EXP_MIN = 5'd0;
    
    // Extract components
    assign sign_A = A_reg[15];
    assign exp_A = A_reg[14:10];
    assign frac_A = A_reg[9:0];
    
    assign sign_B = B_reg[15];
    assign exp_B = B_reg[14:10];
    assign frac_B = B_reg[9:0];
    
    // Special case detection
    always @(*) begin
        is_zero_A = (exp_A == 5'b0) && (frac_A == 10'b0);
        is_inf_A = (exp_A == 5'b11111) && (frac_A == 10'b0);
        is_nan_A = (exp_A == 5'b11111) && (frac_A != 10'b0);
        
        is_zero_B = (exp_B == 5'b0) && (frac_B == 10'b0);
        is_inf_B = (exp_B == 5'b11111) && (frac_B == 10'b0);
        is_nan_B = (exp_B == 5'b11111) && (frac_B != 10'b0);
    end
    
    // Pipeline stage 1: Multiplication and special case handling
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stage1_valid <= 1'b0;
            sign_prod <= 1'b0;
            exp_sum <= 6'b0;
            frac_prod <= 22'b0;
        end else if (ready_reg) begin
            stage1_valid <= 1'b1;
            
            // Sign calculation
            sign_prod <= sign_A ^ sign_B;
            
            // Exponent calculation (subtract bias)
            exp_sum <= {1'b0, exp_A} + {1'b0, exp_B} - EXP_BIAS;
            
            // Fraction multiplication (with implicit 1)
            if (is_zero_A || is_zero_B) begin
                frac_prod <= 22'b0;
            end else begin
                frac_prod <= {1'b1, frac_A} * {1'b1, frac_B};
            end
        end else begin
            stage1_valid <= 1'b0;
        end
    end
    
    // Rounding logic (round to nearest even)
    wire [21:0] frac_normalized;
    wire [4:0] exp_normalized;
    wire round_bit, sticky_bit, guard_bit;
    wire round_up;
    
    // Normalization
    assign frac_normalized = (frac_prod[21]) ? (frac_prod >> 1) : frac_prod;
    assign exp_normalized = (frac_prod[21]) ? (exp_sum + 1) : exp_sum;
    
    // Rounding bits
    assign guard_bit = frac_normalized[10];
    assign round_bit = frac_normalized[9];
    assign sticky_bit = |frac_normalized[8:0];
    
    // Round to nearest even
    assign round_up = guard_bit & (round_bit | sticky_bit | frac_normalized[11]);
    
    // Pipeline stage 2: Normalization, rounding and final result assembly
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stage2_valid <= 1'b0;
            C <= 16'b0;
            Valid <= 1'b0;
            exp_adj <= 5'b0;
            frac_rounded <= 11'b0;
            is_zero_prod <= 1'b0;
            is_inf_prod <= 1'b0;
            is_nan_prod <= 1'b0;
        end else if (stage1_valid) begin
            stage2_valid <= 1'b1;
            
            // Handle special cases
            is_nan_prod <= is_nan_A | is_nan_B | (is_inf_A & is_zero_B) | (is_zero_A & is_inf_B);
            is_inf_prod <= (is_inf_A | is_inf_B) & ~is_nan_prod;
            is_zero_prod <= (is_zero_A | is_zero_B) & ~is_nan_prod;
            
            if (is_nan_prod) begin
                // NaN result
                C <= {sign_prod, 5'b11111, 10'b1};
            end else if (is_inf_prod) begin
                // Infinity result
                C <= {sign_prod, 5'b11111, 10'b0};
            end else if (is_zero_prod) begin
                // Zero result
                C <= {sign_prod, 15'b0};
            end else begin
                // Normal case: apply rounding
                if (round_up) begin
                    frac_rounded <= frac_normalized[21:11] + 1;
                    exp_adj <= exp_normalized;
                    
                    // Handle carry from rounding
                    if (frac_rounded[10]) begin
                        frac_rounded <= {1'b0, frac_rounded[10:1]};
                        exp_adj <= exp_normalized + 1;
                    end
                end else begin
                    frac_rounded <= frac_normalized[21:11];
                    exp_adj <= exp_normalized;
                end
                
                // Check for overflow/underflow
                if (exp_adj >= EXP_MAX) begin
                    // Overflow to infinity
                    C <= {sign_prod, 5'b11111, 10'b0};
                end else if (exp_adj <= EXP_MIN) begin
                    // Underflow to zero
                    C <= {sign_prod, 15'b0};
                end else begin
                    // Normal result
                    C <= {sign_prod, exp_adj, frac_rounded[9:0]};
                end
            end
            
            Valid <= 1'b1;
        end else begin
            stage2_valid <= 1'b0;
            Valid <= 1'b0;
        end
    end
    
    // Input register and ready handling
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            A_reg <= 16'b0;
            B_reg <= 16'b0;
            ready_reg <= 1'b0;
            state <= 2'b0;
        end else begin
            case (state)
                2'b00: begin // Idle state
                    if (Ready) begin
                        A_reg <= A;
                        B_reg <= B;
                        ready_reg <= 1'b1;
                        state <= 2'b01;
                    end
                end
                2'b01: begin // Processing state
                    ready_reg <= 1'b0;
                    if (stage2_valid) begin
                        state <= 2'b00;
                    end
                end
                default: state <= 2'b00;
            endcase
        end
    end

endmodule
*/

//Revised version

module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);

    // Internal registers for pipeline stages
    reg [15:0] A_reg, B_reg;
    reg ready_reg;
    reg [1:0] state;
    
    // Floating point components extraction
    wire sign_A = A_reg[15];
    wire [4:0] exp_A = A_reg[14:10];
    wire [9:0] frac_A = A_reg[9:0];
    
    wire sign_B = B_reg[15];
    wire [4:0] exp_B = B_reg[14:10];
    wire [9:0] frac_B = B_reg[9:0];
    
    // Stage 1 signals
    reg stage1_valid;
    reg sign_prod;
    reg [5:0] exp_sum;
    reg [21:0] frac_prod;
    reg is_zero_A, is_zero_B;
    reg is_inf_A, is_inf_B;
    reg is_nan_A, is_nan_B;
    
    // Stage 2 signals
    reg stage2_valid;
    reg [5:0] exp_normalized;
    reg [21:0] frac_normalized;
    reg guard_bit, round_bit, sticky_bit;
    reg round_up;
    reg is_zero_prod, is_inf_prod, is_nan_prod;
    
    // Constants
    localparam [4:0] EXP_BIAS = 5'd15;
    localparam [4:0] EXP_MAX = 5'd31;
    localparam [4:0] EXP_MIN = 5'd0;
    
    // Special case detection (combinational)
    always @(*) begin
        is_zero_A = (exp_A == 5'b0) && (frac_A == 10'b0);
        is_inf_A = (exp_A == 5'b11111) && (frac_A == 10'b0);
        is_nan_A = (exp_A == 5'b11111) && (frac_A != 10'b0);
        
        is_zero_B = (exp_B == 5'b0) && (frac_B == 10'b0);
        is_inf_B = (exp_B == 5'b11111) && (frac_B == 10'b0);
        is_nan_B = (exp_B == 5'b11111) && (frac_B != 10'b0);
    end
    
    // Pipeline stage 1: Multiplication and special case handling
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stage1_valid <= 1'b0;
            sign_prod <= 1'b0;
            exp_sum <= 6'b0;
            frac_prod <= 22'b0;
            exp_normalized <= 6'b0;
            frac_normalized <= 22'b0;
            guard_bit <= 1'b0;
            round_bit <= 1'b0;
            sticky_bit <= 1'b0;
            round_up <= 1'b0;
        end else if (ready_reg) begin
            stage1_valid <= 1'b1;
            
            // Sign calculation
            sign_prod <= sign_A ^ sign_B;
            
            // Exponent calculation (subtract bias)
            exp_sum <= {1'b0, exp_A} + {1'b0, exp_B} - EXP_BIAS;
            
            // Fraction multiplication (with implicit 1)
            if (is_zero_A || is_zero_B) begin
                frac_prod <= 22'b0;
            end else begin
                frac_prod <= {1'b1, frac_A} * {1'b1, frac_B};
            end
            
            // Normalization logic (moved from combinational to sequential)
            if (frac_prod[21]) begin
                frac_normalized <= frac_prod >> 1;
                exp_normalized <= exp_sum + 1;
            end else begin
                frac_normalized <= frac_prod;
                exp_normalized <= exp_sum;
            end
            
            // Rounding bits calculation
            guard_bit <= frac_normalized[10];
            round_bit <= frac_normalized[9];
            sticky_bit <= |frac_normalized[8:0];
            
            // Round to nearest even
            round_up <= guard_bit & (round_bit | sticky_bit | frac_normalized[11]);
            
        end else begin
            stage1_valid <= 1'b0;
        end
    end
    
    // Pipeline stage 2: Rounding and final result assembly
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stage2_valid <= 1'b0;
            C <= 16'b0;
            Valid <= 1'b0;
            is_zero_prod <= 1'b0;
            is_inf_prod <= 1'b0;
            is_nan_prod <= 1'b0;
        end else if (stage1_valid) begin
            stage2_valid <= 1'b1;
            
            // Handle special cases
            is_nan_prod <= is_nan_A | is_nan_B | (is_inf_A & is_zero_B) | (is_zero_A & is_inf_B);
            is_inf_prod <= (is_inf_A | is_inf_B) & ~is_nan_prod;
            is_zero_prod <= (is_zero_A | is_zero_B) & ~is_nan_prod;
            
            if (is_nan_prod) begin
                // NaN result
                C <= {sign_prod, 5'b11111, 10'b1};
            end else if (is_inf_prod) begin
                // Infinity result
                C <= {sign_prod, 5'b11111, 10'b0};
            end else if (is_zero_prod) begin
                // Zero result
                C <= {sign_prod, 15'b0};
            end else begin
                // Normal case: apply rounding with carry handling
                reg [10:0] temp_frac_rounded;
                reg [5:0] temp_exp_adj;
                
                if (round_up) begin
                    temp_frac_rounded = frac_normalized[21:11] + 1;
                    temp_exp_adj = exp_normalized;
                    
                    // Handle carry from rounding
                    if (temp_frac_rounded[10]) begin
                        temp_frac_rounded = {1'b0, temp_frac_rounded[10:1]};
                        temp_exp_adj = temp_exp_adj + 1;
                    end
                end else begin
                    temp_frac_rounded = frac_normalized[21:11];
                    temp_exp_adj = exp_normalized;
                end
                
                // Check for overflow/underflow
                if (temp_exp_adj >= EXP_MAX) begin
                    // Overflow to infinity
                    C <= {sign_prod, 5'b11111, 10'b0};
                end else if (temp_exp_adj <= EXP_MIN) begin
                    // Underflow to zero
                    C <= {sign_prod, 15'b0};
                end else begin
                    // Normal result
                    C <= {sign_prod, temp_exp_adj[4:0], temp_frac_rounded[9:0]};
                end
            end
            
            Valid <= 1'b1;
        end else begin
            stage2_valid <= 1'b0;
            Valid <= 1'b0;
        end
    end
    
    // Input register and state machine
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            A_reg <= 16'b0;
            B_reg <= 16'b0;
            ready_reg <= 1'b0;
            state <= 2'b00;
        end else begin
            case (state)
                2'b00: begin // Idle state
                    ready_reg <= 1'b0;
                    if (Ready) begin
                        A_reg <= A;
                        B_reg <= B;
                        ready_reg <= 1'b1;
                        state <= 2'b01;
                    end
                end
                2'b01: begin // Stage 1 processing
                    ready_reg <= 1'b0;
                    state <= 2'b10;
                end
                2'b10: begin // Stage 2 processing
                    if (stage2_valid) begin
                        state <= 2'b00;
                    end
                end
                default: begin
                    state <= 2'b00;
                    ready_reg <= 1'b0;
                end
            endcase
        end
    end

endmodule