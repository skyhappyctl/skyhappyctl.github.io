import sys
from pathlib import Path

root_dir = str(Path(__file__).parent.parent)
sys.path.append(root_dir)

from Basic.circuit import CIRCUIT, SUBMODULE, submodule_set
from Basic.tools import read_markdown, extract_code, write_file, replace_prompt
from Basic.LLM_interface import DeepSeek_R1

test_prompts = [
    "If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets? Explain your reasoning step by step.",
    "A bat and a ball cost $1.10 in total. The bat costs $1.00 more than the ball. How much does the ball cost? Show your work.",
    "Sarah is twice as old as John. In 5 years, the sum of their ages will be 35. How old are Sarah and John now? Provide a detailed solution.",
    "There are three boxes: one contains only apples, one contains only oranges, and one contains both apples and oranges. The labels on the boxes are all wrong. You can only pick one fruit from one box (without looking inside). How do you determine the correct labels for all three boxes? Explain your reasoning process."
]

system_prompt = 'You are a senior digital circuit engineer. Please help me complete the following tasks. Please pay attention to the Tips in each prompt.'

prompt_paths = {
    'naive' : 'Prompts/naive_prompt.md',
    'zero_shot1' : 'Prompts/zero_shot_prompt1.md',
    'zero_shot2' : 'Prompts/zero_shot_prompt2.md',
    'zero_shot3' : 'Prompts/zero_shot_prompt3.md',
    'one_shot1' : 'Prompts/one_shot_prompt1.md',
    'one_shot2' : 'Prompts/one_shot_prompt2.md',
    'homework1' : 'Prompts/homework_prompt1.md',
    'match_submodule' : "Prompts/Match_Submodule.md",
    'design_topmodule' : "Prompts/Design_Topmodule.md",
    'correct_problem' : "Prompts/Correct_Problem.md"
}

get_related_id = lambda text: eval(text.split('=')[1].strip())

def Match_Submodule(circuit: CIRCUIT):
    prompt = read_markdown(prompt_paths['match_submodule'])
    prompt = replace_prompt(prompt, circuit.get_replacement())

    response = DeepSeek_R1.get_answer(
        request = prompt,
        system_prompt = system_prompt,
        supplement = None,
        stream = True,
        is_reason = True,
        is_print = True
    )

    RelatedID = extract_code(response, "Related ID", "python")
    circuit.RelatedID = get_related_id(RelatedID)

def Design_Topmodule(circuit: CIRCUIT):
    prompt = read_markdown(prompt_paths['design_topmodule'])

    # 将子模块的RTL插入到prompt中
    target_section = "### Retrieval Submodules"
    target_index = prompt.find(target_section)
    insert_position = target_index + len(target_section)
    insert_text = ""
    for index in circuit.RelatedID:
        insert_text += submodule_set[str(index)].get_RTL_text()
    prompt = (prompt[:insert_position] + insert_text + prompt[insert_position:])

    prompt = replace_prompt(prompt, circuit.get_replacement())
    response = DeepSeek_R1.get_answer(
        request = prompt,
        system_prompt = system_prompt,
        supplement = None,
        stream = True,
        is_reason = True,
        is_print = True
    )

    circuit.rtl_code = extract_code(response, "RTL", "verilog")
    circuit.testbench_code = extract_code(response, "TestBench", "systemverilog")

def Correct_Problem(circuit: CIRCUIT, last_message = None):
    prompt = read_markdown(prompt_paths['correct_problem'])

    prompt = replace_prompt(prompt, circuit.get_replacement())

    message, response = DeepSeek_R1.get_answer(
        request = prompt,
        system_prompt = system_prompt,
        supplement = None,
        stream = True,
        is_reason = True,
        is_print = True,
        is_multi_round = True,
        last_message = last_message,
    )
    result = extract_code(response, "Result", "text")

    if result == "Success":
        return message, True

    elif result == "Failed":
        rtl_code = extract_code(response, "Revised RTL", "verilog")
        if rtl_code != None:
            circuit.rtl_code = rtl_code

        testbench_code = extract_code(response, "Revised TestBench", "systemverilog")
        if testbench_code != None:
            circuit.testbench_code = testbench_code

        return message, False


if __name__ == '__main__':
    # No-Reason No-Stream interface ---------------------------
    # response = DeepSeek_R1.get_answer( 
    #     request = test_prompts[0],
    #     system_prompt = None,
    #     supplement = None,
    #     stream = False,
    #     is_reason = False,
    #     is_print = True
    # )
    
    
    # No-Reason Stream interface ---------------------------
    # response = DeepSeek_R1.get_answer( 
    #     request = test_prompts[0],
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # Reason Stream interface -------------------------------
    # response = DeepSeek_R1.get_answer( 
    #     request = test_prompts[0],
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = True,
    #     is_print = True
    # )

    # Naive Prompt ------------------------------------------
    # prompt = read_markdown(prompt_paths['naive'])
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )


    # Zero Shot Prompt 1 ---------------------------------------
    # prompt = read_markdown(prompt_paths['zero_shot1'])
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    # write_file(RTL, "RTL/zero_shot1_fp.v")
    # write_file(TestBench, "Test/test_zero_shot1_fp.sv")


    # Zero Shot Prompt 2 ---------------------------------------
    # prompt = read_markdown(prompt_paths['zero_shot2'])
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    # write_file(RTL, "RTL/zero_shot2_fp.v")
    # write_file(TestBench, "Test/test_zero_shot2_fp.sv")


    # Zero Shot Prompt 3 ---------------------------------------
    # prompt = read_markdown(prompt_paths['zero_shot3'])
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    # write_file(RTL, "RTL/zero_shot3_fp.v")
    # write_file(TestBench, "Test/test_zero_shot3_fp.sv")


    # One Shot Prompt 1 ---------------------------------------
    # prompt = read_markdown(prompt_paths['one_shot1'])
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    # write_file(RTL, "RTL/one_shot1_fp.v")
    # write_file(TestBench, "Test/one_zero_shot1_fp.sv")


    # One Shot Prompt 2 ---------------------------------------
    # fp_multiplier = CIRCUIT.load_circuit("Json/fp_multiplier.json")
    # prompt = read_markdown(prompt_paths['one_shot2'])
    # prompt = replace_prompt(prompt, fp_multiplier.get_replacement())
    
    # print("\n\n\n Get Response:\n")
    
    # response = DeepSeek_R1.get_answer( 
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = False,
    #     is_print = True
    # )

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    # fp_multiplier.rtl_code = RTL
    # fp_multiplier.testbench_code = TestBench
    # fp_multiplier.save_all_componet()


    # Homework 1 -----------------------------------------------
    # async_fifo = CIRCUIT(
    #     model_name = "async_fifo",
    #     input_node = "- wr_clk: Write clock domain clock signal (rising edge effective).\n- rd_clk: Read clock domain clock signal (rising edge effective).\n- rst_n: Active-low asynchronous reset signal.\n- wr_en: Write enable signal, high effective.\n- rd_en:Read enable signal, high effective.\n- data_in: 16-bit input data to be written to FIFO.",
    #     output_node = "- data_out: 16-bit output data read from FIFO.\n- full: FIFO full indicator, high effective.\n- empty: FIFO empty indicator, high effective.\n- almost_full: FIFO almost full indicator (programmable threshold), high effective.\n- almost_empty: FIFO almost empty indicator (programmable threshold), high effective.",
    #     specification = "- Support IEEE 754 Half-Precision Floating-Point Format (FP16):\n Support asynchronous clock domains (wr_clk and rd_clk are independent, with arbitrary frequencies and phases).\n- Use Gray code-encoded read and write pointers, synchronized across clock domains via two-stage synchronizers to avoid metastability.\n- FIFO depth is 16 (can store 16 16-bit data words). Programmable almost-full threshold (default: 14) and almost-empty threshold (default: 2).\n- Asynchronous reset behavior: When rst_n is low, all read/write pointers are cleared, full/empty/almost_full/almost_empty flags are reset, and the FIFO is initialized to empty.\n- Data write: When wr_en is high and full is low, data_in is written into the FIFO on the rising edge of wr_clk.\n- Data read: When rd_en is high and empty is low, data_out is read from the FIFO on the rising edge of rd_clk, following first-in-first-out (FIFO) order.\n- Full flag generation: Asserted in the write clock domain when the FIFO is completely full (write pointer catches up to the synchronized read pointer in Gray code).\n- Empty flag generation: Asserted in the read clock domain when the FIFO is completely empty (read pointer catches up to the synchronized write pointer in Gray code).\n- Almost-full flag: Asserted when the number of occupied entries reaches the almost-full threshold (programmable, default 14).\n- Almost-empty flag: Asserted when the number of occupied entries drops to the almost-empty threshold (programmable, default 2).",
    #     test_spec = "- Basic Read-Write Test: Write a sequence of data (e.g., 0x0000 to 0x000F) and read them back, verifying FIFO order and data integrity.\n- Asynchronous Clock Test: Configure wr_clk at 100MHz and rd_clk at 50MHz, perform continuous write and read operations, verify data correctness across clock domains.\n- Full Condition Test: Continuously write data until full is asserted, check that no more data can be written, and verify full flag accuracy.\n- Empty Condition Test: Continuously read data until empty is asserted, check that no more data can be read, and verify empty flag accuracy.\n- Almost-Full/Almost-Empty Threshold Test: Set custom thresholds (e.g., almost_full=10, almost_empty=3), verify that the flags are asserted correctly when the entry count reaches the thresholds.\n- Reset Test: Assert rst_n during operation, check that all pointers, flags, and data outputs are initialized correctly after reset.\n- Concurrent Read-Write Test: Perform write and read operations simultaneously (with proper clock domain handling), verify FIFO stability and data consistency.\n- Edge Case Test: Write 15 entries (one before full), write 16 entries (full), read 1 entry (almost empty at threshold), read all entries (empty), and verify corresponding flag behaviors."
    # )
    
    # async_fifo = CIRCUIT.load_circuit("Json/async_fifo.json")
    # async_fifo.specification = "- Support IEEE 754 Half-Precision Floating-Point Format (FP16):\n Support asynchronous clock domains (wr_clk and rd_clk are independent, with arbitrary frequencies and phases).\n- Use Gray code-encoded read and write pointers, synchronized across clock domains via two-stage synchronizers to avoid metastability.\n- FIFO depth is 16 (can store 16 16-bit data words). Programmable almost-full threshold (default: 14) and almost-empty threshold (default: 2).\n- Asynchronous reset behavior: When rst_n is low, all read/write pointers are cleared, full/empty/almost_full/almost_empty flags are reset, and the FIFO is initialized to empty.\n- Data write: When wr_en is high and full is low, data_in is written into the FIFO on the rising edge of wr_clk. Never perform read operations when empty (causes pointer misalignment).\n- Data read: When rd_en is high and empty is low, data_out is read from the FIFO on the rising edge of rd_clk, following first-in-first-out (FIFO) order.\n- Full flag generation: Asserted in the write clock domain when the FIFO is completely full (write pointer catches up to the synchronized read pointer in Gray code).\n- Empty flag generation: Asserted in the read clock domain when the FIFO is completely empty (read pointer catches up to the synchronized write pointer in Gray code).\n- Almost-full flag: Asserted when the number of occupied entries reaches the almost-full threshold (programmable, default 14).\n- Almost-empty flag: Asserted when the number of occupied entries drops to the almost-empty threshold (programmable, default 2).\n- Traditional Verilog has limited support for loop-based assignments to reg arrays. The syntax of iterating through an array and assigning values via a for loop within an always block is not allowed in older standards. Therefore, if you need to initialize and clear the memory of this FIFO, you either place the initialization in an initial block (for simulation purposes) or use other methods to clear the memory.\n -The synchronizer delay from the write pointer to the read pointer in the asynchronous FIFO causes the read domain to fail to timely detect that the FIFO is not empty, thus losing the first written data. Therefore, it is necessary to ensure that the start time of the read operation is later than the synchronizer's stable time, or to optimize the synchronization logic to reduce the impact of delay on the critical path.\n-  Read and write pointers use n+1 bits (e.g., 5 bits for a depth of 16, where the highest 1 bit serves as the carry bit and the lower 4 bits as the address). When calculating FIFO counts (fifo_count_wr_domain/fifo_count_rd_domain), it is mandatory to check whether the highest 1 bit of the pointers is consistent: 1.If the highest 1 bit is the same, the count equals the difference of the lower n bits; 2. If the highest 1 bit is different (pointer wrap-around), the count equals the difference of the lower n bits plus the depth. Directly calculating the count using wr_ptr_bin - rd_ptr_bin_sync or similar methods is prohibited (failure to handle wrap-around will result in errors in full/empty flags)."
    # async_fifo.SimulationResult = "Test 1: Reset Behavior\nTest 1: Reset Behavior - PASSED\nTest 2: Basic Write and Read Operations\nTest 2: Basic Write and Read Operations - PASSED\nTest 3: Asynchronous Clock Test\nTest 3: Asynchronous Clock Test - PASSED\nTest 4: FIFO Full Condition\nTest 4: FIFO Full Condition - PASSED\nTest 5: FIFO Empty Condition\nTest 5: FIFO Empty Condition - PASSED\nTest 6: Almost-Full/Almost-Empty Threshold Test\nERROR: Should not be almost empty yet - Expected: 0000, Got: 0001\nTest 7: Concurrent Read-Write Test\nTest 8: Edge Case Test\nERROR: Should not be almost empty yet - Expected: 0000, Got: 0001\nTestFailed: 2 errors found"
    # prompt = read_markdown(prompt_paths['homework1'])
    # prompt = replace_prompt(prompt, async_fifo.get_replacement())
    

    # print("\n\n\n Get Response:\n")
    
    # response = DeepSeek_R1.get_answer(
    #     request = prompt,
    #     system_prompt = None,
    #     supplement = None,
    #     stream = True,
    #     is_reason = True,
    #     is_print = True
    # )
    

    # RTL = extract_code(response, "RTL", "verilog")
    # TestBench = extract_code(response, "TestBench", "systemverilog")
    
    

    # async_fifo.rtl_code = RTL
    # async_fifo.testbench_code = TestBench
    # async_fifo.save_all_componet()


    # Lesson 2 --------------------------------------------------

    async_fifo = CIRCUIT.load_circuit("Json/async_fifo.json")
    #Match_Submodule(async_fifo)
    Design_Topmodule(async_fifo)
    
    MAX_ATTEMPT_TIME = 4
    Remained_Attempts = MAX_ATTEMPT_TIME
    last_message = None
    
    while Remained_Attempts > 0:
        print(f"\n\nThe {MAX_ATTEMPT_TIME - Remained_Attempts + 1}th attempt\n\n")
    
        async_fifo.execute_testbench()
        last_message, result = Correct_Problem(async_fifo, last_message)
        async_fifo.save_all_componet()
    
        if result == True:
            break
        Remained_Attempts -= 1
    
    if result == True:
        print(f"\n\nAfter successfully completing the circuit design after {MAX_ATTEMPT_TIME - Remained_Attempts + 1} attempts")
    else:
        print(f"\n\nFailed to complete the circuit design after {MAX_ATTEMPT_TIME} attempts")
    async_fifo.save_all_componet()
