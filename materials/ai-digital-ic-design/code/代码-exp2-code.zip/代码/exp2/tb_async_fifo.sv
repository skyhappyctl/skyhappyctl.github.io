module tb_async_fifo;
    reg wr_clk, rd_clk, rst_n;
    reg wr_en, rd_en;
    reg [15:0] data_in;
    wire [15:0] data_out;
    wire full, empty, almost_full, almost_empty;
    
    // Test parameters
    localparam DEPTH = 16;
    localparam TEST_DATA_COUNT = 20;
    reg [15:0] test_data [0:TEST_DATA_COUNT-1];
    reg [15:0] received_data [0:TEST_DATA_COUNT-1];
    integer write_count = 0;
    integer read_count = 0;
    integer error_count = 0;
    
    // Instantiate DUT
    async_fifo #(
        .ALMOST_FULL_THRESHOLD(10),
        .ALMOST_EMPTY_THRESHOLD(3)
    ) dut (
        .wr_clk(wr_clk),
        .rd_clk(rd_clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .rd_en(rd_en),
        .data_in(data_in),
        .data_out(data_out),
        .full(full),
        .empty(empty),
        .almost_full(almost_full),
        .almost_empty(almost_empty)
    );
    
    // Clock generation
    initial begin
        wr_clk = 0;
        forever #5 wr_clk = ~wr_clk; // 100MHz
    end
    
    initial begin
        rd_clk = 0;
        forever #10 rd_clk = ~rd_clk; // 50MHz
    end
    
    // Test data initialization
    initial begin
        for (int i = 0; i < TEST_DATA_COUNT; i++) begin
            test_data[i] = i;
        end
    end
    
    // Main test sequence
    initial begin
        $display("Starting Async FIFO Test...");
        error_count = 0;
        
        // Test 1: Reset Test
        $display("Test 1: Reset Test");
        rst_n = 0;
        wr_en = 0;
        rd_en = 0;
        data_in = 0;
        #100; // Longer reset period for synchronization
        rst_n = 1;
        #100;
        
        // Check reset values
        if (empty !== 1'b1 || full !== 1'b0) begin
            $display("ERROR: Reset test failed - empty=%b, full=%b", empty, full);
            error_count++;
        end else begin
            $display("PASS: Reset Test");
        end
        
        // Test 2: Basic Read-Write Test
        $display("Test 2: Basic Read-Write Test");
        write_count = 0;
        read_count = 0;
        
        // Write 8 data items
        for (int i = 0; i < 8; i++) begin
            @(negedge wr_clk);
            wr_en = 1;
            data_in = test_data[i];
            @(posedge wr_clk);
            #1;
            wr_en = 0;
            write_count++;
        end
        
        #200; // Longer wait for synchronization
        
        // Read 8 data items
        for (int i = 0; i < 8; i++) begin
            @(negedge rd_clk);
            rd_en = 1;
            @(posedge rd_clk);
            #2; // Wait for output to stabilize
            received_data[i] = data_out;
            if (data_out !== test_data[i]) begin
                $display("ERROR: Data mismatch at read %0d: expected=%h, got=%h", i, test_data[i], data_out);
                error_count++;
            end
            @(negedge rd_clk);
            rd_en = 0;
            read_count++;
        end
        
        if (error_count == 0) begin
            $display("PASS: Basic Read-Write Test");
        end
        
        // Test 3: Full Condition Test
        $display("Test 3: Full Condition Test");
        
        // Reset and start fresh
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;
        
        // Fill the FIFO
        for (int i = 0; i < DEPTH; i++) begin
            @(negedge wr_clk);
            wr_en = 1;
            data_in = test_data[i];
            @(posedge wr_clk);
            #1;
            wr_en = 0;
        end
        
        // Wait a few more cycles for full flag to update
        repeat (4) @(posedge wr_clk);
        #200; // Wait for synchronization
        
        // Check full flag
        if (full !== 1'b1) begin
            $display("ERROR: Full flag not asserted after %0d writes", DEPTH);
            error_count++;
        end
        
        // Try to write when full
        @(negedge wr_clk);
        wr_en = 1;
        data_in = 16'hFFFF;
        @(posedge wr_clk);
        #1;
        wr_en = 0;
        
        // Should not be able to write more data
        if (full !== 1'b1) begin
            $display("ERROR: Full condition violated");
            error_count++;
        end else begin
            $display("PASS: Full Condition Test");
        end
        
        // Test 4: Empty Condition Test
        $display("Test 4: Empty Condition Test");
        
        // Reset and start fresh
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;
        
        // Empty the FIFO
        for (int i = 0; i < DEPTH; i++) begin
            @(negedge rd_clk);
            rd_en = 1;
            @(posedge rd_clk);
            #2;
            @(negedge rd_clk);
            rd_en = 0;
        end
        
        #200; // Wait for synchronization
        
        // Check empty flag
        if (empty !== 1'b1) begin
            $display("ERROR: Empty flag not asserted");
            error_count++;
        end else begin
            $display("PASS: Empty Condition Test");
        end
        
        // Test 5: Almost-Full/Almost-Empty Threshold Test
        $display("Test 5: Almost-Full/Almost-Empty Threshold Test");
        
        // Reset and start fresh
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;
        
        // Write until almost full
        for (int i = 0; i < 10; i++) begin
            @(negedge wr_clk);
            wr_en = 1;
            data_in = test_data[i];
            @(posedge wr_clk);
            #1;
            wr_en = 0;
        end
        
        #200; // Wait for synchronization
        
        if (almost_full !== 1'b1) begin
            $display("ERROR: Almost-full flag not asserted at threshold 10");
            error_count++;
        end
        
        // Read until almost empty
        for (int i = 0; i < 7; i++) begin
            @(negedge rd_clk);
            rd_en = 1;
            @(posedge rd_clk);
            #2;
            @(negedge rd_clk);
            rd_en = 0;
        end
        
        #200; // Wait for synchronization
        
        if (almost_empty !== 1'b1) begin
            $display("ERROR: Almost-empty flag not asserted at threshold 3");
            error_count++;
        end else begin
            $display("PASS: Almost-Full/Almost-Empty Threshold Test");
        end
        
        // Test 6: Concurrent Read-Write Test
        $display("Test 6: Concurrent Read-Write Test");
        
        // Reset and start fresh
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;
        
        fork
            // Writer thread
            begin
                for (int i = 0; i < 12; i++) begin
                    @(negedge wr_clk);
                    wr_en = 1;
                    data_in = test_data[i];
                    @(posedge wr_clk);
                    #1;
                    wr_en = 0;
                    #20; // Delay between writes
                end
            end
            
            // Reader thread
            begin
                // Wait for first data to be available
                #100;
                for (int i = 0; i < 12; i++) begin
                    @(negedge rd_clk);
                    rd_en = 1;
                    @(posedge rd_clk);
                    #2;
                    if (data_out !== test_data[i]) begin
                        $display("ERROR: Concurrent test data mismatch at %0d: expected=%h, got=%h", i, test_data[i], data_out);
                        error_count++;
                    end
                    @(negedge rd_clk);
                    rd_en = 0;
                    #20; // Delay between reads
                end
            end
        join
        
        if (error_count == 0) begin
            $display("PASS: Concurrent Read-Write Test");
        end
        
        // Test 7: Edge Case Test
        $display("Test 7: Edge Case Test");
        
        // Reset
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;
        
        // Write 15 entries (one before full)
        for (int i = 0; i < 15; i++) begin
            @(negedge wr_clk);
            wr_en = 1;
            data_in = test_data[i];
            @(posedge wr_clk);
            #1;
            wr_en = 0;
        end
        
        #200; // Wait for synchronization
        
        if (full !== 1'b0 || almost_full !== 1'b1) begin
            $display("ERROR: Edge case - flags incorrect after 15 writes");
            error_count++;
        end
        
        // Write 16th entry (full)
        @(negedge wr_clk);
        wr_en = 1;
        data_in = test_data[15];
        @(posedge wr_clk);
        #1;
        wr_en = 0;
        
        // Wait a few more cycles for full flag to update
        repeat (4) @(posedge wr_clk);
        #200; // Wait for synchronization
        
        if (full !== 1'b1) begin
            $display("ERROR: Edge case - full flag not asserted");
            error_count++;
        end
        
        // Read 13 entries to reach almost-empty threshold (3 remaining)
        for (int i = 0; i < 13; i++) begin
            @(negedge rd_clk);
            rd_en = 1;
            @(posedge rd_clk);
            #2;
            @(negedge rd_clk);
            rd_en = 0;
        end
        
        #200; // Wait for synchronization
        
        if (almost_empty !== 1'b1) begin
            $display("ERROR: Edge case - almost empty flag not asserted");
            error_count++;
        end
        
        // Read all remaining entries (empty)
        for (int i = 0; i < 3; i++) begin
            @(negedge rd_clk);
            rd_en = 1;
            @(posedge rd_clk);
            #2;
            @(negedge rd_clk);
            rd_en = 0;
        end
        
        #200; // Wait for synchronization
        
        if (empty !== 1'b1) begin
            $display("ERROR: Edge case - empty flag not asserted");
            error_count++;
        end else begin
            $display("PASS: Edge Case Test");
        end
        
        // Final result
        if (error_count == 0) begin
            $display("TestSuccessed: All tests passed!");
        end else begin
            $display("TestFailed: %0d errors found", error_count);
        end
        
        $finish;
    end
    
    // Monitor
    initial begin
        $monitor("Time=%0t: wr_en=%b, rd_en=%b, data_in=%h, data_out=%h, full=%b, empty=%b, almost_full=%b, almost_empty=%b", 
                 $time, wr_en, rd_en, data_in, data_out, full, empty, almost_full, almost_empty);
    end

endmodule