module async_fifo #(
    parameter ALMOST_FULL_THRESHOLD = 14,
    parameter ALMOST_EMPTY_THRESHOLD = 2
) (
    input wire wr_clk,
    input wire rd_clk,
    input wire rst_n,
    input wire wr_en,
    input wire rd_en,
    input wire [15:0] data_in,
    output reg [15:0] data_out,
    output reg full,
    output reg empty,
    output reg almost_full,
    output reg almost_empty
);

    // FIFO depth and pointer parameters
    localparam DEPTH = 16;
    localparam ADDR_WIDTH = 4;
    localparam PTR_WIDTH = ADDR_WIDTH + 1;
    
    // Memory array
    reg [15:0] mem [0:DEPTH-1];
    
    // Pointers in binary and gray code
    reg [PTR_WIDTH-1:0] wr_ptr_bin, rd_ptr_bin;
    reg [PTR_WIDTH-1:0] wr_ptr_gray, rd_ptr_gray;
    
    // Synchronized pointers
    reg [PTR_WIDTH-1:0] wr_ptr_gray_sync, rd_ptr_gray_sync;
    reg [PTR_WIDTH-1:0] wr_ptr_gray_sync2, rd_ptr_gray_sync2;
    wire [PTR_WIDTH-1:0] wr_ptr_bin_sync, rd_ptr_bin_sync;
    
    // Binary to Gray conversion
    function [PTR_WIDTH-1:0] bin2gray;
        input [PTR_WIDTH-1:0] bin;
        bin2gray = bin ^ (bin >> 1);
    endfunction
    
    // Gray to Binary conversion
    function [PTR_WIDTH-1:0] gray2bin;
        input [PTR_WIDTH-1:0] gray;
        reg [PTR_WIDTH-1:0] bin;
        integer i;
        begin
            bin[PTR_WIDTH-1] = gray[PTR_WIDTH-1];
            for (i = PTR_WIDTH-2; i >= 0; i = i - 1) begin
                bin[i] = bin[i+1] ^ gray[i];
            end
            gray2bin = bin;
        end
    endfunction
    
    // Convert synchronized Gray codes back to binary
    assign wr_ptr_bin_sync = gray2bin(wr_ptr_gray_sync2);
    assign rd_ptr_bin_sync = gray2bin(rd_ptr_gray_sync2);
    
    // Two-stage synchronizers
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr_gray_sync <= {PTR_WIDTH{1'b0}};
            wr_ptr_gray_sync2 <= {PTR_WIDTH{1'b0}};
        end else begin
            wr_ptr_gray_sync <= wr_ptr_gray;
            wr_ptr_gray_sync2 <= wr_ptr_gray_sync;
        end
    end
    
    always @(posedge wr_clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr_gray_sync <= {PTR_WIDTH{1'b0}};
            rd_ptr_gray_sync2 <= {PTR_WIDTH{1'b0}};
        end else begin
            rd_ptr_gray_sync <= rd_ptr_gray;
            rd_ptr_gray_sync2 <= rd_ptr_gray_sync;
        end
    end
    
    // Write pointer and memory control
    always @(posedge wr_clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr_bin <= {PTR_WIDTH{1'b0}};
            wr_ptr_gray <= {PTR_WIDTH{1'b0}};
        end else if (wr_en && !full) begin
            mem[wr_ptr_bin[ADDR_WIDTH-1:0]] <= data_in;
            wr_ptr_bin <= wr_ptr_bin + 1'b1;
            wr_ptr_gray <= bin2gray(wr_ptr_bin + 1'b1);
        end
    end
    
    // Read pointer and output control
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr_bin <= {PTR_WIDTH{1'b0}};
            rd_ptr_gray <= {PTR_WIDTH{1'b0}};
            data_out <= 16'b0;
        end else if (rd_en && !empty) begin
            data_out <= mem[rd_ptr_bin[ADDR_WIDTH-1:0]];
            rd_ptr_bin <= rd_ptr_bin + 1'b1;
            rd_ptr_gray <= bin2gray(rd_ptr_bin + 1'b1);
        end
    end
    
    // Flag generation in write domain
    always @(posedge wr_clk or negedge rst_n) begin
        if (!rst_n) begin
            full <= 1'b0;
            almost_full <= 1'b0;
        end else begin
            // Full when next write would make write pointer equal to synchronized read pointer
            if (wr_en && !full) begin
                full <= ((wr_ptr_bin + 1'b1) == {~rd_ptr_bin_sync[PTR_WIDTH-1], rd_ptr_bin_sync[ADDR_WIDTH-1:0]});
            end else begin
                full <= (wr_ptr_bin == {~rd_ptr_bin_sync[PTR_WIDTH-1], rd_ptr_bin_sync[ADDR_WIDTH-1:0]});
            end
            
            // Calculate FIFO count for almost_full
            if (wr_ptr_bin[PTR_WIDTH-1] == rd_ptr_bin_sync[PTR_WIDTH-1]) begin
                almost_full <= ((wr_ptr_bin[ADDR_WIDTH-1:0] - rd_ptr_bin_sync[ADDR_WIDTH-1:0]) >= ALMOST_FULL_THRESHOLD);
            end else begin
                almost_full <= ((DEPTH - rd_ptr_bin_sync[ADDR_WIDTH-1:0] + wr_ptr_bin[ADDR_WIDTH-1:0]) >= ALMOST_FULL_THRESHOLD);
            end
        end
    end
    
    // Flag generation in read domain
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            empty <= 1'b1;
            almost_empty <= 1'b1;
        end else begin
            // Empty when read pointer equals synchronized write pointer
            empty <= (rd_ptr_bin == wr_ptr_bin_sync);
            
            // Calculate FIFO count for almost_empty
            if (wr_ptr_bin_sync[PTR_WIDTH-1] == rd_ptr_bin[PTR_WIDTH-1]) begin
                almost_empty <= ((wr_ptr_bin_sync[ADDR_WIDTH-1:0] - rd_ptr_bin[ADDR_WIDTH-1:0]) <= ALMOST_EMPTY_THRESHOLD);
            end else begin
                almost_empty <= ((DEPTH - rd_ptr_bin[ADDR_WIDTH-1:0] + wr_ptr_bin_sync[ADDR_WIDTH-1:0]) <= ALMOST_EMPTY_THRESHOLD);
            end
        end
    end
    
    // Memory initialization for simulation
    initial begin
        for (int i = 0; i < DEPTH; i = i + 1) begin
            mem[i] = 16'b0;
        end
    end

endmodule