/*
This is a multiplier for floating point
- Support IEEE 754 Half-Precision Floating-Point Format (FP16):
	- Handle all special cases (zero, infinity, NaN) as specified by IEEE 754.
	- Ensure correct rounding to the nearest even value.
- Use valid and ready signals for handshake. When valid is high, the input operands A and B are ready. When ready is high, the result C is valid.
*/
module fp_multiplier (
    input clk,
    input rst_n,
    input [15:0] A,
    input [15:0] B,
    input Ready,
    output reg [15:0] C,
    output reg Valid
);