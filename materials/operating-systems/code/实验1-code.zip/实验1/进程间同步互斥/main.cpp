#include <iostream>
#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <queue>
#include <algorithm>
#include <Windows.h>
#include <string>

using namespace std;

class Customer {
private:
	int id;							// 顾客序号
	int num;						// 取号
	int enter_time;					// 进入银行时间
	int service_time;				// 需要服务的时间
	int start_time;					// 开始服务时间
	int leave_time;					// 离开银行时间
	int server_id;					// 服务柜员号

public:
	Customer(int id = 0, int enter_time = 0, int service_time = 0)
		: id(id), enter_time(enter_time), service_time(service_time),
		num(-1), start_time(0), leave_time(0), server_id(0) {}

	//private信息接口
	int	get_id() const{	return id;}
	int get_num() const { return num;}
	int get_enter_time() const { return enter_time; }
	int get_service_time() const { return service_time; }
	int get_start_time() const { return start_time; }
	int get_leave_time() const { return leave_time; }
	int get_server_id() const { return server_id; }


	//设置服务接口
	void set_id(int idx) { id = idx; }
	void set_num(int number) { num = number; }
	void set_enter_time(int t) { enter_time = t; }
	void set_service_time(int t) { service_time = t; }
	void set_start_time(int t) { start_time = t; }
	void set_leave_time(int t) { leave_time = t; }
	void set_server_id(int id) { server_id = id; }
};

// 全局共享资源（保持不变）
int current_num = 0;                      // 当前最大取号数（用于生成唯一号码）
std::mutex mtx_num;                     // 保护取号操作的互斥锁
std::queue<Customer> wait_queue;          // 等待服务的顾客队列
std::mutex mtx_queue;                   // 保护队列操作的互斥锁

// 同步变量
int customer_num = 0;					  // 等待服务的顾客数量（替代customer_waiting信号量）
std::condition_variable cv_customer;	  // 顾客到达的条件变量（通知柜员）
int available_servers;					  // 可用柜员数量
std::condition_variable cv_server;		  // 柜员空闲的条件变量 (通知顾客)

// 顾客到达事件处理函数
void customer_enter(Customer& customer) {
	// 取号（互斥操作，确保号码唯一）
	{
		std::lock_guard<std::mutex> lock(mtx_num);
		customer.set_num(++current_num); 
	}

	// 等待可用柜员（无空闲柜员时阻塞）
	{
		std::unique_lock<std::mutex> lock(mtx_queue);  
		cv_server.wait(lock, [&] { return available_servers > 0; });  // 等待柜员空闲
		available_servers--; 
	}

	// 加入等待队列（互斥操作）
	{
		std::lock_guard<std::mutex> lock(mtx_queue);
		wait_queue.push(customer);
		customer_num++;
	}

	// 通知有新顾客等待
	cv_customer.notify_one();		// 唤醒一个柜员
}

void server(int server_id) {
	thread_local int last_leave_time = 0;  // 线程局部变量，记录该柜员上次服务结束时间

	while (true) {
		//  等待有顾客需要服务
		Customer customer;
		{
			std::unique_lock<std::mutex> lock(mtx_queue);
			cv_customer.wait(lock, [&] { return customer_num > 0; });  // 等待顾客到达，无顾客时阻塞
			customer = wait_queue.front();
			wait_queue.pop();
			customer_num--; 
		}

		// 计算服务时间
		int start_time = customer.get_enter_time() > last_leave_time ? customer.get_enter_time() : last_leave_time;
		int leave_time = start_time + customer.get_service_time();

		// 记录服务信息
		customer.set_start_time(start_time);
		customer.set_leave_time(leave_time);
		customer.set_server_id(server_id);

		// 输出结果
		cout << "-------------------------------------------------------" << endl;
		cout << "The " << customer.get_id() << " customer come! His requiring service time is: " << customer.get_service_time() << endl;
		cout << "The enter time: " << customer.get_enter_time() << endl;
		cout << "The service start time: " << customer.get_start_time() << endl;
		cout << "The leave time: " << customer.get_leave_time() << endl;
		cout << "The server's id: " << customer.get_server_id() << endl;

		// 模拟服务耗时
		std::this_thread::sleep_for(std::chrono::seconds(customer.get_service_time()));

		// 服务完成，释放柜员
		{
			std::lock_guard<std::mutex> lock(mtx_queue);
			available_servers++;  
		}
		cv_server.notify_one();  // 通知顾客有柜员空闲

		// 更新柜员空闲时间
		last_leave_time = leave_time;
	}
}


int main() { 
	int server_num = 2;					//柜员数量
	string test_data_file = "C:/Users/local-user/Desktop/test.txt";


	//从文件中读取顾客的数据
	std::vector<Customer> customers;
	ifstream file;
	string line;
	file.open(test_data_file, std::ios::in);
	while (getline(file, line))
	{
		istringstream iss(line);
		int id_customer, enter_time, service_time;
		iss >> id_customer >> enter_time >> service_time;
		customers.push_back(Customer(id_customer, enter_time, service_time));
	}

	std::sort(customers.begin(), customers.end(),
		[](const Customer& a, const Customer& b) {
			return a.get_enter_time() < b.get_enter_time();
		});

	std::vector<std::thread> servers;
	for (int i = 0; i < server_num; i++) {
		servers.emplace_back(server, i + 1);
	}

	int last_enter_time = 0;
	available_servers = server_num;   //初始化

	for (auto& customer : customers) {
		int interval = customer.get_enter_time() - last_enter_time;
		if (interval > 0) {
			std::this_thread::sleep_for(std::chrono::seconds(interval));
		}
		last_enter_time = customer.get_enter_time();
		customer_enter(customer);
	}

	for (auto& t : servers) {
		t.join();
	}

	return 0;
}