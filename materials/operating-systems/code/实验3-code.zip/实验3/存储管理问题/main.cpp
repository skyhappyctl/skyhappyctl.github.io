#include <iostream>
#include <string>
#include <climits>

using namespace std;

enum Status {FREE, ALLOCATED};

// 内存分区节点结构体
struct Partition {
    int start;      // 起始地址
    int size;       // 分区大小
    Status status;  // 分区状态
    Partition* next;// 下一个分区指针

    Partition(int s, int size, Status status)
        : start(s), size(size), status(status), next(nullptr) {
    }
};


class MemoryManageUnit {
private:
    int total_size;             //内存总大小
    Partition* head;            //表头
    Partition* last_used;       //下次适配算法的起始位置

    void insertbehind(Partition* prev, Partition* newNode) {
        newNode->next = prev->next;
        prev->next = newNode;
    }

    void deletenode(Partition* prev, Partition* target) {
        prev->next = target->next;
        delete target;
    }

    // 合并相邻空闲分区
    void mergeFree(Partition* node) {
        //合并后驱空间分区
        while (node->next && node->next->status == FREE) {
            node->size += node->next->size;
            Partition* temp = node->next;
            node->next = temp->next;
            delete temp;
        }
        //合并前驱空间分区
        Partition* current = head;
        Partition* prev = nullptr;
        while (current) {
            if (current == node && prev && prev->status == FREE) {
                prev->size += node->size;
                prev->next = node->next;
                delete node;
                node = prev; // 更新为合并后的前驱节点
            }
            prev = current;
            current = current->next;
        }
    }

    // 首次适配算法，找到合适的空闲区就分配
    Partition* firstFit(int size) {
        Partition* current = head;
        while (current) {
            if (current->status == FREE && current->size >= size) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    // 下次适配算法，从上次分配的位置开始查找下一个满足要求的空闲区
    Partition* nextFit(int size) {
        Partition* current = last_used->next ? last_used->next : head;
        while (true) {
            if (current->status == FREE && current->size >= size) {
                last_used = current; // 更新上次结束位置
                return current;
            }
            if (current == last_used) break; // 遍历完所有节点
            current = current->next;
        }
        return nullptr;
    }

    // 最佳适配算法，找到大小最合适（最小的）的空闲区
    Partition* bestFit(int size) {
        Partition* best = nullptr;
        int minSize = INT_MAX;
        Partition* current = head;
        while (current) {
            if (current->status == FREE && current->size >= size) {
                if (current->size < minSize) {
                    minSize = current->size;
                    best = current;
                }
            }
            current = current->next;
        }
        return best;
    }

    // 最坏适配算法，找到最大的空闲区分配
    Partition* worstFit(int size) {
        Partition* worst = nullptr;
        int maxSize = -1;
        Partition* current = head;
        while (current) {
            if (current->status == FREE && current->size >= size) {
                if (current->size > maxSize) {
                    maxSize = current->size;
                    worst = current;
                }
            }
            current = current->next;
        }
        return worst;
    }

public: 
    //构造函数
    MemoryManageUnit(int total_size = 1024) : total_size(total_size) {
        head = new Partition(0, total_size, FREE);
        last_used = head;
    }

    //析构函数
    ~MemoryManageUnit() {
        Partition* current = head;
        while (current) {
            Partition* temp = current;
            current = current->next;
            delete temp;
        }
    }

    //内存分配接口
    bool allocate(int size, const string& algorithm) {
        if (size <= 0) {
            cout << "错误：申请内存大小必须大于0!" << endl;
            return false;
        }

        Partition* found = nullptr;                             //找到合适的空闲分区
        if (algorithm == "first_fit") found = firstFit(size);
        else if (algorithm == "next_fit") found = nextFit(size);
        else if (algorithm == "best_fit") found = bestFit(size);
        else if (algorithm == "worst_fit") found = worstFit(size);
        else {
            cout << "错误：未知的分配算法!" << endl;
            return false;
        }

        if (!found) {
            cout << "错误：无足够空间分配! " << size << endl;
            return false;
        }

        // 分割空闲分区
        if (found->size > size) {
            Partition* newPartition = new Partition(found->start + size, found->size - size, FREE);
            insertbehind(found, newPartition);
            found->size = size;
        }

        found->status = ALLOCATED;
        return true;
    }

    // 内存释放接口
    bool free(int start) {
        Partition* current = head;
        Partition* prev = nullptr;
        while (current) {
            if (current->status == ALLOCATED && current->start == start) {
                current->status = FREE;
                mergeFree(current); // 合并相邻空闲分区
                return true;
            }
            prev = current;
            current = current->next;
        }
        cout << "错误：未找到起始地址为 " << start << " 的已分配分区!" << endl;
        return false;
    }

    // 可视化内存状态函数
    void visualize() {
        cout << "\n内存使用情况（地址从低到高）：" << endl;
        cout << string(50, '=') << endl;
        Partition* current = head;
        while (current) {
            string status = (current->status == ALLOCATED) ? "已分配" : "空闲";
            cout << "地址：" << current->start << "-"
                << current->start + current->size - 1 << " | "
                << "大小：" << current->size << "  KB" << " | 状态：" << status << endl;
            current = current->next;
        }
        cout << string(50, '=') << "\n" << endl;
    }


};

void menu(MemoryManageUnit mmu)
{
    int choice;
    while (true) {
        cout << "\n===================== 内存管理菜单 =====================" << endl;
        cout << "1. 分配内存（Allocate memory）" << endl;
        cout << "2. 释放内存(Deallocate memory)" << endl;
        cout << "3. 显示内存分配情况(Display memory allocation status)" << endl;
        cout << "4. 退出(Exit)" << endl;
        cout << "请输入选项（1-4）: ";

        if (cin >> choice) {
            if (choice >= 1 && choice <= 4) {
                switch (choice) {
                case 1: { // 内存分配
                    int size;
                    string algo;
                    cout << "\n请输入要分配的内存大小（默认单位为KB）: ";
                    cin >> size;
                    cout << "请选择分配算法（first_fit/next_fit/best_fit/worst_fit）: ";
                    cin >> algo;
                    bool flag = mmu.allocate(size, algo);
                    if(flag)
                    {
                        cout << "已分配成功！当前的内存分配情况为：" << endl;
                        mmu.visualize();
                        cin.clear();
                    }
                    else
                    {
                        cout << "出现异常错误，分配失败！" << endl;
                        cin.clear();
                    }
                    break;
                }
                case 2: { // 内存释放
                    int start;
                    cout << "\n请输入要释放分区的起始地址: ";
                    cin >> start;
                    bool flag = mmu.free(start);
                    if (flag)
                    {
                        cout << "已释放成功！当前的内存分配情况为：" << endl;
                        mmu.visualize();
                        cin.clear();
                    }
                    else
                    {
                        cout << "出现异常错误，释放失败！" << endl;
                        cin.clear();
                    }
                    break;
                }
                case 3: // 显示状态
                    mmu.visualize();
                    cin.clear();
                    break;
                case 4: // 退出程序
                    cout << "感谢使用，程序已退出！" << endl;
                    cin.clear();
                    return;
                }
            }
        }
        else {
            // 清除输入错误状态
            cin.clear();
            // 忽略输入缓冲区中的剩余字符
            cin.ignore(INT_MAX, '\n');
            cout << "输入无效，请重新输入1-4的数字！" << endl;
        }
    }
}

int main() {
    
    int init_mem_size;
    cout << "初始化内存大小（默认单位为KB)：";
    cin >> init_mem_size;
    MemoryManageUnit mmu(init_mem_size);   //默认以KB为内存单位
    menu(mmu);
	return 0;
}