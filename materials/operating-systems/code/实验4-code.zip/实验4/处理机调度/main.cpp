#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

// 测试用例结构体
struct TestCase {
    int processNum;      
    int resourceNum;     
    vector<int> Available;  
    vector<vector<int>> Matrix_MaxNeed;    
    vector<vector<int>> Matrix_Allocation; 
    int pid;             
    vector<int> request;  
};

class Banker {
private:
    int processNum;    // 进程数量
    int resourceNum;   // 资源种类数量
    vector<int> Available;       // 可用资源向量
    vector<vector<int>> Matrix_MaxNeed;     // 最大需求矩阵
    vector<vector<int>> Matrix_Allocation;// 已分配矩阵
    vector<vector<int>> Matrix_Need;    // 需求矩阵

    vector<int> safetyCheck()           //安全性检查函数，模拟实现动态资源分配
    {
        vector<int> safeSequence_final;


        for (int ii = 0; ii < processNum; ii++)
        {
            vector<int> Work = Available;                       //工作向量，模拟分配时的可用资源
            vector<bool> Finish(processNum, false);             //记录模拟运行的进程是否完成，初始全都未完成
            vector<int> safeSequence;

            bool flag = true;
            for (int j = 0; j < resourceNum; j++)
            {
                if (Work[j] < Matrix_Need[ii][j])            //超出了限制
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                for (int j = 0; j < resourceNum; j++)
                    Work[j] += Matrix_Allocation[ii][j];
                safeSequence.push_back(ii);
                Finish[ii] = true;
            }
            else
                continue;

            bool found = true;     //?
            for (int i = 0; i < processNum; i++)
            {
                if (!Finish[i])
                {
                    bool canallocate = true;
                    for (int j = 0; j < resourceNum; j++)
                    {
                        if (Work[j] < Matrix_Need[i][j])            //超出了限制
                        {
                            canallocate = false;
                            break;
                        }
                    }

                    if (canallocate)
                    {
                        for (int j = 0; j < resourceNum; j++)
                            Work[j] += Matrix_Allocation[i][j];
                        safeSequence.push_back(i);
                        Finish[i] = true;
                        i = -1;
                    }
                    
                }
           
                }
                for (bool f : Finish) {
                    if (!f) {
                        //cout << "不存在安全序列，此时系统不安全！" << endl;
                        found = false;
                    }
                if (!found)
                    safeSequence_final = {};
                else
                {
                    safeSequence_final = safeSequence;
                    break;
                }
            }
        }

        return safeSequence_final;
    }

public:
    Banker(int p, int r, vector<int> av,
        vector<vector<int>> m, vector<vector<int>> a)
        : processNum(p), resourceNum(r), Available(av), Matrix_MaxNeed(m), Matrix_Allocation(a) {

        // 计算Need矩阵：Need = MaxNeed - Allocation
        Matrix_Need.resize(processNum, vector<int>(resourceNum));
        for (int i = 0; i < processNum; i++) {
            for (int j = 0; j < resourceNum; j++) {
                Matrix_Need[i][j] = Matrix_MaxNeed[i][j] - Matrix_Allocation[i][j];
                if (Matrix_Need[i][j] < 0) {
                    cerr << "错误：最大需求小于已分配资源！进程" << i << " 资源" << j << " !" << endl;
                    exit(1);
                }
            }
        }
    }

    // 处理资源请求函数，检测合法性
    bool requestResource(int pid, vector<int> request, vector<string>& log) {
        for (int j = 0; j < resourceNum; j++) {
            if (request[j] < 0) {
                log.push_back("错误：请求不能为负数！");
                return false;
            }
            if (request[j] > Available[j]) {
                log.push_back("错误：资源不足，需等待资源释放！");
                return false;
            }
            if (request[j] > Matrix_Need[pid][j]) {
                log.push_back("错误：请求超过需求！");
                return false;
            }

        }

        //保存现场
        vector<int> Available_copy = Available;
        vector<vector<int>> Matrix_Allocation_copy = Matrix_Allocation;
        vector<vector<int>> Matrix_Need_copy = Matrix_Need;

        // 模拟资源分配
        for (int j = 0; j < resourceNum; j++) {
            Available[j] -= request[j];
            Matrix_Allocation[pid][j] += request[j];
            Matrix_Need[pid][j] -= request[j];
        }

        // 输出临时状态
        log.push_back("\n模拟分配后的临时状态：");
        log.push_back("可用资源向量: " + vec2string(Available));
        log.push_back("已分配矩阵:\n " + matrix2string(Matrix_Allocation));
        log.push_back("需求矩阵:\n " + matrix2string(Matrix_Need));

        // 安全性检查
        vector<int> safeSequence = safetyCheck();
        if (!safeSequence.empty()) {                                                 //证明有安全序列
            log.push_back("\n系统处于安全状态！安全序列为: " + seq2string(safeSequence));
                return true;
        }
        else {
            log.push_back("\n无安全序列存在，系统不安全，回滚分配...");
            // 恢复现场
            Available = Available_copy;
            Matrix_Allocation = Matrix_Allocation_copy;
            Matrix_Need = Matrix_Need_copy;
            return false;
        }
    }

    string seq2string(vector<int> seq) {
        string res;
        for (size_t i = 0; i < seq.size(); i++) {
            res += "P" + to_string(seq[i]);
            if (i != seq.size() - 1) res += " -> ";
        }
        return res;
    }

    string vec2string(vector<int> vec)
    {
        string s = "[";
        for (size_t i = 0; i < vec.size(); i++) {
            s += to_string(vec[i]);
            if (i != vec.size() - 1) s += ", ";
        }
        s += "]";
        return s;
    }

    string matrix2string(vector<vector<int>>matrix)
    {
        string s;
        for (size_t i = 0; i < matrix.size(); i++) {
            s += "P" + to_string(i) + ": " + vec2string(matrix[i]) + "\n";
        }
        return s;
    }

    void displayState()
    {
        cout << "\n================当前系统状态================：\n";
        cout << "可用资源向量: " << vec2string(Available) << endl;
        cout << "最大需求矩阵:\n" << matrix2string(Matrix_MaxNeed);
        cout << "已分配矩阵:\n" << matrix2string(Matrix_Allocation);
        cout << "需求矩阵:\n" << matrix2string(Matrix_Need);
    }

};

// 从文件读取测试用例的函数
vector<TestCase> readTestCasesFromFile(const string& filename, vector<string>& log) {
    vector<TestCase> testCases;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "错误：无法打开测试用例文件 " << filename << endl;
        exit(1);
    }

    string line;
    while (getline(file, line)) {
        if (line.empty() || line.substr(0, 4) == "Test") continue; // 跳过空行和测试用例标题

        TestCase tc;
        // 读取进程数量
        if (line.substr(0, 11) == "ProcessNum:") {
            istringstream iss(line.substr(11));
            iss >> tc.processNum;
        }
        // 读取资源种类数
        getline(file, line);
        if (line.substr(0, 12) == "ResourceNum:") {
            istringstream iss(line.substr(12));
            iss >> tc.resourceNum;
        }
        // 读取可用资源向量
        getline(file, line);
        if (line.substr(0, 10) == "Available:") {
            istringstream iss(line.substr(10));
            int val;
            while (iss >> val) {
                tc.Available.push_back(val);
            }
        }
        // 读取最大需求矩阵
        getline(file, line);
        if (line == "Max:") {
            for (int i = 0; i < tc.processNum; i++) {
                getline(file, line);
                istringstream iss(line);
                vector<int> row;
                int val;
                while (iss >> val) {
                    row.push_back(val);
                }
                tc.Matrix_MaxNeed.push_back(row);
            }
        }
        // 读取已分配矩阵
        getline(file, line);
        if (line == "Allocation:") {
            for (int i = 0; i < tc.processNum; i++) {
                getline(file, line);
                istringstream iss(line);
                vector<int> row;
                int val;
                while (iss >> val) {
                    row.push_back(val);
                }
                tc.Matrix_Allocation.push_back(row);
            }
        }
        // 读取请求信息
        getline(file, line);
        if (line.substr(0, 8) == "Request:") {
            istringstream iss(line.substr(8));
            iss >> tc.pid;  // 第一个数是进程ID
            int val;
            while (iss >> val) {
                tc.request.push_back(val);
            }
        }

        testCases.push_back(tc);
        getline(file, line); // 读取测试用例分隔空行
    }
    return testCases;
}

// 通用测试执行函数
void runTestCase(const TestCase& tc, vector<string>& log) {
    cout << "\n================ 执行测试用例 ================\n";
    Banker banker(tc.processNum, tc.resourceNum, tc.Available, tc.Matrix_MaxNeed, tc.Matrix_Allocation);
    banker.displayState();

    bool result = banker.requestResource(tc.pid, tc.request, log);

    cout << "\n操作日志：\n";
    for (string s : log) cout << s << endl;
    cout << "最终分配结果：" << (result ? "成功" : "失败") << endl;
    if (result) banker.displayState();
    log.clear();
}

int main() {

    string test_data_file = "C:/Users/local-user/Desktop/test4.txt";
    vector<string> log;

    vector<TestCase> testCases = readTestCasesFromFile(test_data_file, log);
    for (const auto& tc : testCases) {
        runTestCase(tc, log);
    }

	return 0;
}
